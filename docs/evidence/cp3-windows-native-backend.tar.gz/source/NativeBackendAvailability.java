package com.holdmyspot.codexunleashed.scheduler;

import buildbarn.runner.RunnerOuterClass.RunRequest;
import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.AclEntryPermission;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.AclFileAttributeView;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Executes backend availability with genuine pinned native daemons and the accepted shared Runner.
 * This fixture never admits actions and cannot establish native Bazel action acceptance.
 */
public final class NativeBackendAvailability
{
    /** Prevents construction of the native entry point. */
    private NativeBackendAvailability() {}

    /**
     * Starts, authenticates and collects all original backend processes on this actual release host.
     * @param arguments exact installed product directory and absent owned evidence directory
     * @throws Exception if preparation, authenticated readiness or original collection fails
     */
    public static void main(String[] arguments) throws Exception
    {
        if (arguments.length != 2) throw new IllegalArgumentException("Expected product and absent evidence roots");
        Path products = Path.of(arguments[0]).toAbsolutePath().normalize();
        Path evidence = Path.of(arguments[1]).toAbsolutePath().normalize();
        Files.createDirectory(evidence);
        Path root = evidence.resolve("invocation");
        privateRoot(root);
        try (DefaultToolingScope scope = new DefaultToolingScope())
        {
            BazelNativeBackend.NativeTarget target = BazelNativeBackend.NativeTarget.forHost(
                System.getProperty("os.name"), System.getProperty("os.arch"));
            BazelBackendCredentials.NativeAuthority authority = BazelBackendCredentials.nativeAuthority(scope, root);
            BazelNativeBackend.ValidatedDistribution distribution = BazelNativeBackend.validateDistribution(scope,
                target, products, authority);
            authority.createDirectory(root.resolve("worker-builds"));
            Path keytool = Path.of(System.getProperty("java.home"), "bin", "keytool" + target.suffix());
            BazelBackendCredentials credentials = BazelBackendCredentials.generate(root.resolve("credentials"), keytool,
                authority);
            CompletableFuture<Void> ready = new CompletableFuture<>();
            AtomicInteger readinessCount = new AtomicInteger();
            List<String> readinessPaths = java.util.Collections.synchronizedList(new ArrayList<>());
            Path workerRoot = root.resolve("worker-builds");
            BazelRunner<BazelRunner.Admission> runner = new BazelRunner<>(new BazelRunner.Boundary<>()
            {
                @Override public void validateRoot() throws IOException { authority.requireDirectory(workerRoot); }
                @Override public void checkReadiness(String path) throws IOException
                {
                    authority.requireDirectory(workerRoot);
                    Path relative = Path.of(path);
                    if (relative.isAbsolute() || !relative.normalize().equals(relative) || relative.toString().isEmpty())
                        throw new IOException("Worker readiness is not a normalized relative native path: " + path);
                    Path current = workerRoot;
                    for (Path component : relative)
                    {
                        if (component.toString().equals("..") || component.toString().equals("."))
                            throw new IOException("Worker readiness escapes native root");
                        current = current.resolve(component);
                        if (!Files.isDirectory(current, LinkOption.NOFOLLOW_LINKS))
                            throw new IOException("Worker readiness directory absent: " + current);
                        authority.identity(current);
                    }
                    readinessPaths.add(path);
                    readinessCount.incrementAndGet();
                    ready.complete(null);
                }
                @Override public BazelRunner.Admission admit(RunRequest request) throws IOException
                {
                    throw new IOException("Backend availability fixture does not admit actions");
                }
            }, new BazelRunner.Credentials(credentials.certificateAuthority(), credentials.serverCertificate(),
                credentials.serverKey(), credentials.workerCertificate()));
            List<ProcessDaemon> daemons = new ArrayList<>();
            BazelNativeBackend backend = null;
            Map<String, Object> receipt = new LinkedHashMap<>();
            Throwable failure = null;
            try
            {
                runner.start();
                BazelNativeBackend.WorkerIdentity identity = target.goOperatingSystem().equals("windows") ?
                    new BazelNativeBackend.WindowsWorkerIdentity() : new BazelNativeBackend.PosixWorkerIdentity(
                    ((Number) Files.getAttribute(root, "unix:uid")).intValue(),
                    ((Number) Files.getAttribute(root, "unix:gid")).intValue());
                BazelNativeBackend.PlatformOwner owner = new BazelNativeBackend.PlatformOwner()
                {
                    @Override public BazelBackendCredentials.Protection protection() { return authority; }
                    @Override public BazelNativeBackend.WorkerIdentity workerIdentity() { return identity; }
                    @Override public BazelNativeBackend.Daemon launch(Path executable, Path configuration, Path log,
                        Path workingDirectory, Map<String, String> environment) throws IOException
                    {
                        ProcessBuilder builder = new ProcessBuilder(executable.toString(), configuration.toString())
                            .directory(workingDirectory.toFile()).redirectErrorStream(true).redirectOutput(log.toFile());
                        builder.environment().putAll(environment);
                        ProcessDaemon daemon = new ProcessDaemon(builder.start());
                        daemons.add(daemon);
                        return daemon;
                    }
                };
                BazelNativeBackend.Configuration configuration = new BazelNativeBackend.Configuration(distribution,
                    root, runner.endpoint(), credentials, 1, 67108864, 67108864,
                    BazelNativeBackend.CachePolicy.ACCEPT_CACHED, ready, runner::close);
                backend = BazelNativeBackend.start(scope, configuration, owner);
                backend.requireAlive();
                if (readinessCount.get() == 0 || daemons.size() != 3)
                    throw new IOException("Authentic shared Runner readiness or complete native daemon set absent");
                for (Path credential : credentials.paths()) authority.requireFile(credential);
                receipt.put("availability", "passed");
            }
            catch (Throwable problem)
            {
                failure = problem;
                receipt.put("availability", "failed");
                receipt.put("failure", problem.toString());
                if (problem instanceof BazelNativeBackend.AcquisitionFailure partial) backend = partial.backend();
            }
            finally
            {
                try
                {
                    if (backend != null) backend.close();
                    else
                    {
                        runner.close();
                        for (ProcessDaemon daemon : daemons.reversed()) daemon.close();
                    }
                    receipt.put("nativeCollection", "passed");
                }
                catch (Throwable cleanup)
                {
                    receipt.put("nativeCollection", "failed: " + cleanup);
                    if (failure == null) failure = cleanup;
                    else failure.addSuppressed(cleanup);
                }
                receipt.put("target", target.triple());
                receipt.put("os", System.getProperty("os.name"));
                receipt.put("architecture", System.getProperty("os.arch"));
                receipt.put("java", Runtime.version().toString());
                receipt.put("manifestSha256", distribution.manifestHash());
                receipt.put("authenticatedReadinessCount", readinessCount.get());
                receipt.put("authenticatedReadinessPaths", List.copyOf(readinessPaths));
                receipt.put("daemons", daemons.stream().map(ProcessDaemon::receipt).toList());
                receipt.put("actionAcceptance", "unrun; availability fixture rejects every action");
                Files.writeString(evidence.resolve("receipt.json"), scope.getJsonMapper().writerWithDefaultPrettyPrinter()
                    .writeValueAsString(receipt));
            }
            if (failure instanceof Exception problem) throw problem;
            if (failure instanceof Error problem) throw problem;
        }
    }

    /**
     * Creates an empty root with owner-only native permissions before creating credential material.
     * @param path absent invocation root under the owned fixture directory
     * @throws IOException if filesystem-native permissions cannot be established
     */
    private static void privateRoot(Path path) throws IOException
    {
        if (Files.getFileAttributeView(path.getParent(), PosixFileAttributeView.class) != null)
            Files.createDirectory(path, PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rwx------")));
        else
        {
            Files.createDirectory(path);
            AclFileAttributeView view = Files.getFileAttributeView(path, AclFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
            if (view == null) throw new IOException("No native private-root ACL view");
            view.setAcl(List.of(AclEntry.newBuilder().setType(AclEntryType.ALLOW).setPrincipal(view.getOwner())
                .setPermissions(EnumSet.allOf(AclEntryPermission.class)).build()));
        }
    }

    /**
     * Retains each actual original JDK process through its genuine wait.
     * The configured external Runner owns no actions in this availability gate. Unexpected daemon descendants
     * cause retained cleanup failure instead of a false assertion that their native ownership was collected.
     */
    private static final class ProcessDaemon implements BazelNativeBackend.Daemon
    {
        /** Original process object, never reconstructed from a reused PID. */
        private final Process process;
        /** Authentic original exit status after collection. */
        private Integer collected;

        /**
         * Retains an acquired original daemon before the next native acquisition.
         * @param process actual original native daemon
         */
        private ProcessDaemon(Process process) { this.process = process; }
        @Override public boolean isAlive() { return process.isAlive(); }
        @Override public long exitValue() { return process.exitValue(); }
        @Override public CompletableFuture<Long> onExit()
        {
            return process.onExit().thenApply(original -> (long) original.exitValue());
        }
        @Override public synchronized void close() throws IOException
        {
            if (collected != null) return;
            List<ProcessHandle> helpers = process.descendants().filter(ProcessHandle::isAlive).toList();
            String console = System.getenv("SystemRoot") + "\\System32\\conhost.exe";
            for (ProcessHandle helper : helpers)
                if (!System.getProperty("os.name").startsWith("Windows") ||
                    !helper.info().command().orElse("").equalsIgnoreCase(console))
                    throw new IOException("Unexpected native daemon descendant retains independent authority: " + helper.pid());
            List<CompletableFuture<ProcessHandle>> helperExits = helpers.stream().map(ProcessHandle::onExit).toList();
            process.destroy();
            try
            {
                if (!process.waitFor(10, TimeUnit.SECONDS))
                {
                    process.destroyForcibly();
                    process.waitFor();
                }
                for (CompletableFuture<ProcessHandle> helperExit : helperExits)
                    helperExit.orTimeout(10, TimeUnit.SECONDS).join();
                collected = process.exitValue();
            }
            catch (InterruptedException failure)
            {
                Thread.currentThread().interrupt();
                throw new IOException("Original native wait interrupted; retain daemon authority", failure);
            }
        }

        /**
         * Describes actual original daemon lifetime without exposing private configuration bytes.
         * @return original PID and terminal collection state
         */
        private Map<String, Object> receipt()
        {
            return Map.of("pid", process.pid(), "alive", process.isAlive(), "collected", collected != null,
                "originalExit", collected == null ? "uncollected" : collected);
        }
    }
}
