"""Continue authentic availability after observing the expected POSIX-only Windows test skip."""
from pathlib import Path
import subprocess,json,os,xml.etree.ElementTree as ET
source=Path(__file__).resolve().parent
root=source.parent
report=ET.parse(source/'tests/testng-results.xml').getroot()
assert report.attrib['failed']=='0',report.attrib
skips=[e for e in report.iter('test-method') if e.attrib.get('status')=='SKIP']
assert len(skips)==1,[e.attrib for e in skips]
assert 'posix' in skips[0].attrib['name'].lower(),skips[0].attrib
(source/'native-test-assessment.json').write_text(json.dumps({'passed':int(report.attrib['passed']),'failed':0,'expectedPosixSkip':skips[0].attrib['name'],'nativeWindowsAuthorityTests':'executed, not capability-skipped'},indent=2)+'\n')
java=next((root/'jdk').glob('*/bin/java.exe'))
argv=[str(java),'--enable-native-access=ALL-UNNAMED','-Djava.io.tmpdir='+str(source/'tmp'),'-cp',str(source/'classes')+os.pathsep+str(root/'producer.jar'),'com.holdmyspot.codexunleashed.scheduler.NativeBackendAvailability',str(root/'products'),str(source/'availability')]
with (source/'native-availability.log').open('wb') as output:status=subprocess.run(argv,cwd=source,stdout=output,stderr=subprocess.STDOUT).returncode
(source/'native-availability.json').write_text(json.dumps({'argv':argv,'exit':status},indent=2)+'\n')
print('NATIVE_AVAILABILITY_EXIT',status,flush=True)
raise SystemExit(status)
