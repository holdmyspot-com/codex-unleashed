"""Publish this worker's explicit credential-free products for the named Windows consumer."""
from pathlib import Path
import os,sys,tarfile,hashlib,json,subprocess,shutil
root=Path(__file__).resolve().parent.parent
archive=root/'backend-products-final.tar.gz'
inputs=['products','final-3/strict-compile.log','final-3/strict-compile.json','final-3/native-focused-tests.log','final-3/tests/testng-results.xml']
for optional in ['final-3/native-availability.json','final-3/native-availability.log','final-3/availability/receipt.json','final-3/availability-console/receipt.json','native-producer.log','build/commands']:
 if (root/optional).exists(): inputs.append(optional)
with tarfile.open(archive,'w:gz') as out:
 for name in inputs: out.add(root/name,arcname=name)
h=hashlib.sha256()
with archive.open('rb') as source:
 for block in iter(lambda:source.read(1048576),b''): h.update(block)
receipt={'archive':archive.name,'sha256':h.hexdigest(),'bytes':archive.stat().st_size,'inputs':inputs,'credentialsIncluded':False,'consumer':'/root/windows_bazel_consumer'}
(root/'backend-products-final.json').write_text(json.dumps(receipt,indent=2))
pin='bbbca2ddaa5d8feaa63e36b76fdaad77386f024f'
action=Path(os.environ['RUNNER_WORKSPACE']).parent/'_actions/actions/upload-artifact'/pin/'dist/upload/index.js'
candidates=[Path('C:/actions-runner/externals/node24/bin/node.exe'),Path('D:/a/_temp/../..')]
node=Path(shutil.which('node'))
for drive in ['C:','D:']:
 for base in [Path(drive+'/actions-runner'),Path(drive+'/a'),Path(drive+'/runners')]:
  if base.exists():
   found=list(base.glob('*/externals/node24/bin/node.exe'))+list(base.glob('externals/node24/bin/node.exe'))
   if found: node=found[0]
version=subprocess.check_output([str(node),'-p','process.versions.node'],text=True).strip()
if int(version.split('.')[0])<24: raise RuntimeError('Need runner Node24; selected '+str(node)+' '+version)
env=dict(os.environ)
env.update({'INPUT_NAME':'cp3-bazel-backend-'+sys.argv[1]+'-gX7SSJ','INPUT_PATH':str(archive)+'\n'+str(root/'backend-products-final.json'),'INPUT_IF-NO-FILES-FOUND':'error','INPUT_RETENTION-DAYS':'1','INPUT_COMPRESSION-LEVEL':'0','INPUT_OVERWRITE':'false','INPUT_INCLUDE-HIDDEN-FILES':'false','INPUT_ARCHIVE':'true','GITHUB_OUTPUT':str(root/'artifact-output-final.txt'),'GITHUB_STEP_SUMMARY':str(root/'artifact-summary-final.txt')})
for name in ['artifact-output-final.txt','artifact-summary-final.txt']: (root/name).touch()
with (root/'artifact-upload-final.log').open('wb') as log: status=subprocess.run([str(node),str(action)],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
receipt.update({'exit':status,'node':str(node),'nodeVersion':version,'outputs':(root/'artifact-output-final.txt').read_text()})
(root/'artifact-upload-final.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));sys.exit(status)
