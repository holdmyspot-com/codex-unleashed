"""Prepare exact pinned Java producer inputs and collect its original native build exit.

Only execute on the owned Windows worker. Every download is authenticated by its
vendor or retained artifact digest. Source, dependencies and actual JDK27 coexist
in a fresh recreation; valid build outputs remain for resume on this same worker.
"""
from pathlib import Path
import hashlib,io,json,os,subprocess,sys,tarfile,urllib.request,zipfile
root=Path(__file__).resolve().parent
arch=sys.argv[1]
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(1024*1024),b''):h.update(part)
    return h.hexdigest()
def run(name,args):
    with (root/(name+'.log')).open('wb') as log:
        status=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    (root/(name+'.receipt.json')).write_text(json.dumps({'argv':args,'exit':status},indent=2)+'\n')
    if status:raise SystemExit(status)
metadata=json.loads((root/('jdk27-'+arch+'.json')).read_text())
archive=root/'jdk.zip'
if not archive.exists() or digest(archive)!=metadata['sha256_hash']:
    urllib.request.urlretrieve(metadata['download_url'],archive)
assert digest(archive)==metadata['sha256_hash']
jdkroot=root/'jdk';jdkroot.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        path=Path(info.filename)
        assert not path.is_absolute() and '..' not in path.parts
    z.extractall(jdkroot)
java=next(jdkroot.glob('*/bin/java.exe'));javac=java.with_name('javac.exe')
run('jdk-version',[str(java),'-XshowSettings:properties','-version'])
ziproot=root/'runtime.zip'
if not ziproot.exists():
    with ziproot.open('wb') as out:
        result=subprocess.run(['gh','api','repos/holdmyspot-com/codex-unleashed/actions/artifacts/13095214026/zip'],stdout=out,stderr=subprocess.PIPE)
    if result.returncode:raise RuntimeError(result.stderr.decode())
assert digest(ziproot)=='319f8cb12e8cf625a9f8393fb77ff5c0deb389ae38fb5fd584c2379d2bfc7b2e'
with zipfile.ZipFile(ziproot) as z:
    name='runtime-assets.tar'
    with z.open(name) as stream, (root/name).open('wb') as output:
        import shutil;shutil.copyfileobj(stream,output)
assert digest(root/name)=='9720f7922f802785bc83d75cb9ad28da495232705345998da798fe9752d7c45c'
with tarfile.open(root/name) as t:
    members=[m for m in t if m.name.lstrip('./') in ('producer.jar','producer-jar-inputs.json')]
    assert len(members)==2
    for m in members:
        assert m.isfile()
        with t.extractfile(m) as source,(root/Path(m.name).name).open('wb') as output:shutil.copyfileobj(source,output)
jar=root/'producer.jar'
assert digest(jar)=='8a94ce90c46175be289486b1e0cab9c39f1bdd2303111d47ca1c567b38b65aa8'
classes=root/'classes';classes.mkdir(exist_ok=True)
sources=[root/n for n in ['BazelNativeBackend.java','BazelBackendCredentials.java','BazelNativeBackendMain.java','BazelRunner.java']]
run('strict-compile',[str(javac),'--release','27','-Xlint:all,-processing','-Werror','-Xdoclint:all/private','-cp',str(jar),'-d',str(classes),*[str(p) for p in sources]])
resources=classes/'com/holdmyspot/codexunleashed/scheduler/buildbarn';resources.mkdir(parents=True,exist_ok=True)
shutil.copyfile(root/'worker-windows.json.template',resources/'worker-windows.json.template')
(root/'fixture-temp').mkdir(exist_ok=True)
target=('x86_64' if arch=='x64' else 'aarch64')+'-pc-windows-msvc'
run('native-producer',[str(java),'-Djava.io.tmpdir='+str(root/'fixture-temp'),'-cp',str(classes)+os.pathsep+str(jar),'com.holdmyspot.codexunleashed.distribution.BazelNativeBackendMain',target,str(root/'build'),str(root/'products')])
print('NATIVE_PRODUCER_COMPLETE',target,flush=True)
