"""Verify provider ZIP bytes and selectively retrieve nonnative control members without native extraction."""
import io,zipfile,tarfile,urllib.request,subprocess,hashlib,json,sys
from pathlib import Path
r=Path(__file__).resolve().parent
arch,artifact,expected=sys.argv[1:]
token=subprocess.check_output(['gh','auth','token'],text=True).strip()
req=urllib.request.Request('https://api.github.com/repos/holdmyspot-com/codex-unleashed/actions/artifacts/'+artifact+'/zip',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'})
class Redirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  result=super().redirect_request(req,fp,code,msg,headers,newurl)
  result.remove_header('Authorization');return result
response=urllib.request.build_opener(Redirect()).open(req);url=response.url
h=hashlib.sha256();count=0
for block in iter(lambda:response.read(1048576),b''):h.update(block);count+=len(block)
assert h.hexdigest()==expected,(h.hexdigest(),expected)
class RangeReader(io.RawIOBase):
 def __init__(self):self.position=0;self.start=-1;self.buffer=b''
 def seekable(self):return True
 def readable(self):return True
 def tell(self):return self.position
 def seek(self,offset,whence=0):
  self.position=(0 if whence==0 else self.position if whence==1 else count)+offset;return self.position
 def read(self,size=-1):
  if size<0:size=count-self.position
  if self.position>=count:return b''
  size=min(size,count-self.position)
  if not(self.start<=self.position and self.position+size<=self.start+len(self.buffer)):
   end=min(count,self.position+max(size,4*1048576))-1
   with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':f'bytes={self.position}-{end}'})) as q:
    assert q.status==206,q.status
    self.start=self.position;self.buffer=q.read()
  offset=self.position-self.start;data=self.buffer[offset:offset+size];self.position+=len(data);return data
out=r/('windows-'+arch)/'retrieved-controls';out.mkdir()
items=[];omitted=[]
with zipfile.ZipFile(RangeReader()) as z:
 archive=next(x for x in z.namelist() if x.endswith('backend-products-final.tar.gz'))
 with z.open(archive) as stream,tarfile.open(fileobj=stream,mode='r|gz') as t:
  for m in t:
   if not m.isfile():continue
   if m.name.startswith('products/') and m.name!='products/backend-manifest.json':omitted.append({'name':m.name,'bytes':m.size});continue
   if not(m.name.endswith(('.json','.xml','.log'))):raise RuntimeError('Unexpected shareable member '+m.name)
   b=t.extractfile(m).read();p=out/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
   items.append({'name':m.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 for name in z.namelist():
  if name.endswith('backend-products-final.json'):
   b=z.read(name);(out/'backend-products-final.json').write_bytes(b)
receipt={'artifact':int(artifact),'zipSha256':expected,'zipBytes':count,'controls':items,'nativePayloadsNotExtracted':omitted,'credentialMaterialExtracted':False}
(out/'retrieval.json').write_text(json.dumps(receipt,indent=2)+'\n');print(arch,'VERIFIED_CONTROL_RETRIEVAL',len(items),'native omitted',len(omitted))
