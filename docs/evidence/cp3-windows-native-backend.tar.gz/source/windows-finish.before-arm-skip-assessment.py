"""Compile final source recreation, resume completed products, then prove authentic availability.

Only runs within this invocation's retained native worker. Original failures,
command receipts and completed products remain untouched except expected resume.
"""
from pathlib import Path
import hashlib,json,os,subprocess,sys,shutil
root=Path(__file__).resolve().parent.parent
source=Path(__file__).resolve().parent
arch=sys.argv[1]
java=next((root/'jdk').glob('*/bin/java.exe'));javac=java.with_name('javac.exe')
jar=root/'producer.jar';classes=source/'classes';classes.mkdir()
(source/'tmp').mkdir()
def run(name,argv):
    with (source/(name+'.log')).open('wb') as output:
        code=subprocess.run(argv,cwd=source,stdout=output,stderr=subprocess.STDOUT).returncode
    (source/(name+'.json')).write_text(json.dumps({'argv':argv,'exit':code},indent=2)+'\n')
    print(name,code,flush=True)
    if code:raise SystemExit(code)
sources=sorted(source.glob('*.java'))
run('strict-compile',[str(javac),'--release','27','-Xlint:all,-processing','-Werror','-Xdoclint:all/private','-cp',str(jar),'-d',str(classes),*[str(p) for p in sources]])
resources=classes/'com/holdmyspot/codexunleashed/scheduler/buildbarn';resources.mkdir(parents=True)
shutil.copyfile(source/'worker-windows.json.template',resources/'worker-windows.json.template')
base=[str(java),'--enable-native-access=ALL-UNNAMED','-Djava.io.tmpdir='+str(source/'tmp'),'-cp',str(classes)+os.pathsep+str(jar)]
run('native-focused-tests',base+['org.testng.TestNG','-parallel','methods','-threadcount','8','-d',str(source/'tests'),'-testclass','com.holdmyspot.codexunleashed.scheduler.BazelNativeBackendTest,com.holdmyspot.codexunleashed.scheduler.BazelBackendCredentialsTest,com.holdmyspot.codexunleashed.distribution.BazelNativeBackendMainTest'])
target=('x86_64' if arch=='x64' else 'aarch64')+'-pc-windows-msvc'
run('native-producer-resume',base+['com.holdmyspot.codexunleashed.distribution.BazelNativeBackendMain',target,str(root/'build'),str(root/'products'),'--resume'])
run('native-availability',base+['com.holdmyspot.codexunleashed.scheduler.NativeBackendAvailability',str(root/'products'),str(source/'availability')])
print('FINAL_NATIVE_GATES_COMPLETE',target,flush=True)
