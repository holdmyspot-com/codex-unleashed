package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import org.testng.annotations.Test;
import static com.holdmyspot.codexunleashed.scheduler.TestRequirements.requireException;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/**
 * Exercises the common native target boundary without claiming native execution.
 */
public final class BazelNativeBackendTest
{
    /**
     * Creates independent boundary checks.
     */
    public BazelNativeBackendTest() {}

    /**
     * The shared target contract supports both real architectures on every release operating system.
     */
    @Test
    public void resolvesEveryReleaseHost()
    {
        String[][] hosts = {
            {"Linux", "amd64", "x86_64-unknown-linux-musl"},
            {"Linux", "aarch64", "aarch64-unknown-linux-musl"},
            {"Mac OS X", "x86_64", "x86_64-apple-darwin"},
            {"Mac OS X", "aarch64", "aarch64-apple-darwin"},
            {"Windows 11", "amd64", "x86_64-pc-windows-msvc"},
            {"Windows 11", "aarch64", "aarch64-pc-windows-msvc"}
        };
        for (String[] host : hosts)
            requireThat(BazelNativeBackend.NativeTarget.forHost(host[0], host[1]).triple(), "nativeTarget")
                .isEqualTo(host[2]);
    }

    /**
     * Accepts exactly hashed native machine headers and rejects changed bytes before any launch authority.
     * These portable synthetic files exercise validation only; they are never executed.
     * @throws Exception if owned fixture creation or validation fails
     */
    @Test
    public void validatesNativeManifestAndArchitecture() throws Exception
    {
        for (String[] host : new String[][]{{"Mac OS X", "aarch64"}, {"Mac OS X", "x86_64"},
            {"Windows 11", "aarch64"}, {"Windows 11", "amd64"}})
        {
            BazelNativeBackend.NativeTarget target = BazelNativeBackend.NativeTarget.forHost(host[0], host[1]);
            try (Fixture fixture = Fixture.open(target))
            {
                BazelNativeBackend.ValidatedDistribution accepted = BazelNativeBackend.validateDistribution(
                    fixture.scope, target, fixture.root);
                requireThat(accepted.executables().keySet(), "exactNativeDaemonSet")
                    .isEqualTo(Set.of("bb_storage", "bb_scheduler", "bb_worker"));
                Path worker = fixture.root.resolve("bb_worker" + target.suffix());
                Files.writeString(worker, "changed actual bytes");
                requireException(IOException.class, () -> BazelNativeBackend.validateDistribution(fixture.scope, target, fixture.root));
            }
        }
    }

    /**
     * Correctly hashed files for the wrong processor do not become native launch authority.
     * @throws Exception if fixture creation or manifest serialization fails
     */
    @Test
    public void rejectsHashedWrongMachine() throws Exception
    {
        BazelNativeBackend.NativeTarget target = BazelNativeBackend.NativeTarget.forHost("Windows 11", "aarch64");
        try (Fixture fixture = Fixture.open(target))
        {
            Files.write(fixture.root.resolve("bb_worker.exe"), header(BazelNativeBackend.NativeTarget.forHost("Windows 11", "amd64")));
            fixture.writeManifest();
            requireException(IOException.class, () -> BazelNativeBackend.validateDistribution(fixture.scope, target, fixture.root));
        }
    }

    /**
     * Moving a validated distribution object away and recreating identical bytes cannot reuse its native authority.
     * @throws Exception if fixture creation or original object replacement fails
     */
    @Test
    public void rejectsReplacedOriginalRoot() throws Exception
    {
        BazelNativeBackend.NativeTarget target = BazelNativeBackend.NativeTarget.forHost("Mac OS X", "aarch64");
        try (Fixture fixture = Fixture.open(target))
        {
            BazelNativeBackend.ValidatedDistribution accepted = BazelNativeBackend.validateDistribution(fixture.scope, target, fixture.root);
            Path old = fixture.root.resolveSibling(fixture.root.getFileName() + "-original");
            Files.move(fixture.root, old);
            try
            {
                Files.createDirectory(fixture.root);
                try (java.util.stream.Stream<Path> files = Files.list(old))
                {
                    for (Path file : files.toList())
                    {
                        Path replacement = fixture.root.resolve(file.getFileName());
                        Files.copy(file, replacement);
                        if (!replacement.getFileName().toString().equals(BazelNativeBackend.MANIFEST))
                            requireThat(replacement.toFile().setExecutable(true), "replacementExecutable").isTrue();
                    }
                }
                requireException(IOException.class, () -> accepted.revalidate(fixture.scope));
            }
            finally { org.apache.commons.io.file.PathUtils.deleteDirectory(old); }
        }
    }

    /**
     * Produces a deliberately synthetic minimal header for portable rejection checks.
     * @param target selected format and native processor
     * @return synthetic header bytes, never a runnable product
     */
    private static byte[] header(BazelNativeBackend.NativeTarget target)
    {
        ByteBuffer bytes = ByteBuffer.allocate(128).order(ByteOrder.LITTLE_ENDIAN);
        if (target.goOperatingSystem().equals("darwin"))
        {
            bytes.putInt(0, 0xfeedfacf);
            bytes.putInt(4, target.goArchitecture().equals("arm64") ? 0x0100000c : 0x01000007);
            bytes.putInt(12, 2);
        }
        else
        {
            bytes.put(0, (byte) 'M'); bytes.put(1, (byte) 'Z'); bytes.putInt(60, 64);
            bytes.putInt(64, 0x00004550);
            bytes.putShort(68, (short) (target.goArchitecture().equals("arm64") ? 0xaa64 : 0x8664));
            bytes.putShort(86, (short) 2); bytes.putShort(88, (short) 0x020b);
        }
        return bytes.array();
    }

    /**
     * Owns a portable manifest fixture and one borrowed-service scope per test invocation.
     */
    private static final class Fixture implements AutoCloseable
    {
        /** Unique fixture root, removed after each check. */
        private final Path root;
        /** Test-local Pouch scope for shared JSON services. */
        private final DefaultToolingScope scope;
        /** Exact expected native target for fixture serialization. */
        private final BazelNativeBackend.NativeTarget target;

        /**
         * Retains already-acquired fixture ownership.
         * @param root unique owned fixture directory
         * @param scope original test-owned Pouch scope
         * @param target exact native format under test
         */
        private Fixture(Path root, DefaultToolingScope scope, BazelNativeBackend.NativeTarget target)
        {
            this.root = root;
            this.scope = scope;
            this.target = target;
        }

        /**
         * Creates synthetic validator inputs without launching or extracting a native executable.
         * @param target exact native format under test
         * @return fully owned portable fixture
         * @throws Exception if fixture creation fails after retained cleanup
         */
        private static Fixture open(BazelNativeBackend.NativeTarget target) throws Exception
        {
            Path root = Files.createTempDirectory("native-backend-validator-");
            DefaultToolingScope scope = new DefaultToolingScope();
            Fixture fixture = new Fixture(root, scope, target);
            try
            {
                for (String name : Set.of("bb_storage", "bb_scheduler", "bb_worker"))
                {
                    Path path = root.resolve(name + target.suffix());
                    Files.write(path, header(target));
                    requireThat(path.toFile().setExecutable(true), "fixtureExecutable").isTrue();
                }
                fixture.writeManifest();
                return fixture;
            }
            catch (Exception | Error failure)
            {
                try { fixture.close(); }
                catch (Exception cleanup) { failure.addSuppressed(cleanup); }
                throw failure;
            }
        }

        /**
         * Serializes the exact current file identities into the fixture manifest.
         * @throws Exception if hashing or scope-owned serialization fails
         */
        private void writeManifest() throws Exception
        {
            Map<String, Object> files = new LinkedHashMap<>();
            for (String name : Set.of("bb_storage", "bb_scheduler", "bb_worker"))
            {
                String filename = name + target.suffix();
                files.put(name, Map.of("path", filename, "sha256", HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(root.resolve(filename))))));
            }
            scope.getJsonMapper().writeValue(root.resolve(BazelNativeBackend.MANIFEST).toFile(), Map.of(
                "schema", 1, "target", target.triple(), "executionCommit", BazelNativeBackend.EXECUTION_COMMIT,
                "storageCommit", BazelNativeBackend.STORAGE_COMMIT, "executables", files));
        }

        @Override public void close() throws IOException
        {
            try { org.apache.commons.io.file.PathUtils.deleteDirectory(root); }
            finally { scope.close(); }
        }
    }
}
