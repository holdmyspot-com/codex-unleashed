"""Prove queued inode retention across atomic rename and immediate consumer unlink.

Run on an owned Linux worker with CAP_SYS_ADMIN and an explicit JDK27 home. Only
this probe's collector is temporarily stopped to force queued-event retention;
no product/controller or real pressure runs in this check. Cleanup always resumes
and collects that collector. Output identifies the consumer's exact PID and bytes.
"""
from pathlib import Path
import base64,hashlib,json,os,signal,subprocess,sys,time
root=Path(__file__).resolve().parent
jdk=Path(sys.argv[1]); classes=root/'capture-classes'; classes.mkdir(exist_ok=True)
source=root/'recreation/FanotifyCapture.java'
command=[str(jdk/'bin/javac'),'--release','27','-Xlint:all,-processing','-Werror','-Xdoclint:all/private','-d',str(classes),str(source)]
p=subprocess.run(command,capture_output=True,text=True)
(root/'capture-compile.json').write_text(json.dumps(dict(command=command,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest()),indent=2))
p.check_returncode()
case=root/sys.argv[2];case.mkdir(); ready=case/'ready';stop=case/'stop';output=case/'events.tsv'
command=[str(jdk/'bin/java'),'--enable-native-access=ALL-UNNAMED','-cp',str(classes),'FanotifyCapture',str(case),str(output),str(ready),str(stop)]
with (case/'stdout').open('wb')as stdout,(case/'stderr').open('wb')as stderr:
 collector=subprocess.Popen(command,stdout=stdout,stderr=stderr)
 try:
  deadline=time.monotonic()+10
  while not ready.exists():
   if collector.poll() is not None:raise RuntimeError('Collector failed before readiness')
   if time.monotonic()>deadline:raise TimeoutError('Collector readiness deadline')
   time.sleep(.01)
  os.kill(collector.pid,signal.SIGSTOP)
  deadline=time.monotonic()+5
  while 'State:\tT' not in Path('/proc',str(collector.pid),'status').read_text():
   if time.monotonic()>deadline:raise TimeoutError('Collector stop not observed')
   time.sleep(.005)
  before={x.name:os.readlink(x) for x in Path('/proc',str(collector.pid),'fd').iterdir()}
  publication=case/'terminate.xml.pending';publication.write_bytes(b'publication-bytes');publication.replace(case/'terminate.xml')
  value=b'exact consumed PSI fixture\x00\xff\n'
  pending=case/'capture-probe-response.pending';published=case/'capture-probe-response.properties'
  pending.write_bytes(value);os.replace(pending,published)
  script='import os,sys,json,pathlib; p=pathlib.Path(sys.argv[1]); b=p.read_bytes(); p.unlink(); print(json.dumps(dict(pid=os.getpid(),hex=b.hex(),removed=not p.exists())))'
  result=subprocess.run([sys.executable,'-c',script,str(published)],capture_output=True,text=True,check=True)
  consumer=json.loads(result.stdout)
  assert consumer['removed'] and consumer['hex']==value.hex()
  os.kill(collector.pid,signal.SIGCONT)
  deadline=time.monotonic()+10
  records=[]
  while time.monotonic()<deadline:
   records=[line.split('\t')for line in output.read_text().splitlines()]
   if any(int(r[2])==consumer['pid'] for r in records):break
   if collector.poll() is not None:raise RuntimeError('Collector failed after readiness')
   time.sleep(.01)
  selected=[r for r in records if int(r[2])==consumer['pid']]
  assert len(selected)==1,selected
  event=selected[0]
  assert int(event[1])&16
  assert base64.b64decode(event[4])==value
  assert base64.b64decode(event[3]).decode().endswith('capture-probe-response.properties (deleted)')
  producer=[r for r in records if int(r[2])==os.getpid() and int(r[1])&8 and 'capture-probe-response' in base64.b64decode(r[3]).decode()]
  assert len(producer)==1 and int(producer[0][0])<int(event[0])
  assert base64.b64decode(producer[0][4])==value
  publication_events=[r for r in records if base64.b64decode(r[3]).decode().endswith('/terminate.xml')]
  assert len(publication_events)==1 and base64.b64decode(publication_events[0][4])==b'publication-bytes'
  after={x.name:os.readlink(x) for x in Path('/proc',str(collector.pid),'fd').iterdir()}
  assert all(before.get(key)==value for key,value in after.items()),(before,after)
  stop.write_text('collected consumer; finish notification drain\n')
  status=collector.wait(timeout=10);assert status==0
  report=dict(task_contract='acknowledged',passed=True,scope='notification inode retention only; no product/pressure executed',command=command,collectorPid=collector.pid,collectorExit=status,consumer=consumer,producerPid=os.getpid(),producerOrdinal=int(producer[0][0]),consumerOrdinal=int(event[0]),event=event,terminationPublication=publication_events[0],descriptorNamesBefore=before,descriptorNamesAfter=after,allDeliveredDescriptorsClosed=True,listenerProcessCollected=True,sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest())
  (case/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
 finally:
  if collector.poll() is None:
   os.kill(collector.pid,signal.SIGCONT);stop.write_text('probe finalization\n')
   try:collector.wait(timeout=10)
   except subprocess.TimeoutExpired:collector.kill();collector.wait();raise
