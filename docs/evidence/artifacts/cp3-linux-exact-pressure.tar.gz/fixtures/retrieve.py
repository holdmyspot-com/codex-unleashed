"""Retrieve only the already sealed source/control archive over the owned channel."""
from pathlib import Path
import base64,hashlib,json,re,subprocess,sys,tarfile
worker=Path(sys.argv[1]);destination=Path(sys.argv[2]);expected=sys.argv[3]
destination.mkdir();log=destination/'retrieval.raw'
with log.open('wb')as output:
 subprocess.run(['python3',str(worker/'remote.py'),'sudo base64 -w 128 "$CAPTURE_WORK/connected-evidence.tar.gz"'],stdout=output,stderr=output,check=True)
lines=[line.strip()for line in log.read_bytes().splitlines()if re.fullmatch(rb'[A-Za-z0-9+/]{4,128}={0,2}',line.strip())]
raw=base64.b64decode(b''.join(lines),validate=True);actual=hashlib.sha256(raw).hexdigest();assert actual==expected
archive=destination/'connected-evidence.tar.gz';archive.write_bytes(raw)
with tarfile.open(archive)as inp:
 members=inp.getmembers();assert len({m.name for m in members})==len(members)
 index=json.loads(inp.extractfile('inventory.json').read())['files']
 for m in members:
  assert m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts
  data=inp.extractfile(m).read();assert not data.startswith((b'\x7fELF',b'MZ'))
  if m.name!='inventory.json':assert len(data)==index[m.name]['bytes']and hashlib.sha256(data).hexdigest()==index[m.name]['sha256']
 inp.extractall(destination/'evidence',filter='data')
(destination/'retrieval-verification.json').write_text(json.dumps(dict(passed=True,sha256=actual,bytes=len(raw),members=len(members),cleanRetrieval='Every safe member and determining source/control identity checked before extraction'),indent=2)+'\n');print(json.dumps(dict(passed=True,sha256=actual,bytes=len(raw),members=len(members))))
