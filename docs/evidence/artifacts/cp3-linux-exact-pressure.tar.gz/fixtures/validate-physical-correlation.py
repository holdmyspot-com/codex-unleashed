"""Require exact accepted host/resident/verify consumption before native termination.

The JDK Properties decoder supplies parsed values from untouched captured bytes.
Queue ordinals authenticate order independently of the asynchronous observer clock.
This validator establishes attribution only; the original whole-build validator
separately requires native closure, retry position, FIFO and useful output.
"""
from pathlib import Path
import base64,hashlib,json,re,subprocess,sys,xml.etree.ElementTree as ET


def validate(case, java=None, classes=None):
    """Replay complete authority exchanges and bind termination to its accepted batch."""
    result=json.loads((case/'result.json').read_text());pid=result['controllerPid']
    assert result['capture']['exit']==0 and not result['capture'].get('fallbackKill',False)
    assert result['exit']==0 and not result['fallbackKill']
    root=case.parent.parent;owner=root.parent
    command=[str(java or owner/'jdk/bin/java'),'-cp',str(classes or owner/'capture-classes'),'PropertiesDecoder',str(case/'capture-events.tsv')]
    decoded=subprocess.run(command,capture_output=True,text=True)
    (case/'properties-decoder-receipt.json').write_text(json.dumps(dict(command=command,exit=decoded.returncode,stderr=decoded.stderr),indent=2)+'\n');decoded.check_returncode()
    properties={}
    for line in decoded.stdout.splitlines():
        ordinal,key,value=line.split('\t');properties.setdefault(int(ordinal),{})[base64.b64decode(key).decode()]=base64.b64decode(value).decode()
    records=[];previous=0
    for line in (case/'capture-events.tsv').read_text().splitlines():
        ordinal,mask,origin,path,body=line.split('\t');ordinal=int(ordinal);mask=int(mask)
        assert ordinal>previous and not mask&0x4000;previous=ordinal
        path=base64.b64decode(path).decode().removesuffix(' (deleted)')
        records.append(dict(ordinal=ordinal,mask=mask,pid=int(origin),path=path,body=base64.b64decode(body)))
    owned=[x for x in records if x['pid']==pid]
    exchanges={};termination=[]
    for item in owned:
        path=Path(item['path']);match=re.fullmatch(r'(request|response)-(\d+)\.properties(?:\.pending)?',path.name)
        if match:
            kind,number=match.groups();assert item['mask']&(8 if kind=='request' else 16)
            key=(str(path.parent),int(number));pair=exchanges.setdefault(key,{})
            assert kind not in pair,'Duplicate authenticated close event'
            pair[kind]=item
        elif path.name in ['terminate.xml','terminate.xml.pending'] and item['mask']&8:
            termination.append(item)
    assert exchanges and len(termination)==1
    directories={key[0]for key in exchanges};assert len(directories)==1
    numbers=sorted(key[1]for key in exchanges);assert numbers==list(range(1,max(numbers)+1))
    registry=set();pending=None;accepted=[];mutations=0
    for key in sorted(exchanges,key=lambda x:x[1]):
        pair=exchanges[key];assert set(pair)=={'request','response'},f'Incomplete ordinal {key}'
        request,response=pair['request'],pair['response'];assert request['ordinal']<response['ordinal']
        q=properties[request['ordinal']];r=properties[response['ordinal']];operation=q['operation']
        if r['status']!='ok':pending=None;continue
        if operation in ['register','unregister']:
            attempt=(q['name'],q['attempt'])
            if operation=='register':assert attempt not in registry;registry.add(attempt)
            else:assert attempt in registry;registry.remove(attempt)
            mutations+=1;pending=None
        elif operation=='host':
            for name in ['total','hostAvailable','available','swapTotal','swapUsed','swapOut','stall']:assert int(r[name])>=0
            pending=dict(host=r,registry=set(registry),residents={},generation=mutations,hostRequest=request['ordinal'],hostConsumed=response['ordinal'],hostSequence=key[1])
        elif operation=='resident':
            if pending is not None:
                attempt=(q['name'],q['attempt']);assert attempt in pending['registry']
                assert attempt not in pending['residents'] and int(r['resident'])>=0
                pending['residents'][attempt]=dict(request=request['ordinal'],consumed=response['ordinal'],resident=int(r['resident']))
        elif operation=='verify':
            if pending is not None:
                assert pending['generation']==mutations and pending['registry']==registry
                assert set(pending['residents'])==registry,'Accepted sample lacks complete live residency'
                pending['verifyRequest']=request['ordinal'];pending['verifyConsumed']=response['ordinal'];accepted.append(pending);pending=None
        else:raise AssertionError('Unexpected operation '+operation)
    correlations=[]
    for event in termination:
        document=ET.fromstring(event['body']);values={e.attrib['key']:e.text or ''for e in document.findall('entry')}
        assert values['phase']=='TERMINATE'
        victim=result['selectedPhysicalCompilers'][-1]['native']
        assert values['root.pid']==str(victim['pid'])
        assert values['action.group'].removeprefix('/sys/fs/cgroup') in victim['cgroup']
        terminal=[x['values']for x in result['receipts'].values()if x['values'].get('phase')=='RESULT' and x['values'].get('root.pid')==values['root.pid']]
        assert len(terminal)==1 and terminal[0]['attempt']==values['attempt'] and terminal[0]['root.exit']=='137' and terminal[0]['instrumentation.closed']=='true' and terminal[0]['termination']=='true'
        candidates=[(i,x)for i,x in enumerate(accepted)if x['verifyConsumed']<event['ordinal']]
        assert candidates;i,current=candidates[-1];assert i>0
        previous=accepted[i-1];assert current['host']['boot']==previous['host']['boot']
        delta={name:int(current['host'][name])-int(previous['host'][name])for name in ['stall','swapOut','swapUsed']}
        assert delta['stall']>0,'Exact consumed accepted sample has no new PSI stall'
        assert delta['swapOut']==0 and delta['swapUsed']<=0,'Swap growth is a competing pressure trigger'
        assert len(current['registry'])>=2
        assert previous['verifyConsumed']<current['hostRequest']<current['hostConsumed']<current['verifyRequest']<current['verifyConsumed']<event['ordinal']
        assert all(current['hostConsumed']<v['request']<v['consumed']<current['verifyRequest']for v in current['residents'].values())
        # No later host exchange may intervene between accepted sampling and action.
        assert not any(current['verifyConsumed']<v['request']['ordinal']<event['ordinal'] and properties[v['request']['ordinal']]['operation']=='host'for v in exchanges.values())
        def serial(batch):
            """Encode exact complete batch without losing native attempt identities."""
            return dict(batch,registry=sorted(batch['registry']),residents=[dict(name=k[0],attempt=k[1],**v)for k,v in sorted(batch['residents'].items())])
        correlations.append(dict(terminationOrdinal=event['ordinal'],terminationPath=event['path'],terminationSha256=hashlib.sha256(event['body']).hexdigest(),control=values,previous=serial(previous),accepted=serial(current),counterDelta=delta))
    report=dict(gate='passed',controllerPid=pid,queueRecords=len(records),authorityExchanges=len(exchanges),completeRequestOrdinals=numbers,acceptedBatches=len(accepted),correlations=correlations,captureSha256=hashlib.sha256((case/'capture-events.tsv').read_bytes()).hexdigest(),scope='Exact consumed pressure attribution; whole-build acceptance separately required')
    (case/'physical-correlation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))


if __name__=='__main__':validate(Path(sys.argv[1]),*sys.argv[2:])
