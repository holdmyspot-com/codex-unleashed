"""Transfer one named input through the caller's independently owned live SSH FIFO.

Arguments are local worker-owner directory, local input file, and an alphanumeric
remote basename. Each 256-byte base64 payload receives its own completion receipt.
Reject existing destination files; hash verification is required before use. All
commands/results remain under the worker owner for final evidence and cleanup.
"""
from pathlib import Path
import subprocess,base64,hashlib,sys,re
worker=Path(sys.argv[1]);source=Path(sys.argv[2]);name=sys.argv[3]
assert re.fullmatch('[A-Za-z0-9_.-]+',name)
raw=source.read_bytes();encoded=base64.b64encode(raw).decode()
commands=['test ! -e "$CAPTURE_WORK/incoming/'+name+'" && : > "$CAPTURE_WORK/incoming/'+name+'.b64"']
commands+=['printf %s '+encoded[i:i+256]+' >> "$CAPTURE_WORK/incoming/'+name+'.b64"' for i in range(0,len(encoded),256)]
commands+=['base64 -d "$CAPTURE_WORK/incoming/'+name+'.b64" > "$CAPTURE_WORK/incoming/'+name+'" && echo "'+hashlib.sha256(raw).hexdigest()+'  $CAPTURE_WORK/incoming/'+name+'" | sha256sum -c -']
with (worker/('transfer-'+name+'.log')).open('x')as log:
 for command in commands:subprocess.run(['python3',str(worker/'remote.py'),command],stdout=log,stderr=log,check=True)
print(dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),commands=len(commands)))
