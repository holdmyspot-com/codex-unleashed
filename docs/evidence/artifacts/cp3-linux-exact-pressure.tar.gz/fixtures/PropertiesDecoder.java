import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Properties;

/** Decodes captured properties with the same JDK parser used by installed Main. */
public final class PropertiesDecoder
{
    /** Prevents construction of this standalone evidence fixture. */
    private PropertiesDecoder() {}

    /**
     * Reads captured event TSV and emits ordinal, base64 key and base64 value.
     * Only properties files are parsed; control XML remains original exact bytes.
     * @param arguments one captured event TSV path
     * @throws Exception if any capture or properties record is malformed
     */
    public static void main(String[] arguments) throws Exception
    {
        if (arguments.length != 1)
            throw new IllegalArgumentException("Expected one capture TSV path");
        var decoder = Base64.getDecoder();
        var encoder = Base64.getEncoder();
        for (String line : Files.readAllLines(Path.of(arguments[0]), StandardCharsets.UTF_8))
        {
            String[] fields = line.split("\\t", -1);
            if (fields.length != 5)
                throw new IllegalArgumentException("Expected five event fields");
            String path = new String(decoder.decode(fields[3]), StandardCharsets.UTF_8);
            if (!path.contains(".properties"))
                continue;
            var properties = new Properties();
            properties.load(new StringReader(new String(decoder.decode(fields[4]), StandardCharsets.UTF_8)));
            for (String key : properties.stringPropertyNames().stream().sorted().toList())
                System.out.println(fields[0] + "\t" + encoder.encodeToString(key.getBytes(StandardCharsets.UTF_8)) +
                    "\t" + encoder.encodeToString(properties.getProperty(key).getBytes(StandardCharsets.UTF_8)));
        }
    }
}
