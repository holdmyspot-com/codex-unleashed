"""Export determining source/control bytes while retaining native bodies remotely."""
from pathlib import Path
import hashlib,io,json,tarfile
r=Path(__file__).resolve().parent;o=r.parent
files={}
def include(path):
    """Retain one nonsymlink evidence input, rejecting native executable bodies."""
    assert path.is_file() and not path.is_symlink(),str(path)
    data=path.read_bytes();assert not data.startswith((b'\x7fELF',b'MZ')),str(path)
    files[path.relative_to(o).as_posix()]=data
for p in r.iterdir():
    if p.is_file()and not p.is_symlink()and(p.suffix in ['.json','.py','.stdout','.stderr','.java']or p.name.endswith('.py.preimage')):include(p)
manifest=json.loads((r/'cli-source-manifest.json').read_text())
assert len(manifest)==298
for name,value in manifest.items():
    p=r/'source'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==value;include(p)
for directory in [r/'cases',r/'history',o/'recreation',*o.glob('capture-native-probe*')]:
    for p in directory.rglob('*'):
        if p.is_file()and not p.is_symlink():include(p)
for p in [o/'capture-probe.py']:
    include(p)
for name in json.loads((r/'fixture-manifest.json').read_text()):include(r/'fixture'/name)
index={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in sorted(files.items())}
files['inventory.json']=(json.dumps(dict(task_contract='acknowledged',sourceCommit='aeac145f38f395658348a93fe681ba528c523ecb',files=index,excludedNativeBodies=['JDK','Rust','Frida','compiled C helper','native useful artifact','jimage extracted class bodies','Maven cache','physical-cache','Cargo target'],claim='All determining source/control bytes, exact capture and failures; native bodies represented by acquired and executed identities'),indent=2)+'\n').encode()
p=o/'connected-evidence.tar.gz'
with tarfile.open(p,'w:gz')as archive:
    for name,data in sorted(files.items()):
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;archive.addfile(entry,io.BytesIO(data))
receipt=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),members=len(files))
(o/'connected-evidence.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
