"""Bind the real Maven runtime to exact immutable inputs and linked class bytes.

Run inside the owned product root after its actual runtime profile returns zero.
The native jimage extraction remains remote and is never copied into evidence.
Only metadata, byte identities and class-equivalence results are exported.
"""
from pathlib import Path
import hashlib,json,subprocess,os,zipfile
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'cli-source-manifest.json').read_text())
assert all(sha(root/'source'/name)==value for name,value in manifest.items())
cli=root/'source/tooling/cli';build=root/'source/.cat/work/temp/build-caches/maven/source-cache';runtime=build/'runtime';jdk=root.parent/'jdk'
expected=[runtime/'.complete',runtime/'bin/codex-tooling',runtime/'bin/codex-cargo-wrapper-linux',runtime/'bin/java',runtime/'lib/modules']
assert all(p.is_file() for p in expected)
report=dict(sourceManifestSha256=sha(root/'cli-source-manifest.json'),sourceInputs=len(manifest),runtime=str(runtime),cli=str(runtime/'bin/codex-tooling'),wrapper=str(runtime/'bin/codex-cargo-wrapper-linux'),identities={p.relative_to(root).as_posix():sha(p)for p in expected},buildContract='Unmodified committed POM actual Maven runtime profile with tests skipped; new connected native acceptance follows',sourceCommit='aeac145f38f395658348a93fe681ba528c523ecb')
(root/'bundle-result.json').write_text(json.dumps(report,indent=2)+'\n')
extract=root/'linked-class-check'
command=[str(jdk/'bin/jimage'),'extract','--dir',str(extract),str(runtime/'lib/modules')]
p=subprocess.run(command,capture_output=True,text=True)
(root/'jimage-command.json').write_text(json.dumps(dict(command=command,exit=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2));p.check_returncode()
classes=build/'classes';linked=extract/'com.holdmyspot.codexunleashed.tooling'
checks={p.relative_to(classes).as_posix():dict(compiled=sha(p),linked=sha(linked/p.relative_to(classes)))for p in classes.rglob('*')if p.is_file() and p.suffix!='.class'}
jar=zipfile.ZipFile(build/'modules/tooling-cli-1.0-SNAPSHOT.jar')
class_checks={p.relative_to(classes).as_posix():sha(p)==hashlib.sha256(jar.read(p.relative_to(classes).as_posix())).hexdigest()for p in classes.rglob('*.class')if p.name!='module-info.class'}
assert class_checks and all(class_checks.values())
assert checks and all(x['compiled']==x['linked']for x in checks.values())
(root/'linked-class-equivalence.json').write_text(json.dumps(dict(runtimeModulesSha256=sha(runtime/'lib/modules'),resourcesEqual=True,checks=checks,compiledClassesEqualPackagedJar=class_checks,linkedClassTransformation="Unmodified committed DistributionMain uses --strip-debug; linked class byte equality is not claimed"),indent=2)+'\n')
print(json.dumps(dict(sourceInputs=len(manifest),linkedClassesAndResources=len(checks),runtime=str(runtime))))
