import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

/**
 * Retains Linux close-notification bytes and originating process identities without delaying consumers.
 * The caller starts this fixture before its workload and creates the stop file after collecting that
 * workload. Every event descriptor and the listener are closed, including on a capture failure.
 */
public final class FanotifyCapture
{
    /** Linux fanotify close events, from linux/fanotify.h; no permission events are requested. */
    private static final long CLOSE_EVENTS = 0x18L;
    /** Queue-loss notification from linux/fanotify.h; any occurrence rejects complete coverage. */
    private static final long QUEUE_OVERFLOW = 0x4000L;
    /** Native bindings belong to this one collector; no shared native state is mutated. */
    private final SymbolLookup symbols;
    /** Linker used only to bind the libc operations this collector requires. */
    private final Linker linker;
    /** Native close, shared by listener and delivered inode descriptor cleanup. */
    private final MethodHandle close;
    /** Native read, used for the notification queue and retained inode bytes. */
    private final MethodHandle read;
    /** Native errno address on the collector's platform thread. */
    private final MethodHandle errnoLocation;

    /**
     * Binds the Linux LP64 libc operations without creating a listener.
     * @throws IOException if libc does not expose a required operation
     */
    private FanotifyCapture() throws IOException
    {
        this.linker = Linker.nativeLinker();
        this.symbols = linker.defaultLookup();
        this.close = bind("close", FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.JAVA_INT));
        this.read = bind("read", FunctionDescriptor.of(ValueLayout.JAVA_LONG, ValueLayout.JAVA_INT,
            ValueLayout.ADDRESS, ValueLayout.JAVA_LONG));
        this.errnoLocation = bind("__errno_location", FunctionDescriptor.of(ValueLayout.ADDRESS));
    }

    /**
     * Runs the collector until the stop file exists and its queue has been drained.
     * Each output line contains queue ordinal, mask, PID, base64 pathname, and base64 file bytes.
     * The ready file is published only after the mount mark succeeds. Output excludes events caused
     * by this collector and files outside the owned input root; all events are nevertheless drained.
     * @param arguments owned input root, output TSV, ready file, and stop file, in that order
     * @throws IllegalArgumentException if four paths are not supplied
     * @throws UnsupportedOperationException if the host is not Linux LP64
     * @throws IOException if setup, queue reading, byte retention, or descriptor cleanup fails
     * @throws InterruptedException if the collector thread is interrupted
     */
    public static void main(String[] arguments) throws IOException, InterruptedException
    {
        if (arguments.length != 4)
            throw new IllegalArgumentException("Expected owned root, output TSV, ready file, and stop file");
        if (!System.getProperty("os.name").equals("Linux") || ValueLayout.ADDRESS.byteSize() != 8)
            throw new UnsupportedOperationException("This capture fixture requires Linux LP64");
        Path root = Path.of(arguments[0]).toRealPath();
        Path output = Path.of(arguments[1]);
        Path ready = Path.of(arguments[2]);
        Path stop = Path.of(arguments[3]);
        FanotifyCapture capture = new FanotifyCapture();
        capture.run(root, output, ready, stop);
    }

    /**
     * Binds one required libc symbol to its documented native descriptor.
     * @param name libc symbol
     * @param descriptor native result and argument layouts
     * @return callable native binding
     * @throws IOException if the symbol is unavailable
     */
    // Binding Linux fanotify requires FFM's restricted downcall API; no Java API supplies these events.
    @SuppressWarnings("restricted")
    private MethodHandle bind(String name, FunctionDescriptor descriptor) throws IOException
    {
        MemorySegment symbol = symbols.find(name).orElseThrow(() -> new IOException("Missing libc symbol: " + name));
        return linker.downcallHandle(symbol, descriptor);
    }

    /**
     * Invokes a native binding while preserving invocation failures at this fixture boundary.
     * @param handle native operation
     * @param arguments native arguments matching the bound descriptor
     * @return native result, including negative native error results
     * @throws IOException if the foreign invocation itself fails
     */
    private Object invoke(MethodHandle handle, Object... arguments) throws IOException
    {
        try
        {
            return handle.invokeWithArguments(arguments);
        }
        catch (Throwable failure)
        {
            throw new IOException("Native capture invocation failed", failure);
        }
    }

    /**
     * Reads the current native errno before another native operation can replace it.
     * @return Linux errno number on this platform thread
     * @throws IOException if errno cannot be obtained
     */
    // Linux libc owns the returned int pointer; its four-byte extent is defined by __errno_location.
    @SuppressWarnings("restricted")
    private int errno() throws IOException
    {
        MemorySegment address = (MemorySegment) invoke(errnoLocation);
        return address.reinterpret(4).get(ValueLayout.JAVA_INT, 0);
    }

    /**
     * Closes an owned native descriptor and rejects failed cleanup.
     * @param descriptor listener or delivered inode descriptor owned by this collector
     * @throws IOException if close fails
     */
    private void close(int descriptor) throws IOException
    {
        int result = (int) invoke(close, descriptor);
        if (result != 0)
            throw new IOException("close failed for owned descriptor " + descriptor + ": errno=" + errno());
    }

    /**
     * Owns one mount listener and writes complete close records until the caller stops it.
     * @param root only descendant inode bytes are retained
     * @param output newly created TSV record file
     * @param ready newly created readiness marker
     * @param stop caller-created stop marker
     * @throws IOException if any native or file operation fails, including queue overflow
     * @throws InterruptedException if waiting for native events is interrupted
     */
    private void run(Path root, Path output, Path ready, Path stop) throws IOException, InterruptedException
    {
        MethodHandle initialize = bind("fanotify_init", FunctionDescriptor.of(ValueLayout.JAVA_INT,
            ValueLayout.JAVA_INT, ValueLayout.JAVA_INT));
        MethodHandle mark = bind("fanotify_mark", FunctionDescriptor.of(ValueLayout.JAVA_INT,
            ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.JAVA_LONG,
            ValueLayout.JAVA_INT, ValueLayout.ADDRESS));
        int listener = (int) invoke(initialize, 3, 0x80000);
        if (listener < 0)
            throw new IOException("fanotify_init notification listener failed: errno=" + errno());
        IOException pendingFailure = null;
        try (Arena arena = Arena.ofConfined(); BufferedWriter writer = Files.newBufferedWriter(output,
            StandardCharsets.UTF_8, java.nio.file.StandardOpenOption.CREATE_NEW))
        {
            int result = (int) invoke(mark, listener, 0x11, CLOSE_EVENTS, -100,
                arena.allocateFrom(root.toString()));
            if (result < 0)
                throw new IOException("fanotify_mark owned mount failed: errno=" + errno());
            MemorySegment events = arena.allocate(65536, 8);
            MemorySegment bytes = arena.allocate(65536, 8);
            long ordinal = 0;
            Files.writeString(ready, "listener=" + listener + "\npid=" + ProcessHandle.current().pid() + "\n",
                java.nio.file.StandardOpenOption.CREATE_NEW);
            while (true)
            {
                long count = (long) invoke(read, listener, events, events.byteSize());
                if (count < 0)
                {
                    int error = errno();
                    if (error == 4)
                        continue;
                    if (error != 11)
                        throw new IOException("fanotify queue read failed: errno=" + error);
                    if (Files.exists(stop))
                        break;
                    Thread.sleep(2);
                    continue;
                }
                if (count == 0)
                    throw new IOException("fanotify queue unexpectedly reached EOF");
                ordinal = retain(events, count, bytes, root, writer, ordinal);
                writer.flush();
            }
        }
        catch (IOException failure)
        {
            pendingFailure = failure;
            throw failure;
        }
        finally
        {
            try
            {
                close(listener);
            }
            catch (IOException failure)
            {
                if (pendingFailure == null)
                    throw failure;
                pendingFailure.addSuppressed(failure);
            }
        }
    }

    /**
     * Drains all delivered inode descriptors, retaining relevant bytes in kernel queue order.
     * @param events native metadata buffer
     * @param count bytes returned by the successful native queue read
     * @param bytes reusable native buffer for reading one retained inode
     * @param root owned subtree whose bytes may be retained
     * @param writer TSV evidence destination
     * @param ordinal last processed native event ordinal
     * @return ordinal after this complete batch
     * @throws IOException if metadata is invalid, bytes cannot be retained, or any descriptor cannot close
     */
    private long retain(MemorySegment events, long count, MemorySegment bytes, Path root,
        BufferedWriter writer, long ordinal) throws IOException
    {
        IOException failure = null;
        for (long offset = 0; offset < count;)
        {
            if ((count - offset) < 24)
                throw new IOException("Truncated fanotify metadata");
            int length = events.get(ValueLayout.JAVA_INT, offset);
            int version = Byte.toUnsignedInt(events.get(ValueLayout.JAVA_BYTE, offset + 4));
            long mask = events.get(ValueLayout.JAVA_LONG, offset + 8);
            int descriptor = events.get(ValueLayout.JAVA_INT, offset + 16);
            int pid = events.get(ValueLayout.JAVA_INT, offset + 20);
            ++ordinal;
            try
            {
                if (length < 24 || length > (count - offset) || version != 3)
                    throw new IOException("Invalid fanotify metadata length/version");
                if ((mask & QUEUE_OVERFLOW) != 0)
                    throw new IOException("FAN_Q_OVERFLOW: complete event coverage cannot be established");
                if (descriptor < 0)
                    throw new IOException("Native close event lacks an inode descriptor");
                if (pid != ProcessHandle.current().pid())
                    retainInode(descriptor, mask, pid, root, writer, bytes, ordinal);
            }
            catch (IOException error)
            {
                if (failure == null)
                    failure = error;
                else
                    failure.addSuppressed(error);
            }
            finally
            {
                if (descriptor >= 0)
                {
                    try
                    {
                        close(descriptor);
                    }
                    catch (IOException error)
                    {
                        if (failure == null)
                            failure = error;
                        else
                            failure.addSuppressed(error);
                    }
                }
            }
            if (length < 24 || length > (count - offset))
                break;
            offset += length;
        }
        if (failure != null)
            throw failure;
        return ordinal;
    }

    /**
     * Reads a relevant retained inode directly, even after its original pathname was removed.
     * @param descriptor delivered inode descriptor
     * @param mask kernel event mask
     * @param pid authentic originating process ID
     * @param root owned subtree
     * @param writer evidence destination
     * @param bytes reusable native buffer
     * @param ordinal kernel queue position across all delivered events
     * @throws IOException if a relevant inode cannot be read or exceeds the 65536-byte fixture limit
     */
    private void retainInode(int descriptor, long mask, int pid, Path root, BufferedWriter writer,
        MemorySegment bytes, long ordinal) throws IOException
    {
        Path fdPath = Path.of("/proc/self/fd").resolve(Integer.toString(descriptor));
        String target = Files.readSymbolicLink(fdPath).toString();
        String original = target;
        if (target.endsWith(" (deleted)"))
            original = target.substring(0, target.length() - " (deleted)".length());
        Path inodePath = Path.of(original).normalize();
        if (!inodePath.startsWith(root))
            return;
        String name = inodePath.getFileName().toString();
        boolean isAuthorityRecord = name.endsWith(".properties") || name.endsWith(".properties.pending") ||
            java.util.Set.of("terminate.xml", "terminate.xml.pending").contains(name) ||
            name.startsWith("capture-probe-");
        if (!isAuthorityRecord)
            return;
        java.io.ByteArrayOutputStream content = new java.io.ByteArrayOutputStream();
        while (true)
        {
            long count = (long) invoke(read, descriptor, bytes, bytes.byteSize());
            if (count < 0)
                throw new IOException("Retained inode read failed: errno=" + errno());
            if (count == 0)
                break;
            if ((content.size() + count) > bytes.byteSize())
                throw new IOException("Retained record exceeds 65536 bytes");
            content.writeBytes(bytes.asSlice(0, count).toArray(ValueLayout.JAVA_BYTE));
        }
        Base64.Encoder encoder = Base64.getEncoder();
        writer.write(ordinal + "\t" + mask + "\t" + pid + "\t" +
            encoder.encodeToString(target.getBytes(StandardCharsets.UTF_8)) + "\t" +
            encoder.encodeToString(content.toByteArray()) + "\n");
    }
}
