"""Validate exported native evidence from immutable raw bytes; no native execution."""
from pathlib import Path
import base64, hashlib, json, re, struct, xml.etree.ElementTree as ET
import sys
r=Path(__file__).resolve().parent;e=Path(sys.argv[1]).resolve();case_name=sys.argv[2];case=e/'cases'/case_name
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,d):(r/n).write_text(json.dumps(d,indent=2)+'\n')
gates={}
def gate(n,condition):
 assert condition,n
 gates[n]='passed'
d=load(case/'result.json');training=load(e/'cases/pressure-training/result.json')
gate('savedFinalValidatorIdentity',sha(e/'validate-genuine-pressure-final.py')==sha(r/'validate-genuine-pressure-final.py'))
gate('executedPressureFixtureIdentity',all(sha(e/n)==sha(r/n)for n in ['physical-helper.c','genuine-pressure.py','paired-cli-build.py','pressure-watchdog.py']))
manifest=load(r/'cli-source-manifest.json');gate('exact298SourceInputs',len(manifest)==298 and all(sha(e/'source'/n)==h for n,h in manifest.items()))
bundle=load(e/'bundle-result.json');linked=load(e/'linked-class-equivalence.json');gate('actualBundledPackageIdentity',bundle['sourceManifestSha256']==sha(r/'cli-source-manifest.json')==d['sourceManifestSha256'] and next(v for k,v in bundle['identities'].items() if k.endswith('/lib/modules'))==linked['runtimeModulesSha256'] and linked['resourcesEqual'])
gate('installedPublicMainBoundary',d['command'][0]==bundle['cli'] and d['command'][1:4]==['schedule','--tool','cargo'] and d['command'][-8:]==['--','build','--offline','--release','--target',load(e/'native-tool-identities.json')['compilerWorkloadTarget'],'-p','app'])
gate('realMuslBuildStatusAndStreams',d['exit']==0 and (case/'stdout').read_bytes()==b'' and (case/'stdin').read_bytes()==b'A\0\xff\n')
gate('originalFifoIdentityAndExactOpaqueByte',d['fifoFinalHex']=='2b' and all(d['fifo'][k]==d['fifoFinalIdentity'][k] for k in ['device','inode']))
faults=d['selectedPhysicalCompilers'];gate('twoConcurrentAuthenticatedCompilers',len(faults)==2 and [f['attempt']for f in faults]==[0,1])
for f in faults:
 status=f['native']['status'];gate('configuredCredentialsEmptyGroups-'+f['crate'],re.search(r'^Uid:\s+1001\s+1001\s+1001\s+1001$',status,re.M) and re.search(r'^Gid:\s+1001\s+1001\s+1001\s+1001$',status,re.M) and re.search(r'^Groups:[ \t]*$',status,re.M))
log=(case/'stderr').read_text(errors='replace');order=[];journal=[]
for line in log.splitlines():
 m=re.search(r'INFO: Linux attempt ([\da-f-]+)/(\d+) (.*)',line)
 if m:
  action,attempt,event=m.group(1),int(m.group(2)),m.group(3);journal.append(dict(action=action,attempt=attempt,event=event))
  if event.startswith('accepted-result'):order.append(attempt)
gate('physicalCaseHasNoAllocationDenial', 'Linux Cargo allocation-blocked' not in log)
gate('newestThenOldestThenOriginalPositionRetryThenTail',order==[1,0,2,3])
for attempt in range(4):
 entries=[j for j in journal if j['attempt']==attempt];events=[j['event'] for j in entries]
 gate('completeContainmentCollection-'+str(attempt),len(entries)==7 and events[0].startswith('registered ') and events[1].startswith('actual-zero ') and events[2]=='instrumentation-closed' and events[3]=='collect-published' and events[4].startswith('accepted-result ') and events[5]=='unregistered' and events[6].startswith('cleanup-result '))
gate('newestTerminatedOthersNatural',all(('rootExit=137' in j['event'] and 'terminationRequested=true' in j['event']) if j['attempt']==1 else ('rootExit=0' in j['event'] and 'terminationRequested=false' in j['event']) for j in journal if j['event'].startswith('accepted-result ')))
action_b=faults[1]['action'];gate('freshVictimSameLogicalAction',all(j['action']==action_b for j in journal if j['attempt'] in [1,2]))
# Authenticate retained XML bytes, rather than accepting copied controller dictionaries alone.
xml={sha(p):{x.attrib['key']:x.text for x in ET.fromstring(p.read_bytes()).findall('entry')}for p in (case).glob('receipt-*.xml')}
for key,v in d['receipts'].items():gate('rawReceipt-'+key.split(':')[-1][:12],xml[key.rsplit(':',1)[1]]==v['values'])
launches=[]
for p in xml.values():
 args=[p.get('borrowed.arg.'+str(i))for i in range(int(p.get('borrowed.commandCount','0')))];
 if p.get('phase')=='LAUNCH' and '--crate-name' in args:launches.append(dict(crate=args[args.index('--crate-name')+1],values=p))
b=[x['values']for x in launches if x['crate']==faults[1]['crate']];b.sort(key=lambda p:int(p['borrowed.sequence']))
gate('originalWrapperOuterSlotAcrossRetry',len(b)==2 and [p['borrowed.sequence']for p in b]==['1','2'] and all(b[0][k]==b[1][k] for k in ['borrowed.pid','borrowed.birth','borrowed.action','borrowed.directory','borrowed.cgroup']) and b[0]['borrowed.action']==action_b)
ignore={'borrowed.sequence','borrowed.capability'}
gate('exactRetryArgvEnvironmentSemantics', {k:v for k,v in b[0].items()if k.startswith(('borrowed.arg.','borrowed.env.'))}=={k:v for k,v in b[1].items()if k.startswith(('borrowed.arg.','borrowed.env.'))})
gate('freshAuthenticatedRetryCapability',b[0]['borrowed.capability']!=b[1]['borrowed.capability'] and all(len(base64.b64decode(p['borrowed.capability'],validate=True))==32 and any(base64.b64decode(p['borrowed.capability']))for p in b))
wrappers=[x for x in d['processes']if x['pid']==int(b[0]['borrowed.pid']) and x['birth']==int(b[0]['borrowed.birth'])];gate('independentlyObservedOriginalWrapperBirth',bool(wrappers))
profiles=[]
for name,h in d['history'].items():
 p=e/name;v=p.read_bytes();payload=v[:-32];gate('profile-'+p.name,sha(p)==h and hashlib.sha256(payload).digest()==v[-32:] and struct.unpack('>i',payload[:4])[0]==1 and struct.unpack('>H',payload[4:6])[0]==64 and len(payload)==78)
 identity=payload[6:70].decode('ascii');amount=struct.unpack('>q',payload[70:78])[0];gate('positiveMeasuredProfile-'+p.name,amount>0 and p.name.startswith(identity+'-'));profiles.append(dict(path=name,identity=identity,observedBytes=amount,trained=name in training['history']))
trained={p['identity']for p in profiles if p['trained']};new={p['identity']for p in profiles if not p['trained']};gate('measuredHistoryReuseAcrossInvocations',len(trained)>=3 and len(trained&new)>=3 and training['fixtureBefore']==d['fixtureBefore'])
pressure=load(case/'pressure.json');observations=[json.loads(line)for line in (case/'pressure-observations.jsonl').read_text().splitlines()];helper=[json.loads(line)for line in (case/'helper.jsonl').read_text().splitlines()]
gate('noAllocatorInterpositionPauseOrVmControl',not pressure['allocatorInterposition'] and not pressure['controllerPause'] and not pressure['syntheticEstimates'] and not d['faults'] and not d.get('deliveryPause') and pressure['vmBefore']==pressure['vmAfter'])
gate('boundedHelperReallyTouchedPages',any(x['event']=='resident-growth' and x['touchedBytes']>=64*1024*1024 for x in helper))
def values(text):return {line.split()[0]:int(line.split()[1])for line in text.splitlines()}
def stall(text):return int(re.search(r'^some .*?total=(\d+)',text,re.M)[1])
minimum=min(x['memory']['MemAvailable']for x in observations);total=pressure['initialMemory']['MemTotal']
gate('actualGlobalPhysicalScarcity',minimum<pressure['activation']['memory']['MemAvailable'] and max(values(x['helper']['statistics']).get('anon',0)for x in observations)>0)
gate('noGlobalKernelOomKill',all('oom_kill'in values(x['vmstat'])for x in observations) and len({values(x['vmstat'])['oom_kill']for x in observations})==1)
gate('actualGlobalPsiGrowth',max(stall(x['psi'])for x in observations)>min(stall(x['psi'])for x in observations))
for item in observations:gate('noKernelOomKillAt-'+str(item['monotonic']),all(values(item['delegation']['events']).get(k,0)==0 for k in ['oom','oom_kill','oom_group_kill']))
gate('productDelegationLimitUnlimited',all(x['delegation']['maximum'].strip()=='max'for x in observations))
# Exact JDK-decoded accepted batches replace pathname-poll samples.
correlation=load(case/'physical-correlation.json');authority=[]
for item in correlation['correlations']:
 for key in ['previous','accepted']:
  host=item[key]['host'];authority.append(dict(host,raw='capture-events.tsv',sha256=correlation['captureSha256']))
gate('actualProductionPhysicalSamplesRetained',len(authority)>=2 and max(int(x['stall'])for x in authority)>min(int(x['stall'])for x in authority) and min(int(x['hostAvailable'])for x in authority)<max(int(x['hostAvailable'])for x in authority))
gate('nativeGlobalAndEffectiveAvailabilityAgree',all(x['hostAvailable']==x['available']for x in authority))
oldest,newest=faults
results=[v for v in d['receipts'].values()if v['values'].get('phase')=='RESULT' and v['values'].get('root.pid')==str(newest['native']['pid'])]
gate('nativeVictimActualTerminalReceipt',len(results)==1 and results[0]['values'].get('root.exit')=='137' and results[0]['values'].get('instrumentation.closed')=='true' and results[0]['values'].get('termination')=='true')
gate('victimWholeTerminalBeforeHelperRelease',pressure['closeReason']=='actual-newest-victim-terminal' and pressure['victimTerminalBeforeRelease']==results[0])
gate('normalWatchdogAndNativeHelperRelease',pressure['cleanup']['passed'] and pressure['cleanup']['reason']=='normal-owner-finish' and pressure['watchdogExit']==pressure['helperExit']==0 and not pressure['cleanupFailures'] and not pressure['cleanup']['vmSysctlsChanged'])
gate('noFallbackKillAndInvocationOwnershipClosed',not d['fallbackKill'] and d['passedExecution'] and not d['remainingScratch'] and not d['remainingContainment'])
useful=load(case/'useful-output.json')
gate('genuineCompilerOutputExecutesWithExactUsefulStreams',useful['exit']==7 and useful['inputHex']=='4100ff0a' and useful['stdoutHex']=='47415445004100ff0a' and useful['stderrHex']=='45525200' and useful['uid']==useful['gid']==1001 and useful['supplementaryGroups']==[])
swap_delta=max(item['memory']['SwapTotal']-item['memory']['SwapFree'] for item in observations)-(pressure['initialMemory']['SwapTotal']-pressure['initialMemory']['SwapFree'])
save('raw-order-journal.json',journal);save('raw-authority-journal.json',launches);save('measured-profile-journal.json',profiles);save('production-pressure-journal.json',authority)
save('genuine-pressure-validation.json',dict(task_contract='acknowledged',passed=True,gates=gates,acceptedAttemptOrder=order,minimumObservedAvailableBytes=minimum,maximumHelperResidentAnonBytes=max(values(x['helper']['statistics']).get('anon',0)for x in observations),model=pressure['model'],swapGrowthObservedBytes=max(0,swap_delta),swapGrowthClaim=swap_delta>0,limits=['Physical-pressure acceptance is distinct from previously accepted controlled allocation denial','Bounded owned anonymous pages and file refaulting; no allocator fault injection, VM setting changes or controller pause'],package=bundle))
print(json.dumps(dict(passed=True,gates=len(gates),acceptedAttemptOrder=order,profiles=len(profiles),swapGrowthBytes=max(0,swap_delta))))
