"""Exclude inherited provider credentials from shareable evidence without changing native inputs."""
from pathlib import Path
import base64,hashlib,io,json,re,tarfile
r=Path(__file__).resolve().parent
sensitive=re.compile(r'TOKEN|SECRET|PASSWORD|PRIVATE_KEY|CREDENTIAL',re.I)
for arch in ['x64','arm64']:
 owner=r/(arch+'-final');source=owner/'connected-evidence.tar.gz';source.chmod(0o600)
 changed=[];files={}
 def visit(value,location):
  """Keep compiler input bytes intact; redact only named inherited credential values."""
  if isinstance(value,list):return [visit(v,location+'/'+str(i))for i,v in enumerate(value)]
  if not isinstance(value,dict):return value
  output={}
  for key,item in value.items():
   path=location+'/'+key
   if key=='environment'and isinstance(item,str):
    raw=base64.b64decode(item,validate=True);parts=raw.split(b'\0');keys=[]
    for index,part in enumerate(parts):
     name,separator,body=part.partition(b'=')
     if separator and sensitive.search(name.decode(errors='replace')):
      keys.append(name.decode());parts[index]=name+b'=<credential omitted; sha256='+hashlib.sha256(body).hexdigest().encode()+b'>'
    if keys:
     changed.append(dict(path=path,keys=keys,originalEnvironmentSha256=hashlib.sha256(raw).hexdigest()))
     item=base64.b64encode(b'\0'.join(parts)).decode()
    output[key]=item
   else:output[key]=visit(item,path)
  return output
 with tarfile.open(source)as archive:
  original=json.loads(archive.extractfile('inventory.json').read())
  for member in archive.getmembers():
   if member.name=='inventory.json':continue
   data=archive.extractfile(member).read();before=len(changed)
   if member.name.endswith('.json'):
    parsed=visit(json.loads(data),member.name)
    if len(changed)>before:data=(json.dumps(parsed,indent=2)+'\n').encode()
   elif member.name.endswith('.jsonl'):
    parsed=[visit(json.loads(line),member.name+'/'+str(i))for i,line in enumerate(data.splitlines())]
    if len(changed)>before:data=(''.join(json.dumps(v)+'\n'for v in parsed)).encode()
   files[member.name]=data
 # Source, protocol bytes and the selected compiler environments remain exact.
 assert changed and all(not x['path'].startswith('product/source/')for x in changed)
 inventory={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in files.items()}
 receipt=dict(task_contract='acknowledged',originalArchiveSha256=hashlib.sha256(source.read_bytes()).hexdigest(),originalArchiveCleanRetrievalVerified=True,redactions=changed,claim='Only inherited observer/controller provider credential values omitted; original environment digests retained. Exact consumed protocol bytes, native compiler argv/environment, source and all acceptance predicates remain unchanged.')
 files['credential-omission.json']=(json.dumps(receipt,indent=2)+'\n').encode();inventory['credential-omission.json']=dict(bytes=len(files['credential-omission.json']),sha256=hashlib.sha256(files['credential-omission.json']).hexdigest())
 files['inventory.json']=(json.dumps(dict(original,files=inventory,credentialOmission='credential-omission.json'),indent=2)+'\n').encode()
 safe=owner/'shareable-evidence.tar.gz'
 with tarfile.open(safe,'w:gz')as archive:
  for name,data in sorted(files.items()):
   member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0;archive.addfile(member,io.BytesIO(data))
 with tarfile.open(safe)as archive:
  for member in archive.getmembers():
   assert member.isfile()and '..'not in Path(member.name).parts and not Path(member.name).is_absolute()
   data=archive.extractfile(member).read()
   if member.name!='inventory.json':assert hashlib.sha256(data).hexdigest()==inventory[member.name]['sha256']
  archive.extractall(owner/'shareable',filter='data')
 (owner/'credential-omission.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(dict(architecture=arch,credentialFieldsOmitted=len(changed),shareableSha256=hashlib.sha256(safe.read_bytes()).hexdigest(),bytes=safe.stat().st_size)))
