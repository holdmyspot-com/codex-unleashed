"""Send one short command through the owned SSH FIFO and collect its exact result.

Call only after the preceding command has returned. Each invocation records its
command and output under this owned directory. A unique shell marker identifies
completion; EOF or a quiet transcript never counts as command completion. The
root agent retains and cleans this directory after the worker's final consumer.
"""
import json, re, sys, time, uuid
from pathlib import Path
root = Path(__file__).resolve().parent
command = sys.argv[1]
marker = 'CP3_DONE_' + uuid.uuid4().hex
wire = command + "; printf '\\n" + marker + ":%s\\n' \"$?\"\n"
assert len(wire.encode()) < 512, 'Command exceeds the terminal input bound'
transcript = root / 'ssh-transcript.raw'
offset = transcript.stat().st_size
(root / (marker + '.command.json')).write_text(json.dumps({'command': command, 'offset': offset}) + '\n')
with (root / 'ssh-input').open('w') as output:
    output.write(wire)
pattern = re.compile(rb'(?:\r?\n)' + marker.encode() + rb':([0-9]+)\r?\n')
while True:
    with transcript.open('rb') as capture:
        capture.seek(offset)
        data = capture.read()
    match = pattern.search(data)
    if match:
        (root / (marker + '.output')).write_bytes(data)
        status = int(match.group(1))
        print(data.decode(errors='replace'))
        raise SystemExit(status)
    time.sleep(0.2)
