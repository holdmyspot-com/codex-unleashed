"""Own one foreground SSH PTY and retained transcript through original-worker exit.

Usage: python3 ssh-owner.py CONNECTION_JSON
JSON must contain a destination parsed from the provider's live connection artifact.
Only the local owned key and pinned CA are used. Standard input is exact UTF-8 shell
input; the owner forwards it only after the caller has observed a remote prompt.
The caller must exit the hosted shell and wait for this process to terminate before
removing its key, transcript or provider-owned temporary resources.
"""
import json,os,pty,select,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
connection=json.loads(Path(sys.argv[1]).read_text())
master,slave=pty.openpty()
command=['ssh','-tt','-i',str(root/'client-key'),'-o','IdentitiesOnly=yes','-o','UserKnownHostsFile='+str(root/'known_hosts'),'-o','StrictHostKeyChecking=yes',connection['destination']]
(root/'ssh-command.json').write_text(json.dumps(command,indent=2)+'\n')
child=subprocess.Popen(command,stdin=slave,stdout=slave,stderr=slave,close_fds=True)
os.close(slave)
(root/'ssh-client-pid').write_text(str(child.pid)+'\n')
with (root/'ssh-transcript.raw').open('ab',buffering=0) as transcript:
 while True:
  ready,_,_=select.select([master,sys.stdin.buffer],[],[],1)
  if master in ready:
   try:data=os.read(master,65536)
   except OSError:data=b''
   if not data:break
   transcript.write(data);sys.stdout.buffer.write(data);sys.stdout.buffer.flush()
  if sys.stdin.buffer in ready:
   data=os.read(sys.stdin.fileno(),65536)
   if not data:
    child.terminate();child.wait();os.close(master)
    raise RuntimeError('Client input closed before hosted shell exit; local SSH retired, preserve original worker and reconnect')
   view=memoryview(data)
   while view:view=view[os.write(master,view):]
  if child.poll() is not None:break
status=child.wait();os.close(master)
(root/'ssh-exit.json').write_text(json.dumps({'exit':status})+'\n')
raise SystemExit(status)
