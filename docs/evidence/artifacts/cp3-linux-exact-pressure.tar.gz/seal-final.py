"""Seal the coherent reviewed source/control unit, excluding credentials and native bodies."""
from pathlib import Path
import hashlib,io,json,tarfile
r=Path(__file__).resolve().parent;files={}
def add(name,path):
 """Retain an exact named regular artifact under this handoff's manifest."""
 assert path.is_file()and not path.is_symlink();data=path.read_bytes();assert not data.startswith((b'\x7fELF',b'MZ',b'\xca\xfe\xba\xbe'));assert (b'-----BEGIN '+b'OPENSSH PRIVATE KEY-----')not in data;files[name]=data
for name in ['report.json','README.md','failed-attempts.json','ownership.json','selection.json','eta-history.json','final-recreation-receipt.json','seal-final.py']:
 add(name,r/name)
for name in ['FanotifyCapture.java','PropertiesDecoder.java','dependencies.json','resolution.json']:
 add('fixtures/'+name,r/'recreation'/name)
for name in ['validate-physical-correlation.py','validate-genuine-pressure-final.py','capture-probe.py','finish-runtime.py','export-connected.py','sanitize-export.py','upload.py','upload-incoming.py','retrieve.py']:
 add('fixtures/'+name,r/name)
for arch,worker in [('x64',r),('arm64',r/'arm64-worker')]:
 o=r/(arch+'-final')
 for name in ['shareable-evidence.tar.gz','retrieval-verification.json','final-validation-command.json','shareable-validation.json','credential-omission.json']:
  add(arch+'/'+name,o/name)
 for name in ['physical-correlation.json','properties-decoder-receipt.json']:
  add(arch+'/final/'+name,o/'shareable/product/cases/physical-3'/name)
 for name in ['genuine-pressure-validation.json','raw-order-journal.json','raw-authority-journal.json','measured-profile-journal.json','production-pressure-journal.json']:
  add(arch+'/final/'+name,o/'shareable/product'/name)
 for suffix in ['terminal.json','terminal.log']:
  add(arch+'/provider-'+suffix,r/('provider-'+arch+'-'+suffix))
 add(arch+'/cleanup.json',r/(arch+'-cleanup.json'))
 for p in worker.glob('CP3_DONE_*.command.json'):
  command=json.loads(p.read_text())['command'];add(arch+'/commands/'+p.name,p)
  output=p.with_name(p.name.removesuffix('.command.json')+'.output')
  if output.exists()and 'base64 -w 128'not in command:add(arch+'/commands/'+output.name,output)
 for name in ['ssh-owner.py','remote.py','connection.json','provider-connection.json','ssh-command.json']:
  p=worker/name
  if p.exists():add(arch+'/client/'+name,p)
 transcript=worker/'ssh-transcript.raw';files[arch+'/client/ssh-closure.json']=(json.dumps(dict(exit=0,transcriptSha256=hashlib.sha256(transcript.read_bytes()).hexdigest(),tail=transcript.read_bytes()[-500:].decode(errors='replace')),indent=2)+'\n').encode()
 # Confirm safe nested inventory and every restored determining input.
 with tarfile.open(o/'shareable-evidence.tar.gz')as archive:
  index=json.loads(archive.extractfile('inventory.json').read())['files']
  for member in archive.getmembers():
   assert member.isfile()and not Path(member.name).is_absolute()and '..'not in Path(member.name).parts
   raw=archive.extractfile(member).read();assert not raw.startswith((b'\x7fELF',b'MZ'))
   if member.name!='inventory.json':assert len(raw)==index[member.name]['bytes']and hashlib.sha256(raw).hexdigest()==index[member.name]['sha256']
manifest={n:dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest())for n,d in sorted(files.items())}
files['handoff-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode();(r/'handoff-manifest.json').write_bytes(files['handoff-manifest.json'])
archive=r/'handoff.tar.gz'
with tarfile.open(archive,'w:gz')as out:
 for name,data in sorted(files.items()):
  member=tarfile.TarInfo(name);member.mode=0o644;member.size=len(data);member.mtime=0;out.addfile(member,io.BytesIO(data))
with tarfile.open(archive)as inp:
 assert len(inp.getmembers())==len(files)
 for member in inp.getmembers():assert inp.extractfile(member).read()==files[member.name]
receipt=dict(task_contract='acknowledged',gate='passed',archive=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files),manifestSha256=hashlib.sha256(files['handoff-manifest.json']).hexdigest(),liveHandles=[],localOwner='/root',retainedPrivateOriginals='Task temp only; excluded from shareable archive')
(r/'handoff-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
