"""Run the exact public producer command and retain its authentic process outcome."""
import os,json,subprocess
from pathlib import Path
w=Path(os.environ['CP3_WORK']);line=(w/'shared-prepare-producer.log').read_text().strip().splitlines()[-1];prepared=json.loads(line);root=Path(prepared['root']);command=json.loads((root/'command.json').read_text())
with (root/'main.stdout').open('w') as out,(root/'main.stderr').open('w') as err:
 process=subprocess.Popen(command['argv'],cwd=command['cwd'],env=command['environment'],stdout=out,stderr=err)
 stat=Path(f'/proc/{process.pid}/stat').read_text(); birth=int(stat[stat.rfind(')')+2:].split()[19])
 (root/'main-launch.json').write_text(json.dumps({'pid':process.pid,'birthTicks':birth,'wrapperPid':os.getpid()},indent=2))
 code=process.wait()
(root/'main-result.json').write_text(json.dumps({'argv':command['argv'],'exit':code},indent=2))
print('producer_root',root,'exit',code,flush=True)
print((root/'main.stderr').read_text()[-15000:]);raise SystemExit(code)
