"""Verify the sealed held-exec repair before updating the isolated shared runtime."""
import os,subprocess,tarfile,hashlib,json,zipfile
from pathlib import Path
w=Path(os.environ['CP3_WORK']); r=w/'leader-exec-repair';r.mkdir(exist_ok=True)
with tarfile.open(w/'leader-exec-repair.tar.gz') as t:t.extractall(r,filter='data')
jar=w/'shared-backend-composition/producer.jar';cp=f'{w}/test-classes:{w}/classes:{jar}'
flags=['javac','--release','27','-proc:none','-Xlint:all,-processing','-Werror','-Xdoclint:all/private']
def run(args,log,expected=0):
 with (r/log).open('w') as f:p=subprocess.run(args,cwd=w,stdout=f,stderr=subprocess.STDOUT)
 print(log,p.returncode,flush=True)
 if p.returncode!=expected:print((r/log).read_text());raise RuntimeError(log)
red=r/'red-source';red.mkdir(exist_ok=True);(red/'LinuxBazelTraceHelper.java').write_bytes((r/'LinuxBazelTraceHelper.red.java').read_bytes())
rc=r/'red-classes';gc=r/'green-classes';rc.mkdir(exist_ok=True);gc.mkdir(exist_ok=True)
run(flags+['-cp',cp,'-d',str(rc),str(red/'LinuxBazelTraceHelper.java'),str(r/'LinuxBazelHelperMainTest.java')],'red-compile.log')
run(['java','-cp',f'{rc}:{cp}','org.testng.TestNG','-d',str(r/'red-reports'),'-methods','com.holdmyspot.codexunleashed.scheduler.LinuxBazelHelperMainTest.authenticatesHeldLeaderExec'],'red-test.log',1)
assert 'unchangedLeaderExec' in (r/'red-test.log').read_text()
run(flags+['-cp',cp,'-d',str(gc),str(r/'LinuxBazelTraceHelper.java'),str(r/'LinuxBazelHelperMainTest.java')],'green-compile.log')
run(['java','-cp',f'{gc}:{cp}','org.testng.TestNG','-verbose','2','-d',str(r/'green-reports'),'-parallel','methods','-threadcount','8','-testclass','com.holdmyspot.codexunleashed.scheduler.LinuxBazelHelperMainTest,com.holdmyspot.codexunleashed.scheduler.LinuxBazelNamespaceHooksTest'],'green-test.log')
print((r/'green-test.log').read_text(),flush=True)
old=jar.with_name('producer-before-leader-repair.jar');jar.rename(old)
new={p.relative_to(gc).as_posix():p.read_bytes() for p in gc.rglob('LinuxBazelTraceHelper*.class')}
with zipfile.ZipFile(old) as z,zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_DEFLATED) as out:
 for item in z.infolist():
  if item.filename not in new:out.writestr(item,z.read(item))
 for n,b in new.items():out.writestr(n,b)
receipt={'jar':str(jar),'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'changedClasses':list(new),'red':'unchangedLeaderExec fails','green':'HelperMain and NamespaceHooks methods parallel8'}
(r/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
