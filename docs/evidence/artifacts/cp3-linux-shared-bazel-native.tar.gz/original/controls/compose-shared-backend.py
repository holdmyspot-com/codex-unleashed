"""Compose accepted native runtime with only shared backend and real readiness callers."""
from pathlib import Path
import os,hashlib,json,subprocess,tarfile,shutil,zipfile
w=Path(os.environ['CP3_WORK']);stage=w/'shared-backend-composition';stage.mkdir()
source=stage/'source';source.mkdir()
archive=w/'shared-backend-source-v2.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='2908843b9c5370ef0b8067abb834e4084bbb94d1d1f7607827a3e5a10566035f'
with tarfile.open(archive) as t:t.extractall(source,filter='data')
jar=w/'producer.jar';original=hashlib.sha256(jar.read_bytes()).hexdigest();assert original=='c191680b79d133e8faf3c1b3b13c0743b02779f7089f5743c34e002b9b7fcc74'
jdk=w/'zulu27.30.109-ca-jdk27.0.1.0.3-linux_x64';classes=stage/'classes';classes.mkdir()
sources=sorted((source/'tooling/cli/src/main/java').rglob('*.java'));assert len(sources)==6
command=[str(jdk/'bin/javac'),'--release','27','-proc:none','-Xlint:all,-processing','-Werror','-Xdoclint:all/private','-cp',str(w/'classes')+':'+str(jar),'-d',str(classes),*map(str,sources)]
with (stage/'compile.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
print((stage/'compile.log').read_text());assert result.returncode==0,result.returncode
composed=stage/'producer.jar';shutil.copyfile(jar,composed)
subprocess.run([str(jdk/'bin/jar'),'--update','--file',str(composed),'-C',str(classes),'.'],check=True)
names=['BazelNativeBackend','BazelBackendCredentials','LinuxBazelBackend','BazelRunner','LinuxBazelRunner','LinuxBazelProducer']
def changed(name):
 return any(name=='com/holdmyspot/codexunleashed/scheduler/'+n+'.class' or name.startswith('com/holdmyspot/codexunleashed/scheduler/'+n+'$') for n in names)
with zipfile.ZipFile(jar) as a,zipfile.ZipFile(composed) as b:
 preserved=[n for n in a.namelist() if not changed(n) and n!='META-INF/MANIFEST.MF'];assert all(a.read(n)==b.read(n) for n in preserved)
receipt={'originalJar':original,'composedJar':hashlib.sha256(composed.read_bytes()).hexdigest(),'compileExit':0,'compileCommand':command,'untouchedEntriesCompared':len(preserved),'sourceHashes':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'nativeBuilds':0,'nativeGates':'unrun'}
(stage/'composition.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
