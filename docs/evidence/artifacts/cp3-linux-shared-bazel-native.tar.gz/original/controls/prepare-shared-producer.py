"""Prepare a fresh accepted native fixture using the isolated shared-backend JAR."""
from pathlib import Path
import os,json,subprocess
w=Path(os.environ['CP3_WORK']);config=json.loads((w/'profile-input.json').read_text())
config['jar']=str(w/'shared-backend-composition/producer.jar')
input=w/'shared-profile-input.json';input.write_text(json.dumps(config,indent=2)+'\n')
with (w/'shared-prepare-producer.log').open('w') as log:
 result=subprocess.run(['python3',str(w/'prepare-producer.py'),str(input)],stdout=log,stderr=subprocess.STDOUT)
print((w/'shared-prepare-producer.log').read_text());raise SystemExit(result.returncode)
