"""Compose exact accepted caller classes and prepare the same genuine useful workload."""
from pathlib import Path
import os,tarfile,json,hashlib,subprocess,zipfile
w=Path(os.environ['CP3_WORK']);r=w/'public-dispatch';r.mkdir();c=r/'classes';c.mkdir()
with tarfile.open(w/'public-dispatch-classes.tar.gz') as t:t.extractall(c,filter='data')
manifest=json.loads((c/'class-manifest.json').read_text())
for n,d in manifest.items():assert hashlib.sha256((c/n).read_bytes()).hexdigest()==d
base=w/'shared-backend-composition/producer.jar';assert hashlib.sha256(base.read_bytes()).hexdigest()=='658c325eedc78a05ebeee37fcfe788e29a8852d2c401aa1c510468ee8214ac07'
jar=r/'producer.jar'
with zipfile.ZipFile(base) as z,zipfile.ZipFile(jar,'w',compression=zipfile.ZIP_DEFLATED) as out:
 for item in z.infolist():
  if item.filename not in manifest:out.writestr(item,z.read(item))
 for n in manifest:out.writestr(n,(c/n).read_bytes())
receipt={'baseJarSha256':hashlib.sha256(base.read_bytes()).hexdigest(),'jarSha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'classManifest':manifest,'nativeBuilds':0}
(r/'composition.json').write_text(json.dumps(receipt,indent=2))
config=json.loads((w/'shared-profile-input.json').read_text());config['jar']=str(jar)
p=w/'public-profile-input.json';p.write_text(json.dumps(config))
with (w/'public-prepare-producer.log').open('w') as log:subprocess.run(['python3',str(w/'prepare-producer.py'),str(p)],stdout=log,stderr=subprocess.STDOUT,check=True)
root=Path(json.loads((w/'public-prepare-producer.log').read_text().splitlines()[-1])['root']);command=json.loads((root/'command.json').read_text());argv=command['argv'];i=argv.index('com.holdmyspot.codexunleashed.scheduler.LinuxBazelProducer');profile=argv[i+1];argv[i:i+2]=['com.holdmyspot.codexunleashed.tooling.Main','schedule','--bazel-launch-config',profile];(root/'command.json').write_text(json.dumps(command,indent=2))
s=(w/'run-shared-main.py').read_text().replace('shared-prepare-producer.log','public-prepare-producer.log');(w/'run-public-main.py').write_text(s)
print(json.dumps({'root':str(root),'composition':receipt['jarSha256'],'entry':'Main schedule --bazel-launch-config','nativeBuilds':0}))
