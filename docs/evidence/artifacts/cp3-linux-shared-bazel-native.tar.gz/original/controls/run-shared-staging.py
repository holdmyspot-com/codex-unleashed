"""Stage existing validated native products with exact frozen4 common Java sources."""
import os,subprocess,json,hashlib
from pathlib import Path
w=Path(os.environ['CP3_WORK']);r=w/'shared-staging';r.mkdir();c=r/'classes';c.mkdir()
jar=w/'shared-backend-composition/producer.jar';source=Path(json.loads((w/'shared-profile-input.json').read_text())['distribution']);dest=r/'native-products'
assert hashlib.sha256((w/'BazelNativeBackend.java').read_bytes()).hexdigest()=='04604c6266e381cbcb8418e5f7bed909b6feeb3d249bb3fe683de245006edfee'
def run(args,log):
 with (r/log).open('w') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 print(log,p.returncode,flush=True)
 if p.returncode:print((r/log).read_text());raise RuntimeError(log)
run(['javac','--release','27','-proc:none','-Xlint:all,-processing','-Werror','-Xdoclint:all/private','-cp',str(jar),'-d',str(c),str(w/'BazelNativeBackend.java'),str(w/'StagedBackendProbe.java')],'compile.log')
cp=f'{c}:{jar}';java=['java','--enable-native-access=ALL-UNNAMED','-cp',cp]
run(java+['com.holdmyspot.codexunleashed.scheduler.BazelNativeBackend',str(source),str(dest)],'main.log')
run(java+['StagedBackendProbe',str(dest)],'validate.log');text=(r/'validate.log').read_text();assert 'target=x86_64-unknown-linux-musl' in text and 'products=7' in text
hashes={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}
staged={str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*') if p.is_file()}
assert hashes==staged,(hashes,staged)
receipt={'source':str(source),'destination':str(dest),'target':'x86_64-unknown-linux-musl','products':7,'allProductManifestLicenseHashesEqual':True,'hashes':hashes,'backendSourceSha256':'04604c6266e381cbcb8418e5f7bed909b6feeb3d249bb3fe683de245006edfee','nativeBuilds':0,'acceptedMainJarUnchanged':hashlib.sha256(jar.read_bytes()).hexdigest()}
(r/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
