import com.holdmyspot.codexunleashed.scheduler.BazelNativeBackend;
import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.nio.file.Path;
/** Validates actual staged native products without executing them. */
public final class StagedBackendProbe
{
    /** Prevents construction of this evaluation entry point. */
    private StagedBackendProbe() {}
    /**
     * Validates the actual host target and retained staged native identities.
     * @param args exactly one staged native directory
     * @throws IOException if real native validation fails
     */
    public static void main(String[] args) throws IOException
    {
        try (DefaultToolingScope scope = new DefaultToolingScope())
        {
            BazelNativeBackend.NativeTarget target = BazelNativeBackend.NativeTarget.forHost(
                System.getProperty("os.name"), System.getProperty("os.arch"));
            BazelNativeBackend.ValidatedDistribution value = BazelNativeBackend.validateDistribution(scope,
                target, Path.of(args[0]));
            System.out.println("target=" + value.target().triple());
            System.out.println("products=" + value.executables().size());
            System.out.println("manifestHash=" + value.manifestHash());
        }
    }
}
