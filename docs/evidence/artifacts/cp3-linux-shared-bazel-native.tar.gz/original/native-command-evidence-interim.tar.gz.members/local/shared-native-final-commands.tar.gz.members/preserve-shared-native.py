"""Preserve exact shared runtime and bounded noncredential acceptance receipts."""
import os,json,tarfile,hashlib,subprocess,shutil
from pathlib import Path
w=Path(os.environ['CP3_WORK']);e=w/'shared-native-evidence.tar.gz';base=Path('/var/lib/cp3-static-fXwlkr')
main=base/'producer-cdx2dzxs'; launch=json.loads((main/'main-launch.json').read_text());events=[json.loads(x) for x in next((main/'scratch').glob('bazel-producer-*/producer-events.jsonl')).read_text().splitlines()]
assert json.loads((main/'main-result.json').read_text())['exit']==0
assert sum(x['event']=='publication' and x['payload']['published'] is True for x in events)==1
assert sum(x['event']=='attempt-mapped' for x in events)==1
obj=main/'workspace/bazel-bin/tiny.o'; data=obj.read_bytes();assert data[:4]==b'\x7fELF'
proc=Path(f'/proc/{launch["pid"]}/stat');assert not proc.exists() or int(proc.read_text().split(') ',1)[1].split()[19])!=launch['birthTicks']
(w/'shared-main-verification.json').write_text(json.dumps({'elfBytes':len(data),'elfSha256':hashlib.sha256(data).hexdigest(),'originalProducer':launch,'originalBirthAbsent':True,'singleAttempt':True,'singlePublication':True,'actualStatus':0},indent=2))
allowed={'main-result.json','main-launch.json','main.stdout','main.stderr','terminal-result.json','controller-observations.json','held-native-trap.json','terminal-launch.json','signal.stdout','signal.stderr','cancel.stdout','cancel.stderr','producer-events.jsonl','consumer.stderr','consumer.stdout','namespace.stderr','private.stderr','storage.json.log','scheduler.json.log','worker.json.log'}
with tarfile.open(e,'w:gz') as t:
 for p in sorted(base.glob('producer-*')):
  for f in sorted(p.rglob('*')):
   if f.is_file() and f.name in allowed:t.add(f,arcname='producer-cases/'+str(f.relative_to(base)),recursive=False)
 for p in sorted(w.glob('shared-*.log')):t.add(p,arcname='verification/'+p.name)
 for n in ['shared-main-verification.json','shared-cgroups.json']:
  p=w/n
  if p.exists():t.add(p,arcname='verification/'+p.name)
 for n in ['composition.json','compile.log']:
  p=w/'shared-backend-composition'/n
  if p.exists():t.add(p,arcname='composition/'+n)
 for n in ['receipt.json','red-compile.log','red-test.log','green-compile.log','green-test.log','manifest.json','contract.json']:
  p=w/'leader-exec-repair'/n
  if p.exists():t.add(p,arcname='repair/'+n)
 cgroups={str(p):p.read_text() for p in Path('/sys/fs/cgroup/cp3-static-fXwlkr').rglob('cgroup.events')}
 (w/'shared-cgroups.json').write_text(json.dumps(cgroups,indent=2));t.add(w/'shared-cgroups.json',arcname='cleanup/cgroups.json')
receipt={'evidence':{'bytes':e.stat().st_size,'sha256':hashlib.sha256(e.read_bytes()).hexdigest()},'jarSha256':hashlib.sha256((w/'shared-backend-composition/producer.jar').read_bytes()).hexdigest(),'allCgroupsZero':all('populated 0' in x for x in cgroups.values())}
assert receipt['allCgroupsZero'],receipt
bundle=w/'runtime-shared-native.tar'
with tarfile.open(bundle,'w') as t:
 for n in ['shared-backend-composition','shared-backend-source-v2.tar.gz','leader-exec-repair.tar.gz','verify-leader-repair.py','shared-native-commands.tar.gz','compose-shared-backend.py','shared-native-evidence.tar.gz','shared-cgroups.json']:
  t.add(w/n,arcname=n)
receipt['runtime']={'bytes':bundle.stat().st_size,'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'name':'cp3-shared-native-41347615272'}
(w/'shared-native-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
env=os.environ.copy();env['RUNNER_DEBUG']='0'
for name,value in {'name':receipt['runtime']['name'],'path':str(bundle),'if-no-files-found':'error','retention-days':'3','compression-level':'0','overwrite':'false','include-hidden-files':'false','archive':'true'}.items():env['INPUT_'+name.upper()]=value
with (w/'shared-native-upload.log').open('w') as log:r=subprocess.run([shutil.which('node'),'/home/runner/work/_actions/actions/upload-artifact/bbbca2ddaa5d8feaa63e36b76fdaad77386f024f/dist/upload/index.js'],env=env,stdout=log,stderr=subprocess.STDOUT)
print('artifact_upload_exit',r.returncode);raise SystemExit(r.returncode)
