"""Prepare a genuine native ordinary root23 with child exec0 Bazel action in the owned fresh workspace."""
import os,json,shutil
from pathlib import Path
w=Path(os.environ['CP3_WORK']);root=Path(json.loads((w/'shared-prepare-producer.log').read_text().splitlines()[-1])['root']);profile=json.loads((root/'profile.json').read_text());workspace=root/'workspace'
p=workspace/'thread-case';shutil.copy2(Path('/var/lib/cp3-ordinary-d5P6kg/ordinary-root'),p)
(workspace/'actions.bzl').write_text('''def _run(ctx):
    output = ctx.actions.declare_file(ctx.label.name + ".o")
    ctx.actions.run(executable = "./thread-case", tools = [ctx.file.tool], outputs = [output], arguments = [], env = {"PATH": ".:/usr/bin:/bin", "LANG": "C.UTF-8", "HOME": "/tmp", "TMPDIR": "/tmp"}, mnemonic = "NativeOrdinaryRoot23")
    return [DefaultInfo(files = depset([output]))]
native_exit23 = rule(implementation = _run, attrs = {"tool": attr.label(allow_single_file = True)})
''')
(workspace/'BUILD.bazel').write_text('load(":actions.bzl", "native_exit23")\nnative_exit23(name = "tiny", tool = "thread-case")\n')
for p in [workspace/'thread-case',workspace/'actions.bzl',workspace/'BUILD.bazel']:os.chown(p,profile['trustedUid'],profile['trustedGid'])
s=(w/'run-terminal.py').read_text().replace('prepare-producer.log','shared-prepare-producer.log').replace("assert mode in ('SIGNAL','CANCEL')", "assert mode in ('SIGNAL','CANCEL','EXEC23')").replace("for phase in (['signal'] if mode=='SIGNAL' else ['cap','held']):", "for phase in ([] if mode=='EXEC23' else ['signal'] if mode=='SIGNAL' else ['cap','held']):")
(w/'run-exec23.py').write_text(s)
print(json.dumps({'root':str(root),'fixtureExecutable':str(workspace/'thread-case'),'nativeExecution':'unrun'}))
