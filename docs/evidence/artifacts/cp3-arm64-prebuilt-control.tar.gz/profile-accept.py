"""Run only the authentic ARM64 producer/prebuilt-packaging contract on the retained worker."""
from pathlib import Path
import hashlib,json,os,platform,shutil,subprocess,tarfile,time,urllib.request
root=Path(__file__).resolve().parent
assert root.parent==Path('/home/runner/work/_temp') and root.name.startswith('bazel-prebuilt-')
assert platform.machine()=='aarch64' and os.getuid()!=0
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for child in ['commands','tmp','downloads','tools']:(root/child).mkdir(exist_ok=True)
os.environ['TMPDIR']=str(root/'tmp')

def run(name,argv,env=None,expected=0):
    """Preserve the original process, exact command, logs and every failed attempt."""
    d=root/'commands'/name;d.mkdir(exist_ok=True)
    if (d/'success.json').exists():
        prior=json.loads((d/'success.json').read_text())
        if prior['argv']==list(map(str,argv)) and prior['expected']==expected:return prior
    attempt=d/f'{len(list(d.glob("[0-9]*")))+1:04d}';attempt.mkdir()
    settings=dict(os.environ);settings.update(env or {})
    record={'argv':list(map(str,argv)),'cwd':str(root),'environmentOverrides':env or {},'expected':expected}
    with (attempt/'stdout').open('wb') as out,(attempt/'stderr').open('wb') as err:
        process=subprocess.Popen(argv,cwd=root,env=settings,stdout=out,stderr=err)
        record.update(pid=process.pid,birth=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19]);(attempt/'started.json').write_text(json.dumps(record,indent=2)+'\n')
        start=time.monotonic();progress=start
        while process.poll() is None:
            time.sleep(1)
            if time.monotonic()-progress>=60:
                print(json.dumps({'running':name,'pid':process.pid,'elapsedSeconds':int(time.monotonic()-start),'nativeReceipts':[x.name for x in (root/'native-build/commands').glob('*.json')]}),flush=True);progress=time.monotonic()
        record['exit']=process.returncode
    (attempt/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'command':name,'exit':record['exit'],'receipt':str(attempt)}),flush=True)
    if record['exit']!=expected:raise RuntimeError('Retain original worker for '+name+'; inspect original logs')
    (d/'success.json').write_text(json.dumps(record,indent=2)+'\n');return record

source=root/'source'
build=root/'java-build'
jdk=root/'tools/zulu27.30.107-ca-jdk27.0.1-linux_aarch64'
java=jdk/'bin/java'
expected=json.loads((root/'backend/backend-manifest.json').read_text())
env={'JAVA_HOME':str(jdk),'PATH':str(root/'compiler-deny')+':'+str(jdk/'bin')+':/usr/bin:/bin','MAVEN_OPTS':'-Djava.io.tmpdir='+str(root/'tmp')}
run('actual-maven-prebuilt-profile',['/usr/bin/mvn','--batch-mode','--no-transfer-progress','-f',str(source/'tooling/cli/pom.xml'),'-Pruntime,bazel-native-backend','-Dmaven.test.skip=true','-Dtooling.build.directory='+str(build),'-Dmaven.repo.local='+str(root/'maven-repository'),'-Dbazel.backend.directory='+str(root/'backend'),'package'],env)
runtime=build/'runtime'
assert (runtime/'.complete').is_file() and not (root/'unexpected-compiler').exists()
for name in ['codex-tooling','codex-cargo-wrapper-linux']:
    assert sha(runtime/'bin'/name)==expected['executables'][name]['sha256']
for name,row in expected['executables'].items():
    assert sha(runtime/'lib/bazel-backend/native'/name)==row['sha256']
run('profile-runtime-modules',[str(runtime/'bin/java'),'--list-modules'],env)
for name in ['codex-tooling','codex-tooling-bazel']:
    run('profile-entry-'+name,[str(runtime/'bin'/name),'upstream-v8-script',str(root/'action with spaces.yml')],env)
    d=root/'commands'/('profile-entry-'+name);last=sorted(d.glob('[0-9]*'))[-1]
    assert (last/'stdout').read_text()=='literal public entrypoint success\n'
run('profile-wrapper-entry',[str(runtime/'bin/codex-cargo-wrapper-linux')],{**env,'CODEX_LINUX_CARGO_WRAPPER_CONFIG':''},expected=125)
manifest=json.loads((root/'source-manifest.json').read_text())
for name,row in manifest.items():assert sha(source/name)==row['sha256']
report={'task_contract':'acknowledged','state':'PASS_ACTUAL_MAVEN_ARM64_PREBUILT_PROFILE','sourceManifestSha256':sha(root/'source-manifest.json'),'sourceInputs':318,'runtime':str(runtime),'nativeManifestSha256':sha(runtime/'lib/bazel-backend/native/backend-manifest.json'),'packagedApplicationSha256':sha(runtime/'lib/bazel-backend/codex-tooling.jar'),'runtimeModuleImageSha256':sha(runtime/'lib/modules'),'nativeLaunchers':{name:sha(runtime/'bin'/name) for name in ['codex-tooling','codex-cargo-wrapper-linux']},'copiedSevenNativeHashesMatchProducer':True,'compilerDeniedAndUnused':True,'actualNativeEntrypointsPassed':True,'scope':'producer, actual Maven profile package and entrypoint boundary only; no scheduler/static attach/full release acceptance','activation':False}
(root/'profile-acceptance-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
