"""Validate the authentic immutable ARM64 acceptance export without extracting native bytes."""
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,sys
root=Path(__file__).resolve().parent
archive=Path(sys.argv[1]) if len(sys.argv)>1 else root/'arm64-prebuilt-evidence.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='22a203a498d6991a7c02420c1afa29dffe65364374ef8d36fef9cf8300baed8e'
actual={};jsons={};first={};names=set()
with tarfile.open(archive,'r|gz') as tf:
 for m in tf:
  pp=PurePosixPath(m.name);assert m.isfile() and not pp.is_absolute() and '..' not in pp.parts and m.name not in names,m.name
  names.add(m.name);f=tf.extractfile(m);h=hashlib.sha256();head=b'';content=[]
  keep=m.name.endswith('.json') and m.size<20*1024*1024
  while True:
   b=f.read(1024*1024)
   if not b:break
   if not head:head=b[:64]
   h.update(b)
   if keep:content.append(b)
  actual[m.name]={'sha256':h.hexdigest(),'bytes':m.size,'mode':oct(m.mode)};first[m.name]=head
  if keep:jsons[m.name]=json.loads(b''.join(content))
manifest=jsons['export-manifest.json'];assert len(manifest)==250 and set(actual)==set(manifest)|{'export-manifest.json'}
for name,row in manifest.items():assert actual[name]==row,(name,actual[name],row)
assert actual['export-manifest.json']['sha256']=='085baf67d32d27e9d64521afb8a1e8a871804ebb78fe2b444b118ee368b2ea87'
assert jsons['acceptance-result.json']['state']=='PASS_REAL_ARM64_PRODUCER_TO_COMPILER_FREE_PACKAGE'
assert jsons['profile-acceptance-result.json']['state']=='PASS_ACTUAL_MAVEN_ARM64_PREBUILT_PROFILE'
backend=jsons['backend/backend-manifest.json'];assert len(backend['executables'])==7
for name,row in backend['executables'].items():
 assert actual['backend/'+name]['sha256']==row['sha256'];head=first['backend/'+name];assert head[:6]==b'\x7fELF\x02\x01' and int.from_bytes(head[18:20],'little')==183
source=jsons['source-manifest.json'];assert len(source)==318
assert actual['source-manifest.json']['sha256']=='8d20ad8fa778a1d4b663b34368e7a995af0713500980191350381be49d31fd76'
commands={name:row for name,row in jsons.items() if name.startswith('commands/') and name.endswith('/result.json')}
assert commands['commands/compiler-free-distribution/0001/result.json']['exit']==1
assert commands['commands/compiler-free-distribution/0002/result.json']['exit']==0
assert commands['commands/native-producer/0001/result.json']['exit']==0
assert commands['commands/actual-maven-prebuilt-profile/0001/result.json']['exit']==0
assert commands['commands/profile-wrapper-entry/0001/result.json']['exit']==125
for name in ['codex-tooling','codex-tooling-bazel']:assert commands['commands/profile-entry-'+name+'/0001/result.json']['exit']==0
out=root/'verified-export-json';out.mkdir(exist_ok=True)
for name in ['acceptance-result.json','profile-acceptance-result.json','source-manifest.json','export-manifest.json','backend/backend-manifest.json']:
 (out/name.replace('/','--')).write_text(json.dumps(jsons[name],indent=2)+'\n')
report={'task_contract':'acknowledged','gate':'PASS_HASH_BOUND_REAL_ARM64_EXPORT','archiveSha256':'22a203a498d6991a7c02420c1afa29dffe65364374ef8d36fef9cf8300baed8e','safeUniqueRegularMembers':len(actual),'payloadHashesVerified':len(manifest),'sevenRealArm64ElfHashesVerified':True,'sourceInputs':len(source),'preservedFirstPackagingSetupFailure':True,'activation':False,'nativeBytesExtractedLocally':False,'commandResults':commands}
(root/'export-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='commandResults'},indent=2))
