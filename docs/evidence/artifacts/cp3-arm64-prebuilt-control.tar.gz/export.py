from pathlib import Path
import hashlib,json,tarfile,os,stat
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'profile-acceptance-result.json').read_text())['state']=='PASS_ACTUAL_MAVEN_ARM64_PREBUILT_PROFILE'
# Record actual packaged tree identities, never substitute architecture or binaries.
for name,tree in [('direct-runtime',root/'runtime'),('profile-runtime',root/'java-build/runtime')]:
 rows={}
 for f in sorted(tree.rglob('*')):
  if f.is_symlink(): rows[str(f.relative_to(tree))]={'symlink':os.readlink(f)}
  elif f.is_file():rows[str(f.relative_to(tree))]={'sha256':sha(f),'bytes':f.stat().st_size,'mode':oct(f.stat().st_mode&0o7777)}
 (root/(name+'-inventory.json')).write_text(json.dumps(rows,indent=2)+'\n')
files=set()
for folder in ['commands','backend','native-build/commands']:
 for f in (root/folder).rglob('*'):
  if f.is_file() and not f.is_symlink():files.add(f)
for f in (root/'native-build').iterdir():
 if f.is_file() and not f.is_symlink():files.add(f)
for name in ['accept.py','resume-package.py','profile-accept.py','export.py','acceptance-result.json','profile-acceptance-result.json','source-manifest.json','integrated-source.tar.gz','direct-runtime-inventory.json','profile-runtime-inventory.json','authenticated-marker','java-build/tooling-cli-1.0-SNAPSHOT.jar','java-build/runtime/lib/bazel-backend/codex-tooling.jar']:
 f=root/name
 if f.is_file():files.add(f)
rows={str(f.relative_to(root)):{'sha256':sha(f),'bytes':f.stat().st_size,'mode':oct(f.stat().st_mode&0o7777)} for f in sorted(files)}
manifest=root/'export-manifest.json';manifest.write_text(json.dumps(rows,indent=2)+'\n');files.add(manifest)
archive=root/'arm64-prebuilt-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
 for f in sorted(files):tf.add(f,arcname=str(f.relative_to(root)),recursive=False)
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'payloads':len(rows),'manifestSha256':sha(manifest)}
(root/'export-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
