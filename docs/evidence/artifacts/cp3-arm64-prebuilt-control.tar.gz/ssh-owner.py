"""Hold one authenticated foreground Linux PTY through native ownership collection.

No command deadline or automatic signal kills the SSH client or remote JVM.
Run only within the acknowledged production contract, fresh keys and a verified connection handoff.
"""
from pathlib import Path
import base64,json,os,pty,re,select,shlex,signal,socket,subprocess,time,traceback
ROOT=Path(__file__).resolve().parent
BUFFER=b''

def publish(name,value):
    """Retain one complete local receipt without exposing private-key contents."""
    (ROOT/name).write_text(json.dumps(value,indent=2)+'\n')

def write_all(data):
    """Complete partial PTY writes without treating a local write as remote acknowledgement."""
    offset=0
    while offset<len(data):offset+=os.write(MASTER,data[offset:])

def read_until(token):
    """Wait without a destructive timeout while retaining the same live SSH owner."""
    global BUFFER
    while token not in BUFFER:
        if CHILD.poll() is not None:raise RuntimeError('SSH ended: '+str(CHILD.returncode))
        if select.select([MASTER],[],[],1)[0]:
            data=os.read(MASTER,65536)
            if not data:raise EOFError('PTY ended')
            LOG.write(data);BUFFER+=data
    end=BUFFER.index(token)+len(token);out=BUFFER[:end];BUFFER=BUFFER[end:];return out

def run(request):
    """Send bounded acknowledged physical lines and retain exact command status/output."""
    ident=request['id'];assert re.fullmatch('[a-zA-Z0-9_-]{1,16}',ident)
    payload=base64.b64encode(request['command'].encode()).decode()
    write_all(b"__cat_payload=''\n");read_until(b'CAT_READY> ')
    for index in range(0,len(payload),512):
        ack='ACK_'+ident+'_'+str(index)
        line="__cat_payload+='"+payload[index:index+512]+"'; printf '\\n"+ack+"\\n'\n"
        assert len(line.encode())<4096
        write_all(line.encode());read_until(ack.encode()+b'\r\n');read_until(b'CAT_READY> ')
    marker=('DONE_'+ident+':').encode()
    line="printf '%s' \"$__cat_payload\" | base64 -d | bash; __cat_status=$?; printf '\\n"+marker.decode()+"%s\\n' \"$__cat_status\"\n"
    assert len(line.encode())<4096
    write_all(line.encode());body=read_until(marker);tail=read_until(b'CAT_READY> ')
    match=re.search(rb'(-?\d+)\r?\n',tail);assert match,repr(tail)
    result=dict(exit=int(match.group(1)),output=body[:-len(marker)].decode(errors='replace'))
    publish(ident+'.json',result);return result

def main():
    """Serve sequential command requests, refusing shell exit until cleanup is explicitly certified."""
    global MASTER,CHILD,LOG,BUFFER
    connection=json.loads((ROOT/'connection.json').read_text())
    args=shlex.split(connection['sshCommand']);assert args[0]=='ssh'
    destination=args[-1];assert not destination.startswith('-') and '@' in destination
    MASTER,slave=pty.openpty()
    CHILD=subprocess.Popen(['ssh','-tt','-i',str(ROOT/'client-key'),'-o','IdentitiesOnly=yes',
        '-o','UserKnownHostsFile='+str(ROOT/'known_hosts'),'-o','StrictHostKeyChecking=yes',destination],
        stdin=slave,stdout=slave,stderr=slave,close_fds=True)
    os.close(slave);LOG=(ROOT/'ssh-transcript.bin').open('ab',buffering=0)
    publish('ssh-process.json',dict(owner_pid=os.getpid(),ssh_pid=CHILD.pid,destination=destination))
    # A local interrupt must not discard an unresolved native owner.
    signal.signal(signal.SIGINT,signal.SIG_IGN);signal.signal(signal.SIGTERM,signal.SIG_IGN)
    try:
        while not re.search(rb'(?:\$|#|CAT_READY>) (?:\x1b\[[0-9;?]*[A-Za-z])*$',BUFFER[-512:]):
            if CHILD.poll() is not None:raise RuntimeError('SSH ended before prompt')
            if select.select([MASTER],[],[],1)[0]:
                data=os.read(MASTER,65536);LOG.write(data);BUFFER+=data
        write_all(b"stty -echo; PS1='CAT_READY> '; unset PROMPT_COMMAND; printf '\\nCAT_CONNECTED\\n'\n")
        read_until(b'CAT_CONNECTED\r\n');read_until(b'CAT_READY> ')
        os.chdir(ROOT);server=socket.socket(socket.AF_UNIX);server.bind('rpc.sock');server.listen(1)
        publish('ssh-owner.json',dict(owner_pid=os.getpid(),ssh_pid=CHILD.pid,destination=destination,socket='rpc.sock'))
        print('persistent authenticated SSH RPC ready; workspace effect still required',flush=True)
        while True:
            client,_=server.accept()
            with client:
                data=b''
                while not data.endswith(b'\n'):
                    part=client.recv(65536)
                    if not part:raise EOFError('RPC request ended before newline')
                    data+=part
                request=json.loads(data)
                if request.get('exit'):
                    assert request.get('owned_cleanup_verified') is True
                    assert request.get('export_sha256_verified') is True
                    assert request.get('smoke_marker_verified') is True
                    write_all(b'exit\n');status=CHILD.wait()
                    publish('ssh-exit.json',dict(exit=status));client.sendall(json.dumps(dict(ssh_exit=status)).encode()+b'\n');break
                result=run(request);client.sendall(json.dumps(result).encode()+b'\n')
        server.close();os.close(MASTER);LOG.close()
    except BaseException:
        publish('owner-failure.json',dict(trace=traceback.format_exc(),ssh_alive=CHILD.poll() is None,
            action='Retain PTY and worker; inspect same worker. No automatic signal or timeout cleanup.'))
        while CHILD.poll() is None:
            if select.select([MASTER],[],[],1)[0]:
                try:LOG.write(os.read(MASTER,65536))
                except OSError:time.sleep(1)
        publish('ssh-exit.json',dict(exit=CHILD.returncode,owner_failure=True))
        raise

if __name__=='__main__':main()
