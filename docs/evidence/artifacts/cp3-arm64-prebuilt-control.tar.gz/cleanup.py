from pathlib import Path
import hashlib,json,os,shutil
root=Path(__file__).resolve().parent
assert str(root)=='/home/runner/work/_temp/bazel-prebuilt-4Pxgqj'
assert (root/'authenticated-marker').is_file()
manifest=json.loads((root/'source-manifest.json').read_text())
for name,row in manifest.items():
 f=root/'source'/name;assert hashlib.sha256(f.read_bytes()).hexdigest()==row['sha256'] and f.stat().st_mode&0o7777==int(row['mode'],8),name
known=[]
for f in sorted((root/'commands').glob('*/[0-9]*/started.json')):
 row=json.loads(f.read_text());proc=Path('/proc')/str(row['pid'])/'stat'
 if proc.exists():
  current=proc.read_text().rsplit(')',1)[1].split();same=current[19]==row['birth'];state=current[0]
  assert not same or state=='Z',('Owned command still live; preserve worker',str(f),row['pid'],state)
  status='PID_REUSED' if not same else 'EXITED_ZOMBIE'
 else:status='EXITED_PID_ABSENT'
 known.append({'receipt':str(f.relative_to(root)),'pid':row['pid'],'birth':row['birth'],'status':status})
report={'task_contract':'acknowledged','state':'OWNED_TASK_SCRATCH_REMOVED_AFTER_VERIFIED_EXPORT','root':str(root),'all318SourceBytesAndModesUnchanged':True,'ownedCommandProcesses':known,'processesTerminated':[],'systemWideProcessScan':False,'productNativeCloseClaim':False,'taskCgroupOrNamespaceSettingsChanged':False}
shutil.rmtree(root);assert not root.exists();report['scratchAbsent']=True
print(json.dumps(report),flush=True)
