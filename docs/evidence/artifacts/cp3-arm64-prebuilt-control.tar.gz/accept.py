"""Run only the authentic ARM64 producer/prebuilt-packaging contract on the retained worker."""
from pathlib import Path
import hashlib,json,os,platform,shutil,subprocess,tarfile,time,urllib.request
root=Path(__file__).resolve().parent
assert root.parent==Path('/home/runner/work/_temp') and root.name.startswith('bazel-prebuilt-')
assert platform.machine()=='aarch64' and os.getuid()!=0
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for child in ['commands','tmp','downloads','tools']:(root/child).mkdir(exist_ok=True)
os.environ['TMPDIR']=str(root/'tmp')

def run(name,argv,env=None,expected=0):
    """Preserve the original process, exact command, logs and every failed attempt."""
    d=root/'commands'/name;d.mkdir(exist_ok=True)
    if (d/'success.json').exists():
        prior=json.loads((d/'success.json').read_text())
        if prior['argv']==list(map(str,argv)) and prior['expected']==expected:return prior
    attempt=d/f'{len(list(d.glob("[0-9]*")))+1:04d}';attempt.mkdir()
    settings=dict(os.environ);settings.update(env or {})
    record={'argv':list(map(str,argv)),'cwd':str(root),'environmentOverrides':env or {},'expected':expected}
    with (attempt/'stdout').open('wb') as out,(attempt/'stderr').open('wb') as err:
        process=subprocess.Popen(argv,cwd=root,env=settings,stdout=out,stderr=err)
        record.update(pid=process.pid,birth=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19]);(attempt/'started.json').write_text(json.dumps(record,indent=2)+'\n')
        start=time.monotonic();progress=start
        while process.poll() is None:
            time.sleep(1)
            if time.monotonic()-progress>=60:
                print(json.dumps({'running':name,'pid':process.pid,'elapsedSeconds':int(time.monotonic()-start),'nativeReceipts':[x.name for x in (root/'native-build/commands').glob('*.json')]}),flush=True);progress=time.monotonic()
        record['exit']=process.returncode
    (attempt/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'command':name,'exit':record['exit'],'receipt':str(attempt)}),flush=True)
    if record['exit']!=expected:raise RuntimeError('Retain original worker for '+name+'; inspect original logs')
    (d/'success.json').write_text(json.dumps(record,indent=2)+'\n');return record

source=root/'source'
manifest=[dict(path=name,**row) for name,row in json.loads((root/'source-manifest.json').read_text()).items()]
assert len(manifest)==318
for row in manifest:
    f=source/row['path'];assert sha(f)==row['sha256'] and f.stat().st_mode&0o7777==int(row['mode'],8),row['path']
run('architecture',['uname','-a']);run('apt-update',['sudo','-n','apt-get','update','-y'])
run('apt-musl',['sudo','-n','apt-get','install','-y','--no-install-recommends','musl-tools','maven','build-essential','git','ca-certificates','xz-utils','zstd'])
jdk_archive=root/'downloads/jdk.tar.gz';jdk_hash='68205d91d32f9dea7b61135ec812fa6576f873bfe454dd12488aab8123a84269'
if not jdk_archive.exists():
    with urllib.request.urlopen('https://cdn.azul.com/zulu/bin/zulu27.30.107-ca-jdk27.0.1-linux_aarch64.tar.gz') as response,jdk_archive.open('wb') as output:shutil.copyfileobj(response,output)
assert sha(jdk_archive)==jdk_hash
jdk=root/'tools/zulu27.30.107-ca-jdk27.0.1-linux_aarch64'
if not jdk.exists():
    with tarfile.open(jdk_archive) as tf:tf.extractall(root/'tools',filter='data')
java=jdk/'bin/java';env={'JAVA_HOME':str(jdk),'PATH':str(jdk/'bin')+':/usr/bin:/bin','MAVEN_OPTS':'-Djava.io.tmpdir='+str(root/'tmp')}
run('java-version',[str(java),'-version'],env)
build=root/'java-build'
run('maven-application',['mvn','--batch-mode','--no-transfer-progress','-f',str(source/'tooling/cli/pom.xml'),'-Dmaven.test.skip=true','-Dtooling.build.directory='+str(build),'-Dmaven.repo.local='+str(root/'maven-repository'),'-DincludeScope=runtime','-DoutputDirectory='+str(build/'modules'),'package','dependency:copy-dependencies'],env)
application=build/'tooling-cli-1.0-SNAPSHOT.jar';assert application.is_file();shutil.copyfile(application,build/'modules'/application.name)
cp=str(build/'modules/*');driver=source/'tooling/cli/src/build/java/com/holdmyspot/codexunleashed/distribution/BazelBackendMain.java'
argv=[str(java),'-Djava.io.tmpdir='+str(root/'tmp'),'-cp',cp,str(driver),'aarch64-unknown-linux-musl',str(root/'native-build'),str(root/'backend')]
if (root/'native-build/source-before.json').exists():argv.append('--resume')
run('native-producer',argv,env)
backend=json.loads((root/'backend/backend-manifest.json').read_text())
expected={'bb_worker','bb_scheduler','bb_storage','linux-bazel-action-owner','linux-bazel-action-waiter','codex-tooling','codex-cargo-wrapper-linux'}
assert set(backend['executables'])==expected
for name in expected:
    f=root/'backend'/name;assert sha(f)==backend['executables'][name]['sha256'];header=f.read_bytes()[:64];assert header[:6]==b'\x7fELF\x02\x01' and int.from_bytes(header[18:20],'little')==183
assert backend['launcherSourceSha256']==sha(source/'tooling/cli/src/main/resources/com/holdmyspot/codexunleashed/scheduler/linux-java-launcher.c')
assert backend['launcherHeaderInputs']
deny=root/'compiler-deny';deny.mkdir(exist_ok=True)
for name in ['gcc','cc','clang','musl-gcc','g++','clang++']:
    f=deny/name;f.write_text('#!/bin/sh\nprintf "%s\\n" "$0" >> "'+str(root/'unexpected-compiler')+'"\nexit 97\n');f.chmod(0o755)
compiler_free={**env,'PATH':str(deny)}
runtime=root/'runtime'
run('compiler-free-distribution',[str(java),'-Djava.io.tmpdir='+str(root/'tmp'),str(source/'tooling/cli/src/build/java/com/holdmyspot/codexunleashed/distribution/DistributionMain.java'),str(build/'modules'),str(runtime),'--bazel-backend',str(root/'backend')],compiler_free)
assert (runtime/'.complete').is_file() and not (root/'unexpected-compiler').exists()
for name in ['codex-tooling','codex-cargo-wrapper-linux']:
    assert sha(runtime/'bin'/name)==backend['executables'][name]['sha256']
run('runtime-modules',[str(runtime/'bin/java'),'--list-modules'],compiler_free)
action=root/'action with spaces.yml';action.write_text('runs:\n  using: composite\n  steps:\n    - shell: bash\n      run: "literal public entrypoint success\\n"\n')
for name in ['codex-tooling','codex-tooling-bazel']:
    receipt=run('entry-'+name,[str(runtime/'bin'/name),'upstream-v8-script',str(action)],compiler_free)
    d=root/'commands'/('entry-'+name);last=sorted(d.glob('[0-9]*'))[-1];assert (last/'stdout').read_text()=='literal public entrypoint success\n'
wrapperenv={k:v for k,v in compiler_free.items()};wrapperenv['CODEX_LINUX_CARGO_WRAPPER_CONFIG']=''
run('wrapper-missing-config',[str(runtime/'bin/codex-cargo-wrapper-linux')],wrapperenv,expected=125)
fat=runtime/'lib/bazel-backend/codex-tooling.jar'
run('packaged-seven-validation',[str(runtime/'bin/java'),'-cp',str(fat),'com.holdmyspot.codexunleashed.scheduler.LinuxBazelBackend',str(root/'backend'),str(root/'validated-copy')],compiler_free)
for row in manifest:assert sha(source/row['path'])==row['sha256']
report={'task_contract':'acknowledged','state':'PASS_REAL_ARM64_PRODUCER_TO_COMPILER_FREE_PACKAGE','sourceInputs':318,'sourceManifestSha256':sha(root/'source-manifest.json'),'architecture':platform.machine(),'backendManifestSha256':sha(root/'backend/backend-manifest.json'),'applicationSha256':sha(application),'packagedApplicationSha256':sha(fat),'sevenNativeExecutables':backend['executables'],'javaSha256':sha(java),'javaRuntimeModulesSha256':sha(runtime/'lib/modules'),'all318SourceInputsUnchanged':True,'nativeLaunchersCopiedExactly':True,'compilerDenialSentinelAbsent':True,'actualEntrypoints':['codex-tooling: upstream-v8-script exit0 exact output','codex-tooling-bazel: upstream-v8-script exit0 exact output','codex-cargo-wrapper-linux: missing context fails125'],'schedulerActivation':False,'unrun':['static-image instrumentation','native product CLOSE','required Bazel release consumer','full release'],'retainedForCleanup':str(root)}
(root/'acceptance-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
