from pathlib import Path
import socket,json,os,base64,hashlib,re,time
root=Path(__file__).resolve().parent;os.chdir(root)
size=220134815;expected='22a203a498d6991a7c02420c1afa29dffe65364374ef8d36fef9cf8300baed8e'
archive=root/'arm64-prebuilt-evidence.tar.gz';offset=archive.stat().st_size if archive.exists() else 0
receipts=root/'download-chunks';receipts.mkdir(exist_ok=True)
while offset<size:
 length=min(4*1024*1024,size-offset)
 cmd="python3 - <<'PYREMOTE'\nimport hashlib,base64,json\nf=open('/home/runner/work/_temp/bazel-prebuilt-4Pxgqj/arm64-prebuilt-evidence.tar.gz','rb');f.seek("+str(offset)+");b=f.read("+str(length)+")\nprint(json.dumps(dict(offset="+str(offset)+",bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode())))\nPYREMOTE"
 s=socket.socket(socket.AF_UNIX);s.connect('rpc.sock');s.sendall(json.dumps({'id':'dl'+str(offset),'command':cmd}).encode()+b'\n');parts=[]
 while True:
  part=s.recv(65536);assert part;parts.append(part)
  if part.endswith(b'\n'):break
 response=json.loads(b''.join(parts));assert response['exit']==0
 line=next(x for x in response['output'].splitlines() if x.startswith('{"offset"'))
 row=json.loads(line);data=base64.b64decode(row.pop('data'));assert row['offset']==offset and len(data)==length and hashlib.sha256(data).hexdigest()==row['sha256']
 with archive.open('ab') as f:f.write(data)
 (receipts/(str(offset)+'.json')).write_text(json.dumps(row)+'\n');offset+=length
 print(json.dumps(dict(downloaded=offset,total=size)),flush=True)
assert archive.stat().st_size==size and hashlib.sha256(archive.read_bytes()).hexdigest()==expected
(root/'download-validation.json').write_text(json.dumps(dict(bytes=size,sha256=expected,allChunkHashesVerified=True))+'\n');print('DOWNLOAD_HASH_VERIFIED',flush=True)
