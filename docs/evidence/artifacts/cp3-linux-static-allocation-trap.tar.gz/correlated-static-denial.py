"""Evaluate one libc-independent injected allocation-return trap in pinned Zig.

Load inside GDB with CP3_FIXTURE set to the owned fixture directory. The unchanged
compiler runs under an address-space limit; no result register is modified. A
kernel entry catchpoint discovers an mmap return instruction. GDB then injects
an ordinary software breakpoint there and holds a genuine -ENOMEM before the
compiler can inspect it. This proves only the native boundary, not Java control,
descendant coverage, ordinary-failure behavior or scheduler acceptance.
"""
import gdb
import hashlib, json, os, time
from pathlib import Path

root = Path(os.environ['CP3_FIXTURE'])
zig = root / 'zig-linux-x86_64-0.14.0/zig'
result = {'claim': 'Injected software trap holds genuine static-compiler mmap denial',
          'status': 'UNRUN', 'javaControl': 'UNRUN', 'descendants': 'UNRUN',
          'registersModified': False, 'sites': []}
result['zigSha256Before'] = hashlib.sha256(zig.read_bytes()).hexdigest()
assert result['zigSha256Before'] == '77340932066b76bc9f3a4ac120288f21790ed2836e5cd5a003f4a3c12f37d765'
sites = {}
pending = {}
result["returnObservations"] = []
denied = None


def register(name):
    """Read an x86-64 register from the selected traced thread."""
    return int(gdb.parse_and_eval('(long)$' + name))


class AllocationReturn(gdb.Breakpoint):
    """Inject one software trap at an authenticated mmap return instruction."""
    def __init__(self, address, original):
        super().__init__('*' + hex(address), internal=True)
        self.address = address
        self.original = original

    def stop(self):
        """Hold only a genuine mmap -ENOMEM, leaving every native result intact."""
        global denied
        inferior = gdb.selected_inferior()
        thread = gdb.selected_thread()
        request = pending.pop(tuple(thread.ptid), None)
        if len(result['returnObservations']) < 10:
            result['returnObservations'].append({'thread': list(thread.ptid), 'origRax': register('orig_rax'),
                                                  'rax': register('rax'), 'request': request})
        if request is None or register('rax') != -12:
            return False
        denied = {'pid': inferior.pid, 'thread': list(thread.ptid),
                  'returnAddress': hex(self.address), 'result': register('rax'),
                  'requestBytes': request['bytes'], 'allocationSyscall': request['syscall'],
                  'originalReturnByte': self.original,
                  'trapKind': 'GDB software breakpoint',
                  'stat': Path('/proc/' + str(inferior.pid) + '/stat').read_text()}
        result['denied'] = denied
        print('STATIC_ALLOCATION_DENIED_HELD', flush=True)
        return True


def mmap_boundary():
    """Discover actual syscall return sites while the traced thread is stopped."""
    if register('orig_rax') != 9 or register('rax') != -38:
        return
    address = register('pc')
    pending[tuple(gdb.selected_thread().ptid)] = {'syscall': register('orig_rax'), 'bytes': register('rsi')}
    if address in sites:
        return
    inferior = gdb.selected_inferior()
    instruction = bytes(inferior.read_memory(address - 2, 2))
    assert instruction == b'\x0f\x05', instruction.hex()
    original = bytes(inferior.read_memory(address, 1)).hex()
    mappings = Path('/proc/' + str(inferior.pid) + '/maps').read_text()
    matching = [line for line in mappings.splitlines()
                if int(line.split('-')[0], 16) <= address < int(line.split('-')[1].split()[0], 16)]
    assert len(matching) == 1 and str(zig) in matching[0] and 'r-xp' in matching[0], matching
    sites[address] = AllocationReturn(address, original)
    result['sites'].append({'address': hex(address), 'syscallBytes': instruction.hex(),
                            'originalReturnByte': original, 'mapping': matching[0]})


try:
    for command in ['set pagination off', 'set confirm off', 'set startup-with-shell on',
                    'set disable-randomization off', 'set breakpoint always-inserted on',
                    'set detach-on-fork off', 'set schedule-multiple on']:
        gdb.execute(command)
    gdb.execute('file ' + str(zig))
    gdb.execute('set exec-wrapper /usr/bin/prlimit --as=209715200 --')
    gdb.execute('set environment ZIG_GLOBAL_CACHE_DIR ' + str(root / 'zig-global-cache'))
    gdb.execute('set environment ZIG_LOCAL_CACHE_DIR ' + str(root / 'zig-local-cache'))
    gdb.execute('set args cc -c ' + str(root / 'tiny.c') + ' -o ' + str(root / 'tiny.o'))
    gdb.execute('catch syscall mmap')
    number = gdb.breakpoints()[-1].number
    gdb.execute('commands ' + str(number) + '\nsilent\npython mmap_boundary()\ncontinue\nend')
    gdb.execute('run')
    assert denied is not None, 'Compiler returned without an injected denied-allocation hold'
    time.sleep(2)
    current = Path('/proc/' + str(denied['pid']) + '/stat').read_text()
    assert current.split(') ', 1)[1].split()[0] == 't', current
    result['heldAfterTwoSeconds'] = current
    result['targetLimits'] = Path('/proc/' + str(denied['pid']) + '/limits').read_text()
    assert register('rax') == -12
    gdb.execute('kill inferiors ' + ' '.join(str(i.num) for i in gdb.inferiors() if i.pid))
    result['remainingInferiorPids'] = [i.pid for i in gdb.inferiors() if i.pid]
    assert not result['remainingInferiorPids']
    result['zigSha256After'] = hashlib.sha256(zig.read_bytes()).hexdigest()
    assert result['zigSha256After'] == result['zigSha256Before']
    result['status'] = 'PASSED_NATIVE_BOUNDARY_ONLY'
except BaseException as error:
    import traceback
    result['status'] = 'FAILED'
    result['error'] = {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
    for inferior in gdb.inferiors():
        if inferior.pid:
            gdb.execute('kill inferiors ' + str(inferior.num))
finally:
    (root / 'static-denial-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)
    gdb.execute('quit ' + ('0' if result['status'] == 'PASSED_NATIVE_BOUNDARY_ONLY' else '1'))
