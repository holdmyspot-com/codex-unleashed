"""Inject a native trap at a genuinely denied static Zig mmap return.

Load in GDB with CP3_FIXTURE naming the owned directory. A kernel syscall stop
supplies the authentic request/result; only after -ENOMEM is returned do we
replace the next instruction byte with INT3. The executed injected trap must
hold that unchanged result before the compiler consumes it. No register result
is fabricated. Kill and collect the target after observing its stable hold.
This proves a native candidate boundary; Java control and descendants are unrun.
"""
import gdb
import hashlib, json, os, time, traceback
from pathlib import Path
root = Path(os.environ['CP3_FIXTURE'])
zig = root / 'zig-linux-x86_64-0.14.0/zig'
result = {'status': 'UNRUN', 'javaControl': 'UNRUN', 'descendants': 'UNRUN',
          'registersModified': False, 'nativeReturns': []}
pending = {}
denied = None
catchpoint = None
result['zigSha256Before'] = hashlib.sha256(zig.read_bytes()).hexdigest()
assert result['zigSha256Before'] == '77340932066b76bc9f3a4ac120288f21790ed2836e5cd5a003f4a3c12f37d765'


def register(name):
    """Read a signed native x86-64 register without changing it."""
    return int(gdb.parse_and_eval('(long)$' + name))


def allocation_boundary():
    """Inject INT3 only at an authentic mmap denial's unconsumed return."""
    global denied
    inferior = gdb.selected_inferior()
    thread = gdb.selected_thread()
    key = tuple(thread.ptid)
    assert register('orig_rax') == 9
    native_result = register('rax')
    if native_result == -38:
        pending[key] = {'syscall': 9, 'bytes': register('rsi')}
        return
    request = pending.pop(key)
    if len(result['nativeReturns']) < 10:
        result['nativeReturns'].append({'thread': list(key), 'request': request, 'result': native_result})
    if native_result != -12:
        return
    address = register('pc')
    instruction = bytes(inferior.read_memory(address - 2, 2))
    assert instruction == b'\x0f\x05', instruction.hex()
    original = bytes(inferior.read_memory(address, 1)).hex()
    mappings = Path('/proc/' + str(inferior.pid) + '/maps').read_text()
    matching = [line for line in mappings.splitlines()
                if int(line.split('-')[0], 16) <= address < int(line.split('-')[1].split()[0], 16)]
    assert len(matching) == 1 and str(zig) in matching[0] and 'r-xp' in matching[0], matching
    denied = {'pid': inferior.pid, 'thread': list(key), 'returnAddress': address,
              'request': request, 'nativeResult': native_result, 'originalByte': original,
              'syscallBytes': instruction.hex(), 'mapping': matching[0],
              'stat': Path('/proc/' + str(inferior.pid) + '/stat').read_text(),
              'limits': Path('/proc/' + str(inferior.pid) + '/limits').read_text()}
    inferior.write_memory(address, b'\xcc')
    catchpoint.enabled = False
    result['denied'] = denied
    print('GENUINE_DENIAL_TRAP_INSERTED', flush=True)


try:
    for command in ['set pagination off', 'set confirm off', 'set startup-with-shell on',
                    'set disable-randomization off', 'set detach-on-fork off', 'set schedule-multiple on']:
        gdb.execute(command)
    gdb.execute('file ' + str(zig))
    gdb.execute('set exec-wrapper /usr/bin/prlimit --as=209715200 --')
    gdb.execute('set environment ZIG_GLOBAL_CACHE_DIR ' + str(root / 'zig-global-cache'))
    gdb.execute('set environment ZIG_LOCAL_CACHE_DIR ' + str(root / 'zig-local-cache'))
    gdb.execute('set args cc -c ' + str(root / 'tiny.c') + ' -o ' + str(root / 'tiny.o'))
    gdb.execute('catch syscall mmap')
    catchpoint = gdb.breakpoints()[-1]
    gdb.execute('commands ' + str(catchpoint.number) + '\nsilent\npython allocation_boundary()\ncontinue\nend')
    gdb.execute('run')
    assert denied is not None, 'Compiler stopped without a genuine allocation denial'
    assert register('rax') == -12
    assert register('pc') == denied['returnAddress'] + 1
    inferior = gdb.selected_inferior()
    assert bytes(inferior.read_memory(denied['returnAddress'], 1)) == b'\xcc'
    result['injectedTrapExecuted'] = True
    time.sleep(2)
    result['heldAfterTwoSeconds'] = Path('/proc/' + str(denied['pid']) + '/stat').read_text()
    assert result['heldAfterTwoSeconds'].split(') ', 1)[1].split()[0] == 't'
    assert register('rax') == -12
    gdb.execute('kill inferiors ' + ' '.join(str(i.num) for i in gdb.inferiors() if i.pid))
    result['remainingInferiorPids'] = [i.pid for i in gdb.inferiors() if i.pid]
    assert not result['remainingInferiorPids']
    result['zigSha256After'] = hashlib.sha256(zig.read_bytes()).hexdigest()
    assert result['zigSha256After'] == result['zigSha256Before']
    result['status'] = 'PASSED_NATIVE_BOUNDARY_ONLY'
except BaseException as error:
    result['status'] = 'FAILED'
    result['error'] = {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
    for inferior in gdb.inferiors():
        if inferior.pid:
            gdb.execute('kill inferiors ' + str(inferior.num))
finally:
    (root / 'static-denial-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)
    gdb.execute('quit ' + ('0' if result['status'] == 'PASSED_NATIVE_BOUNDARY_ONLY' else '1'))
