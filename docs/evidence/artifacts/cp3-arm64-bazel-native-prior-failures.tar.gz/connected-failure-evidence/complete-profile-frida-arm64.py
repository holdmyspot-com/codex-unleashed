"""Complete the verified ARM devkit recipe, accepting its harmless root directory."""
from pathlib import Path
import os,json,hashlib,tarfile,subprocess
d=Path(os.environ['CP3_WORK'])/'profile-frida'
release=json.loads((d/'release.json').read_text())
asset=next(a for a in release['assets'] if a['name']=='frida-core-devkit-17.24.3-linux-arm64.tar.xz')
archive=d/asset['name'];actual=hashlib.sha256(archive.read_bytes()).hexdigest()
assert asset['digest']=='sha256:'+actual
with tarfile.open(archive) as t:
 members=t.getmembers()
 assert len({m.name for m in members})==len(members)
 assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and (m.isfile() or m.isdir()) for m in members)
 t.extractall(d,filter='data')
command=['gcc','-shared','-fPIC','-O2','-DNDEBUG','-Wl,--gc-sections','-Wl,-s','-o',str(d/'libfrida-core.so'),'-Wl,--whole-archive,'+str(d/'libfrida-core.a'),'-Wl,--no-whole-archive','-Wl,-soname,libfrida-core.so','-Wl,-z,noexecstack','-ldl','-lm','-pthread','-lrt']
with (d/'link.log').open('w') as output:result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
record={'asset':asset['name'],'asset_sha256':actual,'command':command,'exit':result.returncode,'use':'sealed profile input; static trace never initializes Frida'}
if result.returncode==0:record['output_sha256']=hashlib.sha256((d/'libfrida-core.so').read_bytes()).hexdigest()
(d/'recipe.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
raise SystemExit(result.returncode)
