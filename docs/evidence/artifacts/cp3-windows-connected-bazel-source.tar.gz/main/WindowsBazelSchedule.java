package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.AclEntryFlag;
import java.nio.file.attribute.AclEntryPermission;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.UserPrincipal;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;

/**
 * Runs one native Windows Bazel invocation and retains its scopes until native cleanup acknowledges closure.
 * The original whole-consumer exit code comes from the shared coordinator. Completed memory history and a small
 * invocation event receipt remain in the caller's scratch directory after private native state is removed.
 */
final class WindowsBazelSchedule
{
    /**
     * Prevents construction of this installed native composition boundary.
     */
    private WindowsBazelSchedule() {}

    /**
     * Runs the authenticated Windows Bazel action coordinator on native x64 or ARM64.
     * Host rejection precedes settings inspection, scope creation and native acquisition. The explicit launch document
     * authenticates the original Bazel, complete toolchain, Frida library and running Java module image before launch.
     * Caller-owned tooling services remain borrowed; unresolved cleanup retains the invocation and its child scope.
     * @param tooling caller-owned Pouch services retained through native cleanup
     * @param settings explicit Bazel arguments, profile, workspace, scratch and memory policy
     * @return genuine original whole-consumer exit code with its DWORD bits preserved
     * @throws NullPointerException if an argument is null on a supported host
     * @throws IOException if the host, settings, profile, native execution or cleanup is invalid
     * @throws Scheduler.PendingCleanup if native ownership remains unresolved; close it on the original thread
     */
    static int run(ToolingScope tooling, Scheduler.Settings settings) throws IOException
    {
        requireHost();
        Objects.requireNonNull(tooling, "tooling");
        Objects.requireNonNull(settings, "settings");
        if (!settings.tool().equals("bazel")) throw new IOException("Windows Bazel composition requires the Bazel tool");
        if (settings.bazelLaunchConfiguration() == null)
            throw new IOException("Windows Bazel scheduling requires --bazel-launch-config");
        WindowsBazelScope scope = new WindowsBazelScope(tooling);
        Cleanup cleanup = new Cleanup(scope);
        Throwable primary = null;
        try
        {
            WindowsBazelLaunchConfiguration authorization = WindowsBazelLaunchConfiguration.read(scope,
                settings.bazelLaunchConfiguration());
            authorization.requireIdentities(scope, settings.fridaLibrary(),
                Path.of(System.getProperty("java.home"), "lib", "modules"));
            BazelNativeBackend.FileIdentity identity = BazelBackendCredentials.nativeIdentity(tooling);
            requireDirectory(settings.workspace(), identity);
            requireDirectory(settings.scratch(), identity);
            FileAttribute<List<AclEntry>> privateAcl = privateDirectoryAcl(settings.scratch());
            Path history = settings.scratch().resolve("bazel-memory-history");
            if (!Files.exists(history, LinkOption.NOFOLLOW_LINKS))
            {
                try { Files.createDirectory(history, privateAcl); }
                catch (java.nio.file.FileAlreadyExistsException concurrent)
                {
                    // Concurrent invocations may establish the same persistent history; authenticate it below.
                }
            }
            BazelBackendCredentials.nativeAuthority(tooling, history).requireDirectory(history);
            cleanup.namespace = Files.createTempDirectory(settings.scratch(), "wb-", privateAcl);
            cleanup.identity = identity;
            cleanup.originalIdentity = identity.identity(cleanup.namespace);
            BazelBackendCredentials.nativeAuthority(tooling, cleanup.namespace).requireDirectory(cleanup.namespace);
            cleanup.invocation = new WindowsBazelInvocation(tooling, scope, settings, authorization, cleanup.namespace, history);
            cleanup.invocation.start();
            WindowsBazelInvocation invocation = cleanup.invocation;
            return new SchedulerCoordinator<>(invocation, settings.budget(), WindowsBazelSchedule::pause,
                (event, payload) -> invocation.record(event, eventPayload(payload))).run();
        }
        catch (IOException | RuntimeException | Error failure)
        {
            primary = failure;
            throw failure;
        }
        finally
        {
            try { cleanup.close(); }
            catch (IOException | RuntimeException | Error failure)
            {
                Throwable retained = primary == null ? failure : primary;
                if (retained != failure) retained.addSuppressed(failure);
                throw new Scheduler.PendingCleanup(retained, cleanup::close);
            }
        }
    }

    /**
     * Rejects other native filesystems and unsupported Windows architectures before acquiring resources.
     * @throws IOException if the current JVM is outside the supported native Windows matrix
     */
    private static void requireHost() throws IOException
    {
        String os = System.getProperty("os.name", "");
        if (File.separatorChar != '\\' || !os.startsWith("Windows"))
            throw new IOException("Windows Bazel scheduling requires native Windows x64 or ARM64");
        BazelNativeBackend.NativeTarget target;
        try { target = BazelNativeBackend.NativeTarget.forHost(os, System.getProperty("os.arch", "")); }
        catch (UnsupportedOperationException unsupported)
        {
            throw new IOException("Unsupported native Windows Bazel architecture", unsupported);
        }
        switch (target)
        {
            case WINDOWS_X64, WINDOWS_ARM64 -> { }
            default -> throw new IOException("Windows Bazel scheduling requires a native Windows backend target");
        }
    }

    /**
     * Authenticates an existing directory and every native ancestor without following reparse points.
     * @param directory original absolute normalized workspace or scratch directory
     * @param identity shared actual no-follow native filesystem authority
     * @throws IOException if the path is indirect, non-normalized, unavailable or not a directory
     */
    private static void requireDirectory(Path directory, BazelNativeBackend.FileIdentity identity) throws IOException
    {
        if (!directory.isAbsolute() || !directory.equals(directory.normalize()) ||
            !Files.isDirectory(directory, LinkOption.NOFOLLOW_LINKS))
            throw new IOException("Existing absolute normalized Windows directory required: " + directory);
        for (Path entry = directory; entry != null; entry = entry.getParent()) identity.identity(entry);
    }

    /**
     * Supplies an atomic owner-only ACL with inheritance for newly created private directories.
     * The common native authority subsequently verifies that this owner is the process's actual creating identity.
     * @param parent existing scratch parent whose owner must match the current creating identity
     * @return creation-time ACL attribute
     * @throws IOException if the parent's original owner cannot be read
     */
    private static FileAttribute<List<AclEntry>> privateDirectoryAcl(Path parent) throws IOException
    {
        UserPrincipal owner = Files.getOwner(parent, LinkOption.NOFOLLOW_LINKS);
        List<AclEntry> entries = List.of(AclEntry.newBuilder().setType(AclEntryType.ALLOW).setPrincipal(owner)
            .setPermissions(EnumSet.allOf(AclEntryPermission.class))
            .setFlags(AclEntryFlag.DIRECTORY_INHERIT, AclEntryFlag.FILE_INHERIT).build());
        return new FileAttribute<>()
        {
            @Override public String name() { return "acl:acl"; }
            @Override public List<AclEntry> value() { return entries; }
        };
    }

    /**
     * Copies coordinator events into JSON-compatible primitives while preserving unsigned native action status.
     * @param payload exact coordinator event value
     * @return immutable fields describing the event's original action or control outcome
     */
    private static Map<String, ?> eventPayload(Object payload)
    {
        return switch (payload)
        {
            case Policy.Decision decision -> Map.of("control", decision.control().name(),
                "name", decision.jobName(), "reason", decision.reason());
            case SchedulerCoordinator.Blocked blocked -> Map.of("name", blocked.name(),
                "attemptSequence", blocked.attemptSequence(), "waitSequence", blocked.waitSequence());
            case SchedulerCoordinator.Submission submission -> Map.of("name", submission.name(),
                "estimate", submission.peakBytes() == null ? "unknown" : submission.peakBytes());
            case JobQueue.Completion<?> completion -> Map.of("name", completion.name(),
                "attemptSequence", completion.attemptSequence(), "aborted", completion.outcome().aborted(),
                "result", nativeResult(completion.outcome().result()));
            case Integer status -> Map.of("exit", status);
            case null -> Map.of("value", "null");
            default -> Map.of("value", payload.toString());
        };
    }

    /**
     * Copies a genuine action result without narrowing its unsigned DWORD exit status.
     * @param result original whole-native outcome, or null for an aborted attempt without a result
     * @return exact native exit and abortion fields, or an explicit absent-result marker
     */
    private static Object nativeResult(Object result)
    {
        return switch (result)
        {
            case WindowsProcess.Result status -> Map.of("rootExit", status.rootExit(), "aborted", status.aborted());
            case null -> "absent";
            default -> result.toString();
        };
    }

    /**
     * Waits one bounded coordinator idle interval while preserving interruption.
     * @throws InterruptedException if the coordinator thread is interrupted
     */
    private static void pause() throws InterruptedException { Thread.sleep(1); }

    /**
     * Retains the exact invocation, namespace and child scope until native and filesystem cleanup complete.
     * Calls belong to the constructing coordinator thread. A failed scope close is sticky because repeating an
     * uncertain disposal cannot prove that every scoped resource was retired.
     */
    private static final class Cleanup
    {
        /** Child parser scope retained until every native borrower acknowledges closure. */
        private final WindowsBazelScope scope;
        /** Original coordinator thread, including retained PendingCleanup callbacks. */
        private final Thread owner = Thread.currentThread();
        /** Partially acquired or active native invocation. */
        private WindowsBazelInvocation invocation;
        /** Exclusively allocated private invocation directory; null before allocation. */
        private Path namespace;
        /** Shared actual native no-follow identity authority. */
        private BazelNativeBackend.FileIdentity identity;
        /** Original namespace's native volume and file identity. */
        private Object originalIdentity;
        /** Indicates whether scope disposal already consumed its opportunity. */
        private boolean scopeCloseAttempted;
        /** Sticky failure from a scope disposal that did not acknowledge success. */
        private Throwable scopeFailure;
        /** Indicates whether invocation, namespace and scope all acknowledged closure. */
        private boolean closed;

        /**
         * Retains the child scope before profile parsing or native acquisition.
         * @param scope open invocation-owned parser scope
         */
        private Cleanup(WindowsBazelScope scope) { this.scope = scope; }

        /**
         * Closes native owners before deleting only their original private namespace and releasing services.
         * @throws IOException if native ownership, namespace identity or any cleanup remains unresolved
         */
        private void close() throws IOException
        {
            if (Thread.currentThread() != owner) throw new IllegalStateException("Windows Bazel cleanup belongs to its original thread");
            if (closed) return;
            if (invocation != null)
            {
                invocation.close();
                if (!invocation.isClosed()) throw new IOException("Original Windows Bazel native cleanup remains retained");
                invocation.closeRecording();
            }
            if (namespace != null)
            {
                retireNamespace();
                namespace = null;
            }
            if (scopeCloseAttempted)
                throw new IOException("Original Windows Bazel scope closure remains uncertain", scopeFailure);
            scopeCloseAttempted = true;
            try { scope.close(); }
            catch (RuntimeException | Error failure) { scopeFailure = failure; throw failure; }
            closed = true;
        }

        /**
         * Preserves the event receipt, then removes the authenticated original namespace after native closure.
         * Readonly entries use native metadata-preserving unlink so shared cache inode attributes remain untouched.
         * @throws IOException if identity, receipt publication or unlink remains unresolved
         */
        private void retireNamespace() throws IOException
        {
            if (!Files.exists(namespace, LinkOption.NOFOLLOW_LINKS))
                throw new IOException("Original Windows Bazel namespace disappeared before cleanup: " + namespace);
            if (identity == null) identity = BazelBackendCredentials.nativeIdentity(scope.tooling());
            if (originalIdentity == null) originalIdentity = identity.identity(namespace);
            if (!originalIdentity.equals(identity.identity(namespace)))
                throw new IOException("Original Windows Bazel namespace was replaced: " + namespace);
            Path events = namespace.resolve("events.jsonl");
            if (Files.exists(events, LinkOption.NOFOLLOW_LINKS))
            {
                Object before = identity.identity(events);
                Path receipt = namespace.resolveSibling(namespace.getFileName() + "-events.jsonl");
                if (Files.exists(receipt, LinkOption.NOFOLLOW_LINKS))
                    throw new IOException("Windows Bazel event receipt already exists: " + receipt);
                Files.move(events, receipt, StandardCopyOption.ATOMIC_MOVE);
                if (!before.equals(identity.identity(receipt)))
                    throw new IOException("Windows Bazel event receipt identity changed during publication");
            }
            WindowsBazelFiles files = scope.files();
            List<Path> entries;
            try (Stream<Path> paths = Files.walk(namespace))
            {
                entries = paths.sorted(Comparator.reverseOrder()).toList();
            }
            for (Path entry : entries)
            {
                if (!originalIdentity.equals(identity.identity(namespace)))
                    throw new IOException("Original Windows Bazel namespace changed during cleanup");
                identity.identity(entry);
                files.unlink(entry, identity);
            }
        }
    }
}
