package com.holdmyspot.codexunleashed.scheduler;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Owns complete pristine worker inputs and temporary state across same-path native action retries.
 * Each original authenticated Runner request has one workspace. Its input and temporary root objects remain at
 * their original worker-visible paths. Before release, each attempt materializes independent writable contents,
 * preserving required hardlink equivalence within the input tree while sharing no writable file with a worker cache
 * or the immutable snapshot. Implementations preserve their platform's required link and executable metadata.
 * <p>
 * The coordinator thread exclusively uses this owner. The native attempt owner must establish genuine whole-workload
 * extinction, original result collection and instrumentation/stream disposal before freezing or discarding an attempt.
 * This interface neither infers nor manufactures those native barriers. Uncertain restoration retains the lease and
 * snapshot; callers retain this owner and its private-root protection until cleanup is proven complete.
 */
interface BazelWorkspace extends AutoCloseable
{
    /**
     * Returns complete immutable ready inputs for content identity and later same-path restoration.
     * The caller keeps this independently owned tree inaccessible to every action security identity.
     * @return pristine input snapshot retained through successful workspace closure
     */
    Path immutableSnapshot();

    /**
     * Materializes pristine input and temporary contents at the original authenticated worker paths.
     * The previous native attempt must be terminal and its lease accepted or successfully discarded.
     * Ordinals are never reused, even after a failed materialization. Partial failure remains owned for safe recovery.
     * @param sequence nonnegative queue-wide attempt ordinal not previously reserved by this workspace
     * @return the sole outstanding same-path attempt lease
     * @throws IllegalArgumentException if {@code sequence} is negative or already reserved
     * @throws IllegalStateException if closed or another attempt lease remains outstanding
     * @throws IOException if root identity changed or independent materialization fails
     */
    Attempt begin(long sequence) throws IOException;

    /**
     * Removes only private workspace storage after every attempt lease is resolved.
     * Borrowed worker-visible roots are retained. An unresolved native or storage lease prevents closure.
     * @throws IOException if an attempt remains outstanding or private storage cannot be removed
     */
    @Override
    void close() throws IOException;

    /**
     * Retains same-path execution and rollback authority for one native attempt.
     * The original RPC publication authority outlives this lease across retries. After the genuine whole-native
     * terminal barrier, the caller freezes outputs within the original RPC's publication transaction, then accepts
     * them only if that transaction publishes its genuine final result. Cancellation or rejected publication discards
     * even a frozen lease before retiring the original path claim.
     */
    interface Attempt
    {
        /**
         * Validates the final worker-visible tree and retains rollback authority during response publication.
         * The caller must already have established whole-native zero, original wait and instrumentation/stream disposal.
         * A successful return does not transfer ownership to the worker; {@link #accept()} performs that transition
         * after the original response is accepted. A cancellation before response acceptance calls {@link #discard()}.
         * @throws IllegalStateException if this lease is already frozen or resolved
         * @throws IOException if original root authority changed or the final tree is invalid
         */
        void freeze() throws IOException;

        /**
         * Retires a frozen lease after the original RPC accepted its genuine final action result.
         * Keeps the exact validated output tree at its original paths for worker upload and later reuse.
         * All filesystem/native work and validation must have completed in freeze; this operation only retires
         * the in-memory lease and must not introduce an operational failure after successful RPC publication.
         * The caller must not invoke this operation when publication was cancelled or rejected.
         * @throws IllegalStateException if this lease was not frozen or is already resolved
         */
        void accept();

        /**
         * Restores complete pristine input and temporary state after failed or cancelled execution.
         * The caller must already have established whole-native zero, original wait and instrumentation/stream disposal.
         * This operation also rolls back a frozen lease whose RPC publication was rejected. It retires the lease only
         * after restoration completes; an uncertain failure retains recovery authority and prevents another attempt.
         * @throws IllegalStateException if the lease was already accepted or discarded
         * @throws IOException if roots changed or restoration remains incomplete
         */
        void discard() throws IOException;
    }
}
