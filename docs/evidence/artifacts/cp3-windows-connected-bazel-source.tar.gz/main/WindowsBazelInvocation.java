package com.holdmyspot.codexunleashed.scheduler;

import buildbarn.runner.RunnerOuterClass.RunRequest;
import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Composes the authenticated native Windows Bazel backend and same-path action retries on one coordinator thread.
 * Original RPC/path claims survive retries; the controller, backend daemons and original Bazel consumer remain outside
 * action memory-failure domains. Native workload closure precedes rollback, successful output acceptance and replies.
 */
final class WindowsBazelInvocation implements SchedulerCoordinator.Session<Integer>
{
    /** Borrowed original tooling services. */
    private final ToolingScope tooling;
    /** Borrowed scoped strict parser and original runtime owner. */
    private final WindowsBazelScope scope;
    /** Sole caller memory, workspace and control policy. */
    private final Scheduler.Settings settings;
    /** Validated administrator authorization. */
    private final WindowsBazelLaunchConfiguration authorization;
    /** Actual installed runtime products. */
    private final Path frida;
    /** Exclusive invocation namespace retained through terminal cleanup. */
    private final Path root;
    /** Worker-visible path fixed by the common backend declaration. */
    private final Path workerRoot;
    /** Private host-only snapshots and native state parent. */
    private final Path privateRoot;
    /** Constructing coordinator thread. */
    private final Thread thread = Thread.currentThread();
    /** Unique original invocation identity. */
    private final UUID identity = UUID.randomUUID();
    /** Original readiness completed only by the authenticated worker callback. */
    private final CompletableFuture<Void> workerReadiness = new CompletableFuture<>();
    /** Exact registry for native held action workloads. */
    private final WindowsMeasurements nativeMeasurements;
    /** Content-keyed successful memory history. */
    private final BazelMemoryEstimates estimates;
    /** Every discovered original action, retained through uncertain cleanup. */
    private final Map<String, Action> actions = new LinkedHashMap<>();
    /** Every original Go daemon retained before the next native acquisition. */
    private final List<Daemon> daemons = new ArrayList<>();
    /** Original scoped runtime lease. */
    private FridaRuntime runtime;
    /** Resource-free held action factory, retained through native attempt cleanup. */
    private WindowsAttempts nativeAttempts;
    /** Borrowed console descriptions for the outer consumer only. */
    private WindowsCargoStreams.Root console;
    /** Scope retaining only the existing native console binding. */
    private WindowsCargoScope consoleScope;
    /** Common owner-only authority for private snapshots and daemon state. */
    private BazelBackendCredentials.NativeAuthority protection;
    /** Common exact distribution identity. */
    private BazelNativeBackend.ValidatedDistribution distribution;
    /** Original authenticated Runner transport. */
    private BazelRunner<Admission> runner;
    /** Original common backend including partial acquisition. */
    private BazelNativeBackend backend;
    /** Original build-tool workload, independent of action retry domains. */
    private OuterWorkload original;
    /** Durable owner-thread event stream outside every action tree. */
    private BufferedWriter events;
    /** Whether native preparation consumed its opportunity. */
    private boolean attempted;
    /** Whether new action admission was withdrawn. */
    private boolean stopping;
    /** Whether a final empty Runner poll followed original Bazel completion. */
    private boolean drained;
    /** Genuine original Bazel consumer result after whole-workload collection. */
    private OptionalInt result = OptionalInt.empty();
    /** Whether every invocation dependency has closed. */
    private boolean closed;

    /**
     * Retains resource-free invocation configuration before any native acquisition.
     * @param tooling original borrowed services
     * @param scope original parser/runtime scope
     * @param settings caller-owned scheduler policy
     * @param authorization administrator launch authorization
     * @param root fresh protected invocation directory
     * @param history existing owned persistent history directory
     */
    WindowsBazelInvocation(ToolingScope tooling, WindowsBazelScope scope, Scheduler.Settings settings,
        WindowsBazelLaunchConfiguration authorization, Path root, Path history)
    {
        this.tooling = Objects.requireNonNull(tooling, "tooling");
        this.scope = Objects.requireNonNull(scope, "scope");
        this.settings = Objects.requireNonNull(settings, "settings");
        this.authorization = Objects.requireNonNull(authorization, "authorization");
        this.frida = Objects.requireNonNull(settings.fridaLibrary(), "fridaLibrary");
        this.root = Objects.requireNonNull(root, "root");
        this.workerRoot = root.resolve("worker-builds");
        this.privateRoot = root.resolve("private");
        this.nativeMeasurements = new WindowsMeasurements(tooling);
        this.estimates = new BazelMemoryEstimates(nativeMeasurements, new BazelMemoryHistory(history));
    }

    /**
     * Acquires the actual common backend, authenticated readiness and original consumer once.
     * Partial acquisition remains retained by this invocation for independent explicit cleanup.
     * @throws IOException if current determining inputs or native preparation fail
     */
    void start() throws IOException
    {
        requireThread();
        if (attempted || closed) throw new IllegalStateException("Windows Bazel invocation starts once");
        attempted = true;
        events = Files.newBufferedWriter(root.resolve("events.jsonl"), StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
        record("invocation", Map.of("identity", identity.toString(), "arguments", settings.arguments(),
            "workspace", settings.workspace().toString(), "sourceDigest", authorization.sourceDigest()));
        protection = BazelBackendCredentials.nativeAuthority(tooling, root);
        protection.createDirectory(workerRoot);
        protection.createDirectory(privateRoot);
        distribution = BazelNativeBackend.validateDistribution(tooling,
            BazelNativeBackend.NativeTarget.forHost(System.getProperty("os.name"), System.getProperty("os.arch")),
            authorization.distribution(), protection);
        var credentials = BazelBackendCredentials.generate(root.resolve("credentials"),
            Path.of(System.getProperty("java.home"), "bin", "keytool.exe"), protection);
        runner = new BazelRunner<>(new Boundary(), new BazelRunner.Credentials(credentials.certificateAuthority(),
            credentials.serverCertificate(), credentials.serverKey(), credentials.workerCertificate()));
        runner.start();

        var configuration = new BazelNativeBackend.Configuration(distribution, root, runner.endpoint(), credentials,
            settings.budget().jobs(), authorization.casBytes(), authorization.actionCacheBytes(), authorization.cachePolicy(),
            workerReadiness, this::closeActions);
        BazelNativeBackend.PlatformOwner platform = new BazelNativeBackend.PlatformOwner()
        {
            @Override public BazelBackendCredentials.Protection protection() { return protection; }
            @Override public BazelNativeBackend.WorkerIdentity workerIdentity()
            {
                return new BazelNativeBackend.WindowsWorkerIdentity();
            }
            @Override public BazelNativeBackend.Daemon launch(Path executable, Path configurationFile, Path log,
                Path workingDirectory, Map<String, String> environment) throws IOException
            {
                Map<String, String> combined = new HashMap<>(authorization.environment());
                combined.putAll(environment);
                Daemon daemon = new Daemon(executable, configurationFile, log, workingDirectory, combined);
                daemons.add(daemon);
                daemon.start();
                return daemon;
            }
        };
        try { backend = BazelNativeBackend.start(tooling, configuration, platform); }
        catch (BazelNativeBackend.AcquisitionFailure failure) { backend = failure.backend(); throw failure; }
        record("authenticated-worker-ready", Map.of("workerRoot", workerRoot.toString(),
            "manifest", distribution.manifestHash()));
        runtime = new FridaRuntime(tooling, frida);
        runtime.start();
        nativeAttempts = new WindowsAttempts(identity, Map.of(), settings.controlTimeout(),
            (command, sequence, attemptIdentity, timeout) -> new WindowsAttempt.NativeResources(tooling,
                runtime, nativeMeasurements, command, sequence, attemptIdentity, timeout, null,
                actions.get(command.action().name()).security));
        consoleScope = new WindowsCargoScope(tooling);
        console = WindowsCargoStreams.root(consoleScope);
        original = new OuterWorkload(consumerCommand(authorization.bazel()), authorization.environment());
        original.start();
    }

    /**
     * Preserves direct Bazel arguments and supports an explicit absolute release consumer using the existing hook.
     * @param launcher exact pinned Bazel wrapper with the common startup rc
     * @return executable and unchanged caller argument tail
     */
    private List<String> consumerCommand(Path launcher)
    {
        List<String> command = new ArrayList<>();
        List<String> arguments = settings.arguments();
        if (!arguments.isEmpty() && Path.of(arguments.getFirst()).isAbsolute()) command.addAll(arguments);
        else
        {
            command.add(launcher.toString());
            command.add("--bazelrc=" + backend.startupRc());
            if (!arguments.isEmpty() && arguments.getFirst().equals("bazel")) command.addAll(arguments.subList(1, arguments.size()));
            else command.addAll(arguments);
        }
        return List.copyOf(command);
    }

    @Override public JobQueue.AttemptFactory<Integer> attempts()
    {
        requireThread();
        return (name, sequence) ->
        {
            Action action = actions.get(name);
            if (action == null || action.finished || !action.ready.publicationAllowed())
                throw new IllegalStateException("Original authenticated Bazel action has no execution authority");
            Attempt attempt = new Attempt(action, sequence);
            action.attempts.add(attempt);
            return attempt;
        };
    }

    @Override public Controller.Measurements measurements() { requireThread(); return estimates; }

    @Override public void pump() throws IOException
    {
        requireThread();
        backend.requireAlive();
        for (Action action : actions.values())
        {
            if (!action.finished && !action.ready.publicationAllowed())
                throw new IOException("Original Bazel action RPC cancelled; retain native cleanup before rollback");

        }
        nativeAttempts.pumpAll();
        if (original != null && result.isEmpty()) result = original.advance();
        if (result.isPresent() && !stopping) stopAccepting();
    }

    @Override public Optional<SchedulerCoordinator.Submission> pollSubmission() throws IOException
    {
        requireThread();
        Optional<BazelRunner.Ready<Admission>> incoming = runner.poll();
        if (incoming.isEmpty())
        {
            if (result.isPresent()) drained = true;
            return Optional.empty();
        }
        BazelRunner.Ready<Admission> ready = incoming.orElseThrow();
        String name = identity + ":" + ready.sequence();
        Action action = new Action(name, ready);
        actions.put(name, action);
        action.acquire();
        return Optional.of(estimates.register(name, action.contentIdentity));
    }

    @Override public Optional<SchedulerCoordinator.Blocked> pollBlocked() throws IOException
    {
        requireThread();
        return nativeAttempts.pollBlocked().map(value -> new SchedulerCoordinator.Blocked(value.name(),
            value.attemptSequence(), value.waitSequence()));
    }

    @Override public void acceptOutcome(JobQueue.Completion<Integer> completion) throws IOException
    {
        requireThread();
        Action action = actions.get(completion.name());
        Attempt attempt = action.attempts.stream().filter(value -> value.sequence == completion.attemptSequence())
            .findFirst().orElseThrow(() -> new IOException("Unknown original Bazel attempt outcome"));
        if (!attempt.closed) throw new IOException("Native attempt remains open before output acceptance");
        boolean accepted = false;
        if (!completion.outcome().aborted())
        {
            action.streams.close();
            int status = completion.outcome().result();
            if (status == 0)
            {
                accepted = action.ready.publish(() ->
                {
                    attempt.lease.freeze();
                    if (!action.ready.publicationAllowed()) throw new IOException("Bazel publication cancelled after final validation");
                }, status);
                if (accepted) attempt.lease.accept();
                else attempt.lease.discard();
            }
            else
            {
                attempt.lease.discard();
                accepted = action.ready.complete(status);
            }
            attempt.lease = null;
            action.workspace.close();
            action.security.close();
            action.ready.releaseClaim();
            action.finished = true;
            record("action-result", Map.of("name", action.name, "sequence", attempt.sequence, "exit", status,
                "published", accepted, "identity", action.contentIdentity));
        }
        estimates.completed(completion.name(), completion.attemptSequence(),
            accepted && !completion.outcome().aborted() && completion.outcome().result() == 0);
    }

    @Override public OptionalInt pollToolResult() { requireThread(); return result; }
    @Override public boolean inputClosed() { requireThread(); return result.isPresent() && drained; }
    @Override public boolean hasOpenAttempts()
    {
        requireThread();
        return actions.values().stream().flatMap(action -> action.attempts.stream()).anyMatch(attempt -> !attempt.closed);
    }

    @Override public void stopAccepting()
    {
        requireThread();
        stopping = true;
        if (runner != null) runner.stopAccepting();
    }

    /**
     * Withdraws admissions and closes actions before the common backend can terminate its worker.
     * @throws IOException if any native or storage lease remains unresolved
     */
    private void closeActions() throws IOException
    {
        stopAccepting();
        IOException unresolved = null;
        if (original != null)
            try { original.close(); }
            catch (IOException failure) { unresolved = failure; }
        for (Action action : actions.values())
            try { action.close(); }
            catch (IOException failure)
            {
                if (unresolved == null) unresolved = failure;
                else unresolved.addSuppressed(failure);
            }
        if (unresolved != null) throw unresolved;
    }

    @Override public void close() throws IOException
    {
        requireThread();
        if (closed) return;
        closeActions();
        if (backend != null) backend.close();
        else for (Daemon daemon : daemons.reversed()) daemon.close();
        if (runner != null) runner.close();
        if (runtime != null) runtime.close();
        if (console != null) console.close();
        if (consoleScope != null) consoleScope.close();
        closed = true;
    }

    /**
     * Closes the event stream after the coordinator recorded its terminal result and native owners closed.
     * @throws IOException if native closure remains incomplete or final stream closure fails
     */
    void closeRecording() throws IOException
    {
        requireThread();
        if (!closed) throw new IOException("Native owners must close before final recording retirement");
        if (events != null)
        {
            events.close();
            events = null;
        }
    }

    /**
     * Indicates complete original invocation closure.
     * @return whether native and shared dependencies all acknowledged retirement
     */
    boolean isClosed() { requireThread(); return closed; }

    /**
     * Appends a primitive copied event to the invocation's durable owner-thread stream.
     * @param event explicit event name
     * @param payload copied JSON-compatible primitive fields
     * @throws IOException if durable recording fails
     */
    void record(String event, Object payload) throws IOException
    {
        requireThread();
        if (events == null) return;
        Object copied = payload;
        if (payload instanceof Policy.Decision value)
            copied = Map.of("control", value.control().name(), "name", value.jobName(), "reason", value.reason());
        else if (payload instanceof SchedulerCoordinator.Blocked value)
            copied = Map.of("name", value.name(), "attemptSequence", value.attemptSequence(), "waitSequence", value.waitSequence());
        else if (payload instanceof SchedulerCoordinator.Submission value)
            copied = Map.of("name", value.name(), "estimate", value.peakBytes() == null ? "unknown" : value.peakBytes());
        else if (payload instanceof JobQueue.Completion<?> value)
            copied = Map.of("name", value.name(), "attemptSequence", value.attemptSequence(),
                "aborted", value.outcome().aborted(), "result", value.outcome().result() == null ? "absent" : Integer.toUnsignedLong((Integer) value.outcome().result()));
        events.write(tooling.getJsonMapper().writeValueAsString(Map.of("event", event, "nanoTime", System.nanoTime(), "payload", copied)));
        events.newLine();
        events.flush();
    }

    /** Rejects cross-thread native composition. */
    private void requireThread()
    {
        if (Thread.currentThread() != thread) throw new IllegalStateException("Windows Bazel invocation belongs to its coordinator thread");
    }

    /** Owns one original RPC, independent snapshots and original stream descriptions across retries. */
    private final class Action implements AutoCloseable
    {
        /** Original logical identity and queue position correlation. */
        private final String name;
        /** Original response and path claim authority. */
        private final BazelRunner.Ready<Admission> ready;
        /** Every issued attempt, including partial acquisitions. */
        private final List<Attempt> attempts = new ArrayList<>();
        /** Complete pristine storage owner retained before native launch. */
        private WindowsBazelWorkspace workspace;
        /** Original stdout/stderr descriptions retained across retries. */
        private WindowsBazelStreams streams;
        /** Action package, native root pins and ACL restoration owner. */
        private WindowsBazelSecurity security;
        /** Complete immutable content identity for memory history. */
        private String contentIdentity;
        /** Whether publication or explicit cancellation cleanup resolved this action. */
        private boolean finished;

        /**
         * Retains an admitted original RPC before fallible storage acquisition.
         * @param name stable invocation-issued logical name
         * @param ready original authenticated request
         */
        private Action(String name, BazelRunner.Ready<Admission> ready)
        {
            this.name = name;
            this.ready = ready;
        }

        /**
         * Captures complete pristine input and temporary trees and original open-file descriptions.
         * @throws IOException if current admission, independent copy or stream acquisition fails
         */
        private void acquire() throws IOException
        {
            Admission admission = ready.admission();
            admission.requireCurrent();
            try { security = WindowsBazelSecurity.open(tooling, admission.input(), admission.temporary(), privateRoot,
                List.of(authorization.toolchainRoot(), Path.of(System.getProperty("java.home")), frida)); }
            catch (WindowsBazelSecurity.PreparationFailure failure) { security = failure.owner(); throw failure; }
            var access = new WindowsBazelWorkspace.Access()
            {
                @Override public void requireRoots() throws IOException { security.requireRoots(); }
                @Override public void materialized(Path input, Path temporary) throws IOException
                { security.materialized(input, temporary); }
                @Override public void removeReadonly(Path entry) throws IOException
                { scope.files().unlink(entry, protection); }
            };
            try { workspace = WindowsBazelWorkspace.open(admission.input(), admission.temporary(),
                privateRoot.resolve("request-" + ready.sequence()), protection, access); }
            catch (WindowsBazelWorkspace.PreparationFailure failure) { workspace = failure.recovery(); throw failure; }
            contentIdentity = BazelWorkIdentity.identify(workspace.immutableSnapshot(), admission.input(),
                ready.request().getArgumentsList(), ready.request().getEnvironmentVariablesMap(), admission.cwd(),
                authorization.backendIdentity() + ":" + authorization.sourceDigest() + ":" + distribution.manifestHash());
            try { streams = WindowsBazelStreams.open(tooling, admission.stdout(), admission.stderr()); }
            catch (WindowsBazelStreams.AcquisitionFailure failure) { streams = failure.owner(); throw failure; }
            nativeAttempts.register(name, new WindowsAttempts.Command(new Controller.Action(name, ready.sequence()),
                ready.request().getArgumentsList(), admission.cwd(), ready.request().getEnvironmentVariablesMap(),
                streams.input(), streams.stdout(), streams.stderr()));
            record("ready-input", Map.of("name", name, "originalRun", ready.sequence(), "identity", contentIdentity,
                "input", admission.input().toString(), "cwd", admission.cwd().toString(),
                "arguments", ready.request().getArgumentsList(), "environment", ready.request().getEnvironmentVariablesMap()));
        }

        @Override public void close() throws IOException
        {
            if (finished) return;
            ready.fail(new IOException("Original Bazel invocation is closing"));
            IOException unresolved = null;
            for (Attempt attempt : attempts)
                try { attempt.close(); }
                catch (IOException failure)
                {
                    if (unresolved == null) unresolved = failure;
                    else unresolved.addSuppressed(failure);
                }
            if (unresolved != null) throw unresolved;
            if (streams != null) streams.close();
            for (Attempt attempt : attempts)
                if (attempt.lease != null)
                {
                    attempt.lease.discard();
                    attempt.lease = null;
                }
            if (workspace != null) workspace.close();
            if (security != null) security.close();
            ready.releaseClaim();
            finished = true;
        }
    }

    /** Retains one queue attempt's native and storage owners until genuine collection and rollback. */
    private final class Attempt implements JobQueue.Attempt<Integer>
    {
        /** Original action whose RPC remains pending. */
        private final Action action;
        /** Fresh queue-wide ordinal. */
        private final long sequence;
        /** Same-path execution and rollback lease. */
        private BazelWorkspace.Attempt lease;
        /** Partial or active original native action owner. */
        private WindowsAttempt nativeAttempt;
        /** Genuine non-aborted or terminated result after whole-native zero. */
        private JobQueue.Outcome<Integer> outcome;
        /** Whether native close completed and any retry rollback completed. */
        private boolean closed;

        /**
         * Reserves resource-free attempt ownership before queue acquisition.
         * @param action original logical action
         * @param sequence fresh queue ordinal
         */
        private Attempt(Action action, long sequence) { this.action = action; this.sequence = sequence; }

        @Override public void start() throws IOException
        {
            if (nativeAttempt != null || lease != null || closed) throw new IllegalStateException("Queue attempt starts once");
            action.ready.admission().requireCurrent();
            if (action.attempts.stream().anyMatch(value -> value != this && value.closed)) action.streams.reset();
            lease = action.workspace.begin(sequence);
            canonicalDirectory(action.ready.admission().cwd());
            nativeAttempt = nativeAttempts.create(action.name, sequence);
            nativeAttempt.start();
            record("attempt-started", Map.of("name", action.name, "sequence", sequence,
                "originalRun", action.ready.sequence()));
        }

        @Override public void resume(long waitSequence) throws IOException { nativeAttempt.resume(waitSequence); }
        @Override public void terminate() throws IOException { if (nativeAttempt != null) nativeAttempt.terminate(); }
        @Override public Optional<JobQueue.Outcome<Integer>> poll() throws IOException
        {
            if (nativeAttempt == null || closed) return Optional.empty();
            Optional<JobQueue.Outcome<Integer>> current = nativeAttempt.poll().map(value ->
                new JobQueue.Outcome<>((int) value.result().rootExit(), value.aborted()));
            current.ifPresent(value -> outcome = value);
            return current;
        }

        @Override public void close() throws IOException
        {
            if (closed) return;
            if (nativeAttempt != null)
            {
                try { nativeAttempt.close(); }
                catch (IOException retained)
                {
                    if (!nativeAttempt.cleanupComplete()) throw retained;
                    record("attempt-operation-failure-cleaned", Map.of("name", action.name,
                        "sequence", sequence, "failure", retained.toString()));
                }
            }
            if (lease != null && (outcome == null || outcome.aborted()))
            {
                lease.discard();
                lease = null;
                record("attempt-rollback", Map.of("name", action.name, "sequence", sequence,
                    "nativeClosed", true, "originalRun", action.ready.sequence()));
            }
            closed = true;
        }
    }

    /** Authenticates native path objects on RPC threads without acquiring a native action owner. */
    private final class Boundary implements BazelRunner.Boundary<Admission>
    {
        /** Stable worker directory identity captured before worker launch. */
        private Object workerKey;

        /** Creates a resource-free native pathname boundary. */
        private Boundary() {}

        @Override public synchronized void validateRoot() throws IOException
        {
            canonicalDirectory(workerRoot);
            Object current = fileKey(workerRoot);
            if (workerKey == null) workerKey = current;
            else if (!workerKey.equals(current)) throw new IOException("Original worker build root was replaced");
        }

        @Override public void checkReadiness(String path) throws IOException
        {
            validateRoot();
            resolve(path, true);
            workerReadiness.complete(null);
        }

        @Override public Admission admit(RunRequest request) throws IOException
        {
            validateRoot();
            Path input = resolve(request.getInputRootDirectory(), true);
            Path temporary = resolve(request.getTemporaryDirectory(), true);
            Path cwd = input.resolve(relative(request.getWorkingDirectory(), true));
            canonicalDirectory(cwd);
            Path logs = resolve(request.getServerLogsDirectory(), true);
            Path stdout = resolve(request.getStdoutPath(), false);
            Path stderr = resolve(request.getStderrPath(), false);
            if (input.startsWith(temporary) || temporary.startsWith(input) || stdout.equals(stderr) ||
                stdout.startsWith(input) || stderr.startsWith(input) || stdout.startsWith(temporary) || stderr.startsWith(temporary))
                throw new IOException("Bazel original input, temporary and stream locations must be independent");
            Map<Path, Object> keys = new LinkedHashMap<>();
            for (Path directory : List.of(workerRoot, input, temporary, logs, stdout.getParent(), stderr.getParent()))
                keys.put(directory, fileKey(directory));
            return new Admission(input, temporary, cwd, stdout, stderr, logs, Map.copyOf(keys), BazelBackendCredentials.nativeIdentity(tooling));
        }

        /**
         * Resolves an exact native protocol path beneath the worker root without aliases or symbolic ancestors.
         * @param value original relative protocol pathname
         * @param isDirectory whether the final entry is an existing directory
         * @return original absolute native location
         * @throws IOException if native identity or path syntax is invalid
         */
        private Path resolve(String value, boolean isDirectory) throws IOException
        {
            Path path = workerRoot.resolve(relative(value, false));
            canonicalDirectory(isDirectory ? path : path.getParent());
            if (!isDirectory && Files.exists(path, LinkOption.NOFOLLOW_LINKS))
                throw new IOException("Original Bazel output stream already exists: " + path);
            return path;
        }
    }

    /**
     * Immutable original native admission, independent of response cancellation and native acquisition.
     * @param input original input directory
     * @param temporary original temporary directory
     * @param cwd exact original action working directory
     * @param stdout original absent stdout destination
     * @param stderr original absent stderr destination
     * @param logs original server-log directory
     * @param keys stable original directory object identities
     * @param authority shared actual native file-identity implementation
     */
    private record Admission(Path input, Path temporary, Path cwd, Path stdout, Path stderr, Path logs,
        Map<Path, Object> keys, BazelNativeBackend.FileIdentity authority) implements BazelRunner.Admission
    {
        @Override public List<Path> claimedPaths() { return List.of(input, temporary, stdout, stderr, logs); }

        /**
         * Revalidates original object attachment before action storage or native acquisition.
         * @throws IOException if a native path was replaced or aliased
         */
        private void requireCurrent() throws IOException
        {
            for (Map.Entry<Path, Object> entry : keys.entrySet())
            {
                canonicalDirectory(entry.getKey(), authority);
                if (!entry.getValue().equals(authority.identity(entry.getKey())))
                    throw new IOException("Original admitted Bazel directory was replaced: " + entry.getKey());
            }
        }
    }

    /**
     * Validates native protocol relative paths without rewriting argument strings.
     * @param value original protocol path
     * @param emptyAllowed whether empty cwd means the input root
     * @return normalized relative pathname
     * @throws IOException if syntax is ambiguous or can escape the native root
     */
    private static Path relative(String value, boolean emptyAllowed) throws IOException
    {
        if (value.isEmpty() && emptyAllowed) return Path.of("");
        if (value.isEmpty() || value.startsWith("/") || value.indexOf(0) >= 0 || value.indexOf('\\') >= 0 || value.indexOf(':') >= 0)
            throw new IOException("Native Runner path must be nonempty and relative");
        for (String component : value.split("/", -1))
            if (component.isEmpty() || component.equals(".") || component.equals("..") || component.endsWith(".") || component.endsWith(" "))
                throw new IOException("Native Runner path has an ambiguous component");
        Path path = Path.of(value);
        if (path.isAbsolute() || !path.normalize().equals(path)) throw new IOException("Native Runner path is not normalized");
        return path;
    }

    /**
     * Rejects symbolic ancestors and native case aliases before capturing path claims.
     * @param path existing absolute directory
     * @throws IOException if its original spelling does not identify a direct canonical directory
     */
    private void canonicalDirectory(Path path) throws IOException
    { canonicalDirectory(path, BazelBackendCredentials.nativeIdentity(tooling)); }

    /**
     * Rejects indirect ancestors using actual native no-follow identities.
     * @param path direct absolute existing directory
     * @param authority shared native identity implementation
     * @throws IOException if any ancestor is indirect or the spelling is aliased
     */
    private static void canonicalDirectory(Path path, BazelNativeBackend.FileIdentity authority) throws IOException
    {
        if (!path.isAbsolute() || !path.equals(path.normalize()) || !Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS) ||
            !path.equals(path.toRealPath())) throw new IOException("Canonical direct native directory required: " + path);
        for (Path entry = path; entry != null; entry = entry.getParent()) authority.identity(entry);
    }

    /**
     * Reads stable native NIO object authority without following its final entry.
     * @param path existing native entry
     * @return nonnull stable filesystem key
     * @throws IOException if the filesystem cannot supply stable identity
     */
    private Object fileKey(Path path) throws IOException
    { return BazelBackendCredentials.nativeIdentity(tooling).identity(path); }

    /** Retains the original consumer in its independent atomic Job outside every action memory domain. */
    private final class OuterWorkload implements AutoCloseable
    {
        /** Copied original executable and unchanged argument tail. */
        private final List<String> command;
        /** Complete explicit original consumer environment. */
        private final Map<String, String> environment;
        /** Original native owner, including checked partial preparation. */
        private WindowsProcess process;
        /** Whether native destruction acknowledged whole-Job zero and original process collection. */
        private boolean retired;

        /**
         * Retains configuration before native acquisition.
         * @param command exact executable and argument tail
         * @param environment complete explicit environment
         */
        private OuterWorkload(List<String> command, Map<String, String> environment)
        { this.command = List.copyOf(command); this.environment = Map.copyOf(environment); }

        /**
         * Creates the original atomic Job while suspended, then releases its primary thread.
         * @throws IOException if original preparation or release fails
         */
        private void start() throws IOException
        {
            try { process = WindowsProcess.prepare(tooling, command, settings.workspace(), environment,
                console.input(), console.output(), console.error()); }
            catch (WindowsProcess.PreparationFailure failure) { process = failure.owner(); throw failure; }
            process.releaseRoot();
        }

        /**
         * Observes a genuine original result only after the entire native Job is empty.
         * @return original DWORD bit pattern, or empty while a genuine original member remains
         * @throws IOException if the original process or Job observations fail
         */
        private OptionalInt advance() throws IOException
        {
            Optional<WindowsProcess.Result> value = process.poll();
            if (value.isEmpty()) return OptionalInt.empty();
            WindowsProcess.Result originalResult = value.orElseThrow();
            if (originalResult.aborted()) throw new IOException("Original Bazel consumer was terminated");
            close();
            return OptionalInt.of((int) originalResult.rootExit());
        }

        @Override public void close() throws IOException
        {
            if (retired) return;
            if (process != null) process.close();
            retired = true;
        }
    }

    /** Retains each daemon's logs through its dedicated original native owner-thread collection. */
    private final class Daemon implements BazelNativeBackend.Daemon
    {
        /** Actual authenticated native product. */
        private final Path executable;
        /** Common protected configuration. */
        private final Path configuration;
        /** Common already created protected stdout log. */
        private final Path log;
        /** Explicit original working directory. */
        private final Path directory;
        /** Complete copied controller-owned environment. */
        private final Map<String, String> environment;
        /** Original descriptions retained through every native borrower. */
        private WindowsBazelStreams streams;
        /** Original native owner thread, retained before acquisition. */
        private WindowsBazelDaemon nativeOwner;
        /** Whether native and log disposal acknowledged completion. */
        private boolean retired;

        /**
         * Reserves resource-free composition before log and daemon acquisition.
         * @param executable actual native product
         * @param configuration common protected configuration
         * @param log existing empty protected stdout log
         * @param directory explicit native working directory
         * @param environment complete daemon environment
         */
        private Daemon(Path executable, Path configuration, Path log, Path directory, Map<String, String> environment)
        {
            this.executable = executable;
            this.configuration = configuration;
            this.log = log;
            this.directory = directory;
            this.environment = Map.copyOf(environment);
        }

        /**
         * Opens existing protected log objects and starts the original native daemon once.
         * @throws IOException if any native log or daemon acquisition fails
         */
        private void start() throws IOException
        {
            Path error = log.resolveSibling(log.getFileName() + ".stderr");
            protection.createFile(error);
            try { streams = WindowsBazelStreams.openLogs(tooling, protection, log, error); }
            catch (WindowsBazelStreams.AcquisitionFailure failure) { streams = failure.owner(); throw failure; }
            nativeOwner = new WindowsBazelDaemon(tooling, executable, configuration, directory, environment,
                streams, settings.controlTimeout());
            nativeOwner.start();
        }

        @Override public boolean isAlive() { return nativeOwner != null && nativeOwner.isAlive(); }
        @Override public long exitValue() throws IOException
        {
            if (nativeOwner == null) throw new IOException("Original native daemon was never acquired");
            return nativeOwner.exitValue();
        }
        @Override public CompletableFuture<Long> onExit()
        {
            if (nativeOwner == null) throw new IllegalStateException("Original native daemon was never acquired");
            return nativeOwner.onExit();
        }
        @Override public void close() throws IOException
        {
            if (retired) return;
            if (nativeOwner != null) nativeOwner.close();
            if (streams != null) streams.close();
            retired = true;
        }
    }
}
