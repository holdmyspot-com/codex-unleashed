package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import io.github.cowwoc.pouch10.core.AbstractScope;
import io.github.cowwoc.pouch10.core.ConcurrentLazyFactory;
import io.github.cowwoc.pouch10.core.Scopes;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import tools.jackson.core.StreamReadConstraints;
import tools.jackson.core.StreamReadFeature;
import tools.jackson.core.json.JsonFactory;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.json.JsonMapper;

/**
 * Owns bounded native Bazel profile parsing services for one Windows invocation.
 * The caller retains its borrowed tooling scope through native cleanup. Parser acquisition is safe for concurrent
 * callers while open; native execution owners remain coordinator-thread confined and retain their own lifetimes.
 */
final class WindowsBazelScope extends AbstractScope
{
    /** Caller-owned linker and application services retained through this scope's borrowers. */
    private final ToolingScope tooling;
    /** Strict profile parser: one MiB documents, eight nesting levels, 262144-character strings and 20-digit numbers. */
    private final ConcurrentLazyFactory<JsonMapper> json = ConcurrentLazyFactory.create(() ->
        JsonMapper.builder(JsonFactory.builder().enable(StreamReadFeature.STRICT_DUPLICATE_DETECTION).
            streamReadConstraints(StreamReadConstraints.builder().maxDocumentLength(1048576).maxNestingDepth(8).
                maxStringLength(262144).maxNumberLength(20).build()).build()).
            enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS).build(), value -> {});
    /** Immutable fixed-ABI file disposition bindings shared by serialized native unlink operations. */
    private final ConcurrentLazyFactory<WindowsBazelFiles> files;
    /** Indicates whether disposal began and new service acquisition is forbidden. */
    private final AtomicBoolean closed = new AtomicBoolean();

    /**
     * Borrows caller services without acquiring native resources or constructing a parser.
     * @param tooling caller-owned services retained through completed cleanup
     * @throws NullPointerException if {@code tooling} is null
     */
    WindowsBazelScope(ToolingScope tooling)
    {
        this.tooling = Objects.requireNonNull(tooling, "tooling");
        files = ConcurrentLazyFactory.create(() -> new WindowsBazelFiles(this.tooling), value -> {});
    }

    /**
     * Returns the caller-owned application and native linker services.
     * @return borrowed services
     * @throws IllegalStateException if this scope is closed
     */
    ToolingScope tooling()
    {
        requireOpen();
        return tooling;
    }

    /**
     * Returns the immutable bounded parser that rejects duplicate fields and trailing JSON documents.
     * @return borrowed parser retained by this scope
     * @throws IllegalStateException if this scope is closed
     */
    JsonMapper json()
    {
        requireOpen();
        return json.getValue();
    }

    /**
     * Returns fixed native disposition bindings without acquiring an operation handle.
     * @return borrowed immutable bindings retained by this scope
     * @throws IllegalStateException if this scope is closed
     * @throws UnsupportedOperationException if the actual host lacks the required Windows ABI
     */
    WindowsBazelFiles files()
    {
        requireOpen();
        return files.getValue();
    }

    @Override public boolean isClosed() { return closed.get(); }

    @Override public void close()
    {
        if (closed.compareAndSet(false, true))
            Scopes.runAll(() -> children.shutdown(Duration.ZERO), json::close, files::close);
    }

    /**
     * Rejects acquisition after disposal begins.
     * @throws IllegalStateException if this scope is closed
     */
    private void requireOpen()
    {
        if (closed.get()) throw new IllegalStateException("Bazel scope is closed");
    }
}
