package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeoutException;

/**
 * Entry point of the packaged native Windows Bazel console launcher.
 * The approved consumer receives the absolute packaged executable through {@code CODEX_BAZEL_BIN};
 * its invocation environment also carries the pinned real executable and the common backend startup rc.
 * Arguments are captured using existing native UTF-16 ingress and passed through WindowsProcess's CRT encoding.
 */
public final class WindowsBazelLauncher
{
    /** Invocation-approved real Bazel executable, never the wrapper itself. */
    static final String EXECUTABLE_ENV = "CODEX_BAZEL_EXECUTABLE";
    /** Invocation-owned common backend startup configuration. */
    static final String STARTUP_RC_ENV = "CODEX_BAZEL_STARTUP_RC";
    /** Maximum supported monotonic whole-Job wait, without imposing a practical build deadline. */
    private static final Duration COMPLETION_WAIT = Duration.ofNanos(Long.MAX_VALUE);

    /** Prevents construction of the process entry point. */
    private WindowsBazelLauncher() {}

    /**
     * Adds approved launcher configuration to a complete consumer environment.
     * Reserved names are replaced case-insensitively, matching Windows environment semantics.
     * The app-image DLL directory is prepended to PATH, as required to preserve native launcher ingress.
     * The application image must be packaged before invocation; no compiler is needed by the consumer.
     * @param environment complete caller environment
     * @param launcher absolute packaged native console executable
     * @param executable absolute pinned real Bazel executable
     * @param startupRc absolute common backend startup rc
     * @return immutable configured environment
     * @throws NullPointerException if an input or environment entry is null
     * @throws IllegalArgumentException if a path is relative
     */
    static Map<String, String> environment(Map<String, String> environment, Path launcher,
        Path executable, Path startupRc)
    {
        Objects.requireNonNull(environment, "environment");
        var result = new LinkedHashMap<String, String>();
        for (var entry : environment.entrySet())
        {
            String name = Objects.requireNonNull(entry.getKey(), "environment name");
            String value = Objects.requireNonNull(entry.getValue(), "environment value");
            boolean reserved = name.equalsIgnoreCase("CODEX_BAZEL_BIN") ||
                name.equalsIgnoreCase(EXECUTABLE_ENV) || name.equalsIgnoreCase(STARTUP_RC_ENV);
            if (!reserved) result.put(name, value);
        }
        Path image = absolute(launcher);
        String pathName = result.keySet().stream().filter(name -> name.equalsIgnoreCase("PATH")).
            findFirst().orElse("PATH");
        String application = image.getParent().resolve("app").toString();
        result.put(pathName, result.containsKey(pathName) ? application + ";" + result.get(pathName) : application);
        result.put("CODEX_BAZEL_BIN", image.toString());
        result.put(EXECUTABLE_ENV, absolute(executable).toString());
        result.put(STARTUP_RC_ENV, absolute(startupRc).toString());
        return Map.copyOf(result);
    }

    /**
     * Prepends common startup arguments while preserving every caller argument and its order.
     * @param environment actual captured Windows environment
     * @param arguments caller arguments excluding the native launcher executable
     * @return immutable real Bazel command
     * @throws NullPointerException if an input or argument is null
     * @throws IOException if an approved path is absent or relative
     */
    static List<String> command(Map<String, String> environment, List<String> arguments) throws IOException
    {
        Objects.requireNonNull(environment, "environment");
        Objects.requireNonNull(arguments, "arguments");
        var result = new ArrayList<String>();
        result.add(requiredPath(environment, EXECUTABLE_ENV).toString());
        result.add("--batch");
        result.add("--bazelrc=" + requiredPath(environment, STARTUP_RC_ENV));
        result.addAll(List.copyOf(arguments));
        return List.copyOf(result);
    }

    /**
     * Executes real Bazel with exact native arguments, working directory, environment and separate binary streams.
     * Resources remain live until genuine whole-Job completion. Exit retains all unsigned DWORD status bits.
     * @param ignored JVM arguments, replaced by the actual native UTF-16 command line
     * @throws IOException if native capture, process ownership or cleanup fails
     */
    public static void main(String[] ignored) throws IOException
    {
        long status;
        try (DefaultToolingScope tooling = new DefaultToolingScope();
            WindowsCargoScope scope = new WindowsCargoScope(tooling))
        {
            var state = WindowsCreationReceipt.currentState(tooling);
            var arguments = WindowsCargoRegistration.parseCommandLine(tooling, state.commandLine());
            var environment = WindowsCargoRegistration.nativeEnvironment(state.environment());
            try (var streams = WindowsCargoStreams.root(scope);
                var process = WindowsProcess.start(tooling,
                    command(environment, arguments.subList(1, arguments.size())), Path.of(state.directory()),
                    environment, streams.input(), streams.output(), streams.error()))
            {
                try { status = process.waitFor(COMPLETION_WAIT).rootExit(); }
                catch (TimeoutException failure) { throw new IOException("Bazel exceeded the supported wait range", failure); }
            }
        }
        System.exit((int) status);
    }

    /**
     * Requires an explicitly absolute caller path without resolving relative input against ambient state.
     * @param path caller path
     * @return unchanged absolute path
     * @throws NullPointerException if path is null
     * @throws IllegalArgumentException if path is relative
     */
    private static Path absolute(Path path)
    {
        Objects.requireNonNull(path, "path");
        if (!path.isAbsolute()) throw new IllegalArgumentException("Bazel launcher paths must be absolute: " + path);
        return path;
    }

    /**
     * Reads one required path using Windows environment name comparison.
     * @param environment actual captured environment
     * @param name required approved variable
     * @return absolute path without normalization or path rewriting
     * @throws IOException if the variable is absent, empty, conflicting or relative
     */
    private static Path requiredPath(Map<String, String> environment, String name) throws IOException
    {
        String value = null;
        for (var entry : environment.entrySet())
            if (entry.getKey().equalsIgnoreCase(name))
            {
                if (value != null) throw new IOException("Conflicting Bazel launcher environment: " + name);
                value = entry.getValue();
            }
        if (value == null || value.isEmpty()) throw new IOException("Bazel launcher requires " + name);
        Path path = Path.of(value);
        if (!path.isAbsolute()) throw new IOException("Bazel launcher requires an absolute " + name);
        return path;
    }
}
