package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.IOException;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemoryLayout;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;

/**
 * Owns one action's NUL input and separate, newly created output files across native attempts.
 * Callers keep this owner open until the entire action Job is empty and its hooks are disposed.
 * Resetting after that barrier clears both original file descriptions for a fresh retry.
 * Output files belong to the worker workspace and remain there after handle retirement.
 * Operations on one owner are serialized; the borrowed Pouch scope outlives this owner.
 */
final class WindowsBazelStreams implements AutoCloseable
{
    /** Native operations retained until every handle has been retired successfully. */
    private final Calls calls;
    /** Directory pins followed by stream handles, in acquisition order. */
    private final List<OwnedHandle> handles = new ArrayList<>();
    /** Original owned NUL input, acquired without using process standard handles. */
    private MemorySegment input;
    /** Original owned standard-output file description. */
    private MemorySegment stdout;
    /** Original owned standard-error file description. */
    private MemorySegment stderr;
    /** Indicates whether terminal disposal started, so handles can no longer be borrowed. */
    private boolean closing;
    /** Indicates whether every owned resource was successfully disposed. */
    private boolean closed;
    /** First failed or uncertain disposal, retained without replaying its native effect. */
    private IOException closeFailure;

    /**
     * Creates exact worker-supplied output destinations and opens NUL input on native 64-bit Windows.
     * Existing destinations are rejected rather than truncated. Every ancestor is pinned against
     * deletion and checked using the shared no-follow native identity reader before file creation.
     * If acquisition fails, all acquired handle close authorities are consumed once. A failed cleanup
     * is reported as {@link AcquisitionFailure}, which retains this owner for diagnostic ownership.
     * @param scope borrowed Pouch services retained through disposal
     * @param stdout absolute normalized, absent standard-output destination
     * @param stderr absolute normalized, absent distinct standard-error destination
     * @return stream owner whose handles WindowsProcess may borrow
     * @throws NullPointerException if an argument is null
     * @throws IllegalArgumentException if destinations are relative, non-normalized or equal
     * @throws UnsupportedOperationException if native 64-bit Windows is unavailable
     * @throws IOException if creation, identity checking or cleanup fails
     */
    static WindowsBazelStreams open(ToolingScope scope, Path stdout, Path stderr) throws IOException
    {
        Objects.requireNonNull(scope, "scope");
        validate(stdout, stderr);
        BazelNativeBackend.FileIdentity identity = BazelBackendCredentials.nativeIdentity(scope);
        return open(new Native(scope, false), identity, stdout, stderr);
    }

    /**
     * Opens two existing empty controller-owned daemon logs without replacing either original file.
     * Action output creation continues using CREATE_NEW through the separate open operation.
     * @param scope borrowed native services
     * @param authority original private-file protection and native identity authority
     * @param stdout existing empty protected stdout log
     * @param stderr existing empty protected stderr log
     * @return original descriptions with ancestor pins retained through daemon Job closure
     * @throws IOException if protection, identity, emptiness or native acquisition fails
     */
    static WindowsBazelStreams openLogs(ToolingScope scope, BazelBackendCredentials.NativeAuthority authority,
        Path stdout, Path stderr) throws IOException
    {
        validate(stdout, stderr);
        for (Path file : List.of(stdout, stderr))
        {
            authority.requireFile(file);
            if (Files.size(file) != 0) throw new IOException("Original daemon log is not empty: " + file);
        }
        Object outputIdentity = authority.identity(stdout), errorIdentity = authority.identity(stderr);
        WindowsBazelStreams owner = open(new Native(scope, true), authority, stdout, stderr);
        try
        {
            authority.requireFile(stdout);
            authority.requireFile(stderr);
            if (!outputIdentity.equals(authority.identity(stdout)) || !errorIdentity.equals(authority.identity(stderr)))
                throw new IOException("Original protected daemon log was replaced during acquisition");
            return owner;
        }
        catch (IOException | RuntimeException | Error failure)
        {
            try { owner.close(); }
            catch (IOException cleanup)
            {
                AcquisitionFailure retained = new AcquisitionFailure(failure, owner);
                retained.addSuppressed(cleanup);
                if (failure instanceof Error fatal) { fatal.addSuppressed(retained); throw fatal; }
                throw retained;
            }
            throw failure;
        }
    }

    /**
     * Acquires outputs through transferred native operations and a borrowed no-follow identity reader.
     * Directory identities are checked across pin acquisition, and new file identities are checked for aliasing.
     * @param calls native operation owner transferred after argument validation
     * @param identity shared no-follow filesystem identity reader
     * @param stdout absolute normalized, absent standard-output destination
     * @param stderr absolute normalized, absent distinct standard-error destination
     * @return acquired stream owner
     * @throws NullPointerException if an argument is null
     * @throws IllegalArgumentException if destinations are relative, non-normalized or equal
     * @throws IOException if acquisition or cleanup fails
     */
    static WindowsBazelStreams open(Calls calls, BazelNativeBackend.FileIdentity identity,
        Path stdout, Path stderr) throws IOException
    {
        Objects.requireNonNull(identity, "identity");
        validate(stdout, stderr);
        WindowsBazelStreams owner = new WindowsBazelStreams(calls);
        try
        {
            LinkedHashSet<Path> parents = new LinkedHashSet<>();
            for (Path destination : List.of(stdout, stderr))
            {
                Path parent = destination.getParent();
                List<Path> ancestors = new ArrayList<>();
                while (parent != null) { ancestors.add(parent); parent = parent.getParent(); }
                for (Path ancestor : ancestors.reversed()) parents.add(ancestor);
            }
            for (Path parent : parents)
            {
                Object before = identity.identity(parent);
                if (!Files.isDirectory(parent, LinkOption.NOFOLLOW_LINKS))
                    throw new IOException("Output ancestor is not a directory: " + parent);
                owner.acquire(() -> calls.pinDirectory(parent));
                if (!before.equals(identity.identity(parent)))
                    throw new IOException("Output ancestor changed during pin acquisition: " + parent);
            }
            owner.stdout = owner.acquire(() -> calls.create(stdout));
            Object outputIdentity = identity.identity(stdout);
            owner.stderr = owner.acquire(() -> calls.create(stderr));
            Object errorIdentity = identity.identity(stderr);
            if (outputIdentity.equals(errorIdentity))
                throw new IOException("Output destinations identify the same native file");
            owner.input = owner.acquire(calls::openNull);
            return owner;
        }
        catch (IOException | RuntimeException | Error failure)
        {
            try { owner.close(); }
            catch (IOException cleanup)
            {
                AcquisitionFailure retained = new AcquisitionFailure(failure, owner);
                retained.addSuppressed(cleanup);
                if (failure instanceof Error fatal) { fatal.addSuppressed(retained); throw fatal; }
                throw retained;
            }
            throw failure;
        }
    }

    /**
     * Retains already validated native operations without performing acquisition.
     * @param calls transferred native operation owner
     * @throws NullPointerException if {@code calls} is null
     */
    private WindowsBazelStreams(Calls calls) { this.calls = Objects.requireNonNull(calls, "calls"); }

    /**
     * Validates destinations before native acquisition begins.
     * @param stdout requested standard-output path
     * @param stderr requested standard-error path
     * @throws NullPointerException if either destination is null
     * @throws IllegalArgumentException if destinations are relative, non-normalized or equal
     */
    private static void validate(Path stdout, Path stderr)
    {
        Objects.requireNonNull(stdout, "stdout");
        Objects.requireNonNull(stderr, "stderr");
        for (Path destination : List.of(stdout, stderr))
            if (!destination.isAbsolute() || !destination.equals(destination.normalize()))
                throw new IllegalArgumentException("Output destination must be absolute and normalized: " + destination);
        if (stdout.equals(stderr)) throw new IllegalArgumentException("Output destinations must be distinct");
    }

    /**
     * Reserves ownership before invoking a native acquisition, then retains its original result.
     * @param operation native acquisition invoked after the owner slot is registered
     * @return the retained handle
     * @throws IOException if the native result is NULL or INVALID_HANDLE_VALUE
     */
    private MemorySegment acquire(Acquisition operation) throws IOException
    {
        OwnedHandle slot = new OwnedHandle();
        handles.add(slot);
        MemorySegment handle = Objects.requireNonNull(operation.acquire(), "Native acquisition returned null");
        slot.handle = handle;
        if (handle.address() == 0 || handle.address() == -1L)
            throw new IOException("Native stream acquisition returned an invalid handle");
        return handle;
    }

    /**
     * Returns NUL input for an explicit WindowsProcess launch handle list.
     * @return borrowed input handle retained by this owner
     * @throws IllegalStateException if disposal started
     */
    MemorySegment input() { requireOpen(); return input; }

    /**
     * Returns the original standard-output file description for explicit launch duplication.
     * @return borrowed standard-output handle
     * @throws IllegalStateException if disposal started
     */
    MemorySegment stdout() { requireOpen(); return stdout; }

    /**
     * Returns the original standard-error file description for explicit launch duplication.
     * @return borrowed standard-error handle
     * @throws IllegalStateException if disposal started
     */
    MemorySegment stderr() { requireOpen(); return stderr; }

    /**
     * Clears both original output descriptions without reopening or changing their paths.
     * The caller must first prove the previous whole Job is empty and dispose all its hooks and
     * duplicated output handles. If either reset fails, the caller must fail the action and close
     * this owner; a partially reset output pair cannot be used for publication or a retry.
     * @throws IllegalStateException if disposal started
     * @throws IOException if either seek or truncation fails
     */
    void reset() throws IOException
    {
        requireOpen();
        calls.reset(stdout);
        calls.reset(stderr);
    }

    /**
     * Indicates whether all handles and native bindings were disposed successfully.
     * @return true after successful terminal disposal
     */
    boolean isClosed() { return closed; }

    /**
     * Rejects handle borrowing after disposal starts.
     * @throws IllegalStateException if disposal started
     */
    private void requireOpen()
    {
        if (closing) throw new IllegalStateException("Action streams are closing or closed");
    }

    /**
     * Consumes every handle's close authority once, then releases native bindings on success.
     * The caller must first establish whole-Job-zero and hook disposal for every attempt that
     * borrowed these handles. A failed close remains sticky and retains the owner and bindings;
     * later calls rethrow it without repeating uncertain native effects.
     * @throws IOException if any handle or binding disposal fails
     */
    @Override public void close() throws IOException
    {
        if (closeFailure != null) throw closeFailure;
        if (closed) return;
        closing = true;
        for (OwnedHandle handle : handles.reversed())
        {
            try { handle.close(calls); }
            catch (IOException | RuntimeException | Error failure) { recordCloseFailure(failure); }
        }
        if (closeFailure != null) throw closeFailure;
        try { calls.close(); }
        catch (IOException | RuntimeException | Error failure)
        {
            recordCloseFailure(failure);
            throw closeFailure;
        }
        closed = true;
    }

    /**
     * Retains a failed disposal so subsequent calls cannot report successful cleanup.
     * @param failure first or later failed disposal
     */
    private void recordCloseFailure(Throwable failure)
    {
        IOException reported = failure instanceof IOException io ? io :
            new IOException("Action stream disposal did not complete", failure);
        if (closeFailure == null) closeFailure = reported;
        else if (closeFailure != reported) closeFailure.addSuppressed(reported);
    }

    /**
     * Reports failed acquisition with retained ownership of uncertain native cleanup.
     */
    static final class AcquisitionFailure extends IOException
    {
        /** Java serialization version for this exception's stable superclass contract. */
        private static final long serialVersionUID = 1L;
        /** In-process owner retained after uncertain disposal; native resources cannot be serialized. */
        private final transient WindowsBazelStreams owner;

        /**
         * Retains the original acquisition cause and the resource owner.
         * @param cause acquisition failure before ownership could be returned
         * @param owner retained resource owner
         */
        private AcquisitionFailure(Throwable cause, WindowsBazelStreams owner)
        {
            super("Action stream acquisition failed and native cleanup remains unresolved", cause);
            this.owner = Objects.requireNonNull(owner, "owner");
        }

        /**
         * Returns the owner whose failed cleanup must remain part of the action's retained state.
         * @return retained owner; closing it rethrows the original cleanup failure without replay,
         * or null if this exception was serialized and deserialized outside its acquiring process
         */
        WindowsBazelStreams owner() { return owner; }
    }

    /**
     * Retains one original handle and its single native close authority.
     */
    private static final class OwnedHandle
    {
        /** Original acquired value, or NULL before acquisition; invalid native results own no handle. */
        private MemorySegment handle = MemorySegment.NULL;
        /** Indicates whether its close authority has been consumed. */
        private boolean attempted;

        /**
         * Reserves handle ownership without performing a native acquisition.
         */
        private OwnedHandle() {}

        /**
         * Consumes the close authority before invoking a potentially uncertain native operation.
         * @param calls native operation owner
         * @throws IOException if native close fails
         */
        private void close(Calls calls) throws IOException
        {
            if (attempted) return;
            attempted = true;
            if (handle.address() != 0 && handle.address() != -1L) calls.closeHandle(handle);
        }
    }

    /**
     * Performs one acquisition after its owner has reserved a cleanup slot.
     */
    @FunctionalInterface
    private interface Acquisition
    {
        /**
         * Acquires one original native handle without transferring its cleanup authority elsewhere.
         * @return acquired handle, or an invalid native value reporting unsuccessful acquisition
         * @throws IOException if native acquisition fails
         */
        MemorySegment acquire() throws IOException;
    }

    /**
     * Owns the Win32 operations needed for action stream acquisition and retirement.
     */
    interface Calls extends AutoCloseable
    {
        /**
         * Pins an existing directory against deletion without following a final reparse point.
         * @param directory existing ancestor of a stream destination
         * @return owned directory handle
         * @throws IOException if acquisition fails
         */
        MemorySegment pinDirectory(Path directory) throws IOException;
        /**
         * Creates an absent destination without overwriting any existing object.
         * @param destination exact worker-supplied output path
         * @return owned writable handle, denying deletion while open
         * @throws IOException if creation fails, including an existing destination
         */
        MemorySegment create(Path destination) throws IOException;
        /**
         * Opens the Windows NUL device for input without borrowing process standard handles.
         * @return owned readable NUL handle
         * @throws IOException if acquisition fails
         */
        MemorySegment openNull() throws IOException;
        /**
         * Seeks the original file description to zero and truncates it there.
         * @param handle owned writable stream handle
         * @throws IOException if either operation fails
         */
        void reset(MemorySegment handle) throws IOException;
        /**
         * Attempts native disposal once for an owned handle.
         * @param handle original owned native handle
         * @throws IOException if native disposal fails or becomes uncertain
         */
        void closeHandle(MemorySegment handle) throws IOException;
        /**
         * Disposes native binding storage after every handle was successfully retired.
         * @throws IOException if disposal fails
         */
        @Override void close() throws IOException;
    }

    /**
     * Binds the documented Win32 file APIs through a caller-owned Pouch native linker.
     */
    private static final class Native implements Calls
    {
        /** Win32 OPEN_EXISTING: opening never replaces an existing directory or device. */
        private static final int OPEN_EXISTING = 3;
        /** Win32 CREATE_NEW: an already existing output destination is a creation failure. */
        private static final int CREATE_NEW = 1;
        /** Win32 FILE_FLAG_OPEN_REPARSE_POINT: acquisition never follows a final reparse point. */
        private static final int NO_FOLLOW = 0x00200000;
        /** Win32 FILE_FLAG_BACKUP_SEMANTICS: permits directory handle acquisition. */
        private static final int DIRECTORY = 0x02000000;
        /** Win32 FILE_SHARE_READ | FILE_SHARE_WRITE, deliberately excluding FILE_SHARE_DELETE. */
        private static final int SHARE_READ_WRITE = 3;
        /** Whether controller-protected empty log objects already exist. */
        private final boolean existingLogs;
        /** Binding lifetime, independent of individual per-call allocations. */
        private final Arena arena = Arena.ofShared();
        /** Captured same-call Windows error layout. */
        private final MemoryLayout stateLayout;
        /** Byte offset of GetLastError in each native invocation's capture record. */
        private final long errorOffset;
        /** Native CreateFileW function including captured error state. */
        private final MethodHandle open;
        /** Native SetFilePointerEx function including captured error state. */
        private final MethodHandle seek;
        /** Native SetEndOfFile function including captured error state. */
        private final MethodHandle truncate;
        /** Native CloseHandle function including captured error state. */
        private final MethodHandle close;

        /**
         * Resolves only file-handle APIs unavailable through Java's borrowed-handle launch contract.
         * @param scope borrowed Pouch native linker provider
         * @param existingLogs whether both destinations are authenticated existing empty daemon logs
         * @throws UnsupportedOperationException if native 64-bit Windows is unavailable
         */
        // FFM library lookup requires native-access authority; Java has no standard HANDLE acquisition API.
        @SuppressWarnings("restricted")
        private Native(ToolingScope scope, boolean existingLogs)
        {
            this.existingLogs = existingLogs;
            if (!System.getProperty("os.name", "").startsWith("Windows") || ValueLayout.ADDRESS.byteSize() != 8)
            {
                arena.close();
                throw new UnsupportedOperationException("Bazel action streams require native 64-bit Windows");
            }
            try
            {
                Linker linker = scope.getNativeLinker();
                SymbolLookup library = SymbolLookup.libraryLookup("kernel32.dll", arena);
                this.stateLayout = Linker.Option.captureStateLayout();
                this.errorOffset = stateLayout.byteOffset(MemoryLayout.PathElement.groupElement("GetLastError"));
                this.open = bind(linker, library, "CreateFileW", ValueLayout.ADDRESS, ValueLayout.ADDRESS,
                    ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.JAVA_INT,
                    ValueLayout.JAVA_INT, ValueLayout.ADDRESS);
                this.seek = bind(linker, library, "SetFilePointerEx", ValueLayout.JAVA_INT,
                    ValueLayout.ADDRESS, ValueLayout.JAVA_LONG, ValueLayout.ADDRESS, ValueLayout.JAVA_INT);
                this.truncate = bind(linker, library, "SetEndOfFile", ValueLayout.JAVA_INT, ValueLayout.ADDRESS);
                this.close = bind(linker, library, "CloseHandle", ValueLayout.JAVA_INT, ValueLayout.ADDRESS);
            }
            catch (RuntimeException | Error failure) { arena.close(); throw failure; }
        }

        /**
         * Resolves one documented native symbol with same-call error capture.
         * @param linker borrowed Pouch linker
         * @param library owned loaded kernel library
         * @param name native exported symbol
         * @param result native return layout
         * @param arguments native parameter layouts
         * @return bound native call
         */
        // Binding the required HANDLE operations is an intentional native-access boundary.
        @SuppressWarnings("restricted")
        private static MethodHandle bind(Linker linker, SymbolLookup library, String name,
            MemoryLayout result, MemoryLayout... arguments)
        {
            return linker.downcallHandle(library.find(name).orElseThrow(),
                FunctionDescriptor.of(result, arguments), Linker.Option.captureCallState("GetLastError"));
        }

        /**
         * Opens an exact native path with a non-inheritable, deletion-denying original handle.
         * @param name native Windows path or device name
         * @param access requested Win32 access mask
         * @param disposition documented Win32 creation disposition
         * @param flags documented Win32 file flags
         * @return owned valid native handle
         * @throws IOException if CreateFileW fails
         */
        private MemorySegment open(String name, int access, int disposition, int flags) throws IOException
        {
            try (Arena temporary = Arena.ofConfined())
            {
                MemorySegment state = temporary.allocate(stateLayout);
                MemorySegment path = temporary.allocateFrom(ValueLayout.JAVA_CHAR, (name + '\0').toCharArray());
                MemorySegment handle;
                try
                {
                    handle = (MemorySegment) open.invokeExact(state, path, access, SHARE_READ_WRITE, MemorySegment.NULL,
                        disposition, flags, MemorySegment.NULL);
                }
                catch (RuntimeException | Error failure) { throw failure; }
                catch (Throwable failure) { throw new IOException("CreateFileW invocation failed: " + name, failure); }
                if (handle.address() == -1L || handle.address() == 0)
                    throw failure("CreateFileW(" + name + ")", state);
                return handle;
            }
        }

        /**
         * Converts an absolute path to the Windows extended-length namespace.
         * @param path absolute normalized local path
         * @return native textual path without path normalization
         */
        private static String nativePath(Path path)
        {
            String text = path.toString();
            if (text.startsWith("\\\\?\\")) return text;
            if (text.startsWith("\\\\")) return "\\\\?\\UNC\\" + text.substring(2);
            return "\\\\?\\" + text;
        }

        @Override public MemorySegment pinDirectory(Path directory) throws IOException
        {
            return open(nativePath(directory), 0, OPEN_EXISTING, NO_FOLLOW | DIRECTORY);
        }

        @Override public MemorySegment create(Path destination) throws IOException
        {
            return open(nativePath(destination), 0x40000000, existingLogs ? OPEN_EXISTING : CREATE_NEW, NO_FOLLOW);
        }

        @Override public MemorySegment openNull() throws IOException
        {
            return open("NUL", 0x80000000, OPEN_EXISTING, 0);
        }

        @Override public void reset(MemorySegment handle) throws IOException
        {
            try (Arena temporary = Arena.ofConfined())
            {
                MemorySegment state = temporary.allocate(stateLayout);
                try
                {
                    int positioned = (int) seek.invokeExact(state, handle, 0L, MemorySegment.NULL, 0);
                    if (positioned == 0) throw failure("SetFilePointerEx", state);
                    int truncated = (int) truncate.invokeExact(state, handle);
                    if (truncated == 0) throw failure("SetEndOfFile", state);
                }
                catch (IOException | RuntimeException | Error failure) { throw failure; }
                catch (Throwable failure) { throw new IOException("Stream reset invocation failed", failure); }
            }
        }

        @Override public void closeHandle(MemorySegment handle) throws IOException
        {
            try (Arena temporary = Arena.ofConfined())
            {
                MemorySegment state = temporary.allocate(stateLayout);
                try
                {
                    int result = (int) close.invokeExact(state, handle);
                    if (result == 0) throw failure("CloseHandle", state);
                }
                catch (IOException | RuntimeException | Error failure) { throw failure; }
                catch (Throwable failure) { throw new IOException("CloseHandle invocation failed", failure); }
            }
        }

        /**
         * Captures an operation's native failure before any cleanup can replace its error state.
         * @param operation failed Win32 operation
         * @param state same-call native error record
         * @return failure containing the unsigned Windows error code
         */
        private IOException failure(String operation, MemorySegment state)
        {
            return new IOException(operation + " failed: GetLastError=" +
                Integer.toUnsignedString(state.get(ValueLayout.JAVA_INT, errorOffset)));
        }

        @Override public void close() throws IOException
        {
            try { arena.close(); }
            catch (RuntimeException failure) { throw new IOException("Native stream binding disposal failed", failure); }
        }
    }
}
