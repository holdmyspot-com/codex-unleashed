package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.IOException;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Retains one original backend daemon on a dedicated native owner thread.
 * The common backend may wait for genuine original termination while its coordinator is blocked on readiness.
 * All WindowsProcess operations remain on their constructing thread; original log descriptions stay caller-owned
 * until whole-Job zero, original wait collection and native handle disposal complete.
 */
final class WindowsBazelDaemon implements BazelNativeBackend.Daemon
{
    /** Borrowed tooling retained through terminal owner-thread shutdown. */
    private final ToolingScope tooling;
    /** Original immutable daemon command. */
    private final List<String> command;
    /** Original explicit working directory. */
    private final Path directory;
    /** Complete explicit environment. */
    private final Map<String, String> environment;
    /** Borrowed original daemon streams retained through completed close. */
    private final WindowsBazelStreams streams;
    /** Positive native control acknowledgement interval. */
    private final Duration timeout;
    /** Sole executor for original thread-confined native ownership, including cleanup retries. */
    private final ScheduledExecutorService owner = Executors.newSingleThreadScheduledExecutor(task ->
        Thread.ofPlatform().name("windows-bazel-daemon-owner").unstarted(task));
    /** Authentic original result, or a native observation fault that wakes the common readiness wait. */
    private final CompletableFuture<Long> terminal = new CompletableFuture<>();
    /** Original partial or active native owner, accessed only on the dedicated thread. */
    private WindowsProcess process;
    /** Whether original native preparation returned a complete suspended owner. */
    private boolean prepared;
    /** Original periodic observation, cancelled only after native closure. */
    private ScheduledFuture<?> polling;
    /** Whether original native close acknowledged success. */
    private volatile boolean nativeClosed;
    /** Whether start consumed its opportunity. */
    private boolean started;
    /** Whether the original native owner and its executor both retired. */
    private boolean closed;

    /**
     * Reserves resource-free daemon ownership before native acquisition.
     * @param tooling borrowed scoped native services
     * @param executable authenticated actual native product
     * @param configuration common protected configuration file
     * @param directory explicit existing native working directory
     * @param environment exact complete environment
     * @param streams original borrowed native descriptions
     * @param timeout positive bounded native control interval
     */
    WindowsBazelDaemon(ToolingScope tooling, Path executable, Path configuration, Path directory,
        Map<String, String> environment, WindowsBazelStreams streams, Duration timeout)
    {
        this.tooling = tooling;
        this.command = List.of(executable.toString(), configuration.toString());
        this.directory = directory;
        this.environment = Map.copyOf(environment);
        this.streams = streams;
        this.timeout = WindowsAttempts.checkedTimeout(timeout);
    }

    /**
     * Prepares the actual atomic Job while suspended and releases its original primary thread.
     * Partial failure remains attached to this owner and the same native thread for explicit cleanup.
     * @throws IOException if native preparation, release or acknowledgement fails
     */
    void start() throws IOException
    {
        if (started || closed) throw new IllegalStateException("Original native daemon starts once");
        started = true;
        execute(() ->
        {
            try { process = WindowsProcess.prepare(tooling, command, directory, environment,
                streams.input(), streams.stdout(), streams.stderr()); }
            catch (WindowsProcess.PreparationFailure failure) { process = failure.owner(); throw failure; }
            prepared = true;
            process.releaseRoot();
            polling = owner.scheduleWithFixedDelay(this::observe, 0, 1, TimeUnit.MILLISECONDS);
        });
    }

    /**
     * Observes genuine original termination on the constructing native thread.
     * Observation failure wakes readiness as a failure while retaining the executor and native owner for cleanup.
     */
    private void observe()
    {
        if (nativeClosed || terminal.isDone()) return;
        try
        {
            Optional<WindowsProcess.Result> result = process.poll();
            if (result.isPresent()) terminal.complete(result.orElseThrow().rootExit());
        }
        catch (IOException | RuntimeException | Error failure) { terminal.completeExceptionally(failure); }
    }

    @Override public boolean isAlive() { return started && !nativeClosed && !terminal.isDone(); }

    @Override public long exitValue() throws IOException
    {
        if (!terminal.isDone()) throw new IOException("Original backend daemon has no terminal observation");
        try { return terminal.get(); }
        catch (InterruptedException failure)
        {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted reading original backend daemon status", failure);
        }
        catch (ExecutionException failure) { throw new IOException("Original backend daemon observation failed", failure.getCause()); }
    }

    @Override public CompletableFuture<Long> onExit() { return terminal; }

    @Override public void close() throws IOException
    {
        if (closed) return;
        if (!nativeClosed)
            execute(() ->
            {
                if (process != null && !prepared) process.close();
                else if (process != null)
                {
                    Optional<WindowsProcess.Result> result = process.poll();
                    if (result.isEmpty()) process.terminate();
                    long began = System.nanoTime();
                    while (result.isEmpty())
                    {
                        result = process.poll();
                        if (result.isEmpty())
                        {
                            if (System.nanoTime() - began >= timeout.toNanos())
                                throw new IOException("Original backend daemon Job remains owned during cleanup");
                            try { Thread.sleep(1); }
                            catch (InterruptedException failure)
                            {
                                Thread.currentThread().interrupt();
                                throw new IOException("Interrupted collecting original backend daemon Job", failure);
                            }
                        }
                    }
                    terminal.complete(result.orElseThrow().rootExit());
                    process.close();
                }
                nativeClosed = true;
                if (polling != null) polling.cancel(false);
            });
        owner.shutdown();
        try
        {
            if (!owner.awaitTermination(timeout.toNanos(), TimeUnit.NANOSECONDS))
                throw new IOException("Original backend daemon owner thread remains retained");
        }
        catch (InterruptedException failure)
        {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted retiring original backend daemon owner thread", failure);
        }
        closed = true;
    }

    /**
     * Runs one owner-thread operation and waits for its authentic acknowledgement without cancelling uncertain work.
     * @param operation native action executed on the original owner thread
     * @throws IOException if the action, native ownership or controlling thread fails
     */
    private void execute(Operation operation) throws IOException
    {
        CompletableFuture<Void> acknowledgement = new CompletableFuture<>();
        owner.execute(() ->
        {
            try { operation.run(); acknowledgement.complete(null); }
            catch (IOException | RuntimeException | Error failure) { acknowledgement.completeExceptionally(failure); }
        });
        try { acknowledgement.get(); }
        catch (InterruptedException failure)
        {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted awaiting original daemon owner acknowledgement", failure);
        }
        catch (ExecutionException failure)
        {
            Throwable cause = failure.getCause();
            if (cause instanceof IOException checked) throw checked;
            if (cause instanceof RuntimeException unchecked) throw unchecked;
            if (cause instanceof Error fatal) throw fatal;
            throw new IOException("Original daemon operation failed", cause);
        }
    }

    /** Represents a checked operation on the original dedicated native thread. */
    @FunctionalInterface
    private interface Operation
    {
        /**
         * Performs one original acquisition, observation or disposal.
         * @throws IOException if native acknowledgement or collection fails
         */
        void run() throws IOException;
    }
}
