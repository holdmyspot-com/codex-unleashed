package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serial;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Owns one native Windows AppContainer and its explicit filesystem access grants.
 * The creating thread retains this owner through the entire action Job, instrumentation drain and
 * workspace restoration. Public roots receive package-specific read/execute grants and mutation denials;
 * private controller state receives no package grants. Original action roots and all their ancestors
 * remain pinned against rename or deletion. This class does not launch or drain processes itself.
 */
public final class WindowsBazelSecurity implements AutoCloseable
{
    /** Read, execute, synchronize and security-descriptor read, without mutation. */
    private static final int READ_EXECUTE = 0x1200a9;
    /** Filesystem data/metadata mutation, deletion and discretionary security changes. */
    private static final int MUTATION = 0x000d0156;
    /** Data read/write/execute and deletion, excluding ownership and ACL changes. */
    private static final int MODIFY = 0x1301bf;
    /** Native services and all argument storage remain live through cleanup. */
    private final Native nativeApi;
    /** Single authorized controlling thread. */
    private final Thread thread = Thread.currentThread();
    /** Shared no-follow native identities; no independent file-ID ABI is introduced. */
    private final BazelNativeBackend.FileIdentity identities;
    /** Original action input root. */
    private final Path input;
    /** Original action temporary root. */
    private final Path temporary;
    /** Owner-only controller state excluded from action grants. */
    private final Path privateRoot;
    /** Unique per-invocation AppContainer profile name. */
    private final String profileName = "CodexUnleashed.Bazel." + UUID.randomUUID().toString().replace("-", "");
    /** Profile SID output storage reserved before native profile creation. */
    private final MemorySegment sidOutput;
    /** Borrowed native launch capabilities retained until this owner closes. */
    private final MemorySegment capabilities;
    /** Native root and ancestor handles, in acquisition order. */
    private final Map<Path, Pin> pins = new LinkedHashMap<>();
    /** Own-SID ACL mutations retained before effects; close never restores stale complete ACLs. */
    private final Map<Path, Grant> grants = new LinkedHashMap<>();
    /** Original root mandatory labels retained before replacement. */
    private final Map<Path, Label> labels = new LinkedHashMap<>();
    /** LocalAlloc security descriptors and ACLs retained until their single release attempt. */
    private final List<LocalMemory> localMemory = new ArrayList<>();
    /** Checked capsule reserved before native resources are acquired. */
    private final PreparationFailure preparationFailure = new PreparationFailure(this);
    /** Named cross-controller mutex protects merge/revoke of shared public ACLs. */
    private MemorySegment mutex = MemorySegment.NULL;
    /** Whether this thread currently owns the ACL mutex. */
    private boolean locked;
    /** Profile creation attempted, including an uncertain result. */
    private boolean profileAttempted;
    /** Whether close has withdrawn further acquisition. */
    private boolean closing;
    /** Whether all resources have been released. */
    private boolean closed;
    /** First uncertain cleanup prevents repeating a native effect. */
    private IOException cleanupFailure;

    /**
     * Carries a partial security owner when automatic construction cleanup cannot finish.
     * It is deliberately nonserializable because native ownership cannot cross serialization.
     */
    public static final class PreparationFailure extends IOException
    {
        /** Serialization version for the checked diagnostic type. */
        @Serial private static final long serialVersionUID = 1L;
        /** Exact partial owner, retained in this process only. */
        private final transient WindowsBazelSecurity owner;
        /**
         * Reserves a failure capsule before native acquisition.
         * @param owner exact partial owner
         */
        private PreparationFailure(WindowsBazelSecurity owner)
        { super("Security preparation failed with retained native ownership"); this.owner = owner; }
        /**
         * Returns the original owner for retained cleanup accounting.
         * @return exact original partial security owner
         */
        public WindowsBazelSecurity owner() { return owner; }
        /**
         * Rejects transfer of process-local native ownership.
         * @param stream attempted output
         * @throws NotSerializableException always
         */
        @Serial private void writeObject(ObjectOutputStream stream) throws NotSerializableException
        { throw new NotSerializableException("Native security ownership is process-local"); }
        /**
         * Rejects reconstruction without native ownership.
         * @param stream attempted input
         * @throws InvalidObjectException always
         */
        @Serial private void readObject(ObjectInputStream stream) throws InvalidObjectException
        { throw new InvalidObjectException("Native security ownership cannot be deserialized"); }
    }

    /**
     * Opens the AppContainer, retains original roots and grants explicit public read surfaces.
     * No action-tree ACL or label is modified until {@link #materialized(Path, Path)} is called.
     * Paths must be absolute, existing, ordinary no-follow objects. Action roots must be distinct,
     * disjoint directories; private state and public read surfaces must not overlap action trees.
     * Public roots must be disjoint from privateRoot. Their package grants are removed on close.
     *
     * @param scope caller-owned Pouch native services retained through owner close
     * @param input original action input directory
     * @param temporary original action temporary directory
     * @param privateRoot existing owner-only controller directory
     * @param publicReadRoots complete trusted toolchain/runtime/agent read and execute surfaces
     * @return owner retained through Job zero, instrumentation drain and workspace restoration
     * @throws IOException if native protection, path validation or cleanup fails; PreparationFailure
     * retains any unfinished partial owner
     * @throws NullPointerException if an argument or read-root member is null
     * @throws IllegalArgumentException if paths are relative, overlapping or non-normalized
     * @throws UnsupportedOperationException if native 64-bit Windows is unavailable
     */
    public static WindowsBazelSecurity open(ToolingScope scope, Path input, Path temporary,
        Path privateRoot, List<Path> publicReadRoots) throws IOException
    {
        Objects.requireNonNull(scope, "scope");
        Objects.requireNonNull(publicReadRoots, "publicReadRoots");
        Path in = absolute(input), tmp = absolute(temporary), priv = absolute(privateRoot);
        List<Path> reads = publicReadRoots.stream().map(WindowsBazelSecurity::absolute).distinct().toList();
        if (overlap(in, tmp) || overlap(in, priv) || overlap(tmp, priv))
            throw new IllegalArgumentException("Input, temporary and private roots must be disjoint");
        for (Path read : reads)
            if (overlap(priv, read) || overlap(read, in) || overlap(read, tmp))
                throw new IllegalArgumentException("Public reads overlap private or writable roots: " + read);
        if (!System.getProperty("os.name").startsWith("Windows") || ValueLayout.ADDRESS.byteSize() != 8)
            throw new UnsupportedOperationException("AppContainer security requires native 64-bit Windows");
        BazelBackendCredentials.NativeAuthority authority = BazelBackendCredentials.nativeAuthority(scope, priv);
        authority.requireDirectory(priv);
        WindowsBazelSecurity owner = new WindowsBazelSecurity(scope, in, tmp, priv, authority);
        try
        {
            owner.acquire(reads);
            return owner;
        }
        catch (IOException | RuntimeException | Error failure)
        {
            owner.preparationFailure.initCause(failure);
            try { owner.close(); }
            catch (IOException | RuntimeException | Error cleanup)
            {
                owner.preparationFailure.addSuppressed(cleanup);
                throw owner.preparationFailure;
            }
            throw failure;
        }
    }

    /**
     * Allocates native storage before acquiring profiles, handles or ACL grants.
     * @param scope borrowed Pouch services
     * @param input original input root
     * @param temporary original temporary root
     * @param privateRoot authenticated owner-only private root
     * @param identities shared native identity authority
     */
    private WindowsBazelSecurity(ToolingScope scope, Path input, Path temporary, Path privateRoot,
        BazelNativeBackend.FileIdentity identities)
    {
        this.input = input;
        this.temporary = temporary;
        this.privateRoot = privateRoot;
        this.identities = identities;
        nativeApi = new Native(scope.getNativeLinker());
        try
        {
            sidOutput = nativeApi.arena.allocate(ValueLayout.ADDRESS);
            capabilities = nativeApi.arena.allocate(24, 8);
        }
        catch (RuntimeException | Error failure)
        {
            nativeApi.arena.close();
            throw failure;
        }
    }

    /**
     * Acquires retained pins, a unique profile and public read grants.
     * @param reads explicit public read surfaces
     * @throws IOException if an acquisition or ACL operation fails
     */
    private void acquire(List<Path> reads) throws IOException
    {
        pinAncestors(input);
        pinAncestors(temporary);
        pinAncestors(privateRoot);
        for (Path path : reads) pinAncestors(path);
        if (!Files.isDirectory(input, LinkOption.NOFOLLOW_LINKS)
            || !Files.isDirectory(temporary, LinkOption.NOFOLLOW_LINKS))
            throw new IOException("Action roots must be real directories");
        profileAttempted = true;
        int result = nativeApi.integer("CreateAppContainerProfile", nativeApi.wide(profileName),
            nativeApi.wide(profileName), nativeApi.wide(profileName), MemorySegment.NULL, 0, sidOutput);
        if (result != 0)
        {
            profileAttempted = false;
            throw new IOException("CreateAppContainerProfile HRESULT=" + Integer.toUnsignedString(result));
        }
        MemorySegment sid = sidOutput.get(ValueLayout.ADDRESS, 0);
        if (sid.address() == 0) throw new IOException("AppContainer profile returned no SID");
        capabilities.set(ValueLayout.ADDRESS, 0, sid);
        mutex = nativeApi.pointer("CreateMutexW", MemorySegment.NULL, 0,
            nativeApi.wide("Local\\CodexUnleashed.Bazel.AppContainerAcl.v1"));
        nativeApi.requireHandle(mutex, "CreateMutexW");
        withAclLock(() -> {
            for (Path read : reads) grantTree(read, false);
        });
        requireRoots();
    }

    /**
     * Authenticates all retained original roots and ancestors against shared native identities.
     * @throws IOException if any pinned path no longer identifies its original object
     * @throws IllegalStateException if called outside the creating thread or after close
     */
    public void requireRoots() throws IOException
    {
        requireThread();
        if (closed) throw new IllegalStateException("Security owner is closed");
        for (Pin pin : pins.values())
            if (!pin.identity.equals(identities.identity(pin.path)))
                throw new IOException("Pinned original root or ancestor identity changed: " + pin.path);
    }

    /**
     * Grants the action access after the workspace has replaced borrowed/cache-linked contents with
     * independent materialized copies at the same original roots. The caller guarantees that every
     * descendant is independently owned; this operation must never receive worker-cache hardlinks.
     * It may be repeated after restoration, and only for the exact roots authenticated by open.
     *
     * @param input exact original input root
     * @param temporary exact original temporary root
     * @throws IOException if an identity, permission or mandatory-label operation fails
     * @throws IllegalStateException if acquisition is closed or the thread differs
     * @throws IllegalArgumentException if the supplied roots differ from the original roots
     */
    public void materialized(Path input, Path temporary) throws IOException
    {
        requireAcquiring();
        if (!this.input.equals(absolute(input)) || !this.temporary.equals(absolute(temporary)))
            throw new IllegalArgumentException("Materialization must preserve exact original action roots");
        requireRoots();
        withAclLock(() -> {
            grantTree(this.input, true);
            grantTree(this.temporary, true);
        });
        requireRoots();
    }

    /**
     * Borrows the native SECURITY_CAPABILITIES used by atomic suspended process preparation.
     * @return live native 24-byte structure; caller never frees or mutates it
     * @throws IllegalStateException if the owner is stopping, closed or called from another thread
     */
    public MemorySegment capabilities()
    {
        requireAcquiring();
        return capabilities.asReadOnly();
    }

    /**
     * Retains each ancestor before opening the next path component, preventing rename races.
     * @param path existing ordinary target
     * @throws IOException if native opening or no-follow identity validation fails
     */
    private void pinAncestors(Path path) throws IOException
    {
        if (path.getParent() != null) pinAncestors(path.getParent());
        if (pins.containsKey(path)) return;
        Object before = identities.identity(path);
        Pin pin = new Pin(path, before);
        pins.put(path, pin);
        pin.handle = nativeApi.pointer("CreateFileW", nativeApi.path(path),
            0x80, 3, MemorySegment.NULL, 3, 0x02200000, MemorySegment.NULL);
        if (pin.handle.address() == 0 || pin.handle.address() == -1)
        {
            pin.released = true;
            throw nativeApi.failure("CreateFileW(root pin)");
        }
        if (!before.equals(identities.identity(path)))
            throw new IOException("Original root changed while acquiring its pin: " + path);
    }

    /**
     * Grants one no-follow tree using the already selected native ACL facility.
     * @param root ordinary trusted target
     * @param writable whether this is an independently materialized writable action tree
     * @throws IOException if identity, traversal or ACL/label application fails
     */
    private void grantTree(Path root, boolean writable) throws IOException
    {
        try (var paths = Files.walk(root))
        {
            for (Path path : (Iterable<Path>) paths::iterator)
            {
                Object identity = identities.identity(path);
                Grant prior = grants.get(path);
                if (prior == null || !prior.identity.equals(identity))
                {
                    Grant grant = new Grant(path, identity);
                    grants.put(path, grant);
                    changeAcl(path, 1, writable ? MODIFY : READ_EXECUTE);
                    if (!writable) changeAcl(path, 3, MUTATION);
                    if (!identity.equals(identities.identity(path)))
                        throw new IOException("Object changed while granting package access: " + path);
                }
                if (writable) lowIntegrity(path);
            }
        }
    }

    /**
     * Merges or revokes only this profile's SID, preserving other invocations' current grants.
     * @param path pinned or independently materialized object
     * @param mode SET_ACCESS=2 is unused; GRANT_ACCESS=1, DENY_ACCESS=3, REVOKE_ACCESS=4
     * @param permissions exact native filesystem mask, ignored when revoking
     * @throws IOException if the ACL cannot be read, merged or applied
     */
    private void changeAcl(Path path, int mode, int permissions) throws IOException
    {
        MemorySegment old = nativeApi.arena.allocate(ValueLayout.ADDRESS);
        MemorySegment descriptor = localOutput();
        int readStatus = nativeApi.integer("GetNamedSecurityInfoW", nativeApi.path(path),
            1, 4, MemorySegment.NULL, MemorySegment.NULL, old, MemorySegment.NULL, descriptor);
        nativeApi.requireStatus(readStatus, "GetNamedSecurityInfoW(DACL)");
        if (old.get(ValueLayout.ADDRESS, 0).address() == 0)
        {
            if (mode == 4) return; // A NULL DACL cannot contain this invocation's package SID.
            throw new IOException("Unrestricted NULL DACL is unsupported for package grant: " + path);
        }
        MemorySegment entry = nativeApi.arena.allocate(48, 8);
        entry.set(ValueLayout.JAVA_INT, 0, permissions);
        entry.set(ValueLayout.JAVA_INT, 4, mode);
        entry.set(ValueLayout.JAVA_INT, 8, Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS) ? 3 : 0);
        entry.set(ValueLayout.JAVA_INT, 28, 0); // TRUSTEE_IS_SID, not a name to resolve.
        entry.set(ValueLayout.ADDRESS, 40, sidOutput.get(ValueLayout.ADDRESS, 0));
        MemorySegment merged = localOutput();
        int mergeStatus = nativeApi.integer("SetEntriesInAclW", 1, entry, old.get(ValueLayout.ADDRESS, 0), merged);
        nativeApi.requireStatus(mergeStatus, "SetEntriesInAclW");
        nativeApi.requireStatus(nativeApi.integer("SetNamedSecurityInfoW", nativeApi.path(path),
            1, 4, MemorySegment.NULL, MemorySegment.NULL, merged.get(ValueLayout.ADDRESS, 0), MemorySegment.NULL),
            "SetNamedSecurityInfoW(DACL)");
    }

    /**
     * Assigns low integrity only after independent workspace materialization.
     * Original materialized-object labels are retained and restored before native authority is released.
     * @param path independently owned action object
     * @throws IOException if native mandatory-label operations fail
     */
    private void lowIntegrity(Path path) throws IOException
    {
        Object identity = identities.identity(path);
        Label prior = labels.get(path);
        if (prior == null || !prior.identity.equals(identity))
        {
            Label alias = null;
            for (Label existing : labels.values())
                if (existing.identity.equals(identity)) { alias = existing; break; }
            if (alias != null) labels.put(path, new Label(path, identity, alias.sacl));
            else
            {
            MemorySegment sacl = nativeApi.arena.allocate(ValueLayout.ADDRESS);
            MemorySegment descriptor = localOutput();
            nativeApi.requireStatus(nativeApi.integer("GetNamedSecurityInfoW", nativeApi.path(path),
                1, 0x10, MemorySegment.NULL, MemorySegment.NULL, MemorySegment.NULL, sacl, descriptor),
                "GetNamedSecurityInfoW(LABEL)");
            labels.put(path, new Label(path, identity, sacl.get(ValueLayout.ADDRESS, 0)));
            }
        }
        MemorySegment descriptor = localOutput();
        MemorySegment bytes = nativeApi.arena.allocate(ValueLayout.JAVA_INT);
        String text = Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS) ? "S:(ML;OICI;NW;;;LW)" : "S:(ML;;NW;;;LW)";
        nativeApi.requireBool(nativeApi.integer("ConvertStringSecurityDescriptorToSecurityDescriptorW",
            nativeApi.wide(text), 1, descriptor, bytes), "ConvertStringSecurityDescriptorToSecurityDescriptorW");
        MemorySegment sd = descriptor.get(ValueLayout.ADDRESS, 0);
        MemorySegment present = nativeApi.arena.allocate(ValueLayout.JAVA_INT);
        MemorySegment defaulted = nativeApi.arena.allocate(ValueLayout.JAVA_INT);
        MemorySegment sacl = nativeApi.arena.allocate(ValueLayout.ADDRESS);
        nativeApi.requireBool(nativeApi.integer("GetSecurityDescriptorSacl", sd, present, sacl, defaulted),
            "GetSecurityDescriptorSacl");
        nativeApi.requireStatus(nativeApi.integer("SetNamedSecurityInfoW", nativeApi.path(path),
            1, 0x10, MemorySegment.NULL, MemorySegment.NULL, MemorySegment.NULL, sacl.get(ValueLayout.ADDRESS, 0)),
            "SetNamedSecurityInfoW(LABEL)");
    }

    /**
     * Reserves an output slot and native-allocation release record before calling a LocalAlloc producer.
     * @return native pointer output, initially NULL
     */
    private MemorySegment localOutput()
    {
        MemorySegment output = nativeApi.arena.allocate(ValueLayout.ADDRESS);
        localMemory.add(new LocalMemory(output));
        return output;
    }

    /**
     * Serializes current-ACL merge/revoke without serializing action execution.
     * @param operation ACL operation under the shared mutation lock
     * @throws IOException if acquisition, operation or lock release fails
     */
    private void withAclLock(IoOperation operation) throws IOException
    {
        int wait = nativeApi.integer("WaitForSingleObject", mutex, -1);
        if (wait != 0 && wait != 0x80) throw nativeApi.failure("WaitForSingleObject(ACL mutex)");
        locked = true;
        try { operation.run(); }
        catch (IOException | RuntimeException | Error failure)
        {
            try
            {
                nativeApi.requireBool(nativeApi.integer("ReleaseMutex", mutex), "ReleaseMutex");
                locked = false;
            }
            catch (IOException | RuntimeException | Error cleanup) { failure.addSuppressed(cleanup); }
            throw failure;
        }
        nativeApi.requireBool(nativeApi.integer("ReleaseMutex", mutex), "ReleaseMutex");
        locked = false;
    }

    /**
     * Removes only this package's grants and restores original root labels, after all consumers drain.
     * A failure retains the remaining native resources and permanently records the first uncertain cleanup;
     * subsequent close calls report that failure instead of repeating a potentially completed native release.
     * The caller must not close this owner while any action or injected code can still execute.
     * @throws IOException if native cleanup cannot be confirmed; the caller retains this owner
     * @throws IllegalStateException if called outside the creating thread
     */
    @Override public void close() throws IOException
    {
        requireThread();
        if (closed) return;
        closing = true;
        if (cleanupFailure != null) throw cleanupFailure;
        if (nativeApi.unresolved != null) throw nativeApi.unresolved;
        try
        {
            if (locked)
            {
                nativeApi.requireBool(nativeApi.integer("ReleaseMutex", mutex), "ReleaseMutex(cleanup)");
                locked = false;
            }
            if (mutex.address() != 0)
            {
                withAclLock(() -> {
                    for (Grant grant : grants.values())
                    {
                        if (!Files.exists(grant.path, LinkOption.NOFOLLOW_LINKS)) continue;
                        if (!grant.identity.equals(identities.identity(grant.path))) continue;
                        changeAcl(grant.path, 4, 0);
                    }
                    for (Label label : labels.values())
                    {
                        if (!Files.exists(label.path, LinkOption.NOFOLLOW_LINKS)
                            || !label.identity.equals(identities.identity(label.path))) continue;
                        nativeApi.requireStatus(nativeApi.integer("SetNamedSecurityInfoW", nativeApi.path(label.path),
                            1, 0x10, MemorySegment.NULL, MemorySegment.NULL, MemorySegment.NULL, label.sacl),
                            "SetNamedSecurityInfoW(restore original label)");
                    }
                });
                nativeApi.requireBool(nativeApi.integer("CloseHandle", mutex), "CloseHandle(ACL mutex)");
                mutex = MemorySegment.NULL;
            }
            for (LocalMemory allocation : localMemory)
                if (!allocation.released)
                {
                    MemorySegment value = allocation.output.get(ValueLayout.ADDRESS, 0);
                    if (value.address() != 0 && nativeApi.pointer("LocalFree", value).address() != 0)
                        throw nativeApi.failure("LocalFree");
                    allocation.released = true;
                }
            if (profileAttempted)
            {
                int result = nativeApi.integer("DeleteAppContainerProfile", nativeApi.wide(profileName));
                if (result != 0 && result != (int)0x80070002L)
                    throw new IOException("DeleteAppContainerProfile HRESULT=" + Integer.toUnsignedString(result));
                profileAttempted = false;
            }
            MemorySegment sid = sidOutput.get(ValueLayout.ADDRESS, 0);
            if (sid.address() != 0)
            {
                if (nativeApi.pointer("FreeSid", sid).address() != 0) throw nativeApi.failure("FreeSid");
                sidOutput.set(ValueLayout.ADDRESS, 0, MemorySegment.NULL);
            }
            List<Pin> reverse = new ArrayList<>(pins.values()).reversed();
            for (Pin pin : reverse)
                if (!pin.released)
                {
                    nativeApi.requireBool(nativeApi.integer("CloseHandle", pin.handle), "CloseHandle(root pin)");
                    pin.released = true;
                }
            nativeApi.arena.close();
            closed = true;
        }
        catch (IOException | RuntimeException | Error failure)
        {
            cleanupFailure = failure instanceof IOException io ? io : new IOException("Native security cleanup is unresolved", failure);
            throw cleanupFailure;
        }
    }

    /**
     * Requires the constructing thread and open acquisition authority.
     * @throws IllegalStateException if stopping, closed or called by another thread
     */
    private void requireAcquiring()
    {
        requireThread();
        if (closing || closed) throw new IllegalStateException("Security acquisition is closed");
    }

    /**
     * Requires the single native arena owner thread.
     * @throws IllegalStateException if the current thread differs
     */
    private void requireThread()
    { if (thread != Thread.currentThread()) throw new IllegalStateException("Security owner belongs to another thread"); }

    /**
     * Accepts an exact absolute normalized native path.
     * @param path supplied path
     * @return unchanged validated path
     * @throws NullPointerException if path is null
     * @throws IllegalArgumentException if path is relative or contains redundant components
     */
    private static Path absolute(Path path)
    {
        Objects.requireNonNull(path, "path");
        if (!path.isAbsolute() || !path.normalize().equals(path))
            throw new IllegalArgumentException("Security paths must be absolute and normalized: " + path);
        return path;
    }

    /**
     * Tests whether either path contains the other.
     * @param first first normalized path
     * @param second second normalized path
     * @return whether the trees overlap
     */
    private static boolean overlap(Path first, Path second)
    { return first.startsWith(second) || second.startsWith(first); }

    /** Checked ACL operation under the shared mutation lock. */
    @FunctionalInterface private interface IoOperation
    {
        /**
         * Performs one current-ACL mutation sequence.
         * @throws IOException if a native operation fails
         */
        void run() throws IOException;
    }

    /** Original no-follow directory or public-image pin. */
    private static final class Pin
    {
        /** Retained original path. */ private final Path path;
        /** Shared immutable native identity. */ private final Object identity;
        /** Original no-share-delete handle, reserved before opening. */ private MemorySegment handle = MemorySegment.NULL;
        /** Whether native release succeeded. */ private boolean released;
        /**
         * Retains one acquired original handle.
         * @param path original path
         * @param identity original shared identity
         */
        private Pin(Path path, Object identity)
        { this.path = path; this.identity = identity; }
    }

    /** One object that may contain this profile's SID grant. */
    private static final class Grant
    {
        /** Granted path. */ private final Path path;
        /** Identity before any ACL effect. */ private final Object identity;
        /**
         * Records mutation ownership before a native effect.
         * @param path granted path
         * @param identity shared original identity
         */
        private Grant(Path path, Object identity) { this.path = path; this.identity = identity; }
    }

    /** Original mandatory-label ACL retained in its still-owned native descriptor. */
    private static final class Label
    {
        /** Pinned original action root. */ private final Path path;
        /** Shared identity before label mutation. */ private final Object identity;
        /** Original SACL pointer, or NULL for no explicit label. */ private final MemorySegment sacl;
        /**
         * Retains an original root label before replacement.
         * @param path pinned action root
         * @param identity shared original identity
         * @param sacl original native label ACL
         */
        private Label(Path path, Object identity, MemorySegment sacl)
        { this.path = path; this.identity = identity; this.sacl = sacl; }
    }

    /** One LocalAlloc result whose release must not be repeated after uncertainty. */
    private static final class LocalMemory
    {
        /** Producer output slot reserved before native allocation. */ private final MemorySegment output;
        /** Whether LocalFree confirmed release. */ private boolean released;
        /**
         * Reserves release ownership before a native allocator runs.
         * @param output native allocator output slot
         */
        private LocalMemory(MemorySegment output) { this.output = output; }
    }

    /** Fixed documented Win32 LLP64 bindings using the caller's Pouch native linker. */
    private static final class Native
    {
        /** Confined storage and system-library references. */ private final Arena arena = Arena.ofConfined();
        /** Captured GetLastError storage used only by the controlling thread. */
        private final MemorySegment state = arena.allocate(Linker.Option.captureStateLayout());
        /** Fixed ABI method handles by exact export name. */ private final Map<String, MethodHandle> functions = new LinkedHashMap<>();
        /** An invocation without a native result permanently retains the owner for reconciliation. */
        private IOException unresolved;
        /**
         * Binds only documented native platform APIs selected by the capability probe.
         * @param linker caller-owned Pouch linker
         */
        // These APIs have no JDK AppContainer counterpart; caller native-access authority remains required.
        @SuppressWarnings("restricted")
        private Native(Linker linker)
        {
            try
            {
                SymbolLookup kernel = SymbolLookup.libraryLookup("Kernel32", arena);
                SymbolLookup security = SymbolLookup.libraryLookup("Advapi32", arena);
                SymbolLookup profiles = SymbolLookup.libraryLookup("Userenv", arena);
                var p = ValueLayout.ADDRESS;
                var i = ValueLayout.JAVA_INT;
                bind(linker, profiles, "CreateAppContainerProfile", p,p,p,p,i,p);
                bind(linker, profiles, "DeleteAppContainerProfile", p);
                bindPointer(linker, security, "FreeSid", p);
                bindPointer(linker, kernel, "CreateFileW", p,i,i,p,i,i,p);
                bindPointer(linker, kernel, "CreateMutexW", p,i,p);
                bind(linker, kernel, "CloseHandle", p);
                bind(linker, kernel, "WaitForSingleObject", p,i);
                bind(linker, kernel, "ReleaseMutex", p);
                bindPointer(linker, kernel, "LocalFree", p);
                bind(linker, security, "GetNamedSecurityInfoW", p,i,i,p,p,p,p,p);
                bind(linker, security, "SetNamedSecurityInfoW", p,i,i,p,p,p,p);
                bind(linker, security, "SetEntriesInAclW", i,p,p,p);
                bind(linker, security, "ConvertStringSecurityDescriptorToSecurityDescriptorW", p,i,p,p);
                bind(linker, security, "GetSecurityDescriptorSacl", p,p,p,p);
            }
            catch (RuntimeException | Error failure) { arena.close(); throw failure; }
        }

        /**
         * Binds a DWORD or BOOL return with captured native error state.
         * @param linker shared Pouch linker
         * @param symbols owned system-library lookup
         * @param name exact export
         * @param arguments fixed argument layouts
         */
        @SuppressWarnings("restricted")
        private void bind(Linker linker, SymbolLookup symbols, String name, java.lang.foreign.MemoryLayout... arguments)
        {
            functions.put(name, linker.downcallHandle(symbols.find(name).orElseThrow(),
                FunctionDescriptor.of(ValueLayout.JAVA_INT, arguments), Linker.Option.captureCallState("GetLastError")));
        }

        /**
         * Binds a pointer return with captured native error state.
         * @param linker shared Pouch linker
         * @param symbols owned system-library lookup
         * @param name exact export
         * @param arguments fixed argument layouts
         */
        @SuppressWarnings("restricted")
        private void bindPointer(Linker linker, SymbolLookup symbols, String name, java.lang.foreign.MemoryLayout... arguments)
        {
            functions.put(name, linker.downcallHandle(symbols.find(name).orElseThrow(),
                FunctionDescriptor.of(ValueLayout.ADDRESS, arguments), Linker.Option.captureCallState("GetLastError")));
        }

        /**
         * Invokes one fixed native signature without replacing its native error result.
         * @param name bound export
         * @param arguments ABI arguments
         * @return exact boxed native result
         * @throws IOException if invocation has no authoritative native result
         */
        private Object call(String name, Object... arguments) throws IOException
        {
            List<Object> actual = new ArrayList<>(arguments.length + 1);
            actual.add(state);
            actual.addAll(List.of(arguments));
            try { return functions.get(name).invokeWithArguments(actual); }
            catch (Throwable failure)
            {
                unresolved = new IOException(name + " native result is unresolved", failure);
                throw unresolved;
            }
        }

        /**
         * Returns a bound DWORD/BOOL result.
         * @param name bound export
         * @param arguments fixed ABI arguments
         * @return exact native integer result
         * @throws IOException if invocation is unresolved
         */
        private int integer(String name, Object... arguments) throws IOException
        { return (int) call(name, arguments); }

        /**
         * Returns a bound native pointer result.
         * @param name bound export
         * @param arguments fixed ABI arguments
         * @return exact native pointer
         * @throws IOException if invocation is unresolved
         */
        private MemorySegment pointer(String name, Object... arguments) throws IOException
        { return (MemorySegment) call(name, arguments); }

        /**
         * Encodes an absolute native path with the documented extended-length prefix.
         * @param path absolute normalized Windows path
         * @return confined UTF-16 path storage
         */
        private MemorySegment path(Path path)
        {
            String text = path.toString();
            if (!text.startsWith("\\\\?\\"))
                text = text.startsWith("\\\\") ? "\\\\?\\UNC\\" + text.substring(2) : "\\\\?\\" + text;
            return wide(text);
        }

        /**
         * Creates a NUL-terminated UTF-16 native argument.
         * @param text native text without NUL
         * @return confined argument storage
         */
        private MemorySegment wide(String text)
        {
            byte[] bytes = (text + "\0").getBytes(StandardCharsets.UTF_16LE);
            MemorySegment result = arena.allocate(bytes.length, 2);
            result.copyFrom(MemorySegment.ofArray(bytes));
            return result;
        }

        /**
         * Rejects invalid native handles.
         * @param handle original result
         * @param operation native operation
         * @throws IOException if NULL or INVALID_HANDLE_VALUE
         */
        private void requireHandle(MemorySegment handle, String operation) throws IOException
        { if (handle.address() == 0 || handle.address() == -1) throw failure(operation); }

        /**
         * Requires a nonzero BOOL.
         * @param result exact native BOOL
         * @param operation operation context
         * @throws IOException if native rejected the request
         */
        private void requireBool(int result, String operation) throws IOException
        { if (result == 0) throw failure(operation); }

        /**
         * Requires ERROR_SUCCESS from a security API.
         * @param result exact native DWORD error
         * @param operation operation context
         * @throws IOException if native returned an error
         */
        private void requireStatus(int result, String operation) throws IOException
        { if (result != 0) throw new IOException(operation + " native error=" + Integer.toUnsignedString(result)); }

        /**
         * Captures the original native failure before another native call replaces it.
         * @param operation failed native operation
         * @return checked native failure
         */
        private IOException failure(String operation)
        {
            long offset = Linker.Option.captureStateLayout().byteOffset(java.lang.foreign.MemoryLayout.PathElement.groupElement("GetLastError"));
            return new IOException(operation + " GetLastError=" + Integer.toUnsignedString(state.get(ValueLayout.JAVA_INT, offset)));
        }
    }
}
