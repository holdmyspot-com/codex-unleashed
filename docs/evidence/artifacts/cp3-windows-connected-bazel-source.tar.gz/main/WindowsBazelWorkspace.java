package com.holdmyspot.codexunleashed.scheduler;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.DosFileAttributeView;
import java.nio.file.attribute.DosFileAttributes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Owns independent complete Windows input and temporary snapshots across same-path action retries.
 * The coordinator retains native root pins and exclusive request claims for the complete owner lifetime. Actions
 * receive access only to independently materialized contents; private snapshots retain controller-only protection.
 * Every native descendant, original wait, instrumentation owner and stream must be terminal before lease finalization.
 * This class does not infer that native barrier from filesystem state. Shared native identity rejects reparse points.
 */
final class WindowsBazelWorkspace implements BazelWorkspace
{
    /** Borrowed original authenticated input directory. */
    private final Path input;
    /** Borrowed original authenticated temporary directory. */
    private final Path temporary;
    /** Fresh controller-private storage outside both borrowed trees. */
    private final Path storage;
    /** Complete independent immutable input snapshot. */
    private final Path snapshot;
    /** Complete independent immutable temporary snapshot. */
    private final Path temporarySnapshot;
    /** Shared actual native volume/file identity and private-storage authority. */
    private final BazelBackendCredentials.NativeAuthority authority;
    /** Borrowed native root pins and action ACL assignment retained through workspace closure. */
    private final Access access;
    /** Originally authenticated input directory identity. */
    private final Object inputIdentity;
    /** Originally authenticated temporary directory identity. */
    private final Object temporaryIdentity;
    /** Sole coordinator thread permitted to control this owner. */
    private final Thread thread = Thread.currentThread();
    /** Every reserved attempt ordinal, including failed preparation. */
    private final Set<Long> sequences = new HashSet<>();
    /** Outstanding native execution or storage recovery lease. */
    private Lease active;
    /** Whether private storage has been completely removed. */
    private boolean closed;

    /**
     * Retains original authenticated identities before creating private storage.
     * @param input original input directory
     * @param temporary original temporary directory
     * @param storage absent private workspace path
     * @param authority borrowed shared native identity/private-storage authority
     * @param access borrowed native root pins and materialized action ACL owner
     * @throws IOException if original roots cannot be authenticated
     */
    private WindowsBazelWorkspace(Path input, Path temporary, Path storage,
        BazelBackendCredentials.NativeAuthority authority, Access access) throws IOException
    {
        this.input = input;
        this.temporary = temporary;
        this.storage = storage;
        this.snapshot = storage.resolve("inputs");
        this.temporarySnapshot = storage.resolve("temporary");
        this.authority = Objects.requireNonNull(authority, "authority");
        this.access = Objects.requireNonNull(access, "access");
        access.requireRoots();
        this.inputIdentity = directoryIdentity(input);
        this.temporaryIdentity = directoryIdentity(temporary);
    }

    /**
     * Creates complete independent snapshots, preserving only within-tree hardlink equivalence.
     * All regular files are copied, including read-only worker-cache hardlinks. Native root pins exclude root and
     * ancestor replacement; request claims exclude writers while copying. The absent private path must have a trusted
     * protected parent and share the original roots' filesystem for atomic entry moves. Reparse and special entries
     * are rejected by the common native identity contract before action release.
     * @param input absolute normalized original input directory
     * @param temporary absolute normalized original temporary directory
     * @param storage absolute normalized absent private storage
     * @param authority shared native identity and bounded private-storage protection
     * @param access borrowed root-pin and action-access authority
     * @return complete snapshots and same-path retry owner
     * @throws IOException if identity, snapshots, protection or same-filesystem staging cannot be established
     * @throws PreparationFailure if partial private-storage cleanup fails; retains its recovery owner
     * @throws IllegalArgumentException if paths are relative, unnormalized or overlap
     */
    static WindowsBazelWorkspace open(Path input, Path temporary, Path storage,
        BazelBackendCredentials.NativeAuthority authority, Access access) throws IOException
    {
        absolute(input);
        absolute(temporary);
        absolute(storage);
        if (overlaps(input, temporary) || overlaps(input, storage) || overlaps(temporary, storage))
            throw new IllegalArgumentException("Input, temporary and private workspace trees must be disjoint");
        WindowsBazelWorkspace owner = new WindowsBazelWorkspace(input, temporary, storage, authority, access);
        try
        {
            authority.createDirectory(storage);
            if (!Files.getFileStore(input).equals(Files.getFileStore(storage)) ||
                !Files.getFileStore(temporary).equals(Files.getFileStore(storage)))
                throw new IOException("Same-path restoration requires a common filesystem");
            owner.copy(input, owner.snapshot, new HashMap<>());
            owner.copy(temporary, owner.temporarySnapshot, new HashMap<>());
            owner.requireAttached();
            return owner;
        }
        catch (IOException | RuntimeException | Error failure)
        {
            try { owner.close(); }
            catch (IOException cleanup)
            {
                failure.addSuppressed(cleanup);
                throw new PreparationFailure(owner, failure);
            }
            throw failure;
        }
    }

    @Override public Path immutableSnapshot()
    {
        requireThread();
        if (closed) throw new IllegalStateException("Workspace is closed");
        return snapshot;
    }

    @Override public Attempt begin(long sequence) throws IOException
    {
        requireThread();
        if (closed || active != null) throw new IllegalStateException("Workspace is closed or retains an unresolved lease");
        if (sequence < 0 || !sequences.add(sequence))
            throw new IllegalArgumentException("Attempt ordinal must be nonnegative and never reused");
        requireAttached();
        active = new Lease(sequence);
        active.restore();
        active.issued = true;
        return active;
    }

    @Override public void close() throws IOException
    {
        requireThread();
        if (closed) return;
        if (active != null && !active.issued) active.discard();
        if (active != null) throw new IOException("Workspace retains an unresolved native or storage lease");
        access.requireRoots();
        remove(storage);
        closed = true;
    }

    /**
     * Requires retained native pins and matching actual original directory identities.
     * @throws IOException if either root or its ancestor authority changed
     */
    private void requireAttached() throws IOException
    {
        access.requireRoots();
        if (!inputIdentity.equals(directoryIdentity(input)) || !temporaryIdentity.equals(directoryIdentity(temporary)))
            throw new IOException("Authenticated worker input or temporary root was replaced");
    }

    /** One retained same-path native execution and rollback lease. */
    private final class Lease implements Attempt
    {
        /** Never-reused native attempt ordinal. */
        private final long sequence;
        /** Independent restoration generation, never reusing protected private pathnames. */
        private long generation;
        /** Whether final tree validation completed. */
        private boolean frozen;
        /** Whether begin returned this lease to a caller that may have started native acquisition. */
        private boolean issued;
        /** Whether this lease retired successfully. */
        private boolean resolved;

        /**
         * Reserves recovery ownership before any borrowed-root mutation.
         * @param sequence never-reused native attempt ordinal
         */
        private Lease(long sequence) { this.sequence = sequence; }

        @Override public void freeze() throws IOException
        {
            requireActive();
            if (frozen) throw new IllegalStateException("Attempt is already frozen");
            requireAttached();
            validate(input);
            validate(temporary);
            requireAttached();
            frozen = true;
        }

        @Override public void accept()
        {
            requireActive();
            if (!frozen) throw new IllegalStateException("Only frozen final state can be accepted");
            resolved = true;
            active = null;
        }

        @Override public void discard() throws IOException
        {
            requireActive();
            restore();
            resolved = true;
            active = null;
        }

        /**
         * Fully prepares both independent stages before replacing original directory entries.
         * Partial failure retains this lease and pristine snapshots for later recovery.
         * @throws IOException if complete copying, original authority, atomic entry moves or action ACLs fail
         */
        private void restore() throws IOException
        {
            requireAttached();
            long ordinal = generation;
            generation = Math.incrementExact(generation);
            Path stage = storage.resolve("attempt-" + sequence + "-restore-" + ordinal);
            authority.createDirectory(stage);
            Path inputStage = stage.resolve("inputs");
            Path temporaryStage = stage.resolve("temporary");
            copy(snapshot, inputStage, new HashMap<>());
            copy(temporarySnapshot, temporaryStage, new HashMap<>());
            requireAttached();
            replace(input, inputStage);
            replace(temporary, temporaryStage);
            requireAttached();
            access.materialized(input, temporary);
            requireAttached();
            remove(stage);
            frozen = false;
        }

        /** Rejects stale, cross-thread or already resolved lease operations. */
        private void requireActive()
        {
            requireThread();
            if (closed || resolved || active != this) throw new IllegalStateException("Attempt lease is no longer active");
        }
    }

    /**
     * Replaces entries while retaining the original pinned directory object and its original pathname.
     * @param original borrowed pinned original directory
     * @param stage complete independently materialized same-filesystem tree
     * @throws IOException if deletion, identity validation or atomic entry movement fails
     */
    private void replace(Path original, Path stage) throws IOException
    {
        requireAttached();
        for (Path child : children(original)) remove(child);
        for (Path child : children(stage))
            Files.move(child, original.resolve(child.getFileName()), StandardCopyOption.ATOMIC_MOVE);
        requireAttached();
    }

    /**
     * Independently copies ordinary entries using actual native IDs to preserve internal hardlink groups.
     * Destination files never link to a source/cache inode. Private ACLs remain controller-only until materialization.
     * @param source stable ordinary source entry
     * @param destination absent destination under private storage
     * @param links source IDs mapped only to newly created destination regular files
     * @throws IOException if identity changes, an unsupported entry is present or complete copying fails
     */
    private void copy(Path source, Path destination, Map<Object, Path> links) throws IOException
    {
        Object key = authority.identity(source);
        BasicFileAttributes before = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (before.isDirectory())
        {
            authority.createDirectory(destination);
            for (Path child : children(source)) copy(child, destination.resolve(child.getFileName()), links);
        }
        else if (before.isRegularFile())
        {
            Path prior = links.get(key);
            if (prior == null)
            {
                authority.createFile(destination);
                try (InputStream in = Files.newInputStream(source, LinkOption.NOFOLLOW_LINKS);
                    OutputStream out = Files.newOutputStream(destination, StandardOpenOption.WRITE, LinkOption.NOFOLLOW_LINKS))
                {
                    in.transferTo(out);
                }
                links.put(key, destination);
            }
            else
            {
                Files.createLink(destination, prior);
                authority.requireFile(destination);
            }
        }
        else throw new IOException("Unsupported Windows Bazel tree entry: " + source);
        BasicFileAttributes after = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (!key.equals(authority.identity(source)) || before.size() != after.size() ||
            !before.lastModifiedTime().equals(after.lastModifiedTime()))
            throw new IOException("Worker tree changed during independent copying: " + source);
        Files.setLastModifiedTime(destination, before.lastModifiedTime());
        DosFileAttributeView sourceDos = Files.getFileAttributeView(source, DosFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
        DosFileAttributeView destinationDos = Files.getFileAttributeView(destination, DosFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
        if (sourceDos != null && destinationDos != null)
        {
            DosFileAttributes dos = sourceDos.readAttributes();
            destinationDos.setArchive(dos.isArchive());
            destinationDos.setHidden(dos.isHidden());
            destinationDos.setSystem(dos.isSystem());
            destinationDos.setReadOnly(dos.isReadOnly());
        }
    }

    /**
     * Validates the entire final ordinary tree without traversing reparse points.
     * @param root final original worker-visible entry
     * @throws IOException if any entry is indirect, special or changes during traversal
     */
    private void validate(Path root) throws IOException
    {
        Object identity = authority.identity(root);
        BasicFileAttributes attributes = Files.readAttributes(root, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (attributes.isDirectory()) for (Path child : children(root)) validate(child);
        else if (!attributes.isRegularFile()) throw new IOException("Unsupported final Windows Bazel tree entry: " + root);
        if (!identity.equals(authority.identity(root))) throw new IOException("Final Windows Bazel tree changed: " + root);
    }

    /**
     * Authenticates one direct ordinary directory using the common native identity authority.
     * @param path absolute normalized directory
     * @return actual stable native identity
     * @throws IOException if the object is indirect or not a directory
     */
    private Object directoryIdentity(Path path) throws IOException
    {
        Object key = authority.identity(path);
        if (!Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Expected original directory: " + path);
        return key;
    }

    /**
     * Copies immediate child paths before entry mutation begins.
     * @param root authenticated ordinary directory
     * @return independent child path list
     * @throws IOException if enumeration fails
     */
    private static List<Path> children(Path root) throws IOException
    {
        List<Path> result = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(root))
        {
            for (Path child : stream) result.add(child);
        }
        return result;
    }

    /**
     * Removes an ordinary tree without following links or changing shared read-only inode metadata.
     * The caller's native pins and exclusive lease prevent concurrent writers during every recursive operation.
     * @param root independently owned private tree or discarded independent action entry
     * @throws IOException if complete deletion cannot be established
     */
    private void remove(Path root) throws IOException
    {
        if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) return;
        Object identity = authority.identity(root);
        if (Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS))
            for (Path child : children(root)) remove(child);
        if (!identity.equals(authority.identity(root))) throw new IOException("Entry changed during disposal: " + root);
        DosFileAttributeView dos = Files.getFileAttributeView(root, DosFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
        if (dos != null && dos.readAttributes().isReadOnly()) access.removeReadonly(root);
        else Files.delete(root);
    }

    /**
     * Requires normalized absolute paths before filesystem acquisition.
     * @param path selected ownership boundary
     * @throws IllegalArgumentException if the path is relative or unnormalized
     */
    private static void absolute(Path path)
    {
        Objects.requireNonNull(path, "path");
        if (!path.isAbsolute() || !path.equals(path.normalize()))
            throw new IllegalArgumentException("Windows workspace paths must be absolute and normalized");
    }

    /**
     * Determines whether two ownership boundaries overlap.
     * @param first first directory
     * @param second second directory
     * @return whether either boundary contains the other
     */
    private static boolean overlaps(Path first, Path second)
    {
        return first.startsWith(second) || second.startsWith(first);
    }

    /** Rejects use from a thread other than the original coordinator. */
    private void requireThread()
    {
        if (Thread.currentThread() != thread) throw new IllegalStateException("Workspace belongs to its coordinator thread");
    }

    /** Borrowed native root pins and action ACL authority; this owner never closes it. */
    interface Access
    {
        /**
         * Proves original roots and ancestors remain pinned against replacement.
         * @throws IOException if native pin authority is no longer intact
         */
        void requireRoots() throws IOException;

        /**
         * Assigns required action access only to the independent original-path materialization.
         * The immutable snapshots and private stages retain their controller-only ACLs.
         * @param input original input directory and complete independent contents
         * @param temporary original temporary directory and complete independent contents
         * @throws IOException if required action ACLs cannot be established
         */
        void materialized(Path input, Path temporary) throws IOException;

        /**
         * Unlinks one ordinary read-only entry without changing its inode attributes or following a reparse point.
         * Windows implementations use native ignore-readonly disposition; chmod/attribute clearing is forbidden because
         * an original worker input may remain hardlinked to its cache. The native handle is collected before return.
         * @param entry independently authenticated ordinary entry whose children have already been removed
         * @throws IOException if metadata-preserving unlink cannot be completed
         */
        void removeReadonly(Path entry) throws IOException;
    }

    /** Retains a partially acquired workspace when private storage disposal remains uncertain. */
    static final class PreparationFailure extends IOException
    {
        /** Required stable exception serialization version. */
        private static final long serialVersionUID = 1L;
        /** Process-local recovery authority, intentionally omitted from serialized diagnostics. */
        private final transient WindowsBazelWorkspace recovery;

        /**
         * Retains failed preparation and its unresolved storage owner.
         * @param recovery owner of partial private storage
         * @param cause original preparation failure with cleanup suppression
         */
        private PreparationFailure(WindowsBazelWorkspace recovery, Throwable cause)
        {
            super("Windows workspace preparation retains partial storage", cause);
            this.recovery = recovery;
        }

        /**
         * Returns the retained recovery owner; callers keep its borrowed security authority alive until close succeeds.
         * @return unresolved workspace cleanup owner
         */
        WindowsBazelWorkspace recovery() { return recovery; }
    }
}
