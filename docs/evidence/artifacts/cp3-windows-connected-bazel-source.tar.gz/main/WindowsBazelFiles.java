package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.IOException;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemoryLayout;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.file.Path;
import java.util.Objects;

/**
 * Supplies metadata-preserving native unlink for read-only original cache hardlinks.
 * Immutable functions borrow the invocation's Pouch linker; each operation retains its original no-delete-share handle
 * until actual closure. Identity is supplied exclusively by the common native authority, never a duplicate file-ID ABI.
 * Each operation is independent; the borrowed Pouch scope must outlive retained cleanup ownership.
 */
final class WindowsBazelFiles
{
    /** Win32 captured call state containing the original GetLastError value. */
    private final MemoryLayout stateLayout;
    /** Captured DWORD offset; read before another downcall can replace the error. */
    private final long errorOffset;
    /** Win32 DELETE access permits disposition changes on the acquired entry. */
    private static final int DELETE_ACCESS = 0x00010000;
    /** Win32 FILE_READ_ATTRIBUTES access permits inspecting the opened entry. */
    private static final int READ_ATTRIBUTES = 0x00000080;
    /** Win32 FILE_SHARE_READ | FILE_SHARE_WRITE, excluding FILE_SHARE_DELETE to pin this entry. */
    private static final int SHARE_READ_WRITE = 3;
    /** Win32 OPEN_EXISTING forbids creating a replacement when the authenticated entry disappeared. */
    private static final int OPEN_EXISTING = 3;
    /** Win32 FILE_FLAG_BACKUP_SEMANTICS permits an empty directory handle. */
    private static final int DIRECTORY_HANDLE = 0x02000000;
    /** Win32 FILE_FLAG_OPEN_REPARSE_POINT prevents traversing a final link or junction. */
    private static final int NO_FOLLOW = 0x00200000;
    /** FILE_INFO_BY_HANDLE_CLASS.FileDispositionInfoEx, in the documented zero-based enumeration. */
    private static final int DISPOSITION_EX = 21;
    /** FILE_DISPOSITION_DELETE requests deletion of the opened directory entry. */
    private static final int DELETE_ENTRY = 1;
    /** FILE_DISPOSITION_POSIX_SEMANTICS removes this link when its delete handle closes. */
    private static final int POSIX_SEMANTICS = 2;
    /** FILE_DISPOSITION_IGNORE_READONLY_ATTRIBUTE permits unlink without clearing shared DOS attributes. */
    private static final int IGNORE_READONLY_ATTRIBUTE = 16;
    /** Existing ordinary-file handle acquisition. */
    private final MethodHandle open;
    /** Native disposition update acting on the original no-delete-share file handle. */
    private final MethodHandle disposition;
    /** Original native handle collection. */
    private final MethodHandle close;

    /**
     * Binds only fixed documented 64-bit Win32 functions through borrowed invocation services.
     * @param tooling Pouch native linker retained through every operation and recovery owner
     * @throws NullPointerException if {@code tooling} is null
     * @throws UnsupportedOperationException if a required native function or 64-bit ABI is unavailable
     */
    WindowsBazelFiles(ToolingScope tooling)
    {
        Objects.requireNonNull(tooling, "tooling");
        if (!System.getProperty("os.name", "").startsWith("Windows") ||
            ValueLayout.ADDRESS.byteSize() != Long.BYTES)
            throw new UnsupportedOperationException("Windows Bazel unlink requires a 64-bit Windows runtime");
        Linker linker = tooling.getNativeLinker();
        this.stateLayout = Linker.Option.captureStateLayout();
        this.errorOffset = stateLayout.byteOffset(MemoryLayout.PathElement.groupElement("GetLastError"));
        SymbolLookup symbols = symbols();
        this.open = function(linker, symbols, "CreateFileW", FunctionDescriptor.of(ValueLayout.ADDRESS,
            ValueLayout.ADDRESS, ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS,
            ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS));
        this.disposition = function(linker, symbols, "SetFileInformationByHandle", FunctionDescriptor.of(ValueLayout.JAVA_INT,
            ValueLayout.ADDRESS, ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.JAVA_INT));
        this.close = function(linker, symbols, "CloseHandle", FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.ADDRESS));
    }

    /**
     * Unlinks a direct ordinary read-only entry without clearing attributes on its possibly shared inode.
     * Native FileDispositionInfoEx uses DELETE, POSIX_SEMANTICS and IGNORE_READONLY_ATTRIBUTE. Unsupported native or
     * filesystem behavior fails closed, retaining every original failure; attribute-clearing fallback is forbidden.
     * The caller excludes concurrent writers and pins root ancestors before calling. Deletion changes
     * the number of links and may change filesystem bookkeeping; this operation never clears DOS
     * attributes or writes file bytes or timestamps to work around a readonly rejection.
     * @param path absolute normalized authenticated ordinary file or empty directory
     * @param identity common no-follow native identity reader
     * @throws NullPointerException if either argument is null
     * @throws IllegalArgumentException if {@code path} is relative or non-normalized
     * @throws IOException if ordinary identity, handle acquisition, disposition or collection fails
     * @throws CleanupFailure if original native handle closure is uncertain; retains its operation owner
     */
    void unlink(Path path, BazelNativeBackend.FileIdentity identity) throws IOException
    {
        Objects.requireNonNull(path, "path");
        Objects.requireNonNull(identity, "identity");
        if (!path.isAbsolute() || !path.equals(path.normalize()))
            throw new IllegalArgumentException("Unlink path must be absolute and normalized");
        Object original = identity.identity(path);
        Operation operation = new Operation(path);
        try
        {
            operation.acquire();
            if (!original.equals(identity.identity(path))) throw new IOException("Read-only unlink entry changed: " + path);
            operation.mark();
        }
        catch (IOException | RuntimeException | Error failure)
        {
            try { operation.close(); }
            catch (IOException cleanup)
            {
                CleanupFailure retained = new CleanupFailure(operation, cleanup);
                if (failure instanceof Error fatal) { fatal.addSuppressed(retained); throw fatal; }
                retained.addSuppressed(failure);
                throw retained;
            }
            throw failure;
        }
        try { operation.close(); }
        catch (IOException cleanup) { throw new CleanupFailure(operation, cleanup); }
    }

    /**
     * Owns one native no-delete-share handle and its captured-error storage through acknowledged disposal.
     */
    private final class Operation implements AutoCloseable
    {
        /** Original absolute native file path. */
        private final Path path;
        /** Native allocations retained until original handle closure is acknowledged. */
        private final Arena arena;
        /** Captured native error state for this operation alone. */
        private final MemorySegment state;
        /** Original CreateFileW handle, never reconstructed by pathname. */
        private MemorySegment handle = MemorySegment.NULL;
        /** Reserves CloseHandle exactly once; uncertainty must never replay an ambiguous close effect. */
        private boolean closeAttempted;
        /** Retained original close failure, preventing a later successful acknowledgement. */
        private IOException closeFailure;
        /** Indicates whether native handle and argument storage both closed successfully. */
        private boolean closed;

        /**
         * Retains operation state before native acquisition.
         * @param path authenticated ordinary absolute native entry
         * @throws NullPointerException if {@code path} is null
         */
        private Operation(Path path)
        {
            this.path = Objects.requireNonNull(path, "path");
            this.arena = Arena.ofShared();
            try { this.state = arena.allocate(stateLayout); }
            catch (RuntimeException | Error failure)
            {
                try { arena.close(); }
                catch (RuntimeException | Error cleanup) { if (cleanup != failure) failure.addSuppressed(cleanup); }
                throw failure;
            }
        }

        /**
         * Acquires DELETE and metadata-read access while denying other handles delete sharing.
         * @throws IOException if native opening fails
         */
        private void acquire() throws IOException
        {
            String name = path.toString();
            if (!name.startsWith("\\\\?\\"))
                name = name.startsWith("\\\\") ? "\\\\?\\UNC\\" + name.substring(2) : "\\\\?\\" + name;
            MemorySegment filename = arena.allocateFrom(ValueLayout.JAVA_CHAR, (name + '\0').toCharArray());
            try
            {
                handle = (MemorySegment) open.invokeExact(state, filename, DELETE_ACCESS | READ_ATTRIBUTES,
                    SHARE_READ_WRITE, MemorySegment.NULL, OPEN_EXISTING, DIRECTORY_HANDLE | NO_FOLLOW,
                    MemorySegment.NULL);
            }
            catch (RuntimeException | Error failure) { throw failure; }
            catch (Throwable failure) { throw new IOException("CreateFileW unlink invocation failed", failure); }
            if (handle.address() == -1L || handle.address() == 0)
            {
                handle = MemorySegment.NULL;
                throw failure("CreateFileW");
            }
        }

        /**
         * Requests metadata-preserving POSIX-style disposition on the original owned handle.
         * @throws IOException if the native operation fails or the filesystem rejects its guarantees
         */
        private void mark() throws IOException
        {
            MemorySegment flags = arena.allocate(ValueLayout.JAVA_INT);
            flags.set(ValueLayout.JAVA_INT, 0, DELETE_ENTRY | POSIX_SEMANTICS | IGNORE_READONLY_ATTRIBUTE);
            int result;
            try { result = (int) disposition.invokeExact(state, handle, DISPOSITION_EX, flags, Integer.BYTES); }
            catch (RuntimeException | Error failure) { throw failure; }
            catch (Throwable failure) { throw new IOException("SetFileInformationByHandle unlink invocation failed", failure); }
            if (result == 0) throw failure("SetFileInformationByHandle(FileDispositionInfoEx)");
        }

        @Override public void close() throws IOException
        {
            if (closeFailure != null) throw closeFailure;
            if (closed) return;
            if (handle.address() != 0)
            {
                if (closeAttempted) throw new IllegalStateException("Unlink handle close authority was already consumed");
                closeAttempted = true;
                int result;
                try { result = (int) close.invokeExact(state, handle); }
                catch (Throwable cause)
                {
                    closeFailure = new IOException("CloseHandle unlink invocation remains uncertain", cause);
                    throw closeFailure;
                }
                if (result == 0)
                {
                    closeFailure = failure("CloseHandle");
                    throw closeFailure;
                }
                handle = MemorySegment.NULL;
            }
            try { arena.close(); }
            catch (RuntimeException | Error cause)
            {
                closeFailure = new IOException("Unlink argument storage disposal failed after native handle closure", cause);
                throw closeFailure;
            }
            closed = true;
        }

        /**
         * Captures a caller-visible original Win32 error before cleanup changes the error slot.
         * @param name exact failed native operation
         * @return original failure and path context
         */
        private IOException failure(String name)
        {
            return new IOException(name + " failed for " + path + ": GetLastError=" +
                Integer.toUnsignedString(state.get(ValueLayout.JAVA_INT, errorOffset)));
        }
    }

    /**
     * Retains original operation ownership when native handle or argument-storage disposal cannot be acknowledged.
     */
    static final class CleanupFailure extends IOException
    {
        /** Stable diagnostic serialization version. */
        private static final long serialVersionUID = 1L;
        /** Process-local original operation authority, omitted from serialized diagnostics. */
        private final transient AutoCloseable recovery;

        /**
         * Retains original cleanup ownership and its actual failure.
         * @param recovery original uncertain handle owner
         * @param cause original handle or argument-storage disposal failure
         */
        private CleanupFailure(AutoCloseable recovery, IOException cause)
        {
            super("Read-only Windows unlink retains original native cleanup authority", cause);
            this.recovery = Objects.requireNonNull(recovery, "recovery");
        }

        /**
         * Returns the original operation owner; an uncertain close remains visible on repeated close.
         * @return retained native authority, or null after diagnostic serialization outside its acquiring process
         */
        AutoCloseable recovery() { return recovery; }
    }

    /**
     * Borrows the system library for this process's lifetime, matching existing Windows native bindings.
     * @return Kernel32 documented symbols
     */
    // Installed native-access authorization applies to the fixed Windows system library only.
    @SuppressWarnings("restricted")
    private static SymbolLookup symbols() { return SymbolLookup.libraryLookup("Kernel32", Arena.global()); }

    /**
     * Resolves one fixed documented signature and captures its original Win32 error state.
     * @param linker borrowed invocation native linker
     * @param symbols process-owned system exports
     * @param name exact documented function
     * @param descriptor fixed LLP64 signature
     * @return captured-error native downcall
     */
    // Arguments use documented fixed Win32 signatures and operation-owned native storage.
    @SuppressWarnings("restricted")
    private static MethodHandle function(Linker linker, SymbolLookup symbols, String name, FunctionDescriptor descriptor)
    {
        return linker.downcallHandle(symbols.find(name).orElseThrow(() ->
            new UnsupportedOperationException("Windows does not provide " + name)), descriptor,
            Linker.Option.captureCallState("GetLastError"));
    }
}
