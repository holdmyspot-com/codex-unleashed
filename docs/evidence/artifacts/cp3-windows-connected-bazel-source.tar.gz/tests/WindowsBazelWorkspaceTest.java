package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.DosFileAttributeView;
import java.nio.file.attribute.AclEntryFlag;
import java.nio.file.attribute.AclEntryPermission;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.AclFileAttributeView;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Stream;
import org.testng.annotations.Test;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/** Exercises complete same-path storage using real host file IDs; does not claim native process or ACL isolation. */
public final class WindowsBazelWorkspaceTest
{
    /** Creates a fixture-free test object; each parallel method owns every resource it uses. */
    public WindowsBazelWorkspaceTest() {}

    /**
     * Cache links break, internal hardlinks survive, and failed mutations cannot contaminate retry or cache bytes.
     * @throws IOException if fixture or production storage operations fail
     */
    @Test public void isolatesCacheAndRestoresSameRootObjects() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            Path cache = Files.writeString(fixture.root.resolve("cache"), "pristine");
            DosFileAttributeView cacheDos = Files.getFileAttributeView(cache, DosFileAttributeView.class);
            if (cacheDos != null) cacheDos.setReadOnly(true);
            Files.createLink(fixture.input.resolve("first"), cache);
            Files.createLink(fixture.input.resolve("second"), cache);
            Files.writeString(fixture.temporary.resolve("seed"), "temporary");
            Object inputId = fixture.authority.identity(fixture.input);
            Object temporaryId = fixture.authority.identity(fixture.temporary);
            try (WindowsBazelWorkspace workspace = fixture.open())
            {
                BazelWorkspace.Attempt first = workspace.begin(3);
                requireThat(Files.isSameFile(fixture.input.resolve("first"), cache), "cacheLinkBroken").isFalse();
                requireThat(Files.isSameFile(fixture.input.resolve("first"), workspace.immutableSnapshot().resolve("first")),
                    "snapshotLinkBroken").isFalse();
                requireThat(Files.isSameFile(fixture.input.resolve("first"), fixture.input.resolve("second")),
                    "internalHardlinkPreserved").isTrue();
                DosFileAttributeView actionDos = Files.getFileAttributeView(fixture.input.resolve("first"), DosFileAttributeView.class);
                if (actionDos != null) actionDos.setReadOnly(false);
                Files.writeString(fixture.input.resolve("first"), "poison");
                Files.writeString(fixture.input.resolve("failed-output"), "discard");
                Files.writeString(fixture.temporary.resolve("seed"), "poison");
                first.discard();
                BazelWorkspace.Attempt retry = workspace.begin(4);
                requireThat(Files.readString(fixture.input.resolve("second")), "pristineRetry").isEqualTo("pristine");
                requireThat(Files.readString(fixture.temporary.resolve("seed")), "pristineTemporary").isEqualTo("temporary");
                requireThat(Files.exists(fixture.input.resolve("failed-output")), "failedOutputAbsent").isFalse();
                requireThat(Files.readString(cache), "cacheUnchanged").isEqualTo("pristine");
                if (cacheDos != null) requireThat(cacheDos.readAttributes().isReadOnly(), "cacheReadonlyMetadataUnchanged").isTrue();
                requireThat(fixture.authority.identity(fixture.input), "sameInputObject").isEqualTo(inputId);
                requireThat(fixture.authority.identity(fixture.temporary), "sameTemporaryObject").isEqualTo(temporaryId);
                retry.discard();
            }
            requireThat(Files.exists(fixture.storage), "privateStorageRemoved").isFalse();
            requireThat(Files.isDirectory(fixture.input), "borrowedInputRetained").isTrue();
            requireThat(Files.isDirectory(fixture.temporary), "borrowedTemporaryRetained").isTrue();
        }
    }

    /**
     * A frozen tree whose original RPC rejects publication is fully restored before the lease retires.
     * @throws IOException if real filesystem or production operations fail
     */
    @Test public void rejectedFrozenPublicationRestoresInputsAndTemporary() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            Files.writeString(fixture.input.resolve("source"), "source");
            Files.writeString(fixture.temporary.resolve("seed"), "seed");
            try (WindowsBazelWorkspace workspace = fixture.open())
            {
                BazelWorkspace.Attempt attempt = workspace.begin(1);
                Files.delete(fixture.input.resolve("source"));
                Files.write(fixture.input.resolve("output"), new byte[] {0, -1, 23});
                Files.writeString(fixture.temporary.resolve("seed"), "changed");
                attempt.freeze();
                attempt.discard();
                requireThat(Files.readString(fixture.input.resolve("source")), "sourceRestored").isEqualTo("source");
                requireThat(Files.exists(fixture.input.resolve("output")), "rejectedOutputRemoved").isFalse();
                requireThat(Files.readString(fixture.temporary.resolve("seed")), "temporaryRestored").isEqualTo("seed");
            }
        }
    }

    /**
     * After freeze, successful acceptance retires only memory and leaves exact final binary bytes in place.
     * @throws IOException if real filesystem or production operations fail
     */
    @Test public void acceptanceDoesNotIntroducePostPublicationIo() throws IOException
    {
        try (Fixture fixture = new Fixture(); WindowsBazelWorkspace workspace = fixture.open())
        {
            BazelWorkspace.Attempt attempt = workspace.begin(9);
            byte[] output = {0, 23, -1, 10, 13};
            Files.write(fixture.input.resolve("output"), output);
            attempt.freeze();
            fixture.forbidAccess = true;
            attempt.accept();
            fixture.forbidAccess = false;
            requireThat(java.util.Arrays.equals(Files.readAllBytes(fixture.input.resolve("output")), output),
                "exactAcceptedBinaryOutput").isTrue();
        }
    }

    /**
     * A begin failure after root mutation retains recovery authority and close restores pristine borrowed trees.
     * @throws IOException if real filesystem or production operations fail
     */
    @Test public void failedPreparationRemainsOwnedForRecovery() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            Files.writeString(fixture.input.resolve("source"), "source");
            WindowsBazelWorkspace workspace = fixture.open();
            fixture.failMaterialization = true;
            boolean failed = false;
            try { workspace.begin(12); }
            catch (IOException expected) { failed = true; }
            requireThat(failed, "materializationFailureObserved").isTrue();
            fixture.failMaterialization = false;
            workspace.close();
            requireThat(Files.readString(fixture.input.resolve("source")), "recoveredSource").isEqualTo("source");
            requireThat(Files.exists(fixture.storage), "recoveryStorageRemoved").isFalse();
        }
    }

    /** Owns one independent real-filesystem fixture and explicitly controlled borrowed access boundary. */
    private static final class Fixture implements AutoCloseable, WindowsBazelWorkspace.Access
    {
        /** Unique complete test root. */
        private final Path root;
        /** Original borrowed input directory. */
        private final Path input;
        /** Original borrowed temporary directory. */
        private final Path temporary;
        /** Absent workspace-private path. */
        private final Path storage;
        /** Real host native-linker and parser services. */
        private final DefaultToolingScope scope = new DefaultToolingScope();
        /** Scope sharing only immutable profile and native unlink services within this fixture. */
        private final WindowsBazelScope bazelScope = new WindowsBazelScope(scope);
        /** Shared actual host identity and private-file protection implementation. */
        private final BazelBackendCredentials.NativeAuthority authority;
        /** Explicitly forbids storage-access callbacks after freeze for the acceptance test. */
        private boolean forbidAccess;
        /** Injects ACL-composition failure after complete independent materialization. */
        private boolean failMaterialization;

        /**
         * Creates independent private fixture storage with actual current-host protection.
         * @throws IOException if creation or common native authority acquisition fails
         */
        private Fixture() throws IOException
        {
            root = Files.createTempDirectory("windows-bazel-workspace-");
            PosixFileAttributeView posix = Files.getFileAttributeView(root, PosixFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
            if (posix != null) posix.setPermissions(PosixFilePermissions.fromString("rwx------"));
            else
            {
                AclFileAttributeView acl = Files.getFileAttributeView(root, AclFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
                acl.setAcl(List.of(AclEntry.newBuilder().setType(AclEntryType.ALLOW).setPrincipal(acl.getOwner()).
                    setPermissions(EnumSet.allOf(AclEntryPermission.class)).setFlags(AclEntryFlag.DIRECTORY_INHERIT,
                        AclEntryFlag.FILE_INHERIT).build()));
            }
            input = Files.createDirectory(root.resolve("input"));
            temporary = Files.createDirectory(root.resolve("tmp"));
            storage = root.resolve("workspace");
            authority = BazelBackendCredentials.nativeAuthority(scope, root);
        }

        /**
         * Acquires the production workspace against real current-host file identity.
         * @return complete production workspace
         * @throws IOException if acquisition fails
         */
        private WindowsBazelWorkspace open() throws IOException
        {
            return WindowsBazelWorkspace.open(input, temporary, storage, authority, this);
        }

        @Override public void requireRoots() throws IOException
        {
            if (forbidAccess) throw new IOException("No storage operation is allowed after successful freeze");
        }

        @Override public void materialized(Path materializedInput, Path materializedTemporary) throws IOException
        {
            requireThat(materializedInput, "sameInputPath").isEqualTo(input);
            requireThat(materializedTemporary, "sameTemporaryPath").isEqualTo(temporary);
            if (failMaterialization) throw new IOException("Injected action ACL assignment failure");
        }

        @Override public void removeReadonly(Path entry) throws IOException
        {
            if (System.getProperty("os.name").startsWith("Windows")) bazelScope.files().unlink(entry, authority);
            else Files.delete(entry);
        }

        @Override public void close() throws IOException
        {
            try (Stream<Path> paths = Files.walk(root))
            {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) removeReadonly(path);
            }
            bazelScope.close();
            scope.close();
        }
    }
}
