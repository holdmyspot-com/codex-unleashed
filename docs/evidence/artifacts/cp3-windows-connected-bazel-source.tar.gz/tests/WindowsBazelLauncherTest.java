package com.holdmyspot.codexunleashed.scheduler;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import org.testng.annotations.Test;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/** Checks the invocation boundary without emulating a Windows process or native launcher. */
public final class WindowsBazelLauncherTest
{
    /** Creates independent tests with no shared fixtures. */
    public WindowsBazelLauncherTest() {}

    /**
     * Keeps empty, Unicode, quote, newline, backslash and shell-looking arguments byte-for-character intact.
     * @throws IOException if approved inputs are rejected
     */
    @Test
    public void preservesArgumentsAndPrependsStartupRc() throws IOException
    {
        Path root = Path.of("").toAbsolutePath();
        Path executable = root.resolve("pinned bazel.exe");
        Path rc = root.resolve("common configuration.bazelrc");
        var environment = WindowsBazelLauncher.environment(Map.of(), root.resolve("wrapper.exe"), executable, rc);
        var arguments = List.of("build", "", "two words", "尾\\", "x\\\"y", "line1\nline2", "%PATH%&!$", "--", "//:target");
        var actual = WindowsBazelLauncher.command(environment, arguments);
        requireThat(actual.subList(0, 3), "startupArguments").isEqualTo(
            List.of(executable.toString(), "--batch", "--bazelrc=" + rc));
        requireThat(actual.subList(3, actual.size()), "consumerArguments").isEqualTo(arguments);
    }

    /** Replaces differently cased reserved names without changing unrelated environment values. */
    @Test
    public void configuresAbsoluteExecutableAndReplacesReservedNames()
    {
        Path root = Path.of("").toAbsolutePath();
        var actual = WindowsBazelLauncher.environment(Map.of("codex_bazel_bin", "stale",
            "codex_bazel_executable", "stale", "codex_bazel_startup_rc", "stale", "KEPT", "尾\n%PATH%"),
            root.resolve("wrapper.exe"), root.resolve("bazel.exe"), root.resolve("common.rc"));
        requireThat(actual.size(), "environmentSize").isEqualTo(5);
        requireThat(actual.get("CODEX_BAZEL_BIN"), "launcher").isEqualTo(root.resolve("wrapper.exe").toString());
        requireThat(actual.get("KEPT"), "unrelatedValue").isEqualTo("尾\n%PATH%");
        requireThat(actual.get("PATH"), "nativeLauncherDllDirectory").isEqualTo(root.resolve("app").toString());
    }

    /**
     * Rejects missing startup configuration instead of invoking uncontrolled Bazel.
     * @throws IOException if an unexpected failure escapes
     */
    @Test
    public void rejectsMissingStartupRc() throws IOException
    {
        boolean rejected = false;
        try
        {
            WindowsBazelLauncher.command(Map.of("CODEX_BAZEL_EXECUTABLE",
                Path.of("").toAbsolutePath().resolve("bazel.exe").toString()), List.of("build"));
        }
        catch (IOException expected) { rejected = expected.getMessage().contains("CODEX_BAZEL_STARTUP_RC"); }
        requireThat(rejected, "missingRcRejected").isTrue();
    }

    /** Rejects a relative consumer executable without resolving it against the controller working directory. */
    @Test
    public void rejectsRelativeLauncher()
    {
        Path root = Path.of("").toAbsolutePath();
        boolean rejected = false;
        try { WindowsBazelLauncher.environment(Map.of(), Path.of("wrapper.exe"), root.resolve("bazel.exe"), root.resolve("common.rc")); }
        catch (IllegalArgumentException expected) { rejected = true; }
        requireThat(rejected, "relativeLauncherRejected").isTrue();
    }
}
