package com.holdmyspot.codexunleashed.scheduler;

import static com.holdmyspot.codexunleashed.scheduler.TestRequirements.requireException;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;
import java.io.File;
import java.io.IOException;
import org.testng.SkipException;
import org.testng.annotations.Test;

/** Exercises the actual schedule entry point's rejection before any native or scoped acquisition. */
public final class WindowsBazelScheduleTest
{
    /** Creates a stateless set of independently owned boundary checks. */
    public WindowsBazelScheduleTest() {}

    /**
     * Foreign native filesystems are rejected before even null caller inputs are inspected.
     * No settings, parser, native owner, filesystem fixture or compile-only invocation may be acquired.
     */
    @Test
    public void rejectsForeignHostBeforeInspectingInputs()
    {
        if (File.separatorChar == '\\') throw new SkipException("Foreign-host rejection requires a non-Windows JVM");
        IOException failure = requireException(IOException.class, () -> WindowsBazelSchedule.run(null, null));
        requireThat(failure.getMessage(), "hostDiagnostic").contains("native Windows x64 or ARM64");
    }
}
