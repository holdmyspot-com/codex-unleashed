package com.holdmyspot.codexunleashed.scheduler;

import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;
import static com.holdmyspot.codexunleashed.scheduler.TestRequirements.requireException;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.DosFileAttributeView;
import java.nio.file.attribute.FileTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.testng.SkipException;
import org.testng.annotations.Test;

/**
 * Exercises the native Windows file identity and action-directory executable contract.
 * Each method owns its fixture and may run concurrently with every other method.
 */
public final class WindowsWorkIdentityTest
{
    /**
     * Creates a stateless group of independently owned native Windows checks.
     */
    public WindowsWorkIdentityTest() {}

    /**
     * Complete bytes are reread even when a Windows file's size and modification time are unchanged.
     * @throws IOException if native fixture, identity or cleanup operations fail
     */
    @Test
    public void rereadsWindowsBytesWithoutPosixPermissions() throws IOException
    {
        requireWindows();
        Path root = Files.createTempDirectory("windows-work-bytes-");
        try
        {
            Path tool = Files.writeString(root.resolve("tool.exe"), "image");
            Path input = Files.writeString(root.resolve("input"), "first");
            BazelWorkIdentity.ImmutableFiles cache = new BazelWorkIdentity.ImmutableFiles();
            String original = cache.identify(root, root, List.of(tool.toString()), Map.of(), root, "windows");
            FileTime modified = Files.getLastModifiedTime(input);
            Files.writeString(input, "other");
            Files.setLastModifiedTime(input, modified);
            String changed = cache.identify(root, root, List.of(tool.toString()), Map.of(), root, "windows");
            requireThat(changed.equals(original), "changedBytesReuseIdentity").isFalse();
            requireThat(changed, "cachedMatchesCompleteIdentity").isEqualTo(
                BazelWorkIdentity.identify(root, List.of(tool.toString()), Map.of(), root, "windows"));
        }
        finally { remove(root); }
    }

    /**
     * Changing DOS attributes changes identity even while file bytes remain equal.
     * @throws IOException if native fixture, identity or cleanup operations fail
     */
    @Test
    public void bindsDosFileAttributes() throws IOException
    {
        requireWindows();
        Path root = Files.createTempDirectory("windows-work-attributes-");
        try
        {
            Path tool = Files.writeString(root.resolve("tool.exe"), "image");
            Path input = Files.writeString(root.resolve("input"), "unchanged");
            DosFileAttributeView attributes = Files.getFileAttributeView(input, DosFileAttributeView.class);
            String original = BazelWorkIdentity.identify(root, List.of(tool.toString()), Map.of(), root, "windows");
            attributes.setHidden(true);
            String hidden = BazelWorkIdentity.identify(root, List.of(tool.toString()), Map.of(), root, "windows");
            requireThat(hidden.equals(original), "hiddenAttributeCollapsed").isFalse();
            attributes.setReadOnly(true);
            String readOnly = BazelWorkIdentity.identify(root, List.of(tool.toString()), Map.of(), root, "windows");
            requireThat(readOnly.equals(hidden), "readOnlyAttributeCollapsed").isFalse();
        }
        finally { remove(root); }
    }

    /**
     * A bare Windows executable name resolves against the explicit action directory without PATH search.
     * @throws IOException if native fixture, identity or cleanup operations fail
     */
    @Test
    public void resolvesBareExecutableAgainstActionDirectory() throws IOException
    {
        requireWindows();
        Path root = Files.createTempDirectory("windows-work-command-");
        try
        {
            Files.writeString(root.resolve("tool.exe"), "image");
            String identity = BazelWorkIdentity.identify(root, List.of("tool.exe"), Map.of("Path", "absent"), root, "windows");
            requireThat(identity.length(), "sha256TextLength").isEqualTo(64);
            requireException(IOException.class, () -> BazelWorkIdentity.identify(root, List.of("missing.exe"),
                Map.of("PATH", root.toString(), "PATHEXT", ".exe"), root, "windows"));
        }
        finally { remove(root); }
    }

    /**
     * Rejects Windows drive-relative executable names whose meaning depends on the launcher's drive state.
     * @throws IOException if native fixture, identity or cleanup operations fail
     */
    @Test
    public void rejectsDriveRelativeExecutable() throws IOException
    {
        requireWindows();
        Path root = Files.createTempDirectory("windows-work-drive-");
        try
        {
            Files.writeString(root.resolve("tool.exe"), "image");
            String driveRelative = root.getRoot().toString().substring(0, 2) + "tool.exe";
            requireException(IOException.class, () -> BazelWorkIdentity.identify(root, List.of(driveRelative),
                Map.of(), root, "windows"));
        }
        finally { remove(root); }
    }

    /**
     * Requires the native Windows path provider instead of claiming Windows evidence on another host.
     * @throws SkipException if the current JVM uses another native filesystem
     */
    private static void requireWindows()
    {
        if (File.separatorChar != '\\') throw new SkipException("Requires native Windows filesystem semantics");
    }

    /**
     * Removes only a test-owned root, restoring readonly files before deletion.
     * @param root exclusively owned test fixture
     * @throws IOException if cleanup fails
     */
    private static void remove(Path root) throws IOException
    {
        try (Stream<Path> paths = Files.walk(root))
        {
            for (Path entry : paths.sorted(Comparator.reverseOrder()).toList())
            {
                Files.getFileAttributeView(entry, DosFileAttributeView.class).setReadOnly(false);
                Files.delete(entry);
            }
        }
    }
}
