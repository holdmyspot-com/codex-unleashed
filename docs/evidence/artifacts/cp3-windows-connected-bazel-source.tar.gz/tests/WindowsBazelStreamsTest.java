package com.holdmyspot.codexunleashed.scheduler;

import static com.holdmyspot.codexunleashed.scheduler.TestRequirements.requireException;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.lang.foreign.MemorySegment;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;
import org.testng.annotations.Test;

/**
 * Exercises production acquisition, reset requests and retirement with controlled Win32 results.
 * It proves ownership decisions on every host; actual HANDLE I/O requires the native Windows gate.
 */
public final class WindowsBazelStreamsTest
{
    /**
     * Creates a resource-free test instance; each method owns its mutable fixtures.
     */
    public WindowsBazelStreamsTest() {}

    /**
     * Acquisition uses the two exact destinations and reset targets their original handles.
     * @throws IOException if fixture setup or production acquisition fails
     */
    @Test
    public void resetUsesOriginalSeparateFileDescriptions() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            try (WindowsBazelStreams streams = fixture.open())
            {
                List<Long> original = List.of(streams.stdout().address(), streams.stderr().address());
                requireThat(original.getFirst().equals(original.getLast()), "distinctOutputHandles").isFalse();
                requireThat(fixture.calls.destinations, "unchangedWorkerPaths")
                    .isEqualTo(List.of(fixture.stdout, fixture.stderr));
                requireThat(streams.input().address() == streams.stdout().address(), "separateNullInput").isFalse();
                int acquired = fixture.calls.acquired.size();
                streams.reset();
                requireThat(fixture.calls.resets, "resetOriginalDescriptions").isEqualTo(original);
                requireThat(fixture.calls.acquired.size(), "noReopenDuringReset").isEqualTo(acquired);
            }
            requireThat(fixture.calls.closed, "allOriginalHandlesRetiredInReverseOrder")
                .isEqualTo(fixture.calls.acquired.reversed());
            requireThat(fixture.calls.bindingCloses, "oneBindingDisposal").isEqualTo(1);
        }
    }

    /**
     * Existing output bytes survive rejection and all earlier directory pins are retired.
     * @throws IOException if fixture setup fails
     */
    @Test
    public void existingDestinationIsRejectedWithoutTruncation() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            byte[] original = {(byte) 255, 0, 13, 10, 65};
            Files.write(fixture.stdout, original);
            requireException(IOException.class, fixture::open);
            requireThat(java.util.Arrays.equals(Files.readAllBytes(fixture.stdout), original),
                "existingOutputBytesPreserved").isTrue();
            requireThat(Files.exists(fixture.stderr), "noLaterOutputCreated").isFalse();
            requireThat(fixture.calls.closed, "pinsReleasedAfterCreationRejection")
                .isEqualTo(fixture.calls.acquired.reversed());
            requireThat(fixture.calls.bindingCloses, "rejectedAcquisitionBindingsRetired").isEqualTo(1);
        }
    }

    /**
     * A failure creating stderr retires stdout and pins while leaving worker-owned files in place.
     * @throws IOException if fixture setup fails
     */
    @Test
    public void laterAcquisitionFailureClosesEarlierHandles() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            Files.writeString(fixture.stderr, "existing worker output");
            requireException(IOException.class, fixture::open);
            requireThat(Files.size(fixture.stdout), "newWorkerOutputRemainsEmpty").isEqualTo(0L);
            requireThat(Files.readString(fixture.stderr), "existingErrorUnchanged")
                .isEqualTo("existing worker output");
            requireThat(fixture.calls.closed, "partialAcquisitionHandleCleanup")
                .isEqualTo(fixture.calls.acquired.reversed());
            requireThat(fixture.calls.bindingCloses, "partialAcquisitionBindingsRetired").isEqualTo(1);
        }
    }

    /**
     * Failed close remains sticky, retires independent handles and never replays uncertain effects.
     * @throws IOException if fixture setup or acquisition fails
     */
    @Test
    public void failedCloseRetainsOwnerWithoutReplayingNativeEffects() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            WindowsBazelStreams streams = fixture.open();
            fixture.calls.failedClose = streams.stderr().address();
            IOException first = requireException(IOException.class, streams::close);
            List<Long> effects = List.copyOf(fixture.calls.closed);
            requireThat(requireException(IOException.class, streams::close), "stickyFailure").isEqualTo(first);
            requireThat(fixture.calls.closed, "noRepeatedNativeClose").isEqualTo(effects);
            requireThat(effects, "independentHandlesStillRetired").isEqualTo(fixture.calls.acquired.reversed());
            requireThat(fixture.calls.bindingCloses, "bindingsRetainedForUncertainOwner").isEqualTo(0);
            requireThat(streams.isClosed(), "unresolvedOwnerRemainsOpen").isFalse();
            requireException(IllegalStateException.class, streams::stdout);
        }
    }

    /**
     * An acquisition failure accompanied by uncertain cleanup returns its retained owner.
     * @throws IOException if fixture setup fails
     */
    @Test
    public void acquisitionFailureRetainsUncertainCleanupOwner() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            Files.writeString(fixture.stderr, "existing error");
            fixture.calls.failEveryClose = true;
            WindowsBazelStreams.AcquisitionFailure failure =
                requireException(WindowsBazelStreams.AcquisitionFailure.class, fixture::open);
            requireThat(failure.owner(), "retainedAcquisitionOwner").isNotNull();
            requireThat(failure.owner().isClosed(), "cleanupStillUnresolved").isFalse();
            requireThat(failure.getSuppressed().length, "cleanupFailurePreserved").isEqualTo(1);
            List<Long> first = List.copyOf(fixture.calls.closed);
            requireException(IOException.class, failure.owner()::close);
            requireThat(fixture.calls.closed, "acquisitionCleanupNotReplayed").isEqualTo(first);
        }
    }

    /**
     * A reset failure stops before touching the other output and can still be followed by cleanup.
     * @throws IOException if fixture setup or acquisition fails
     */
    @Test
    public void resetFailureStopsTheRetryPreparation() throws IOException
    {
        try (Fixture fixture = new Fixture(); WindowsBazelStreams streams = fixture.open())
        {
            fixture.calls.failedReset = streams.stdout().address();
            requireException(IOException.class, streams::reset);
            requireThat(fixture.calls.resets, "noSecondResetAfterFailure")
                .isEqualTo(List.of(streams.stdout().address()));
        }
    }

    /**
     * A changed shared identity during directory pin acquisition prevents output creation.
     * @throws IOException if fixture setup fails
     */
    @Test
    public void changedAncestorIdentityPreventsFileCreation() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            Path firstAncestor = fixture.stdout.getRoot();
            BazelNativeBackend.FileIdentity stable = BazelBackendCredentials.nativeIdentity(fixture.scope);
            BazelNativeBackend.FileIdentity changing = path ->
            {
                if (path.equals(firstAncestor) && !fixture.calls.acquired.isEmpty()) return "changed-native-id";
                return stable.identity(path);
            };
            requireException(IOException.class,
                () -> WindowsBazelStreams.open(fixture.calls, changing, fixture.stdout, fixture.stderr));
            requireThat(fixture.calls.destinations.isEmpty(), "noCreateAfterSubstitution").isTrue();
            requireThat(fixture.calls.closed, "changedAncestorPinRetired")
                .isEqualTo(fixture.calls.acquired.reversed());
        }
    }

    /**
     * A binding disposal failure remains sticky without replaying handles or binding disposal.
     * @throws IOException if fixture setup or acquisition fails
     */
    @Test
    public void bindingDisposalFailureRemainsSticky() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            WindowsBazelStreams streams = fixture.open();
            fixture.calls.failBindingClose = true;
            IOException first = requireException(IOException.class, streams::close);
            requireThat(requireException(IOException.class, streams::close), "sameBindingFailure").isEqualTo(first);
            requireThat(fixture.calls.bindingCloses, "bindingEffectNotRepeated").isEqualTo(1);
            requireThat(fixture.calls.closed, "handleEffectsNotRepeated")
                .isEqualTo(fixture.calls.acquired.reversed());
            requireThat(streams.isClosed(), "bindingUncertaintyRetainsOwner").isFalse();
        }
    }

    /**
     * Invalid destination relationships are rejected before any native or filesystem acquisition.
     * @throws IOException if fixture setup fails
     */
    @Test
    public void invalidDestinationsHaveNoAcquisitionEffects() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            BazelNativeBackend.FileIdentity identity = BazelBackendCredentials.nativeIdentity(fixture.scope);
            requireException(IllegalArgumentException.class,
                () -> WindowsBazelStreams.open(fixture.calls, identity, fixture.stdout, fixture.stdout));
            requireException(IllegalArgumentException.class,
                () -> WindowsBazelStreams.open(fixture.calls, identity, Path.of("relative-output"), fixture.stderr));
            requireThat(fixture.calls.acquired.isEmpty(), "noNativeAcquisitionForInvalidPaths").isTrue();
            requireThat(fixture.calls.destinations.isEmpty(), "noFileCreationForInvalidPaths").isTrue();
            requireThat(fixture.calls.bindingCloses, "invalidCallsDoNotTransferOwnership").isEqualTo(0);
        }
    }

    /**
     * An unchecked native invocation failure remains an unresolved cleanup cause across later close calls.
     * @throws IOException if fixture setup or acquisition fails
     */
    @Test
    public void uncheckedCloseFailureCannotBecomeSuccessfulCleanup() throws IOException
    {
        try (Fixture fixture = new Fixture())
        {
            WindowsBazelStreams streams = fixture.open();
            fixture.calls.failedClose = streams.stderr().address();
            fixture.calls.uncheckedCloseFailure = new IllegalStateException("Controlled uncertain native invocation");
            IOException first = requireException(IOException.class, streams::close);
            requireThat(first.getCause(), "uncheckedInvocationCausePreserved")
                .isEqualTo(fixture.calls.uncheckedCloseFailure);
            requireThat(requireException(IOException.class, streams::close), "uncheckedFailureRemainsSticky")
                .isEqualTo(first);
            requireThat(fixture.calls.closed, "uncheckedCloseEffectsNotReplayed")
                .isEqualTo(fixture.calls.acquired.reversed());
            requireThat(fixture.calls.bindingCloses, "bindingsRetainedForUncheckedUncertainty").isEqualTo(0);
        }
    }

    /**
     * Owns one method's files, Pouch services and controlled native operations.
     */
    private static final class Fixture implements AutoCloseable
    {
        /** Method-local Pouch services used by the actual shared identity reader. */
        private final DefaultToolingScope scope = new DefaultToolingScope();
        /** Root removed by this fixture after every test result. */
        private final Path root;
        /** Exact requested worker output destination. */
        private final Path stdout;
        /** Exact requested worker error destination. */
        private final Path stderr;
        /** Method-local native operation result controller. */
        private final Calls calls = new Calls();

        /**
         * Creates method-owned files and services without any shared mutable fixture.
         * @throws IOException if the fixture root cannot be created
         */
        private Fixture() throws IOException
        {
            try { this.root = Files.createTempDirectory("windows-bazel-streams-test-").toAbsolutePath(); }
            catch (IOException | RuntimeException | Error failure) { scope.close(); throw failure; }
            this.stdout = root.resolve("stdout.bin");
            this.stderr = root.resolve("stderr.bin");
        }

        /**
         * Runs production acquisition using actual shared file identities and controlled HANDLE results.
         * @return owned production stream owner
         * @throws IOException if acquisition fails
         */
        private WindowsBazelStreams open() throws IOException
        {
            return WindowsBazelStreams.open(calls, BazelBackendCredentials.nativeIdentity(scope), stdout, stderr);
        }

        @Override public void close() throws IOException
        {
            try (Stream<Path> paths = Files.walk(root))
            {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
            }
            finally { scope.close(); }
        }
    }

    /**
     * Supplies documented Win32 success/error results so tests can inspect production ownership decisions.
     * CREATE_NEW is represented by Files.createFile; the fixture does not claim native sharing or HANDLE I/O.
     * Failed CloseHandle results model the documented zero result and make no claim about OS handle state.
     */
    private static final class Calls implements WindowsBazelStreams.Calls
    {
        /** Successful simulated native acquisitions in their actual production request order. */
        private final List<Long> acquired = new ArrayList<>();
        /** CloseHandle requests issued by production, including failed requests. */
        private final List<Long> closed = new ArrayList<>();
        /** Exact paths passed to output creation. */
        private final List<Path> destinations = new ArrayList<>();
        /** Original native handles passed to reset. */
        private final List<Long> resets = new ArrayList<>();
        /** Native value whose CloseHandle request reports failure, or zero for no failure. */
        private long failedClose;
        /** Unchecked native invocation failure for failedClose, or null for a checked Win32 result. */
        private RuntimeException uncheckedCloseFailure;
        /** Native value whose reset request reports failure, or zero for no failure. */
        private long failedReset;
        /** Indicates whether every CloseHandle request reports failure. */
        private boolean failEveryClose;
        /** Indicates whether binding disposal reports failure. */
        private boolean failBindingClose;
        /** Number of binding disposal requests. */
        private int bindingCloses;

        /**
         * Creates a resource-free operation controller owned by one test method.
         */
        private Calls() {}

        /**
         * Allocates a distinct synthetic native value for a successful acquisition.
         * @return valid nonzero simulated HANDLE
         */
        private MemorySegment acquire()
        {
            long value = acquired.size() + 100L;
            acquired.add(value);
            return MemorySegment.ofAddress(value);
        }

        @Override public MemorySegment pinDirectory(Path directory) { return acquire(); }

        @Override public MemorySegment create(Path destination) throws IOException
        {
            destinations.add(destination);
            Files.createFile(destination);
            return acquire();
        }

        @Override public MemorySegment openNull() { return acquire(); }

        @Override public void reset(MemorySegment handle) throws IOException
        {
            resets.add(handle.address());
            if (handle.address() == failedReset) throw new IOException("Controlled reset failure");
        }

        @Override public void closeHandle(MemorySegment handle) throws IOException
        {
            closed.add(handle.address());
            if (handle.address() == failedClose && uncheckedCloseFailure != null) throw uncheckedCloseFailure;
            if (failEveryClose || handle.address() == failedClose)
                throw new IOException("Controlled CloseHandle failure: " + handle.address());
        }

        @Override public void close() throws IOException
        {
            ++bindingCloses;
            if (failBindingClose) throw new IOException("Controlled binding disposal failure");
        }
    }
}
