package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.IOException;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Owns allocation instrumentation for authenticated images of one Bazel action.
 * The native workload retains image release and whole-workload terminal authority.
 */
final class MacBazelInstrumentation implements MacImages.InstrumentationFactory
{
    /** Borrowed scoped serialization services. */
    private final ToolingScope scope;
    /** Unique attempt correlation shared by its image installations. */
    private final UUID identity;
    /** Original manager borrowed through terminal hook disposal. */
    private final FridaRuntime.Manager manager;
    /** Native image and original terminal authority. */
    private final MacWorkloadNative.Owner nativeOwner;
    /** Allocation batches consumed by the existing controller. */
    private final AllocationWaits waits;
    /** Positive readiness and grant acknowledgement bound. */
    private final Duration timeout;
    /** Fair invocation-wide service while an installation awaits acknowledgement. */
    private final AllocationHook.Pump peers;
    /** Every issued image remains retained through exact detached or whole-workload disposal. */
    private final Map<Long, Image> images = new LinkedHashMap<>();
    /** Highest installation ordinal issued by this owner. */
    private long generation;
    /** Whether grants and new installations have been withdrawn. */
    private boolean stopped;

    /**
     * Retains resource-free borrowed action services without acquiring a hook.
     * @param scope shared scoped services
     * @param identity unique attempt identity
     * @param manager original active manager
     * @param nativeOwner exact native workload authority
     * @param waits native allocation batches
     * @param timeout positive acknowledgement bound
     * @param peers fair owner-thread frame service
     */
    MacBazelInstrumentation(ToolingScope scope, UUID identity, FridaRuntime.Manager manager,
        MacWorkloadNative.Owner nativeOwner, AllocationWaits waits, Duration timeout, AllocationHook.Pump peers)
    {
        this.scope = Objects.requireNonNull(scope, "scope");
        this.identity = Objects.requireNonNull(identity, "identity");
        this.manager = Objects.requireNonNull(manager, "manager");
        this.nativeOwner = Objects.requireNonNull(nativeOwner, "nativeOwner");
        this.waits = Objects.requireNonNull(waits, "waits");
        this.timeout = LinuxAttempts.checkedTimeout(timeout);
        this.peers = Objects.requireNonNull(peers, "peers");
    }

    @Override public MacImages.Instrumentation create(MacImages.Identity image)
    {
        if (stopped) throw new IllegalStateException("Action instrumentation has stopped");
        long selected = Math.incrementExact(generation);
        Image owner = new Image(Objects.requireNonNull(image, "image"), selected);
        images.put(selected, owner);
        generation = selected;
        return owner;
    }

    /**
     * Services copied frames without releasing images or granting allocation permission.
     * @throws IOException if an active hook reports a genuine protocol failure
     */
    void pump() throws IOException
    {
        for (Image image : images.values())
            if (image.allocation != null && !stopped && !image.retired) image.allocation.pump();
    }

    /**
     * Copies genuine reports, including reports from retired image installations.
     * @return immutable installation-order denial history
     */
    List<AllocationHook.Denial> denials()
    {
        return images.values().stream().filter(image -> image.allocation != null)
            .flatMap(image -> image.allocation.denials().stream()).toList();
    }

    /**
     * Grants exactly one selected native batch through its retained installation.
     * @param wait original wait correlation
     * @throws IOException if permission authority is absent or acknowledgement fails
     */
    void grant(AllocationWaits.Wait wait) throws IOException
    {
        Image image = images.get(wait.installation());
        if (stopped || image == null || image.retired || image.allocation == null)
            throw new IOException("Allocation wait has no active Bazel image");
        image.allocation.grant(wait, peers);
    }

    /** Withdraws continuation authority without waking blocked native allocators. */
    void stop()
    {
        stopped = true;
        waits.stop();
        for (Image image : images.values())
            if (image.allocation != null) image.allocation.stop();
    }

    /** Retains partial native hook ownership before each fallible installation step. */
    private final class Image implements MacImages.Instrumentation
    {
        /** Authenticated held image incarnation. */
        private final MacImages.Identity image;
        /** Never-reused installation ordinal. */
        private final long installation;
        /** Partial or active allocation hook. */
        private AllocationHook allocation;
        /** Whether hook start consumed its opportunity. */
        private boolean attempted;
        /** Whether exact detached hook disposal completed. */
        private boolean retired;

        /**
         * Binds an authenticated image without native acquisition.
         * @param image exact image incarnation
         * @param installation fresh installation ordinal
         */
        private Image(MacImages.Identity image, long installation)
        {
            this.image = image;
            this.installation = installation;
        }

        @Override public void start() throws IOException
        {
            if (attempted || stopped) throw new IllegalStateException("Image hooks start once");
            attempted = true;
            nativeOwner.authority(image);
            allocation = new AllocationHook(scope, identity, installation, image.pid(), manager,
                waits, MacCargoInstrumentation.program(), timeout);
            allocation.start();
            allocation.awaitReady(peers);
            nativeOwner.authority(image);
        }

        @Override public boolean detached() throws IOException
        {
            return !retired && allocation != null && allocation.detached();
        }

        @Override public void closeDetached() throws IOException
        {
            if (retired) return;
            if (!detached()) throw new IOException("Exact instrumentation detachment is unproven");
            allocation.closeDetached();
            retired = true;
        }

        @Override public void close() throws IOException
        {
            if (allocation != null) allocation.close(() -> nativeOwner.terminalResult().isPresent());
        }
    }
}
