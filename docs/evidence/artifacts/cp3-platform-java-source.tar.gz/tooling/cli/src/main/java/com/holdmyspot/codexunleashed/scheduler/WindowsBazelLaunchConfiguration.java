package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.Sha256;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;

/**
 * Retains exact schema-one Windows Bazel launch inputs before native acquisition.
 * Native target and backend executable validation belong to the common backend consumer. The caller supplies memory,
 * concurrency, workspace and scratch policy through scheduler settings. This document grants no Cargo wrapper or
 * jobserver authority; action security is established by the native restricted-token composition.
 * @param source absolute normalized profile file
 * @param sourceDigest SHA-256 of the exact parsed document
 * @param distribution native backend directory authenticated by the common consumer
 * @param bazel pinned native Bazel executable
 * @param toolchainRoot complete pinned native action toolchain directory
 * @param environment exact complete Bazel client environment
 * @param identities exact lowercase SHA-256 identities for bazel, toolchain, frida and javaRuntime; optional launcher pins its complete image
 * @param backendIdentity nonblank trusted backend/toolchain content domain
 * @param casBytes backend CAS capacity in bytes, at least 64 MiB
 * @param actionCacheBytes backend action-cache capacity in bytes, at least 64 MiB
 * @param cachePolicy explicit ordinary or recovery cache policy
 */
record WindowsBazelLaunchConfiguration(Path source, String sourceDigest, Path distribution, Path bazel,
    Path toolchainRoot, Map<String, String> environment, Map<String, String> identities, String backendIdentity,
    long casBytes, long actionCacheBytes, BazelNativeBackend.CachePolicy cachePolicy)
{
    /** Exact required schema-one fields; no implicit security or cache policy is selected from missing fields. */
    private static final Set<String> FIELDS = Set.of("schema", "distribution", "bazel", "toolchainRoot",
        "environment", "identities", "backendIdentity", "casBytes", "actionCacheBytes", "cachePolicy");
    /** Required determining byte identities in addition to the common backend manifest. */
    private static final Set<String> IDENTITIES = Set.of("bazel", "toolchain", "frida", "javaRuntime");

    /**
     * Freezes explicit inputs without opening files or acquiring native execution authority.
     * @param source absolute normalized profile
     * @param sourceDigest exact parsed profile digest
     * @param distribution native backend directory
     * @param bazel pinned native executable
     * @param toolchainRoot complete action toolchain directory
     * @param environment complete client environment, copied with Windows case uniqueness validation
     * @param identities complete exact determining byte digests
     * @param backendIdentity explicit content domain
     * @param casBytes CAS capacity in bytes, at least 64 MiB
     * @param actionCacheBytes action-cache capacity in bytes, at least 64 MiB
     * @param cachePolicy explicit cache behavior
     * @throws NullPointerException if a required input or collection member is null
     * @throws IllegalArgumentException if a path, digest, environment, domain or capacity is invalid
     */
    WindowsBazelLaunchConfiguration
    {
        for (Path path : List.of(source, distribution, bazel, toolchainRoot)) absolute(path);
        digestText(sourceDigest);
        Objects.requireNonNull(backendIdentity, "backendIdentity");
        if (backendIdentity.isBlank() || backendIdentity.indexOf(0) >= 0)
            throw new IllegalArgumentException("Backend content domain must contain text without NUL");
        if (casBytes < 67108864 || actionCacheBytes < 67108864)
            throw new IllegalArgumentException("Backend capacities must each be at least 64 MiB");
        environment = environment(environment);
        identities = Map.copyOf(identities);
        if (!identities.keySet().containsAll(IDENTITIES) ||
            !Set.of("bazel", "toolchain", "frida", "javaRuntime", "launcher").containsAll(identities.keySet()))
            throw new IllegalArgumentException("Windows Bazel identities require " + IDENTITIES + " and permit launcher");
        identities.values().forEach(WindowsBazelLaunchConfiguration::digestText);
        Objects.requireNonNull(cachePolicy, "cachePolicy");
    }

    /**
     * Reads an unchanged bounded regular profile with current-host no-follow native file identity.
     * @param scope borrowed strict parser and native linker services
     * @param source absolute normalized profile
     * @return exact immutable launch inputs requiring native authorization before execution
     * @throws IOException if original file identity, byte bounds or profile validation fails
     */
    static WindowsBazelLaunchConfiguration read(WindowsBazelScope scope, Path source) throws IOException
    {
        return decode(scope, source, bytes(scope, source));
    }

    /**
     * Decodes strict JSON using exact field presence, integral number types and string values.
     * @param scope borrowed invocation parser
     * @param source represented absolute normalized document
     * @param bytes exact complete document, between one byte and one MiB
     * @return resource-free copied launch configuration
     * @throws IOException if JSON, fields, values or bounds are invalid
     */
    static WindowsBazelLaunchConfiguration decode(WindowsBazelScope scope, Path source, byte[] bytes) throws IOException
    {
        if (bytes.length == 0 || bytes.length > 1048576)
            throw new IOException("Bazel profile must contain between one byte and one MiB");
        try
        {
            JsonNode root = scope.json().readTree(bytes);
            if (root == null || !root.isObject()) throw new IOException("Bazel profile must be an object");
            Set<String> fields = new HashSet<>();
            root.propertyNames().forEach(fields::add);
            if (!fields.equals(FIELDS)) throw new IOException("Bazel profile fields must be exactly " + FIELDS);
            JsonNode schema = root.path("schema");
            if (!schema.isIntegralNumber() || !schema.canConvertToInt() || schema.intValue() != 1)
                throw new IOException("Windows Bazel profile schema must be the integer 1");
            return new WindowsBazelLaunchConfiguration(source, digest(bytes), path(root, "distribution"),
                path(root, "bazel"), path(root, "toolchainRoot"), strings(root.path("environment")),
                strings(root.path("identities")), text(root, "backendIdentity"), capacity(root, "casBytes"),
                capacity(root, "actionCacheBytes"), BazelNativeBackend.CachePolicy.valueOf(text(root, "cachePolicy")));
        }
        catch (JacksonException | IllegalArgumentException invalid)
        {
            throw new IOException("Invalid Windows Bazel profile: " + invalid.getMessage(), invalid);
        }
    }

    /**
     * Verifies unchanged profile and exact native Bazel, instrumentation and running module-image bytes.
     * Complete toolchain rows use the existing cross-platform pinned-toolchain format; every entry is authenticated
     * with the shared actual native identity before and after hashing.
     * @param scope retained parser/native identity services
     * @param frida explicit native instrumentation library
     * @param javaRuntime actual running installed module image
     * @throws IOException if any original input is indirect, replaced or differs from its pinned bytes
     */
    void requireIdentities(WindowsBazelScope scope, Path frida, Path javaRuntime) throws IOException
    {
        if (!digest(bytes(scope, source)).equals(sourceDigest)) throw new IOException("Windows Bazel profile changed after parsing");
        BazelNativeBackend.FileIdentity authority = BazelBackendCredentials.nativeIdentity(scope.tooling());
        for (Map.Entry<String, Path> entry : Map.of("bazel", bazel, "frida", frida, "javaRuntime", javaRuntime).entrySet())
        {
            Path file = entry.getValue();
            Object before = authority.identity(file);
            if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS) || !Sha256.digest(file).equals(identities.get(entry.getKey())) ||
                !before.equals(authority.identity(file)))
                throw new IOException("Pinned Windows Bazel input differs: " + entry.getKey());
        }
        requireTree(authority, toolchainRoot, "toolchain");
    }

    /**
     * Authenticates every file and native object in the installed launcher image before a release consumer uses it.
     * @param scope retained native identity services
     * @param image absolute complete packaged application image
     * @throws IOException if its explicit identity is absent, its bytes differ or a native object changes during hashing
     */
    void requireLauncher(WindowsBazelScope scope, Path image) throws IOException
    {
        if (!identities.containsKey("launcher"))
            throw new IOException("An explicit release consumer requires the complete installed launcher identity");
        requireTree(BazelBackendCredentials.nativeIdentity(scope.tooling()), image, "launcher");
    }

    /**
     * Verifies complete content and stable native identities using the existing pinned-toolchain tree format.
     * @param authority shared native no-follow identity authority
     * @param root complete tree root
     * @param name declared determining identity
     * @throws IOException if the content, entry set or native objects differ
     */
    private void requireTree(BazelNativeBackend.FileIdentity authority, Path root, String name) throws IOException
    {
        Map<Path, Object> original = new HashMap<>();
        try (var entries = Files.walk(root))
        {
            for (Path entry : entries.toList()) original.put(entry, authority.identity(entry));
        }
        if (!LinuxCargoLaunchConfiguration.toolchainDigest(root).equals(identities.get(name)))
            throw new IOException("Complete pinned Windows Bazel input differs: " + name);
        try (var entries = Files.walk(root))
        {
            List<Path> current = entries.toList();
            if (!original.keySet().equals(Set.copyOf(current)))
                throw new IOException("Pinned Windows Bazel entry set changed: " + name);
            for (Path entry : current)
                if (!original.get(entry).equals(authority.identity(entry)))
                    throw new IOException("Pinned Windows Bazel entry was replaced: " + entry);
        }
    }

    /**
     * Copies a complete Windows environment while rejecting case aliases and loader-owned options.
     * @param environment exact caller entries
     * @return immutable case-unique entries retaining original spelling and explicit empty values
     * @throws NullPointerException if an entry is null
     * @throws IllegalArgumentException if a name/value is invalid or authorizes a Java launcher override
     */
    private static Map<String, String> environment(Map<String, String> environment)
    {
        Map<String, String> result = Map.copyOf(environment);
        Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (Map.Entry<String, String> entry : result.entrySet())
        {
            String name = entry.getKey();
            boolean driveDirectory = name.length() == 3 && name.charAt(0) == '=' && Character.isLetter(name.charAt(1)) && name.charAt(2) == ':';
            boolean malformed = name.isEmpty() || name.indexOf(0) >= 0 || (name.indexOf('=') >= 0 && !driveDirectory);
            if (malformed || entry.getValue().indexOf(0) >= 0 || !names.add(name))
                throw new IllegalArgumentException("Invalid or case-conflicting Windows environment entry: " + name);
            if (Set.of("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS").contains(name.toUpperCase(Locale.ROOT)))
                throw new IllegalArgumentException("Environment entry overrides the sealed Java launcher: " + name);
        }
        return result;
    }

    /**
     * Reads a direct regular profile while checking actual native object identity before and after the bounded read.
     * @param scope borrowed native identity services
     * @param source absolute normalized profile
     * @return exact original bytes
     * @throws IOException if the file is indirect, oversized, empty or changes during reading
     */
    private static byte[] bytes(WindowsBazelScope scope, Path source) throws IOException
    {
        absolute(source);
        BazelNativeBackend.FileIdentity authority = BazelBackendCredentials.nativeIdentity(scope.tooling());
        Object identity = authority.identity(source);
        BasicFileAttributes before = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (!before.isRegularFile() || before.size() == 0 || before.size() > 1048576)
            throw new IOException("Bazel profile must be a regular file between one byte and one MiB");
        byte[] result;
        try (InputStream input = Files.newInputStream(source, LinkOption.NOFOLLOW_LINKS))
        {
            result = input.readNBytes(1048577);
        }
        BasicFileAttributes after = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (!identity.equals(authority.identity(source)) || before.size() != after.size() ||
            !before.lastModifiedTime().equals(after.lastModifiedTime()) || result.length != before.size())
            throw new IOException("Windows Bazel profile changed while reading");
        return result;
    }

    /**
     * Reads one exact string without coercion.
     * @param root containing JSON object
     * @param field required string member
     * @return unchanged text
     * @throws IOException if the member has another type
     */
    private static String text(JsonNode root, String field) throws IOException
    {
        JsonNode value = root.path(field);
        if (!value.isString()) throw new IOException("Bazel profile requires a string: " + field);
        return value.stringValue();
    }

    /**
     * Reads one native absolute normalized path.
     * @param root containing object
     * @param field required pathname member
     * @return validated native path
     * @throws IOException if the member is not a string
     */
    private static Path path(JsonNode root, String field) throws IOException
    {
        Path path = Path.of(text(root, field));
        absolute(path);
        return path;
    }

    /**
     * Reads a string-only object without changing key spelling or empty values.
     * @param node required JSON object
     * @return copied exact entries
     * @throws IOException if the value is not an object of strings
     */
    private static Map<String, String> strings(JsonNode node) throws IOException
    {
        if (!node.isObject()) throw new IOException("Bazel profile requires a string object");
        Map<String, String> result = new HashMap<>();
        for (String name : node.propertyNames()) result.put(name, text(node, name));
        return result;
    }

    /**
     * Reads an explicit signed-long backend capacity of at least 64 MiB.
     * @param root containing object
     * @param field capacity member
     * @return exact byte capacity
     * @throws IOException if number type, signed range or minimum is invalid
     */
    private static long capacity(JsonNode root, String field) throws IOException
    {
        JsonNode value = root.path(field);
        if (!value.isIntegralNumber() || !value.canConvertToLong() || value.longValue() < 67108864)
            throw new IOException("Bazel profile requires an integral capacity of at least 64 MiB: " + field);
        return value.longValue();
    }

    /**
     * Validates an absolute normalized native path before acquiring an external resource.
     * @param path caller path
     * @throws NullPointerException if {@code path} is null
     * @throws IllegalArgumentException if the path is relative or unnormalized
     */
    private static void absolute(Path path)
    {
        Objects.requireNonNull(path, "path");
        if (!path.isAbsolute() || !path.equals(path.normalize()))
            throw new IllegalArgumentException("Windows Bazel paths must be absolute and normalized");
    }

    /**
     * Validates exact lowercase SHA-256 text.
     * @param value required digest
     * @throws NullPointerException if {@code value} is null
     * @throws IllegalArgumentException if length, case or hexadecimal digits are invalid
     */
    private static void digestText(String value)
    {
        Objects.requireNonNull(value, "value");
        if (value.length() != 64 || !value.equals(value.toLowerCase(Locale.ROOT)))
            throw new IllegalArgumentException("Lowercase SHA-256 identity required");
        HexFormat.of().parseHex(value);
    }

    /**
     * Computes exact profile byte identity using the mandatory JDK SHA-256 provider.
     * @param bytes original profile bytes
     * @return lowercase SHA-256
     */
    private static String digest(byte[] bytes)
    {
        try { return HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(bytes)); }
        catch (java.security.NoSuchAlgorithmException impossible) { throw new AssertionError("JDK requires SHA-256", impossible); }
    }
}
