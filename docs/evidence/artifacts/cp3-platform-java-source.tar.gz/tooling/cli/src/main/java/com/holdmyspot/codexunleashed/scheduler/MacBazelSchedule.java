package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.IOException;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.ValueLayout;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

/** Runs the installed macOS Bazel backend and authenticated action coordinator with caller-owned scopes. */
final class MacBazelSchedule
{
    /** Prevents construction of the installed composition boundary. */
    private MacBazelSchedule() {}

    /**
     * Runs one native Mac Bazel invocation after host and administrator authority validation.
     * Arguments are passed directly to pinned Bazel; an explicit absolute consumer executable may instead use the
     * invocation-owned CODEX_BAZEL_BIN hook for a release script. Caller scopes and standard streams remain borrowed.
     * Small durable event receipts remain under the explicitly supplied scratch root after native state is retired.
     * @param tooling original caller Pouch scope retained through native destruction
     * @param settings explicit memory, workspace, scratch and argument policy
     * @param launchConfiguration explicit administrator schema-one authorization
     * @return genuine original whole-consumer exit code
     * @throws IOException if configuration, native execution or owned cleanup fails
     * @throws Scheduler.PendingCleanup if original native authority remains; retain and close on the original thread
     */
    static int run(ToolingScope tooling, Scheduler.Settings settings, Path launchConfiguration) throws IOException
    {
        requireHost();
        if (!settings.tool().equals("bazel")) throw new IOException("Mac Bazel composition requires the Bazel tool");
        MacCargoScope scope = new MacCargoScope(tooling);
        MacBazelInvocation invocation = null;
        Path namespace = null;
        Throwable primary = null;
        try
        {
            var authorization = MacBazelLaunchConfiguration.read(scope, launchConfiguration);
            var installed = MacBazelLaunchConfiguration.installed(Path.of(System.getProperty("java.home")), settings.fridaLibrary());
            if (nativeId(tooling, "getuid") != 0 || nativeId(tooling, "geteuid") != 0)
                throw new IOException("Mac Bazel native controller requires actual root credentials");
            authorization.requireTrusted(installed);
            MacCargoLaunchConfiguration.requireRootControlled(settings.scratch());
            MacCargoLaunchConfiguration.requireWorkloadTraversal(settings.scratch(), authorization.gid());
            if (!Files.isDirectory(settings.scratch(), LinkOption.NOFOLLOW_LINKS))
                throw new IOException("Mac Bazel scratch must be an existing trusted directory");
            requirePathBudget(settings.scratch());
            Path history = settings.scratch().resolve("bazel-memory-history");
            if (!Files.exists(history, LinkOption.NOFOLLOW_LINKS))
                Files.createDirectory(history, PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rwx------")));
            MacCargoLaunchConfiguration.requireRootControlled(history);
            namespace = Files.createTempDirectory(settings.scratch(), "mb-",
                PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rwx------")));
            invocation = new MacBazelInvocation(tooling, scope, settings, authorization, installed, namespace, history);
            invocation.start();
            MacBazelInvocation retained = invocation;
            return new SchedulerCoordinator<>(invocation, settings.budget(), MacBazelSchedule::pause, retained::record).run();
        }
        catch (IOException | RuntimeException | Error failure)
        {
            primary = failure;
            throw failure;
        }
        finally
        {
            try
            {
                if (invocation != null) invocation.close();
                if (namespace != null) retireNamespace(namespace);
                scope.close();
            }
            catch (IOException | RuntimeException | Error cleanup)
            {
                Throwable failure = primary == null ? cleanup : primary;
                if (failure != cleanup) failure.addSuppressed(cleanup);
                MacBazelInvocation retained = invocation;
                Path retainedNamespace = namespace;
                throw new Scheduler.PendingCleanup(failure, () ->
                {
                    if (retained != null) retained.close();
                    if (retained != null && !retained.isClosed()) throw new IOException("Original Mac Bazel native cleanup remains retained");
                    if (retainedNamespace != null) retireNamespace(retainedNamespace);
                    scope.close();
                });
            }
        }
    }

    /**
     * Rejects foreign platforms before scopes, native functions or temporary resources are acquired.
     * @throws IOException if actual host is not one of the two supported native Mac targets
     */
    static void requireHost() throws IOException
    {
        String os = System.getProperty("os.name");
        if (!os.equals("Mac OS X")) throw new IOException("Mac Bazel scheduling requires actual native macOS");
        BazelNativeBackend.NativeTarget target = BazelNativeBackend.NativeTarget.forHost(os, System.getProperty("os.arch"));
        if (target != BazelNativeBackend.NativeTarget.MACOS_ARM64 && target != BazelNativeBackend.NativeTarget.MACOS_X64)
            throw new IOException("Unsupported native Mac Bazel target");
    }

    /**
     * Checks the longest generated native state pathname before acquiring a namespace.
     * @param scratch absolute trusted scratch parent
     * @throws IOException if generated original native socket paths would exceed the existing 90-byte state bound
     */
    static void requirePathBudget(Path scratch) throws IOException
    {
        int generatedSuffixBytes = 1 + 3 + 20 + 1 + 7 + 1 + 7 + 20;
        if (scratch.toString().getBytes(StandardCharsets.UTF_8).length + generatedSuffixBytes > 90)
            throw new IOException("Mac Bazel scratch is too long for original native control socket paths");
    }

    /**
     * Preserves the small event receipt then removes only a completely retired invocation namespace.
     * Native callers must already have collected all daemons, original consumer, action descendants and open streams.
     * @param namespace exclusive invocation tree whose native owners all acknowledged close
     * @throws IOException if receipt publication or exclusive namespace removal fails
     */
    private static void retireNamespace(Path namespace) throws IOException
    {
        if (!Files.exists(namespace, LinkOption.NOFOLLOW_LINKS)) return;
        Path receipt = namespace.resolve("events.jsonl");
        if (Files.exists(receipt, LinkOption.NOFOLLOW_LINKS))
            Files.move(receipt, namespace.resolveSibling(namespace.getFileName() + "-events.jsonl"));
        try (Stream<Path> paths = Files.walk(namespace))
        {
            for (Path path : paths.sorted(Comparator.reverseOrder()).toList())
            {
                if (Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS))
                {
                    Set<PosixFilePermission> permissions = new HashSet<>(Files.getPosixFilePermissions(path));
                    permissions.add(PosixFilePermission.OWNER_WRITE);
                    permissions.add(PosixFilePermission.OWNER_EXECUTE);
                    Files.setPosixFilePermissions(path, permissions);
                }
                Files.delete(path);
            }
        }
    }

    /**
     * Reads real controller credentials through the caller's borrowed native linker.
     * @param tooling original scoped native services
     * @param operation fixed getuid or geteuid symbol
     * @return actual kernel user ID
     * @throws IOException if native credentials cannot be read
     */
    // Darwin uid_t uses the verified 32-bit return ABI; this fixed downcall needs the caller's explicit native grant.
    @SuppressWarnings("restricted")
    private static int nativeId(ToolingScope tooling, String operation) throws IOException
    {
        var linker = tooling.getNativeLinker();
        var function = linker.downcallHandle(linker.defaultLookup().find(operation).orElseThrow(),
            FunctionDescriptor.of(ValueLayout.JAVA_INT));
        try { return (int) function.invokeExact(); }
        catch (Throwable failure) { throw new IOException("Cannot read actual Mac controller credentials", failure); }
    }

    /**
     * Waits one bounded coordinator idle interval without discarding interruption.
     * @throws InterruptedException if the controlling thread was interrupted
     */
    private static void pause() throws InterruptedException { Thread.sleep(1); }
}
