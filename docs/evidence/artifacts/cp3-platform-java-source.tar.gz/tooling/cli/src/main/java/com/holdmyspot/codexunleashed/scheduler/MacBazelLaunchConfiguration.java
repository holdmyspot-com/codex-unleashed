package com.holdmyspot.codexunleashed.scheduler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import tools.jackson.databind.JsonNode;

/**
 * Retains a bounded administrator-owned schema-one macOS Bazel launch authorization.
 * Parsing acquires no native resources. Current administrator namespace, byte identities and the common backend
 * distribution validator must all succeed before native launch. Scheduler settings retain memory and scratch policy.
 * @param source absolute authorization document
 * @param sourceDigest exact parsed document SHA-256
 * @param uid positive action user ID
 * @param gid positive action group ID, with no supplementary groups
 * @param distribution native backend distribution validated by the common consumer
 * @param bazel exact pinned Bazel executable
 * @param toolchainRoot complete immutable action toolchain root
 * @param environment complete authorized Bazel client environment
 * @param identities exact runtime and tool identities
 * @param backendIdentity explicit backend/toolchain content domain, combined with determining bytes by the consumer
 * @param casBytes explicit backend CAS capacity
 * @param actionCacheBytes explicit backend action-cache capacity
 * @param cachePolicy explicit ordinary or recovery cache behavior
 */
record MacBazelLaunchConfiguration(Path source, String sourceDigest, int uid, int gid, Path distribution,
    Path bazel, Path toolchainRoot, Map<String, String> environment, Map<String, String> identities,
    String backendIdentity, long casBytes, long actionCacheBytes, BazelNativeBackend.CachePolicy cachePolicy)
{
    /** Exact schema-one fields, without optional implicit policy. */
    private static final Set<String> FIELDS = Set.of("schema", "uid", "gid", "supplementaryGroups", "distribution",
        "bazel", "toolchainRoot", "environment", "identities", "backendIdentity", "casBytes", "actionCacheBytes", "cachePolicy");
    /** Actual installed determining byte identities in addition to the common backend manifest. */
    private static final Set<String> IDENTITIES = Set.of("bazel", "toolchain", "workload", "anchor", "frida", "javaRuntime");

    /**
     * Freezes validated primitive configuration without granting native launch authority.
     * @param source absolute administrator document
     * @param sourceDigest exact document digest
     * @param uid positive action user
     * @param gid positive action group
     * @param distribution common backend directory
     * @param bazel pinned Bazel executable
     * @param toolchainRoot complete pinned toolchain root
     * @param environment full client environment
     * @param identities complete actual byte identities
     * @param backendIdentity explicit content domain
     * @param casBytes explicit CAS capacity
     * @param actionCacheBytes explicit action-cache capacity
     * @param cachePolicy ordinary or recovery behavior
     */
    MacBazelLaunchConfiguration
    {
        for (Path path : List.of(source, distribution, bazel, toolchainRoot)) absolute(path);
        digestText(sourceDigest);
        if (uid <= 0 || gid <= 0 || casBytes < 67_108_864 || actionCacheBytes < 67_108_864)
            throw new IllegalArgumentException("Positive unprivileged action IDs and explicit supported capacities required");
        Objects.requireNonNull(backendIdentity, "backendIdentity");
        if (backendIdentity.isBlank() || backendIdentity.indexOf(0) >= 0)
            throw new IllegalArgumentException("Nonblank backend content domain required");
        environment = Map.copyOf(environment);
        environment.forEach((key, value) ->
        {
            if (key.isEmpty() || key.indexOf('=') >= 0 || key.indexOf(0) >= 0 || value.indexOf(0) >= 0 ||
                key.startsWith("DYLD_") || Set.of("LD_PRELOAD", "LD_LIBRARY_PATH", "JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS").contains(key))
                throw new IllegalArgumentException("Invalid or loader-authoritative client environment: " + key);
        });
        identities = Map.copyOf(identities);
        if (!identities.keySet().equals(IDENTITIES)) throw new IllegalArgumentException("Exact installed identities required: " + IDENTITIES);
        identities.values().forEach(MacBazelLaunchConfiguration::digestText);
        Objects.requireNonNull(cachePolicy, "cachePolicy");
    }

    /**
     * Reads an unchanged bounded regular administrator document through a borrowed strict Pouch parser.
     * @param scope scoped parser retained by the invocation
     * @param source absolute normalized document
     * @return resource-free values requiring current authority validation
     * @throws IOException if file identity, bounds or schema validation fails
     */
    static MacBazelLaunchConfiguration read(MacCargoScope scope, Path source) throws IOException
    {
        return decode(scope, source, bytes(source));
    }

    /**
     * Decodes strict schema-one JSON while preserving integer types and exact field presence.
     * @param scope borrowed bounded strict parser scope
     * @param source represented absolute document
     * @param bytes exact original document bytes
     * @return immutable resource-free authorization
     * @throws IOException if the document is malformed, ambiguous or semantically invalid
     */
    static MacBazelLaunchConfiguration decode(MacCargoScope scope, Path source, byte[] bytes) throws IOException
    {
        if (bytes.length == 0 || bytes.length > 1_048_576) throw new IOException("Bazel profile must contain at most one MiB");
        try
        {
            JsonNode root = scope.launchJson().readTree(bytes);
            Set<String> fields = new HashSet<>();
            if (root == null || !root.isObject()) throw new IOException("Bazel profile must be an object");
            root.propertyNames().forEach(fields::add);
            if (!fields.equals(FIELDS)) throw new IOException("Bazel profile fields must be exactly " + FIELDS);
            if (integer(root, "schema") != 1) throw new IOException("Unsupported macOS Bazel profile schema");
            JsonNode groups = root.path("supplementaryGroups");
            if (!groups.isArray() || !groups.isEmpty()) throw new IOException("supplementaryGroups must be an empty array");
            return new MacBazelLaunchConfiguration(source, digest(bytes), integer(root, "uid"), integer(root, "gid"),
                path(root, "distribution"), path(root, "bazel"), path(root, "toolchainRoot"),
                strings(root.path("environment")), strings(root.path("identities")), text(root, "backendIdentity"),
                capacity(root, "casBytes"), capacity(root, "actionCacheBytes"),
                BazelNativeBackend.CachePolicy.valueOf(text(root, "cachePolicy")));
        }
        catch (tools.jackson.core.JacksonException | IllegalArgumentException invalid)
        {
            throw new IOException("Invalid macOS Bazel authorization", invalid);
        }
    }

    /**
     * Revalidates exact administrator document, tools, complete toolchain and actual installed runtime bytes.
     * Common backend target, pins and executable identities remain exclusively validated by the common consumer.
     * @param installed actual runtime products resolved from the running installed Java runtime
     * @throws IOException if any namespace, access mode or determining byte identity differs
     */
    void requireTrusted(Installed installed) throws IOException
    {
        MacCargoLaunchConfiguration.requireRootControlled(source);
        if (((int) Files.getAttribute(source, "unix:mode", LinkOption.NOFOLLOW_LINKS) & 0222) != 0 ||
            !digest(bytes(source)).equals(sourceDigest))
            throw new IOException("Administrator Bazel profile changed or has write permission bits");
        Map<String, Path> files = new HashMap<>(installed.files());
        files.put("bazel", bazel);
        for (Map.Entry<String, Path> entry : files.entrySet())
        {
            Path path = entry.getValue();
            MacCargoLaunchConfiguration.requireRootControlled(path);
            if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS) || !fileDigest(path).equals(identities.get(entry.getKey())))
                throw new IOException("Pinned macOS Bazel input differs: " + entry.getKey());
        }
        for (Path executable : List.of(bazel, installed.anchor()))
        {
            if (!Files.isExecutable(executable)) throw new IOException("Required installed tool is not executable: " + executable);
            MacCargoLaunchConfiguration.requireWorkloadTraversal(executable.getParent(), gid);
        }
        MacCargoLaunchConfiguration.requireRootControlled(toolchainRoot);
        try (var entries = Files.walk(toolchainRoot))
        {
            for (Path entry : entries.toList())
            {
                if (Files.isSymbolicLink(entry))
                {
                    if (!Integer.valueOf(0).equals(Files.getAttribute(entry, "unix:uid", LinkOption.NOFOLLOW_LINKS)))
                        throw new IOException("Toolchain symlink must be administrator-owned: " + entry);
                    MacCargoLaunchConfiguration.requireRootControlled(entry.toRealPath());
                }
                else MacCargoLaunchConfiguration.requireRootControlled(entry);
            }
        }
        if (!MacCargoLaunchConfiguration.toolchainDigest(toolchainRoot).equals(identities.get("toolchain")))
            throw new IOException("Complete pinned macOS Bazel toolchain differs");
    }

    /**
     * Resolves products solely from the actual installed runtime and explicit Frida producer.
     * @param runtime actual java.home
     * @param frida explicit absolute instrumentation library
     * @return actual installed native paths
     * @throws IOException if runtime resolution fails
     */
    static Installed installed(Path runtime, Path frida) throws IOException
    {
        absolute(runtime);
        absolute(frida);
        Path home = runtime.toRealPath();
        return new Installed(home.resolve("lib/codex/libmac-workload.dylib"), home.resolve("bin/codex-workload-anchor"),
            frida, home.resolve("lib/modules"));
    }

    /**
     * Actual installed runtime files, independent of profile-provided lookup roots.
     * @param workload original native workload bridge
     * @param anchor original nonforking anchor
     * @param frida explicit instrumentation producer
     * @param javaRuntime actual installed module image
     */
    record Installed(Path workload, Path anchor, Path frida, Path javaRuntime)
    {
        /**
         * Validates absolute installed paths without acquiring native state.
         * @param workload native bridge
         * @param anchor native anchor
         * @param frida explicit producer
         * @param javaRuntime actual module image
         */
        Installed
        {
            for (Path path : List.of(workload, anchor, frida, javaRuntime)) absolute(path);
        }

        /**
         * Maps actual files to their sole profile identity keys.
         * @return immutable actual runtime paths
         */
        Map<String, Path> files()
        {
            return Map.of("workload", workload, "anchor", anchor, "frida", frida, "javaRuntime", javaRuntime);
        }
    }

    /**
     * Reads a bounded original regular document without following its final entry.
     * @param source absolute normalized document
     * @return exact bytes
     * @throws IOException if type, size or original identity changes
     */
    private static byte[] bytes(Path source) throws IOException
    {
        absolute(source);
        BasicFileAttributes before = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (!before.isRegularFile() || before.size() == 0 || before.size() > 1_048_576 || before.fileKey() == null)
            throw new IOException("Bazel profile must be a bounded regular file with stable identity");
        byte[] result;
        try (var input = Files.newByteChannel(source, Set.of(java.nio.file.StandardOpenOption.READ, LinkOption.NOFOLLOW_LINKS)))
        {
            var output = new java.io.ByteArrayOutputStream();
            var buffer = java.nio.ByteBuffer.allocate(8192);
            while (input.read(buffer) >= 0)
            {
                buffer.flip();
                output.write(buffer.array(), 0, buffer.remaining());
                buffer.clear();
                if (output.size() > 1_048_576) throw new IOException("Bazel profile exceeded its byte bound");
            }
            result = output.toByteArray();
        }
        BasicFileAttributes after = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (!before.fileKey().equals(after.fileKey()) || before.size() != after.size() ||
            !before.lastModifiedTime().equals(after.lastModifiedTime()) || result.length != before.size())
            throw new IOException("Bazel profile changed during read");
        return result;
    }

    /**
     * Reads one exact integer without string or floating-point coercion.
     * @param root containing object
     * @param field required field
     * @return exact integer
     * @throws IOException if the field has another type or range
     */
    private static int integer(JsonNode root, String field) throws IOException
    {
        JsonNode value = root.path(field);
        if (!value.isIntegralNumber() || !value.canConvertToInt()) throw new IOException("Exact integer required: " + field);
        return value.intValue();
    }

    /**
     * Reads an explicit supported backend capacity.
     * @param root containing object
     * @param field required capacity field
     * @return capacity of at least 64 MiB
     * @throws IOException if type, range or minimum differs
     */
    private static long capacity(JsonNode root, String field) throws IOException
    {
        JsonNode value = root.path(field);
        if (!value.isIntegralNumber() || !value.canConvertToLong() || value.longValue() < 67_108_864)
            throw new IOException("Explicit supported capacity required: " + field);
        return value.longValue();
    }

    /**
     * Reads an exact string field.
     * @param root containing object
     * @param field required field
     * @return exact string
     * @throws IOException if the value has another type
     */
    private static String text(JsonNode root, String field) throws IOException
    {
        JsonNode value = root.path(field);
        if (!value.isString()) throw new IOException("String required: " + field);
        return value.stringValue();
    }

    /**
     * Reads one normalized absolute path field.
     * @param root containing object
     * @param field required path field
     * @return exact absolute normalized path
     * @throws IOException if the field is not a string
     */
    private static Path path(JsonNode root, String field) throws IOException
    {
        Path value = Path.of(text(root, field));
        absolute(value);
        return value;
    }

    /**
     * Copies a string-only object without value coercion.
     * @param node required object
     * @return immutable exact entries
     * @throws IOException if any member has another type
     */
    private static Map<String, String> strings(JsonNode node) throws IOException
    {
        if (!node.isObject()) throw new IOException("String object required");
        Map<String, String> result = new HashMap<>();
        for (String name : node.propertyNames()) result.put(name, text(node, name));
        return Map.copyOf(result);
    }

    /**
     * Computes a required regular file's complete byte identity.
     * @param path determining file
     * @return lowercase SHA-256
     * @throws IOException if the file cannot be read
     */
    private static String fileDigest(Path path) throws IOException
    {
        MessageDigest hash = sha256();
        try (var input = Files.newInputStream(path, LinkOption.NOFOLLOW_LINKS))
        {
            byte[] buffer = new byte[65536];
            int count;
            while ((count = input.read(buffer)) >= 0) hash.update(buffer, 0, count);
        }
        return HexFormat.of().formatHex(hash.digest());
    }

    /**
     * Computes exact document identity.
     * @param bytes original bytes
     * @return lowercase SHA-256
     */
    private static String digest(byte[] bytes) { return HexFormat.of().formatHex(sha256().digest(bytes)); }

    /**
     * Acquires the mandatory JDK SHA-256 provider.
     * @return fresh digest state
     */
    private static MessageDigest sha256()
    {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException impossible) { throw new AssertionError("JDK requires SHA-256", impossible); }
    }

    /**
     * Validates lowercase SHA-256 text.
     * @param value supplied identity
     */
    private static void digestText(String value)
    {
        Objects.requireNonNull(value, "value");
        if (value.length() != 64 || !value.equals(value.toLowerCase(java.util.Locale.ROOT)))
            throw new IllegalArgumentException("Lowercase SHA-256 identity required");
        HexFormat.of().parseHex(value);
    }

    /**
     * Validates normalized absolute caller paths.
     * @param path supplied path
     */
    private static void absolute(Path path)
    {
        Objects.requireNonNull(path, "path");
        if (!path.isAbsolute() || !path.equals(path.normalize())) throw new IllegalArgumentException("Absolute normalized path required");
    }
}
