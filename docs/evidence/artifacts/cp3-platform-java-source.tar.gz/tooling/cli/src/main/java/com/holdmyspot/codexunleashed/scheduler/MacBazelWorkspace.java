package com.holdmyspot.codexunleashed.scheduler;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.SecureDirectoryStream;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Restores complete pristine Bazel action trees at their original worker-visible paths on macOS.
 * The invocation serializes each authenticated root and keeps private storage inaccessible to action identities.
 * All native descendants, instrumentation and borrowed streams must be collected before lease finalization.
 * This owner never infers a native terminal barrier from filesystem state.
 */
final class MacBazelWorkspace implements BazelWorkspace
{
    /** Borrowed original action input pathname. */
    private final Path inputPath;
    /** Borrowed original temporary pathname. */
    private final Path temporaryPath;
    /** Fresh private storage, outside both borrowed trees. */
    private final Path storage;
    /** Independent pristine input snapshot. */
    private final Path snapshot;
    /** Independent pristine temporary snapshot. */
    private final Path temporarySnapshot;
    /** Original input descriptor retained through all retry leases. */
    private final SecureDirectoryStream<Path> input;
    /** Original temporary descriptor retained through all retry leases. */
    private final SecureDirectoryStream<Path> temporary;
    /** Stable original input directory identity. */
    private final Object inputKey;
    /** Stable original temporary directory identity. */
    private final Object temporaryKey;
    /** Original input root numeric identity and complete mode, restored after a failed attempt. */
    private final Map<String, Object> inputMetadata;
    /** Original temporary root numeric identity and complete mode, restored after a failed attempt. */
    private final Map<String, Object> temporaryMetadata;
    /** Constructing coordinator thread. */
    private final Thread thread = Thread.currentThread();
    /** Every reserved ordinal, including failed preparations. */
    private final Set<Long> sequences = new HashSet<>();
    /** Outstanding execution or recovery lease. */
    private Lease active;
    /** Whether storage and original descriptors have closed. */
    private boolean closed;
    /** Explicit action UID, or negative when preserving portable fixture ownership. */
    private int workloadUid = -1;
    /** Explicit action primary GID when action ownership is enabled. */
    private int workloadGid;

    /**
     * Retains acquired descriptors while the factory creates independent snapshots.
     * @param inputPath borrowed original input path
     * @param temporaryPath borrowed original temporary path
     * @param storage fresh private storage
     * @param input acquired input descriptor
     * @param temporary acquired temporary descriptor
     * @throws IOException if stable original identities cannot be read
     */
    private MacBazelWorkspace(Path inputPath, Path temporaryPath, Path storage,
        SecureDirectoryStream<Path> input, SecureDirectoryStream<Path> temporary) throws IOException
    {
        this.inputPath = inputPath;
        this.temporaryPath = temporaryPath;
        this.storage = storage;
        this.snapshot = storage.resolve("inputs");
        this.temporarySnapshot = storage.resolve("temporary");
        this.input = input;
        this.temporary = temporary;
        this.inputKey = key(input);
        this.temporaryKey = key(temporary);
        this.inputMetadata = Map.copyOf(Files.readAttributes(inputPath, "unix:uid,gid,mode", LinkOption.NOFOLLOW_LINKS));
        this.temporaryMetadata = Map.copyOf(Files.readAttributes(temporaryPath, "unix:uid,gid,mode", LinkOption.NOFOLLOW_LINKS));
    }

    /**
     * Pins original roots and independently copies every regular input, including read-only cache hardlinks.
     * Literal symlinks, executable modes and hardlink equivalence within each tree are preserved.
     * The caller authenticates the trusted parent of the absent storage path and excludes concurrent root writers.
     * @param inputPath absolute normalized authenticated input directory
     * @param temporaryPath absolute normalized authenticated temporary directory
     * @param storage absolute normalized absent private storage directory
     * @return retained pristine snapshots and original root descriptors
     * @throws IOException if acquisition, copying or stable root validation fails
     * @throws IllegalArgumentException if paths are relative, unnormalized or overlap
     */
    static MacBazelWorkspace open(Path inputPath, Path temporaryPath, Path storage) throws IOException
    {
        absolute(inputPath);
        absolute(temporaryPath);
        absolute(storage);
        if (overlaps(inputPath, temporaryPath) || overlaps(inputPath, storage) || overlaps(temporaryPath, storage))
            throw new IllegalArgumentException("Input, temporary and private trees must be disjoint");
        try (SecureDirectoryStream<Path> parent = directory(storage.getParent()))
        {
            Objects.requireNonNull(parent);
            privateDirectory(storage);
        }
        SecureDirectoryStream<Path> input = null;
        SecureDirectoryStream<Path> temporary = null;
        try
        {
            input = directory(inputPath);
            temporary = directory(temporaryPath);
            if (!Files.getFileStore(inputPath).equals(Files.getFileStore(storage)) ||
                !Files.getFileStore(temporaryPath).equals(Files.getFileStore(storage)))
                throw new IOException("Same-path staging requires a common filesystem");
            MacBazelWorkspace owner = new MacBazelWorkspace(inputPath, temporaryPath, storage, input, temporary);
            copy(inputPath, owner.snapshot, new HashMap<>());
            copy(temporaryPath, owner.temporarySnapshot, new HashMap<>());
            owner.requireAttached();
            return owner;
        }
        catch (IOException | RuntimeException | Error failure)
        {
            if (temporary != null)
                try { temporary.close(); } catch (IOException cleanup) { failure.addSuppressed(cleanup); }
            if (input != null)
                try { input.close(); } catch (IOException cleanup) { failure.addSuppressed(cleanup); }
            try { remove(storage); } catch (IOException cleanup) { failure.addSuppressed(cleanup); }
            throw failure;
        }
    }

    /**
     * Pins pristine trees and assigns only fresh execution materializations to the configured action identity.
     * Private snapshots and original worker-cache inodes retain their original ownership and permissions.
     * @param inputPath original authenticated input root
     * @param temporaryPath original authenticated temporary root
     * @param storage absent private snapshot storage
     * @param uid positive authorized action UID
     * @param gid positive authorized action primary GID
     * @return retained original roots and independently owned action materializations
     * @throws IOException if acquisition or snapshot preparation fails
     * @throws IllegalArgumentException if an identity is privileged or paths are invalid
     */
    static MacBazelWorkspace open(Path inputPath, Path temporaryPath, Path storage, int uid, int gid) throws IOException
    {
        if (uid <= 0 || gid <= 0) throw new IllegalArgumentException("Action ownership requires positive UID and GID");
        MacBazelWorkspace owner = open(inputPath, temporaryPath, storage);
        owner.workloadUid = uid;
        owner.workloadGid = gid;
        return owner;
    }

    @Override public Path immutableSnapshot()
    {
        requireThread();
        if (closed) throw new IllegalStateException("Workspace is closed");
        return snapshot;
    }

    @Override public Attempt begin(long sequence) throws IOException
    {
        requireThread();
        if (closed || active != null) throw new IllegalStateException("Workspace has an outstanding lease or is closed");
        if (sequence < 0 || !sequences.add(sequence))
            throw new IllegalArgumentException("Attempt ordinal must be nonnegative and never reused");
        requireAttached();
        active = new Lease(sequence);
        active.restore();
        if (workloadUid > 0)
        {
            actionOwnership(inputPath);
            actionOwnership(temporaryPath);
            requireAttached();
        }
        active.issued = true;
        return active;
    }

    /**
     * Grants the action ownership of independently copied entries without changing executable or read-only modes.
     * Every link is handled without following it; stable original roots are checked around the whole transition.
     * @param root original action-visible root after independent replacement
     * @throws IOException if an entry changes or numeric POSIX ownership cannot be established
     */
    private void actionOwnership(Path root) throws IOException
    {
        try (var entries = Files.walk(root))
        {
            for (Path entry : entries.toList())
            {
                Object before = Files.readAttributes(entry, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS).fileKey();
                if (before == null) throw new IOException("Materialized action entry lacks stable identity");
                Files.setAttribute(entry, "unix:gid", workloadGid, LinkOption.NOFOLLOW_LINKS);
                Files.setAttribute(entry, "unix:uid", workloadUid, LinkOption.NOFOLLOW_LINKS);
                if (!before.equals(Files.readAttributes(entry, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS).fileKey()))
                    throw new IOException("Materialized action entry changed during ownership grant");
            }
        }
    }

    @Override public void close() throws IOException
    {
        requireThread();
        if (closed) return;
        if (active != null && !active.issued) active.discard();
        if (active != null) throw new IOException("Workspace retains an unresolved native/storage lease");
        remove(storage);
        input.close();
        temporary.close();
        closed = true;
    }

    /**
     * Confirms both pinned objects still occupy their original no-follow paths.
     * @throws IOException if either root or an ancestor was replaced
     */
    private void requireAttached() throws IOException
    {
        try (SecureDirectoryStream<Path> currentInput = directory(inputPath);
            SecureDirectoryStream<Path> currentTemporary = directory(temporaryPath))
        {
            if (!inputKey.equals(key(currentInput)) || !temporaryKey.equals(key(currentTemporary)))
                throw new IOException("Authenticated Bazel root was replaced");
        }
    }

    /** Retains restoration authority until publication acceptance or successful discard. */
    private final class Lease implements Attempt
    {
        /** Never-reused queue ordinal for stage naming. */
        private final long sequence;
        /** Whether final tree validation completed. */
        private boolean frozen;
        /** Whether this lease retired successfully. */
        private boolean resolved;
        /** Whether begin returned this lease to a caller that may have acquired a native workload. */
        private boolean issued;

        /**
         * Reserves recovery ownership before any original-tree mutation.
         * @param sequence nonnegative fresh attempt ordinal
         */
        private Lease(long sequence) { this.sequence = sequence; }

        @Override public void freeze() throws IOException
        {
            requireActive();
            if (frozen) throw new IllegalStateException("Lease is already frozen");
            requireAttached();
            validate(inputPath);
            validate(temporaryPath);
            requireAttached();
            frozen = true;
        }

        @Override public void accept()
        {
            requireActive();
            if (!frozen) throw new IllegalStateException("Only frozen final state can be accepted");
            resolved = true;
            active = null;
        }

        @Override public void discard() throws IOException
        {
            requireActive();
            restore();
            resolved = true;
            active = null;
        }

        /**
         * Prepares complete independent stages before replacing either original tree's entries.
         * A failure retains this lease and pristine snapshots for explicit recovery.
         * @throws IOException if preparation, original identity or restoration fails
         */
        private void restore() throws IOException
        {
            requireAttached();
            Path stage = storage.resolve("attempt-" + sequence);
            remove(stage);
            privateDirectory(stage);
            Path inputStage = stage.resolve("inputs");
            Path temporaryStage = stage.resolve("temporary");
            copy(snapshot, inputStage, new HashMap<>());
            copy(temporarySnapshot, temporaryStage, new HashMap<>());
            requireAttached();
            replace(input, inputStage);
            replace(temporary, temporaryStage);
            if (workloadUid > 0)
            {
                restoreRootMetadata(inputPath, inputMetadata);
                restoreRootMetadata(temporaryPath, temporaryMetadata);
            }
            requireAttached();
            remove(stage);
            frozen = false;
        }

        /** Rejects cross-thread, stale or resolved lease control. */
        private void requireActive()
        {
            requireThread();
            if (resolved || active != this || closed) throw new IllegalStateException("Lease is no longer active");
        }
    }

    /**
     * Restores original root ownership and complete permission bits without replacing its pinned directory object.
     * @param root original authenticated root with no live native users
     * @param metadata original numeric owner, primary group and mode
     * @throws IOException if original metadata cannot be restored
     */
    private static void restoreRootMetadata(Path root, Map<String, Object> metadata) throws IOException
    {
        for (String name : List.of("gid", "uid", "mode"))
            Files.setAttribute(root, "unix:" + name, metadata.get(name), LinkOption.NOFOLLOW_LINKS);
    }

    /**
     * Replaces entries under the retained original directory without replacing the directory itself.
     * @param original pinned original directory
     * @param stage complete independently copied stage
     * @throws IOException if any removal or same-filesystem move fails
     */
    private static void replace(SecureDirectoryStream<Path> original, Path stage) throws IOException
    {
        for (Path name : names(original)) removeEntry(original, name);
        try (SecureDirectoryStream<Path> prepared = directory(stage))
        {
            for (Path name : names(prepared)) prepared.move(name, original, name);
        }
    }

    /**
     * Independently copies one stable entry while retaining required within-tree hardlink equivalence.
     * No destination regular inode is linked to the source or an earlier execution materialization.
     * @param source complete stable source entry
     * @param destination absent destination entry
     * @param links source file identities mapped only to newly created destination inodes
     * @throws IOException if unsupported entry types, identity churn or copying prevent a complete snapshot
     */
    private static void copy(Path source, Path destination, Map<Object, Path> links) throws IOException
    {
        BasicFileAttributes before = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (before.fileKey() == null) throw new IOException("Workspace requires stable file identities");
        if (before.isSymbolicLink()) Files.createSymbolicLink(destination, Files.readSymbolicLink(source));
        else if (before.isDirectory())
        {
            privateDirectory(destination);
            try (DirectoryStream<Path> children = Files.newDirectoryStream(source))
            {
                for (Path child : children) copy(child, destination.resolve(child.getFileName()), links);
            }
            var attributes = Files.getFileAttributeView(source, PosixFileAttributeView.class, LinkOption.NOFOLLOW_LINKS)
                .readAttributes();
            PosixFileAttributeView target = Files.getFileAttributeView(destination, PosixFileAttributeView.class,
                LinkOption.NOFOLLOW_LINKS);
            target.setGroup(attributes.group());
            target.setOwner(attributes.owner());
            target.setPermissions(attributes.permissions());
            Files.getFileAttributeView(destination, BasicFileAttributeView.class, LinkOption.NOFOLLOW_LINKS)
                .setTimes(attributes.lastModifiedTime(), attributes.lastAccessTime(), null);
        }
        else if (before.isRegularFile())
        {
            Path prior = links.get(before.fileKey());
            if (prior == null)
            {
                Files.copy(source, destination, LinkOption.NOFOLLOW_LINKS, StandardCopyOption.COPY_ATTRIBUTES);
                links.put(before.fileKey(), destination);
            }
            else Files.createLink(destination, prior);
        }
        else throw new IOException("Unsupported Bazel tree entry: " + source);
        BasicFileAttributes after = Files.readAttributes(source, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        if (!before.fileKey().equals(after.fileKey()) || before.size() != after.size() ||
            !before.lastModifiedTime().equals(after.lastModifiedTime()))
            throw new IOException("Bazel tree changed during independent materialization: " + source);
    }

    /**
     * Rejects special files in the final tree without following literal symlinks.
     * @param root stable final action root after whole-native zero
     * @throws IOException if an unsupported entry is present
     */
    private static void validate(Path root) throws IOException
    {
        try (SecureDirectoryStream<Path> directory = directory(root))
        {
            validate(directory);
        }
    }

    /**
     * Validates descendants using pinned parent-relative no-follow operations.
     * @param parent pinned final directory
     * @throws IOException if a descendant is unsupported or inaccessible
     */
    private static void validate(SecureDirectoryStream<Path> parent) throws IOException
    {
        for (Path name : names(parent))
        {
            BasicFileAttributes attributes = parent.getFileAttributeView(name, BasicFileAttributeView.class,
                LinkOption.NOFOLLOW_LINKS).readAttributes();
            if (attributes.isDirectory())
                try (SecureDirectoryStream<Path> child = parent.newDirectoryStream(name, LinkOption.NOFOLLOW_LINKS))
                {
                    validate(child);
                }
            else if (!attributes.isRegularFile() && !attributes.isSymbolicLink())
                throw new IOException("Final Bazel tree contains an unsupported entry: " + name);
        }
    }

    /**
     * Opens an absolute directory while refusing symlinks in every ancestor.
     * @param path absolute normalized directory
     * @return owned secure directory descriptor
     * @throws IOException if acquisition or an ancestor check fails
     */
    private static SecureDirectoryStream<Path> directory(Path path) throws IOException
    {
        DirectoryStream<Path> root = Files.newDirectoryStream(path.getRoot());
        if (!(root instanceof SecureDirectoryStream<Path> secure))
        {
            root.close();
            throw new IOException("Bazel same-path ownership requires secure directory streams");
        }
        SecureDirectoryStream<Path> current = secure;
        try
        {
            for (Path name : path)
            {
                SecureDirectoryStream<Path> next = current.newDirectoryStream(name, LinkOption.NOFOLLOW_LINKS);
                current.close();
                current = next;
            }
            return current;
        }
        catch (IOException | RuntimeException | Error failure)
        {
            try { current.close(); } catch (IOException cleanup) { failure.addSuppressed(cleanup); }
            throw failure;
        }
    }

    /**
     * Reads stable directory object authority from its retained descriptor.
     * @param directory acquired directory
     * @return nonnull stable file key
     * @throws IOException if the filesystem cannot supply stable identity
     */
    private static Object key(SecureDirectoryStream<Path> directory) throws IOException
    {
        Object value = directory.getFileAttributeView(BasicFileAttributeView.class).readAttributes().fileKey();
        if (value == null) throw new IOException("Bazel roots require stable directory identities");
        return value;
    }

    /**
     * Copies immediate entry names before mutating a directory.
     * @param directory retained parent descriptor
     * @return independent relative names
     * @throws IOException if a fresh descriptor-relative enumeration cannot be acquired
     */
    private static List<Path> names(SecureDirectoryStream<Path> directory) throws IOException
    {
        List<Path> result = new ArrayList<>();
        try (SecureDirectoryStream<Path> enumeration = directory.newDirectoryStream(Path.of("."), LinkOption.NOFOLLOW_LINKS))
        {
            for (Path entry : enumeration) result.add(entry.getFileName());
        }
        return result;
    }

    /**
     * Removes an entry without following contained symlinks, restoring owner write access only for disposal.
     * @param parent retained parent descriptor
     * @param name immediate relative name
     * @throws IOException if complete removal cannot be established
     */
    private static void removeEntry(SecureDirectoryStream<Path> parent, Path name) throws IOException
    {
        BasicFileAttributes attributes = parent.getFileAttributeView(name, BasicFileAttributeView.class,
            LinkOption.NOFOLLOW_LINKS).readAttributes();
        if (attributes.isDirectory())
        {
            PosixFileAttributeView view = parent.getFileAttributeView(name, PosixFileAttributeView.class,
                LinkOption.NOFOLLOW_LINKS);
            Set<PosixFilePermission> permissions = new HashSet<>(view.readAttributes().permissions());
            permissions.add(PosixFilePermission.OWNER_WRITE);
            permissions.add(PosixFilePermission.OWNER_EXECUTE);
            permissions.add(PosixFilePermission.OWNER_READ);
            view.setPermissions(permissions);
            try (SecureDirectoryStream<Path> child = parent.newDirectoryStream(name, LinkOption.NOFOLLOW_LINKS))
            {
                for (Path entry : names(child)) removeEntry(child, entry);
            }
            parent.deleteDirectory(name);
        }
        else parent.deleteFile(name);
    }

    /**
     * Removes one private owned tree using no-follow parent authority.
     * @param root independently owned root, possibly absent after a failed creation
     * @throws IOException if disposal remains incomplete
     */
    private static void remove(Path root) throws IOException
    {
        if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) return;
        try (SecureDirectoryStream<Path> parent = directory(root.getParent()))
        {
            removeEntry(parent, root.getFileName());
        }
    }

    /**
     * Creates an administrative directory inaccessible to workload identities.
     * @param path absent owned directory
     * @throws IOException if private creation fails
     */
    private static void privateDirectory(Path path) throws IOException
    {
        Files.createDirectory(path, PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rwx------")));
    }

    /**
     * Validates one normalized absolute boundary.
     * @param path caller-selected filesystem root
     */
    private static void absolute(Path path)
    {
        Objects.requireNonNull(path, "path");
        if (!path.isAbsolute() || !path.equals(path.normalize()))
            throw new IllegalArgumentException("Workspace paths must be absolute and normalized");
    }

    /**
     * Determines whether two roots overlap.
     * @param first first root
     * @param second second root
     * @return whether either root contains the other
     */
    private static boolean overlaps(Path first, Path second)
    {
        return first.startsWith(second) || second.startsWith(first);
    }

    /** Rejects control outside the original coordinator thread. */
    private void requireThread()
    {
        if (Thread.currentThread() != thread) throw new IllegalStateException("Workspace belongs to its coordinator thread");
    }
}
