package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.OptionalLong;
import java.util.UUID;

/**
 * Retains one fresh native Bazel workload from held launch through original whole-workload collection.
 * The invocation retains borrowed stream descriptions and workspace rollback authority across retries.
 */
final class MacBazelAttempt implements JobQueue.Attempt<Integer>
{
    /** Invocation services retained through terminal native disposal. */
    private final Context context;
    /** Immutable authenticated action launch. */
    private final Command command;
    /** Original logical action identity retained across retries. */
    private final String name;
    /** Fresh queue-wide attempt ordinal. */
    private final long sequence;
    /** Coordinator thread retaining all native owners. */
    private final Thread thread = Thread.currentThread();
    /** Genuine native allocation batches for this attempt. */
    private final AllocationWaits waits = new AllocationWaits();
    /** First execution fault, independent of cleanup completion. */
    private final MacAttempt.Fault fault;
    /** Original manager retained before fallible start. */
    private FridaRuntime.Manager manager;
    /** Fresh native state directory retained through cleanup. */
    private Path scratch;
    /** Original partial or active native owner. */
    private MacWorkloadNative.Owner owner;
    /** Whether original held-root acquisition returned. */
    private boolean rootAcquired;
    /** Complete original workload and authenticated image authority. */
    private MacWorkload workload;
    /** Allocation-only image installations retained through native zero. */
    private MacBazelInstrumentation instrumentation;
    /** Whether exact native ownership is registered for measurement. */
    private boolean registered;
    /** Whether this attempt consumed its acquisition opportunity. */
    private boolean attempted;
    /** Whether start or grant control currently excludes wait publication. */
    private boolean controlling;
    /** Whether queue termination withdrew continuation authority. */
    private boolean stopping;
    /** Whether every native and private-state owner has closed. */
    private boolean closed;
    /** Genuine final result, available only after native and measurement retirement. */
    private JobQueue.Outcome<Integer> outcome;
    /** Exact original root authority captured before release. */
    private List<Long> rootAuthority = List.of();

    /**
     * Binds a resource-free native attempt before the invocation registers it with its retaining factory.
     * @param context borrowed invocation services
     * @param command authenticated exact argv, environment, working directory and streams
     * @param name nonblank original logical action identity
     * @param sequence nonnegative fresh attempt ordinal
     */
    MacBazelAttempt(Context context, Command command, String name, long sequence)
    {
        this.context = Objects.requireNonNull(context, "context");
        this.command = Objects.requireNonNull(command, "command");
        new MacMeasurements.Attempt(name, sequence);
        this.name = name;
        this.sequence = sequence;
        this.fault = new MacAttempt.Fault(name, sequence);
    }

    @Override public void start() throws IOException
    {
        requireThread();
        fault.requireCertain();
        if (attempted || stopping || closed) throw new IllegalStateException("Native Bazel attempt starts once");
        attempted = true;
        controlling = true;
        try
        {
            manager = context.runtime().newManager();
            manager.start();
            scratch = Files.createTempDirectory(context.directory(), "action-");
            var launch = new MacWorkloadNative.Launch(context.library(), context.helper(), scratch,
                command.directory(), command.streams(), command.arguments(), command.environment(), command.uid(), command.gid());
            owner = new MacWorkloadNative.Owner(context.scope(), launch, manager);
            MacImages.Identity root = owner.root();
            rootAcquired = true;
            rootAuthority = List.copyOf(owner.authority(root));
            context.measurements().register(new MacMeasurements.Attempt(name, sequence), owner);
            registered = true;
            instrumentation = new MacBazelInstrumentation(context.scope(), UUID.randomUUID(), manager, owner,
                waits, context.timeout(), context.peers());
            workload = new MacWorkload(context.scope(), owner, instrumentation, context.timeout());
            workload.start();
        }
        catch (IOException | RuntimeException cause) { throw fault.failed(cause); }
        finally { controlling = false; }
    }

    @Override public void resume(long waitSequence) throws IOException
    {
        requireThread();
        fault.requireCertain();
        if (instrumentation == null || controlling || stopping || closed)
            throw new IllegalStateException("Bazel attempt has no allocation continuation authority");
        controlling = true;
        try { waits.resume(waitSequence, instrumentation::grant); }
        catch (IOException | RuntimeException cause) { throw fault.failed(cause); }
        finally { controlling = false; }
    }

    @Override public void terminate() throws IOException
    {
        requireThread();
        if (controlling) throw new IllegalStateException("Queue control cannot reenter native acquisition or grant");
        stop();
        if (closed) return;
        try
        {
            if (workload != null) workload.cancel();
            else if (owner != null && rootAcquired) owner.cancel();
        }
        catch (IOException | RuntimeException cause) { throw fault.failed(cause); }
    }

    @Override public Optional<JobQueue.Outcome<Integer>> poll() throws IOException
    {
        requireThread();
        fault.requireCertain();
        if (controlling) throw new IllegalStateException("Queue polling cannot reenter native controls");
        if (outcome != null) return Optional.of(outcome);
        if (workload == null || closed) return Optional.empty();
        try
        {
            pump();
            OptionalInt result = workload.advance();
            if (result.isEmpty()) return Optional.empty();
            retireMeasurement();
            outcome = new JobQueue.Outcome<>(result.getAsInt(), stopping);
            return Optional.of(outcome);
        }
        catch (IOException | RuntimeException cause) { throw fault.failed(cause); }
    }

    /**
     * Services native frames without granting waits or releasing queued images.
     * @throws IOException if a native protocol fails
     */
    void pump() throws IOException
    {
        requireThread();
        fault.requireCertain();
        if (instrumentation != null && !stopping && !closed) instrumentation.pump();
    }

    /**
     * Publishes one authentic allocation batch outside acquisition and grant callbacks.
     * @return next original wait ordinal, or empty while inactive
     * @throws IOException if earlier permission effects remain uncertain
     */
    OptionalLong pollAllocationWait() throws IOException
    {
        requireThread();
        if (controlling || stopping || closed) return OptionalLong.empty();
        fault.requireCertain();
        return waits.poll();
    }

    /**
     * Copies observed native denial history without changing workload state.
     * @return immutable actual report history
     */
    List<AllocationHook.Denial> denials()
    {
        requireThread();
        return instrumentation == null ? List.of() : instrumentation.denials();
    }

    /**
     * Returns exact root authority captured while the original root was held.
     * @return immutable original image authority, empty before successful acquisition
     */
    List<Long> rootAuthority() { requireThread(); return rootAuthority; }

    /**
     * Indicates complete native, instrumentation, measurement and private-state retirement.
     * @return whether successful close completed
     */
    boolean isClosed() { requireThread(); return closed; }

    @Override public void close() throws IOException
    {
        requireThread();
        if (controlling) throw new IllegalStateException("Native cleanup cannot reenter start or grant");
        if (closed) return;
        stop();
        fault.cleanup(() ->
        {
            if (workload != null)
            {
                if (workload.completedResult().isEmpty()) workload.cancel();
                long began = System.nanoTime();
                while (workload.completedResult().isEmpty())
                {
                    try { workload.advance(); }
                    catch (IOException cause)
                    {
                        if (workload.completedResult().isEmpty()) throw cause;
                    }
                    if (System.nanoTime() - began >= context.timeout().toNanos())
                        throw new IOException("Bazel cleanup awaits original whole-workload collection");
                    if (workload.completedResult().isEmpty()) pause();
                }
            }
            else if (owner != null)
            {
                MacAttempt.collectPartial(rootAcquired, new MacAttempt.PartialOwner()
                {
                    @Override public void cancel() throws IOException { owner.cancel(); }
                    @Override public OptionalInt terminalResult() throws IOException { return owner.terminalResult(); }
                    @Override public void close() throws IOException { owner.close(); }
                }, context.timeout());
            }
            else if (manager != null) manager.close();
            retireMeasurement();
            if (scratch != null) Files.delete(scratch);
            closed = true;
        });
    }

    /** Withdraws hook permissions before requesting native cancellation. */
    private void stop()
    {
        stopping = true;
        waits.stop();
        if (instrumentation != null) instrumentation.stop();
    }

    /**
     * Removes only the exact registered owner after original native and instrumentation closure.
     * @throws IOException if native ownership remains open
     */
    private void retireMeasurement() throws IOException
    {
        if (owner != null && !owner.isClosed()) throw new IOException("Whole native owner must close before registry retirement");
        if (registered)
        {
            context.measurements().unregister(new MacMeasurements.Attempt(name, sequence), owner);
            registered = false;
        }
    }

    /**
     * Pauses bounded native collection while retaining interruption.
     * @throws IOException if interrupted
     */
    private static void pause() throws IOException
    {
        try { Thread.sleep(1); }
        catch (InterruptedException cause)
        {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while retaining Bazel cleanup ownership", cause);
        }
    }

    /** Rejects cross-thread native control. */
    private void requireThread()
    {
        if (Thread.currentThread() != thread) throw new IllegalStateException("Native attempt belongs to its coordinator thread");
    }

    /**
     * Borrows invocation-level native resources without acquiring them.
     * @param scope caller-owned scoped services
     * @param runtime original started runtime
     * @param measurements exact owner registry
     * @param library trusted absolute native bridge
     * @param helper trusted absolute anchor
     * @param directory short absolute attempt-state parent
     * @param timeout positive native acknowledgement and collection bound
     * @param peers fair invocation-wide frame service
     */
    record Context(ToolingScope scope, FridaRuntime runtime, MacMeasurements.NativeSource measurements,
        Path library, Path helper, Path directory, Duration timeout, AllocationHook.Pump peers)
    {
        /**
         * Validates borrowed services and absolute native paths.
         * @param scope caller-owned services
         * @param runtime original started runtime
         * @param measurements exact registry
         * @param library native bridge
         * @param helper native anchor
         * @param directory attempt-state parent
         * @param timeout positive bound
         * @param peers fair frame service
         */
        Context
        {
            Objects.requireNonNull(scope, "scope");
            Objects.requireNonNull(runtime, "runtime");
            Objects.requireNonNull(measurements, "measurements");
            Objects.requireNonNull(peers, "peers");
            for (Path path : List.of(library, helper, directory))
                if (!path.isAbsolute() || !path.equals(path.normalize()))
                    throw new IllegalArgumentException("Native paths must be absolute and normalized");
            timeout = LinuxAttempts.checkedTimeout(timeout);
        }
    }

    /**
     * Retains exact authenticated action inputs and invocation-owned borrowed stream descriptions.
     * @param arguments unchanged executable and argument strings
     * @param environment unchanged ordered NAME=value strings
     * @param directory original absolute working directory
     * @param streams original borrowed open-file descriptions
     * @param uid unprivileged authorized workload user
     * @param gid authorized primary workload group
     */
    record Command(List<String> arguments, List<String> environment, Path directory,
        MacWorkloadNative.Streams streams, int uid, int gid)
    {
        /**
         * Freezes authenticated launch fields before native acquisition.
         * @param arguments exact argv
         * @param environment exact environment
         * @param directory original working directory
         * @param streams borrowed original streams
         * @param uid authorized user
         * @param gid authorized group
         */
        Command
        {
            arguments = List.copyOf(arguments);
            environment = List.copyOf(environment);
            Objects.requireNonNull(directory, "directory");
            Objects.requireNonNull(streams, "streams");
            if (arguments.isEmpty() || arguments.getFirst().isEmpty() || !directory.isAbsolute() ||
                !directory.equals(directory.normalize()) || uid <= 0 || gid < 0)
                throw new IllegalArgumentException("Authorized unprivileged Bazel action and absolute cwd required");
        }
    }
}
