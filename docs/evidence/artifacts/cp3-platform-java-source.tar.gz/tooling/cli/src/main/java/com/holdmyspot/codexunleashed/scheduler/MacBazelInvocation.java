package com.holdmyspot.codexunleashed.scheduler;

import buildbarn.runner.RunnerOuterClass.RunRequest;
import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.OptionalLong;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * Composes the authenticated native macOS Bazel backend and same-path action retries on one coordinator thread.
 * Original RPC/path claims survive retries; the controller, backend daemons and original Bazel consumer remain outside
 * action memory-failure domains. Native workload closure precedes rollback, successful output acceptance and replies.
 */
final class MacBazelInvocation implements SchedulerCoordinator.Session<Integer>
{
    /** Borrowed original tooling services. */
    private final ToolingScope tooling;
    /** Borrowed scoped strict parser and original runtime owner. */
    private final MacCargoScope scope;
    /** Sole caller memory, workspace and control policy. */
    private final Scheduler.Settings settings;
    /** Validated administrator authorization. */
    private final MacBazelLaunchConfiguration authorization;
    /** Actual installed runtime products. */
    private final MacBazelLaunchConfiguration.Installed installed;
    /** Exclusive invocation namespace retained through terminal cleanup. */
    private final Path root;
    /** Worker-visible path fixed by the common backend declaration. */
    private final Path workerRoot;
    /** Private host-only snapshots and native state parent. */
    private final Path privateRoot;
    /** Constructing coordinator thread. */
    private final Thread thread = Thread.currentThread();
    /** Unique original invocation identity. */
    private final UUID identity = UUID.randomUUID();
    /** Original readiness completed only by the authenticated worker callback. */
    private final CompletableFuture<Void> workerReadiness = new CompletableFuture<>();
    /** Exact registry for native held action workloads. */
    private final MacMeasurements.NativeSource nativeMeasurements;
    /** Content-keyed successful memory history. */
    private final BazelMemoryEstimates estimates;
    /** Every discovered original action, retained through uncertain cleanup. */
    private final Map<String, Action> actions = new LinkedHashMap<>();
    /** Every original Go daemon retained before the next native acquisition. */
    private final List<Daemon> daemons = new ArrayList<>();
    /** Original scoped runtime lease. */
    private MacCargoScope.RuntimeLease runtimeLease;
    /** Common exact distribution identity. */
    private BazelNativeBackend.ValidatedDistribution distribution;
    /** Original authenticated Runner transport. */
    private BazelRunner<Admission> runner;
    /** Original common backend including partial acquisition. */
    private BazelNativeBackend backend;
    /** Original build-tool workload, independent of action retry domains. */
    private OuterWorkload original;
    /** Immutable Darwin stream functions shared by this invocation's original stream owners. */
    private Descriptors descriptors;
    /** Durable owner-thread event stream outside every action tree. */
    private BufferedWriter events;
    /** Whether native preparation consumed its opportunity. */
    private boolean attempted;
    /** Whether new action admission was withdrawn. */
    private boolean stopping;
    /** Whether a final empty Runner poll followed original Bazel completion. */
    private boolean drained;
    /** Genuine original Bazel consumer result after whole-workload collection. */
    private OptionalInt result = OptionalInt.empty();
    /** Whether every invocation dependency has closed. */
    private boolean closed;

    /**
     * Retains resource-free invocation configuration before any native acquisition.
     * @param tooling original borrowed services
     * @param scope original parser/runtime scope
     * @param settings caller-owned scheduler policy
     * @param authorization administrator launch authorization
     * @param installed actual installed native paths
     * @param root fresh protected invocation directory
     * @param history existing owned persistent history directory
     */
    MacBazelInvocation(ToolingScope tooling, MacCargoScope scope, Scheduler.Settings settings,
        MacBazelLaunchConfiguration authorization, MacBazelLaunchConfiguration.Installed installed,
        Path root, Path history)
    {
        this.tooling = Objects.requireNonNull(tooling, "tooling");
        this.scope = Objects.requireNonNull(scope, "scope");
        this.settings = Objects.requireNonNull(settings, "settings");
        this.authorization = Objects.requireNonNull(authorization, "authorization");
        this.installed = Objects.requireNonNull(installed, "installed");
        this.root = Objects.requireNonNull(root, "root");
        this.workerRoot = root.resolve("worker-builds");
        this.privateRoot = root.resolve("private");
        this.nativeMeasurements = new MacMeasurements.NativeSource(tooling);
        this.estimates = new BazelMemoryEstimates(new MacMeasurements(nativeMeasurements), new BazelMemoryHistory(history));
    }

    /**
     * Acquires the actual common backend, authenticated readiness and original consumer once.
     * Partial acquisition remains retained by this invocation for independent explicit cleanup.
     * @throws IOException if current determining inputs or native preparation fail
     */
    void start() throws IOException
    {
        requireThread();
        if (attempted || closed) throw new IllegalStateException("Mac Bazel invocation starts once");
        attempted = true;
        events = Files.newBufferedWriter(root.resolve("events.jsonl"), StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
        record("invocation", Map.of("identity", identity.toString(), "arguments", settings.arguments(),
            "workspace", settings.workspace().toString(), "sourceDigest", authorization.sourceDigest()));
        var protection = BazelBackendCredentials.nativeAuthority(tooling, root);
        protection.createDirectory(workerRoot);
        protection.createDirectory(privateRoot);
        distribution = BazelNativeBackend.validateDistribution(tooling,
            BazelNativeBackend.NativeTarget.forHost(System.getProperty("os.name"), System.getProperty("os.arch")),
            authorization.distribution(), protection);
        var credentials = BazelBackendCredentials.generate(root.resolve("credentials"),
            Path.of(System.getProperty("java.home"), "bin", "keytool"), protection);
        runner = new BazelRunner<>(new Boundary(), new BazelRunner.Credentials(credentials.certificateAuthority(),
            credentials.serverCertificate(), credentials.serverKey(), credentials.workerCertificate()));
        runner.start();
        descriptors = new Descriptors(tooling);
        var configuration = new BazelNativeBackend.Configuration(distribution, root, runner.endpoint(), credentials,
            settings.budget().jobs(), authorization.casBytes(), authorization.actionCacheBytes(), authorization.cachePolicy(),
            workerReadiness, this::closeActions);
        BazelNativeBackend.PlatformOwner platform = new BazelNativeBackend.PlatformOwner()
        {
            @Override public BazelBackendCredentials.Protection protection() { return protection; }
            @Override public BazelNativeBackend.WorkerIdentity workerIdentity()
            {
                return new BazelNativeBackend.PosixWorkerIdentity(authorization.uid(), authorization.gid());
            }
            @Override public BazelNativeBackend.Daemon launch(Path executable, Path configurationFile, Path log,
                Path workingDirectory, Map<String, String> environment) throws IOException
            {
                ProcessBuilder builder = new ProcessBuilder(executable.toString(), configurationFile.toString())
                    .directory(workingDirectory.toFile()).redirectErrorStream(true).redirectOutput(log.toFile());
                builder.environment().clear();
                builder.environment().putAll(authorization.environment());
                builder.environment().putAll(environment);
                Daemon daemon = new Daemon(builder.start(), settings.controlTimeout());
                daemons.add(daemon);
                return daemon;
            }
        };
        try { backend = BazelNativeBackend.start(tooling, configuration, platform); }
        catch (BazelNativeBackend.AcquisitionFailure failure) { backend = failure.backend(); throw failure; }
        // Private setup is complete. Only search permission is granted on these two ancestors; every credential,
        // cache and snapshot child stays owner-only, and no later private-authority creation is performed.
        for (Path directory : List.of(root, workerRoot))
        {
            Object originalKey = fileKey(directory);
            Files.setAttribute(directory, "unix:gid", authorization.gid(), LinkOption.NOFOLLOW_LINKS);
            Files.setPosixFilePermissions(directory, PosixFilePermissions.fromString("rwx--x---"));
            if (!originalKey.equals(fileKey(directory))) throw new IOException("Original backend ancestor changed during traversal grant");
        }
        record("authenticated-worker-ready", Map.of("workerRoot", workerRoot.toString(),
            "searchOnlyGroup", authorization.gid(), "manifest", distribution.manifestHash(),
            "rootKey", fileKey(root).toString(), "workerKey", fileKey(workerRoot).toString()));
        runtimeLease = scope.runtime(installed.frida());
        Map<String, String> environment = new HashMap<>(authorization.environment());
        Path launcher = LinuxBazelProducer.bazelLauncher(root.resolve("bazel"), authorization.bazel(), backend.startupRc());
        environment.put("CODEX_BAZEL_BIN", launcher.toString());
        List<String> command = consumerCommand(launcher);
        original = new OuterWorkload(runtimeLease.value(), command, environment);
        original.start();
    }

    /**
     * Preserves direct Bazel arguments and supports an explicit absolute release consumer using the existing hook.
     * @param launcher exact pinned Bazel wrapper with the common startup rc
     * @return executable and unchanged caller argument tail
     */
    private List<String> consumerCommand(Path launcher)
    {
        List<String> command = new ArrayList<>();
        List<String> arguments = settings.arguments();
        if (!arguments.isEmpty() && Path.of(arguments.getFirst()).isAbsolute()) command.addAll(arguments);
        else
        {
            command.add(launcher.toString());
            if (!arguments.isEmpty() && arguments.getFirst().equals("bazel")) command.addAll(arguments.subList(1, arguments.size()));
            else command.addAll(arguments);
        }
        return List.copyOf(command);
    }

    @Override public JobQueue.AttemptFactory<Integer> attempts()
    {
        requireThread();
        return (name, sequence) ->
        {
            Action action = actions.get(name);
            if (action == null || action.finished || !action.ready.publicationAllowed())
                throw new IllegalStateException("Original authenticated Bazel action has no execution authority");
            Attempt attempt = new Attempt(action, sequence);
            action.attempts.add(attempt);
            return attempt;
        };
    }

    @Override public Controller.Measurements measurements() { requireThread(); return estimates; }

    @Override public void pump() throws IOException
    {
        requireThread();
        backend.requireAlive();
        for (Action action : actions.values())
        {
            if (!action.finished && !action.ready.publicationAllowed())
                throw new IOException("Original Bazel action RPC cancelled; retain native cleanup before rollback");
            for (Attempt attempt : action.attempts)
                if (attempt.nativeAttempt != null && !attempt.closed) attempt.nativeAttempt.pump();
        }
        if (original != null && result.isEmpty()) result = original.advance();
        if (result.isPresent() && !stopping) stopAccepting();
    }

    @Override public Optional<SchedulerCoordinator.Submission> pollSubmission() throws IOException
    {
        requireThread();
        Optional<BazelRunner.Ready<Admission>> incoming = runner.poll();
        if (incoming.isEmpty())
        {
            if (result.isPresent()) drained = true;
            return Optional.empty();
        }
        BazelRunner.Ready<Admission> ready = incoming.orElseThrow();
        String name = identity + ":" + ready.sequence();
        Action action = new Action(name, ready);
        actions.put(name, action);
        action.acquire();
        return Optional.of(estimates.register(name, action.contentIdentity));
    }

    @Override public Optional<SchedulerCoordinator.Blocked> pollBlocked() throws IOException
    {
        requireThread();
        for (Action action : actions.values())
            for (Attempt attempt : action.attempts)
                if (attempt.nativeAttempt != null && !attempt.closed)
                {
                    OptionalLong wait = attempt.nativeAttempt.pollAllocationWait();
                    if (wait.isPresent())
                        return Optional.of(new SchedulerCoordinator.Blocked(action.name, attempt.sequence, wait.getAsLong()));
                }
        return Optional.empty();
    }

    @Override public void acceptOutcome(JobQueue.Completion<Integer> completion) throws IOException
    {
        requireThread();
        Action action = actions.get(completion.name());
        Attempt attempt = action.attempts.stream().filter(value -> value.sequence == completion.attemptSequence())
            .findFirst().orElseThrow(() -> new IOException("Unknown original Bazel attempt outcome"));
        if (!attempt.closed) throw new IOException("Native attempt remains open before output acceptance");
        boolean accepted = false;
        if (!completion.outcome().aborted())
        {
            action.streams.close();
            int status = completion.outcome().result();
            if (status == 0)
            {
                accepted = action.ready.publish(() ->
                {
                    attempt.lease.freeze();
                    if (!action.ready.publicationAllowed()) throw new IOException("Bazel publication cancelled after final validation");
                }, status);
                if (accepted) attempt.lease.accept();
                else attempt.lease.discard();
            }
            else
            {
                attempt.lease.discard();
                accepted = action.ready.complete(status);
            }
            attempt.lease = null;
            action.workspace.close();
            action.ready.releaseClaim();
            action.finished = true;
            record("action-result", Map.of("name", action.name, "sequence", attempt.sequence, "exit", status,
                "published", accepted, "identity", action.contentIdentity));
        }
        estimates.completed(completion.name(), completion.attemptSequence(),
            accepted && !completion.outcome().aborted() && completion.outcome().result() == 0);
    }

    @Override public OptionalInt pollToolResult() { requireThread(); return result; }
    @Override public boolean inputClosed() { requireThread(); return result.isPresent() && drained; }
    @Override public boolean hasOpenAttempts()
    {
        requireThread();
        return actions.values().stream().flatMap(action -> action.attempts.stream()).anyMatch(attempt -> !attempt.closed);
    }

    @Override public void stopAccepting()
    {
        requireThread();
        stopping = true;
        if (runner != null) runner.stopAccepting();
    }

    /**
     * Withdraws admissions and closes actions before the common backend can terminate its worker.
     * @throws IOException if any native or storage lease remains unresolved
     */
    private void closeActions() throws IOException
    {
        stopAccepting();
        IOException unresolved = null;
        if (original != null)
            try { original.close(); }
            catch (IOException failure) { unresolved = failure; }
        for (Action action : actions.values())
            try { action.close(); }
            catch (IOException failure)
            {
                if (unresolved == null) unresolved = failure;
                else unresolved.addSuppressed(failure);
            }
        if (unresolved != null) throw unresolved;
    }

    @Override public void close() throws IOException
    {
        requireThread();
        if (closed) return;
        closeActions();
        if (backend != null) backend.close();
        else for (Daemon daemon : daemons.reversed()) daemon.close();
        if (runner != null) runner.close();
        if (runtimeLease != null) runtimeLease.close();
        if (events != null) events.close();
        closed = true;
    }

    /**
     * Indicates complete original invocation closure.
     * @return whether native and shared dependencies all acknowledged retirement
     */
    boolean isClosed() { requireThread(); return closed; }

    /**
     * Appends a primitive copied event to the invocation's durable owner-thread stream.
     * @param event explicit event name
     * @param payload copied JSON-compatible primitive fields
     * @throws IOException if durable recording fails
     */
    void record(String event, Object payload) throws IOException
    {
        requireThread();
        if (events == null) return;
        Object copied = payload;
        if (payload instanceof Policy.Decision value)
            copied = Map.of("control", value.control().name(), "name", value.jobName(), "reason", value.reason());
        else if (payload instanceof SchedulerCoordinator.Blocked value)
            copied = Map.of("name", value.name(), "attemptSequence", value.attemptSequence(), "waitSequence", value.waitSequence());
        else if (payload instanceof SchedulerCoordinator.Submission value)
            copied = Map.of("name", value.name(), "estimate", value.peakBytes() == null ? "unknown" : value.peakBytes());
        else if (payload instanceof JobQueue.Completion<?> value)
            copied = Map.of("name", value.name(), "attemptSequence", value.attemptSequence(),
                "aborted", value.outcome().aborted(), "result", value.outcome().result());
        events.write(tooling.getJsonMapper().writeValueAsString(Map.of("event", event, "nanoTime", System.nanoTime(), "payload", copied)));
        events.newLine();
        events.flush();
    }

    /** Rejects cross-thread native composition. */
    private void requireThread()
    {
        if (Thread.currentThread() != thread) throw new IllegalStateException("Mac Bazel invocation belongs to its coordinator thread");
    }

    /**
     * Services existing allocation frames during bounded native acknowledgement waits.
     * @throws IOException if a retained installation reports a fault
     */
    private void pumpHooks() throws IOException
    {
        for (Action action : actions.values())
            for (Attempt attempt : action.attempts)
                if (attempt.nativeAttempt != null && !attempt.closed) attempt.nativeAttempt.pump();
    }

    /** Owns one original RPC, independent snapshots and original stream descriptions across retries. */
    private final class Action implements AutoCloseable
    {
        /** Original logical identity and queue position correlation. */
        private final String name;
        /** Original response and path claim authority. */
        private final BazelRunner.Ready<Admission> ready;
        /** Every issued attempt, including partial acquisitions. */
        private final List<Attempt> attempts = new ArrayList<>();
        /** Complete pristine storage owner retained before native launch. */
        private MacBazelWorkspace workspace;
        /** Original stdout/stderr descriptions retained across retries. */
        private Streams streams;
        /** Complete immutable content identity for memory history. */
        private String contentIdentity;
        /** Whether publication or explicit cancellation cleanup resolved this action. */
        private boolean finished;

        /**
         * Retains an admitted original RPC before fallible storage acquisition.
         * @param name stable invocation-issued logical name
         * @param ready original authenticated request
         */
        private Action(String name, BazelRunner.Ready<Admission> ready)
        {
            this.name = name;
            this.ready = ready;
        }

        /**
         * Captures complete pristine input and temporary trees and original open-file descriptions.
         * @throws IOException if current admission, independent copy or stream acquisition fails
         */
        private void acquire() throws IOException
        {
            Admission admission = ready.admission();
            admission.requireCurrent();
            workspace = MacBazelWorkspace.open(admission.input(), admission.temporary(),
                privateRoot.resolve("request-" + ready.sequence()), authorization.uid(), authorization.gid());
            contentIdentity = BazelWorkIdentity.identify(workspace.immutableSnapshot(), admission.input(),
                ready.request().getArgumentsList(), ready.request().getEnvironmentVariablesMap(), admission.cwd(),
                authorization.backendIdentity() + ":" + authorization.sourceDigest() + ":" + distribution.manifestHash());
            streams = new Streams(descriptors, admission.stdout(), admission.stderr());
            streams.start();
            record("ready-input", Map.of("name", name, "originalRun", ready.sequence(), "identity", contentIdentity,
                "input", admission.input().toString(), "cwd", admission.cwd().toString(),
                "arguments", ready.request().getArgumentsList(), "environment", ready.request().getEnvironmentVariablesMap()));
        }

        @Override public void close() throws IOException
        {
            if (finished) return;
            ready.fail(new IOException("Original Bazel invocation is closing"));
            for (Attempt attempt : attempts) attempt.close();
            if (streams != null) streams.close();
            for (Attempt attempt : attempts)
                if (attempt.lease != null)
                {
                    attempt.lease.discard();
                    attempt.lease = null;
                }
            if (workspace != null) workspace.close();
            ready.releaseClaim();
            finished = true;
        }
    }

    /** Retains one queue attempt's native and storage owners until genuine collection and rollback. */
    private final class Attempt implements JobQueue.Attempt<Integer>
    {
        /** Original action whose RPC remains pending. */
        private final Action action;
        /** Fresh queue-wide ordinal. */
        private final long sequence;
        /** Same-path execution and rollback lease. */
        private BazelWorkspace.Attempt lease;
        /** Partial or active original native action owner. */
        private MacBazelAttempt nativeAttempt;
        /** Genuine non-aborted or terminated result after whole-native zero. */
        private JobQueue.Outcome<Integer> outcome;
        /** Whether native close completed and any retry rollback completed. */
        private boolean closed;

        /**
         * Reserves resource-free attempt ownership before queue acquisition.
         * @param action original logical action
         * @param sequence fresh queue ordinal
         */
        private Attempt(Action action, long sequence) { this.action = action; this.sequence = sequence; }

        @Override public void start() throws IOException
        {
            if (nativeAttempt != null || lease != null || closed) throw new IllegalStateException("Queue attempt starts once");
            action.ready.admission().requireCurrent();
            lease = action.workspace.begin(sequence);
            canonicalDirectory(action.ready.admission().cwd());
            RunRequest request = action.ready.request();
            var context = new MacBazelAttempt.Context(tooling, runtimeLease.value(), nativeMeasurements,
                installed.workload(), installed.anchor(), privateRoot, settings.controlTimeout(), MacBazelInvocation.this::pumpHooks);
            var command = new MacBazelAttempt.Command(request.getArgumentsList(), request.getEnvironmentVariablesMap().entrySet()
                .stream().map(entry -> entry.getKey() + "=" + entry.getValue()).toList(), action.ready.admission().cwd(),
                action.streams.borrow(), authorization.uid(), authorization.gid());
            nativeAttempt = new MacBazelAttempt(context, command, action.name, sequence);
            nativeAttempt.start();
            record("attempt-started", Map.of("name", action.name, "sequence", sequence,
                "rootAuthority", nativeAttempt.rootAuthority(), "originalRun", action.ready.sequence()));
        }

        @Override public void resume(long waitSequence) throws IOException { nativeAttempt.resume(waitSequence); }
        @Override public void terminate() throws IOException { if (nativeAttempt != null) nativeAttempt.terminate(); }
        @Override public Optional<JobQueue.Outcome<Integer>> poll() throws IOException
        {
            if (nativeAttempt == null || closed) return Optional.empty();
            Optional<JobQueue.Outcome<Integer>> current = nativeAttempt.poll();
            current.ifPresent(value -> outcome = value);
            return current;
        }

        @Override public void close() throws IOException
        {
            if (closed) return;
            if (nativeAttempt != null) nativeAttempt.close();
            if (lease != null && (outcome == null || outcome.aborted()))
            {
                lease.discard();
                lease = null;
                record("attempt-rollback", Map.of("name", action.name, "sequence", sequence,
                    "nativeClosed", nativeAttempt == null || nativeAttempt.isClosed(), "originalRun", action.ready.sequence()));
            }
            closed = true;
        }
    }

    /** Authenticates native path objects on RPC threads without acquiring a native action owner. */
    private final class Boundary implements BazelRunner.Boundary<Admission>
    {
        /** Stable worker directory identity captured before worker launch. */
        private Object workerKey;

        /** Creates a resource-free native pathname boundary. */
        private Boundary() {}

        @Override public synchronized void validateRoot() throws IOException
        {
            canonicalDirectory(workerRoot);
            Object current = fileKey(workerRoot);
            if (workerKey == null) workerKey = current;
            else if (!workerKey.equals(current)) throw new IOException("Original worker build root was replaced");
        }

        @Override public void checkReadiness(String path) throws IOException
        {
            validateRoot();
            resolve(path, true);
            workerReadiness.complete(null);
        }

        @Override public Admission admit(RunRequest request) throws IOException
        {
            validateRoot();
            Path input = resolve(request.getInputRootDirectory(), true);
            Path temporary = resolve(request.getTemporaryDirectory(), true);
            Path cwd = input.resolve(relative(request.getWorkingDirectory(), true));
            canonicalDirectory(cwd);
            Path logs = resolve(request.getServerLogsDirectory(), true);
            Path stdout = resolve(request.getStdoutPath(), false);
            Path stderr = resolve(request.getStderrPath(), false);
            if (input.startsWith(temporary) || temporary.startsWith(input) || stdout.equals(stderr) ||
                stdout.startsWith(input) || stderr.startsWith(input) || stdout.startsWith(temporary) || stderr.startsWith(temporary))
                throw new IOException("Bazel original input, temporary and stream locations must be independent");
            Map<Path, Object> keys = new LinkedHashMap<>();
            for (Path directory : List.of(workerRoot, input, temporary, logs, stdout.getParent(), stderr.getParent()))
                keys.put(directory, fileKey(directory));
            return new Admission(input, temporary, cwd, stdout, stderr, logs, Map.copyOf(keys));
        }

        /**
         * Resolves an exact native protocol path beneath the worker root without aliases or symbolic ancestors.
         * @param value original relative protocol pathname
         * @param isDirectory whether the final entry is an existing directory
         * @return original absolute native location
         * @throws IOException if native identity or path syntax is invalid
         */
        private Path resolve(String value, boolean isDirectory) throws IOException
        {
            Path path = workerRoot.resolve(relative(value, false));
            canonicalDirectory(isDirectory ? path : path.getParent());
            if (!isDirectory && Files.exists(path, LinkOption.NOFOLLOW_LINKS))
                throw new IOException("Original Bazel output stream already exists: " + path);
            return path;
        }
    }

    /**
     * Immutable original native admission, independent of response cancellation and native acquisition.
     * @param input original input directory
     * @param temporary original temporary directory
     * @param cwd exact original action working directory
     * @param stdout original absent stdout destination
     * @param stderr original absent stderr destination
     * @param logs original server-log directory
     * @param keys stable original directory object identities
     */
    private record Admission(Path input, Path temporary, Path cwd, Path stdout, Path stderr, Path logs,
        Map<Path, Object> keys) implements BazelRunner.Admission
    {
        @Override public List<Path> claimedPaths() { return List.of(input, temporary, stdout, stderr, logs); }

        /**
         * Revalidates original object attachment before action storage or native acquisition.
         * @throws IOException if a native path was replaced or aliased
         */
        private void requireCurrent() throws IOException
        {
            for (Map.Entry<Path, Object> entry : keys.entrySet())
            {
                canonicalDirectory(entry.getKey());
                if (!entry.getValue().equals(fileKey(entry.getKey())))
                    throw new IOException("Original admitted Bazel directory was replaced: " + entry.getKey());
            }
        }
    }

    /**
     * Validates native protocol relative paths without rewriting argument strings.
     * @param value original protocol path
     * @param emptyAllowed whether empty cwd means the input root
     * @return normalized relative pathname
     * @throws IOException if syntax is ambiguous or can escape the native root
     */
    private static Path relative(String value, boolean emptyAllowed) throws IOException
    {
        if (value.isEmpty() && emptyAllowed) return Path.of("");
        if (value.isEmpty() || value.startsWith("/") || value.indexOf(0) >= 0)
            throw new IOException("Native Runner path must be nonempty and relative");
        for (String component : value.split("/", -1))
            if (component.isEmpty() || component.equals(".") || component.equals(".."))
                throw new IOException("Native Runner path has an ambiguous component");
        Path path = Path.of(value);
        if (path.isAbsolute() || !path.normalize().equals(path)) throw new IOException("Native Runner path is not normalized");
        return path;
    }

    /**
     * Rejects symbolic ancestors and native case aliases before capturing path claims.
     * @param path existing absolute directory
     * @throws IOException if its original spelling does not identify a direct canonical directory
     */
    private static void canonicalDirectory(Path path) throws IOException
    {
        if (!path.isAbsolute() || !path.equals(path.normalize()) || !Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS) ||
            !path.equals(path.toRealPath())) throw new IOException("Canonical direct native directory required: " + path);
    }

    /**
     * Reads stable native NIO object authority without following its final entry.
     * @param path existing native entry
     * @return nonnull stable filesystem key
     * @throws IOException if the filesystem cannot supply stable identity
     */
    private static Object fileKey(Path path) throws IOException
    {
        Object key = Files.readAttributes(path, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS).fileKey();
        if (key == null) throw new IOException("Native Bazel path lacks stable filesystem identity: " + path);
        return key;
    }

    /** Retains the original build consumer in its own native service outside action memory-failure domains. */
    private final class OuterWorkload implements AutoCloseable
    {
        /** Original started runtime borrowed through terminal collection. */
        private final FridaRuntime runtime;
        /** Original consumer executable and argument strings. */
        private final List<String> command;
        /** Complete explicit consumer environment. */
        private final Map<String, String> environment;
        /** Original manager retained before initialization. */
        private FridaRuntime.Manager manager;
        /** Fresh private native state directory. */
        private Path state;
        /** Original partial or active native owner. */
        private MacWorkloadNative.Owner owner;
        /** Whether held-root acquisition returned. */
        private boolean acquired;
        /** Genuine original status published only after native service, anchor and stream collection. */
        private OptionalInt completed = OptionalInt.empty();
        /** Whether terminal native and state cleanup completed. */
        private boolean retired;

        /**
         * Retains resource-free original consumer configuration.
         * @param runtime original started runtime
         * @param command original consumer command
         * @param environment complete explicit environment
         */
        private OuterWorkload(FridaRuntime runtime, List<String> command, Map<String, String> environment)
        {
            this.runtime = runtime;
            this.command = List.copyOf(command);
            this.environment = Map.copyOf(environment);
        }

        /**
         * Acquires held original native ownership before releasing the trusted consumer.
         * The consumer and Bazel controller are outside the action instrumentation domain. No Frida session is
         * injected into their system shell or compiler-driver images, so they contain no instrumentation kqueues.
         * @throws IOException if original preparation fails
         */
        private void start() throws IOException
        {
            manager = runtime.newManager();
            manager.start();
            state = Files.createTempDirectory(privateRoot, "outer-");
            var launch = new MacWorkloadNative.Launch(installed.workload(), installed.anchor(), state, settings.workspace(),
                new MacWorkloadNative.Streams(0, 1, 2), command,
                environment.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).toList(), 0, 0);
            owner = new MacWorkloadNative.Owner(tooling, launch, manager);
            MacImages.Identity rootIdentity = owner.root();
            acquired = true;
            List<Long> authority = owner.authority(rootIdentity);
            owner.releaseRoot();
            record("original-consumer-released", Map.of("authority", authority, "command", command,
                "workingDirectory", settings.workspace().toString()));
        }

        /**
         * Observes the original native coalition cut and wait, then collects its service and anchor.
         * @return genuine original result only after complete native retirement
         * @throws IOException if original native authority fails
         */
        private OptionalInt advance() throws IOException
        {
            if (completed.isPresent()) return completed;
            OptionalInt result = owner.terminalResult();
            if (result.isPresent())
            {
                owner.close();
                completed = result;
            }
            return completed;
        }

        @Override public void close() throws IOException
        {
            if (retired) return;
            if (owner != null && !owner.isClosed())
                MacAttempt.collectPartial(acquired, new MacAttempt.PartialOwner()
                {
                    @Override public void cancel() throws IOException { owner.cancel(); }
                    @Override public OptionalInt terminalResult() throws IOException { return owner.terminalResult(); }
                    @Override public void close() throws IOException { owner.close(); }
                }, settings.controlTimeout());
            else if (owner == null && manager != null) manager.close();
            if (state != null) Files.delete(state);
            retired = true;
        }
    }

    /** Retains an original pinned standalone Go daemon and its real wait object. */
    private static final class Daemon implements BazelNativeBackend.Daemon
    {
        /** Original process object, never reconstructed from a numeric PID. */
        private final Process process;
        /** Positive terminal wait bound. */
        private final Duration timeout;
        /** Whether genuine original wait and native stream disposal completed. */
        private boolean collected;

        /**
         * Retains a newly acquired original native daemon before the caller starts another daemon.
         * @param process original acquired process
         * @param timeout positive collection bound
         */
        private Daemon(Process process, Duration timeout) { this.process = process; this.timeout = timeout; }
        @Override public boolean isAlive() { return process.isAlive(); }
        @Override public long exitValue() { return process.exitValue(); }
        @Override public CompletableFuture<Long> onExit()
        {
            return process.onExit().thenApply(original -> (long) original.exitValue());
        }

        @Override public synchronized void close() throws IOException
        {
            if (collected) return;
            if (process.descendants().anyMatch(ProcessHandle::isAlive))
                throw new IOException("Unexpected native backend descendants retain independent cleanup authority");
            process.destroy();
            try
            {
                if (!process.waitFor(timeout.toNanos(), TimeUnit.NANOSECONDS))
                {
                    process.destroyForcibly();
                    if (!process.waitFor(timeout.toNanos(), TimeUnit.NANOSECONDS))
                        throw new IOException("Original native backend wait remains incomplete");
                }
                process.getOutputStream().close();
                process.getInputStream().close();
                process.getErrorStream().close();
                collected = true;
            }
            catch (InterruptedException cause)
            {
                Thread.currentThread().interrupt();
                throw new IOException("Interrupted original daemon wait; retain native authority", cause);
            }
        }
    }

    /** Retains original stream descriptions through all native borrowers and every retry. */
    private static final class Streams implements AutoCloseable
    {
        /** Borrowed immutable Darwin stream functions. */
        private final Descriptors functions;
        /** Original absent destinations, never rewritten across retries. */
        private final List<Path> outputs;
        /** Exact created output identities checked before response publication. */
        private final Map<Path, Object> outputKeys = new LinkedHashMap<>();
        /** Every original owned descriptor retained immediately on acquisition. */
        private final int[] descriptors = {-1, -1, -1};
        /** Whether the single acquisition opportunity was consumed. */
        private boolean attempted;
        /** Whether every original descriptor acknowledged close. */
        private boolean closed;
        /** Sticky uncertain native close, never replayed against a potentially reused numeric descriptor. */
        private IOException closeFailure;

        /**
         * Retains resource-free original stream destinations.
         * @param functions borrowed Darwin functions
         * @param stdout authenticated absent stdout path
         * @param stderr authenticated absent stderr path
         */
        private Streams(Descriptors functions, Path stdout, Path stderr)
        {
            this.functions = functions;
            this.outputs = List.of(stdout, stderr);
        }

        /**
         * Opens stdin and original outputs once, retaining each descriptor before further fallible work.
         * @throws IOException if creation, native opening or exact descriptor identity fails
         */
        private void start() throws IOException
        {
            if (attempted || closed) throw new IllegalStateException("Original stream acquisition starts once");
            attempted = true;
            descriptors[0] = functions.open(Path.of("/dev/null"), false);
            for (int index = 0; index < outputs.size(); ++index)
            {
                Path output = outputs.get(index);
                Files.createFile(output, PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rw-------")));
                Object key = fileKey(output);
                descriptors[index + 1] = functions.open(output, true);
                functions.requireIdentity(descriptors[index + 1], output);
                if (!key.equals(fileKey(output))) throw new IOException("Original stream object changed during open");
                outputKeys.put(output, key);
            }
        }

        /**
         * Borrows the original open-file descriptions without reopening or resetting their offsets.
         * @return original input/output/error descriptions
         */
        private MacWorkloadNative.Streams borrow()
        {
            if (!attempted || closed || descriptors[0] < 0 || descriptors[1] < 0 || descriptors[2] < 0)
                throw new IllegalStateException("Original action streams are unavailable");
            return new MacWorkloadNative.Streams(descriptors[0], descriptors[1], descriptors[2]);
        }

        @Override public void close() throws IOException
        {
            if (closeFailure != null) throw closeFailure;
            if (closed) return;
            IOException pathFailure = null;
            try
            {
                for (Map.Entry<Path, Object> entry : outputKeys.entrySet())
                    if (!entry.getValue().equals(fileKey(entry.getKey())))
                        throw new IOException("Original Bazel stream pathname was replaced: " + entry.getKey());
            }
            catch (IOException failure) { pathFailure = failure; }
            for (int index = descriptors.length - 1; index >= 0; --index)
            {
                int descriptor = descriptors[index];
                if (descriptor < 0) continue;
                descriptors[index] = -1;
                try { functions.close(descriptor); }
                catch (IOException failure)
                {
                    if (closeFailure == null) closeFailure = failure;
                    else closeFailure.addSuppressed(failure);
                }
            }
            if (closeFailure != null)
            {
                if (pathFailure != null) closeFailure.addSuppressed(pathFailure);
                throw closeFailure;
            }
            closed = true;
            if (pathFailure != null) throw pathFailure;
        }
    }

    /** Uses Darwin's original open/close/fstat contracts without reflecting into JDK descriptor internals. */
    private static final class Descriptors
    {
        /** Native errno capture layout supplied by this host's linker. */
        private static final java.lang.foreign.MemoryLayout ERROR_STATE = Linker.Option.captureStateLayout();
        /** Captured errno byte offset in the native host layout. */
        private static final long ERROR_OFFSET = ERROR_STATE.byteOffset(java.lang.foreign.MemoryLayout.PathElement.groupElement("errno"));
        /** Darwin O_CLOEXEC from bsd/sys/fcntl.h. */
        private static final int CLOSE_ON_EXEC = 0x01000000;
        /** Darwin O_NOFOLLOW from bsd/sys/fcntl.h. */
        private static final int NO_FOLLOW = 0x0100;
        /** Darwin O_WRONLY from bsd/sys/fcntl.h. */
        private static final int WRITE_ONLY = 1;
        /** Darwin __DARWIN_STRUCT_STAT64 buffer size for both supported 64-bit targets. */
        private static final long STAT_SIZE = 144;
        /** Darwin stat64 device number offset. */
        private static final long DEVICE_OFFSET = 0;
        /** Darwin stat64 inode number offset. */
        private static final long INODE_OFFSET = 8;
        /** Original open function with captured errno and the third variadic mode argument. */
        private final MethodHandle open;
        /** Original close function with captured errno. */
        private final MethodHandle close;
        /** Original 64-bit-inode fstat function with captured errno. */
        private final MethodHandle stat;

        /**
         * Binds Darwin signatures only after the public boundary validates the native host.
         * @param scope original scope supplying the shared linker
         * @throws IOException if a required native symbol is absent
         */
        // Restricted downcalls use the verified Darwin LP64 ABI and owned bounded buffers; the caller grants native access.
        @SuppressWarnings("restricted")
        private Descriptors(ToolingScope scope) throws IOException
        {
            if (!System.getProperty("os.name").startsWith("Mac")) throw new IOException("Darwin stream bindings require macOS");
            Linker linker = scope.getNativeLinker();
            open = linker.downcallHandle(linker.defaultLookup().find("open").orElseThrow(),
                FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.JAVA_INT, ValueLayout.JAVA_INT),
                Linker.Option.firstVariadicArg(2), Linker.Option.captureCallState("errno"));
            close = linker.downcallHandle(linker.defaultLookup().find("close").orElseThrow(),
                FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.JAVA_INT), Linker.Option.captureCallState("errno"));
            var symbol = linker.defaultLookup().find("fstat$INODE64");
            if (symbol.isEmpty()) symbol = linker.defaultLookup().find("fstat");
            stat = linker.downcallHandle(symbol.orElseThrow(),
                FunctionDescriptor.of(ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS),
                Linker.Option.captureCallState("errno"));
        }

        /**
         * Opens a previously authenticated original pathname without inheriting this controller descriptor on exec.
         * @param path original input or already-created output
         * @param writable whether output write access is required
         * @return retained original native descriptor
         * @throws IOException if native acquisition fails
         */
        private int open(Path path, boolean writable) throws IOException
        {
            try (Arena arena = Arena.ofConfined())
            {
                var state = arena.allocate(ERROR_STATE);
                int descriptor = (int) open.invoke(state, arena.allocateFrom(path.toString()),
                    CLOSE_ON_EXEC | NO_FOLLOW | (writable ? WRITE_ONLY : 0), 0);
                if (descriptor < 0) throw new IOException("Cannot open original Bazel stream " + path + ": errno=" + state.get(ValueLayout.JAVA_INT, ERROR_OFFSET));
                return descriptor;
            }
            catch (IOException failure) { throw failure; }
            catch (Throwable failure) { throw new IOException("Darwin original stream acquisition failed", failure); }
        }

        /**
         * Confirms an original descriptor still denotes the exact admitted native file object.
         * @param descriptor retained native descriptor
         * @param path original authenticated stream pathname
         * @throws IOException if descriptor or pathname identity differs
         */
        private void requireIdentity(int descriptor, Path path) throws IOException
        {
            try (Arena arena = Arena.ofConfined())
            {
                var state = arena.allocate(ERROR_STATE);
                var data = arena.allocate(STAT_SIZE, Long.BYTES);
                if ((int) stat.invoke(state, descriptor, data) != 0)
                    throw new IOException("Cannot authenticate original stream descriptor: errno=" + state.get(ValueLayout.JAVA_INT, ERROR_OFFSET));
                Map<String, Object> attributes = Files.readAttributes(path, "unix:dev,ino", LinkOption.NOFOLLOW_LINKS);
                if (data.get(ValueLayout.JAVA_INT, DEVICE_OFFSET) != ((Number) attributes.get("dev")).intValue() ||
                    data.get(ValueLayout.JAVA_LONG, INODE_OFFSET) != ((Number) attributes.get("ino")).longValue())
                    throw new IOException("Original stream descriptor and native pathname identity differ");
            }
            catch (IOException failure) { throw failure; }
            catch (Throwable failure) { throw new IOException("Darwin original stream identity failed", failure); }
        }

        /**
         * Consumes one original close opportunity; callers never replay a failed numeric descriptor close.
         * @param descriptor original owned native description
         * @throws IOException if native close is uncertain
         */
        private void close(int descriptor) throws IOException
        {
            try (Arena arena = Arena.ofConfined())
            {
                var state = arena.allocate(ERROR_STATE);
                if ((int) close.invoke(state, descriptor) != 0)
                    throw new IOException("Original stream close is uncertain: errno=" + state.get(ValueLayout.JAVA_INT, ERROR_OFFSET));
            }
            catch (IOException failure) { throw failure; }
            catch (Throwable failure) { throw new IOException("Darwin original stream close failed", failure); }
        }
    }

    /**
     * Pauses bounded original native collection while preserving interruption.
     * @throws IOException if interrupted
     */
    private static void pause() throws IOException
    {
        try { Thread.sleep(1); }
        catch (InterruptedException cause)
        {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while retaining original macOS Bazel ownership", cause);
        }
    }
}
