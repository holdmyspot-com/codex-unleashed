package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.testng.annotations.Test;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/** Exercises the exact production bounded JSON boundary without claiming native execution authority. */
public final class WindowsBazelLaunchConfigurationTest
{
    /** Creates a fixture-free test object; every parallel method owns its parser scope. */
    public WindowsBazelLaunchConfigurationTest() {}

    /**
     * Explicit empty environment values and exact capacities survive production decoding.
     * @throws IOException if valid production decoding fails
     */
    @Test public void acceptsExactExplicitSchema() throws IOException
    {
        try (var tooling = new DefaultToolingScope(); var scope = new WindowsBazelScope(tooling))
        {
            Map<String, Object> input = document();
            input.put("environment", Map.of("Path", "sealed", "EMPTY", ""));
            var result = WindowsBazelLaunchConfiguration.decode(scope, source(), scope.json().writeValueAsBytes(input));
            requireThat(result.environment(), "exactEnvironment").isEqualTo(Map.of("Path", "sealed", "EMPTY", ""));
            requireThat(result.casBytes(), "explicitCasBytes").isEqualTo(67108864L);
            requireThat(result.cachePolicy(), "explicitPolicy").isEqualTo(BazelNativeBackend.CachePolicy.ACCEPT_CACHED);
        }
    }

    /**
     * An installed explicit consumer can pin the complete packaged launcher image independently.
     * @throws IOException if exact production decoding fails
     */
    @Test public void acceptsCompleteInstalledLauncherIdentity() throws IOException
    {
        try (var tooling = new DefaultToolingScope(); var scope = new WindowsBazelScope(tooling))
        {
            Map<String, Object> input = document();
            Map<String, String> identities = new LinkedHashMap<>();
            identities.put("bazel", "0".repeat(64));
            identities.put("toolchain", "1".repeat(64));
            identities.put("frida", "2".repeat(64));
            identities.put("javaRuntime", "3".repeat(64));
            identities.put("launcher", "4".repeat(64));
            input.put("identities", identities);
            var result = WindowsBazelLaunchConfiguration.decode(scope, source(), scope.json().writeValueAsBytes(input));
            requireThat(result.identities().get("launcher"), "completeInstalledImageIdentity").isEqualTo("4".repeat(64));
            identities.put("unknown", "5".repeat(64));
            reject(scope, scope.json().writeValueAsBytes(input));
        }
    }

    /**
     * Missing, unknown, null, floating-point and out-of-range selecting fields cannot be silently normalized.
     * @throws IOException if fixture serialization fails
     */
    @Test public void rejectsCollapsedPresenceAndNumericRepresentations() throws IOException
    {
        try (var tooling = new DefaultToolingScope(); var scope = new WindowsBazelScope(tooling))
        {
            for (String field : List.of("schema", "cachePolicy", "environment", "backendIdentity"))
            {
                Map<String, Object> input = document();
                input.remove(field);
                reject(scope, scope.json().writeValueAsBytes(input));
            }
            for (Object schema : List.of(1.0, "1", 2, Long.MAX_VALUE))
            {
                Map<String, Object> input = document();
                input.put("schema", schema);
                reject(scope, scope.json().writeValueAsBytes(input));
            }
            Map<String, Object> input = document();
            input.put("casBytes", 67108864.0);
            reject(scope, scope.json().writeValueAsBytes(input));
            input = document();
            input.put("unknown", true);
            reject(scope, scope.json().writeValueAsBytes(input));
            input = document();
            input.put("backendIdentity", null);
            reject(scope, scope.json().writeValueAsBytes(input));
        }
    }

    /**
     * Duplicate fields, trailing documents, case aliases and launcher overrides fail the same production boundary.
     * @throws IOException if fixture serialization fails
     */
    @Test public void rejectsAmbiguousDocumentsAndWindowsEnvironment() throws IOException
    {
        try (var tooling = new DefaultToolingScope(); var scope = new WindowsBazelScope(tooling))
        {
            String json = scope.json().writeValueAsString(document());
            reject(scope, json.replace("\"schema\":1", "\"schema\":1,\"schema\":1").getBytes(StandardCharsets.UTF_8));
            reject(scope, (json + "{}").getBytes(StandardCharsets.UTF_8));
            reject(scope, new byte[1048577]);
            for (Map<String, String> environment : List.of(Map.of("PATH", "first", "Path", "second"),
                Map.of("JAVA_TOOL_OPTIONS", "-agentlib:untrusted"), Map.of("Bad=Name", "value")))
            {
                Map<String, Object> input = document();
                input.put("environment", environment);
                reject(scope, scope.json().writeValueAsBytes(input));
            }
        }
    }

    /**
     * Submits exact malformed bytes to the production decoding operation and requires a caller-visible rejection.
     * @param scope method-owned strict parser
     * @param bytes exact rejected document
     */
    private static void reject(WindowsBazelScope scope, byte[] bytes)
    {
        boolean failed = false;
        try { WindowsBazelLaunchConfiguration.decode(scope, source(), bytes); }
        catch (IOException expected) { failed = true; }
        requireThat(failed, "invalidProfileRejected").isTrue();
    }

    /**
     * Creates a resource-free valid native-path document for the current host's decoder.
     * @return fresh mutable exact required-field document
     */
    private static Map<String, Object> document()
    {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("schema", 1);
        result.put("distribution", source().resolveSibling("backend").toString());
        result.put("bazel", source().resolveSibling("bazel.exe").toString());
        result.put("toolchainRoot", source().resolveSibling("toolchain").toString());
        result.put("environment", Map.of());
        result.put("identities", Map.of("bazel", "0".repeat(64), "toolchain", "1".repeat(64),
            "frida", "2".repeat(64), "javaRuntime", "3".repeat(64)));
        result.put("backendIdentity", "explicit-backend");
        result.put("casBytes", 67108864L);
        result.put("actionCacheBytes", 67108864L);
        result.put("cachePolicy", "ACCEPT_CACHED");
        return result;
    }

    /**
     * Provides a native absolute normalized logical profile name without reading or creating a file.
     * @return represented host-native profile
     */
    private static Path source() { return Path.of(System.getProperty("java.io.tmpdir")).toAbsolutePath().normalize().resolve("profile.json"); }
}
