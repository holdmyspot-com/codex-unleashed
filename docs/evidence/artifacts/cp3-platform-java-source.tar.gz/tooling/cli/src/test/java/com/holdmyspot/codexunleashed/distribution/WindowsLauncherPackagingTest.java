package com.holdmyspot.codexunleashed.distribution;

import java.io.DataInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.tools.ToolProvider;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/** Exercises actual subprocess receipt of the production Windows packaging arguments and failure streams. */
public final class WindowsLauncherPackagingTest
{
    /** Creates independent parallel fixtures. */
    public WindowsLauncherPackagingTest() {}

    /**
     * Covers ordinary Cargo and additive Bazel packaging with successful and failing external tool results.
     * @return independent packaging cases
     */
    @DataProvider(parallel = true)
    public Object[][] cases() { return new Object[][] {{false, 0}, {true, 0}, {false, 23}, {true, 23}}; }

    /**
     * Runs a real Java argv receiver through the production packaging subprocess boundary.
     * The receiver is an external tool model; it does not claim native jpackage or executable acceptance.
     * @param bazel whether to add the native Bazel console
     * @param exit actual receiver status
     * @throws Exception if compilation, invocation, receipt verification or cleanup fails
     */
    @Test(dataProvider = "cases")
    public void receivesProductionArgumentsAndStatus(boolean bazel, int exit) throws Exception
    {
        Path root = Files.createTempDirectory("windows packaging ").toAbsolutePath();
        try
        {
            Path source = root.resolve("Receiver.java");
            Files.writeString(source, """
                import java.nio.file.*;
                import java.util.*;
                public final class Receiver {
                    public static void main(String[] args) throws Exception {
                        Path receipt=Path.of(args[0]); int status=Integer.parseInt(args[1]);
                        List<String> argv=List.of(args).subList(2,args.length);
                        try(var out=new java.io.DataOutputStream(Files.newOutputStream(receipt))) {
                            for(String value:argv) out.writeUTF(value);
                        }
                        int extra=argv.indexOf("--add-launcher");
                        if(extra>=0) {
                            String spec=argv.get(extra+1);
                            if(!spec.startsWith("codex-bazel-wrapper=")) throw new IllegalStateException(spec);
                            Path properties=Path.of(spec.substring(spec.indexOf('=')+1));
                            if(!properties.isAbsolute()) throw new IllegalStateException("relative properties");
                            Properties declaration=new Properties();
                            try(var in=Files.newInputStream(properties)){declaration.load(in);}
                            System.out.println("module="+declaration.getProperty("module"));
                            System.out.println("win-console="+declaration.getProperty("win-console"));
                        }
                        System.out.println("receiver-stdout");System.err.println("receiver-stderr");
                        if(status==0) Files.createDirectory(Path.of(argv.get(argv.indexOf("--dest")+1)).resolve("codex-cargo-wrapper"));
                        System.exit(status);
                    }
                }
                """);
            Path classes = Files.createDirectory(root.resolve("classes"));
            requireThat(ToolProvider.getSystemJavaCompiler().run(null, null, null, "--release", "27",
                "-d", classes.toString(), source.toString()), "ReceiverCompilation").isEqualTo(0);
            Path modules = Files.createDirectory(root.resolve("modules space"));
            Path runtime = Files.createDirectory(root.resolve("runtime space"));
            Path jdk = root.resolve("jdk space");
            Path tmp = root.resolve("tmp space");
            Path receipt = root.resolve("argv.bin");
            Path stderr = root.resolve("stderr.txt");
            List<String> streams = new ArrayList<>();
            IOException failure = null;
            try
            {
                DistributionMain.packageWindowsWrapper(modules, runtime, bazel, jdk, tmp, (argv, diagnostic) -> {
                    List<String> command = new ArrayList<>(List.of(Path.of(System.getProperty("java.home"),
                        "bin", System.getProperty("os.name").startsWith("Windows") ? "java.exe" : "java").toString(),
                        "-cp", classes.toString(), "Receiver", receipt.toString(), Integer.toString(exit)));
                    command.addAll(argv);
                    try (Process child = new ProcessBuilder(command).redirectOutput(diagnostic.toFile()).
                        redirectError(stderr.toFile()).start())
                    {
                        int status;
                        try { status = child.waitFor(); }
                        catch (InterruptedException interrupted)
                        {
                            Thread.currentThread().interrupt(); throw new IOException("Receiver interrupted", interrupted);
                        }
                        streams.add(Files.readString(diagnostic));
                        return status;
                    }
                });
            }
            catch (IOException caught) { failure = caught; }
            List<String> actual = new ArrayList<>();
            try (DataInputStream input = new DataInputStream(Files.newInputStream(receipt)))
            {
                while (input.available() > 0) actual.add(input.readUTF());
            }
            requireThat(actual.getFirst(), "ActualJpackageExecutable").isEqualTo(jdk.resolve("bin/jpackage.exe").toString());
            requireThat(actual.subList(1, 7), "OriginalCargoImageOptions").isEqualTo(List.of(
                "-J-Djava.io.tmpdir=" + tmp, "--type", "app-image", "--name", "codex-cargo-wrapper", "--dest"));
            requireThat(actual.subList(8, 16), "OriginalCargoModuleAndConsole").isEqualTo(List.of(
                "--runtime-image", runtime.toString(), "--module-path", modules.toString(), "--module",
                "com.holdmyspot.codexunleashed.tooling/com.holdmyspot.codexunleashed.scheduler.WindowsCargoWrapperMain",
                "--win-console", "--java-options=--enable-native-access=com.holdmyspot.codexunleashed.tooling"));
            requireThat(actual.contains("--add-launcher"), "OptionalBazelOnly").isEqualTo(bazel);
            requireThat(actual.size(), "ExactArgumentCount").isEqualTo(bazel ? 18 : 16);
            String expected = bazel ? "module=com.holdmyspot.codexunleashed.tooling/com.holdmyspot.codexunleashed.scheduler.WindowsBazelLauncher\nwin-console=true\nreceiver-stdout\n" : "receiver-stdout\n";
            requireThat(streams.getFirst().replace("\r\n", "\n"), "ReceiverReadActualDeclarationAndStdout").isEqualTo(expected);
            requireThat(Files.readString(stderr).strip(), "ReceiverSeparateStderr").isEqualTo("receiver-stderr");
            requireThat(failure == null, "OriginalExitPreserved").isEqualTo(exit == 0);
            if (failure != null)
                requireThat(failure.getMessage(), "ActualExit23AndCapturedDiagnostic").isEqualTo(
                    "jpackage failed with status 23: " + streams.getFirst().strip());
            requireThat(Files.isDirectory(runtime.resolve("wrapper-image/codex-cargo-wrapper")),
                "PublishOnlyAfterSuccess").isEqualTo(exit == 0);
            requireThat(Files.exists(Path.of(actual.get(7))), "OwnedStagingRemoved").isFalse();
        }
        finally
        {
            try (var paths = Files.walk(root))
            {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
            }
        }
    }
}
