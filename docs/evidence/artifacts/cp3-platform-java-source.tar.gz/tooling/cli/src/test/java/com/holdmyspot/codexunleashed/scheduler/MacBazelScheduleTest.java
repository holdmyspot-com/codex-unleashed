package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import org.testng.annotations.Test;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/** Verifies macOS Bazel selection at the public scheduler's native composition boundary. */
public final class MacBazelScheduleTest
{
    /** Creates a fixture-free test whose methods own all mutable state. */
    public MacBazelScheduleTest() {}

    /**
     * Delivers the exact Bazel command to one selected native adapter and preserves its original status.
     * The supplied platform observation models macOS; the controlled adapter proves dispatch only.
     */
    @Test
    public void dispatchesBazelWithoutCargoAuthority()
    {
        AtomicInteger calls = new AtomicInteger();
        String[] options = {"--tool", "bazel", "--workspace", ".", "--scratch", "scratch",
            "--frida-library", "frida", "--headroom-bytes", "1048576", "--max-jobs", "2",
            "--control-timeout-ms", "120000", "--bazel-launch-config", "bazel.json", "--", "build", "//:compile", "a b", ""};
        try (DefaultToolingScope scope = new DefaultToolingScope())
        {
            int result = Scheduler.SharedSecrets.run(scope, options, System.in, System.out, System.err,
                "Mac OS X", (services, settings) ->
                {
                    calls.incrementAndGet();
                    requireThat(settings.tool(), "selectedBuildTool").isEqualTo("bazel");
                    requireThat(settings.arguments(), "unchangedArguments").isEqualTo(List.of("build", "//:compile", "a b", ""));
                    return 23;
                });
            requireThat(result, "genuineNativeAdapterStatus").isEqualTo(23);
            requireThat(calls.get(), "oneNativeAdapterInvocation").isEqualTo(1);
        }
    }
}
