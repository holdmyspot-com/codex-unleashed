package com.holdmyspot.codexunleashed.scheduler;

import java.util.ArrayList;
import java.util.List;
import org.testng.annotations.Test;
import static com.holdmyspot.codexunleashed.scheduler.TestRequirements.requireException;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/** Verifies explicit Bazel construction selection before native adapter activation. */
public final class BazelSchedulerOptionsTest
{
    /** Creates independent option checks without shared fixtures. */
    public BazelSchedulerOptionsTest() {}

    /** Preserves the literal tool arguments when selecting an explicit Bazel document. */
    @Test public void acceptsBazelConfiguration()
    {
        var settings = Scheduler.parse(options("bazel").toArray(String[]::new));
        requireThat(settings.bazelLaunchConfiguration(), "explicitBazelConfiguration")
            .isEqualTo(java.nio.file.Path.of("bazel launch.json").toAbsolutePath().normalize());
        requireThat(settings.arguments(), "unchangedArguments").isEqualTo(List.of("build", "a b", ""));
    }

    /** Rejects a Bazel construction document for a different build tool. */
    @Test public void rejectsBazelConfigurationForCargo()
    {
        requireException(IllegalArgumentException.class,
            () -> Scheduler.parse(options("cargo").toArray(String[]::new)));
    }

    /** Rejects conflicting native authority documents before opening either document. */
    @Test public void rejectsConflictingConfiguration()
    {
        for (String option : List.of("--linux-launch-config", "--windows-launch-config", "--mac-launch-config"))
        {
            List<String> arguments = options("bazel");
            arguments.addAll(0, List.of(option, "other.json"));
            requireException(IllegalArgumentException.class,
                () -> Scheduler.parse(arguments.toArray(String[]::new)));
        }
    }

    /** Rejects duplicate and blank Bazel document selection before native work. */
    @Test public void rejectsDuplicateOrBlankConfiguration()
    {
        List<String> duplicate = options("bazel");
        duplicate.addAll(0, List.of("--bazel-launch-config", "other.json"));
        requireException(IllegalArgumentException.class,
            () -> Scheduler.parse(duplicate.toArray(String[]::new)));
        List<String> blank = options("bazel");
        blank.set(1, " ");
        requireException(IllegalArgumentException.class,
            () -> Scheduler.parse(blank.toArray(String[]::new)));
    }

    /** Dispatches the Mac Bazel boundary with the original services, document and literal arguments. */
    @Test public void dispatchesMacBazelAndPreservesStatus()
    {
        var calls = new java.util.concurrent.atomic.AtomicInteger();
        try (var scope = new com.holdmyspot.codexunleashed.tooling.DefaultToolingScope())
        {
            int result = Scheduler.SharedSecrets.run(scope, options("bazel").toArray(String[]::new),
                System.in, System.out, System.err, "Mac OS X", (services, settings) ->
                {
                    calls.incrementAndGet();
                    requireThat(services == scope, "originalBorrowedServices").isTrue();
                    requireThat(settings.bazelLaunchConfiguration(), "originalBazelDocument")
                        .isEqualTo(java.nio.file.Path.of("bazel launch.json").toAbsolutePath().normalize());
                    requireThat(settings.arguments(), "literalBazelArguments").isEqualTo(List.of("build", "a b", ""));
                    return 23;
                });
            requireThat(result, "originalBazelStatus").isEqualTo(23);
            requireThat(calls.get(), "oneBazelBoundary").isEqualTo(1);
        }
    }

    /** Rejects absent Mac Bazel authority before acquiring the native execution boundary. */
    @Test public void rejectsMissingMacBazelConfiguration()
    {
        var calls = new java.util.concurrent.atomic.AtomicInteger();
        List<String> arguments = options("bazel");
        arguments.subList(0, 2).clear();
        try (var scope = new com.holdmyspot.codexunleashed.tooling.DefaultToolingScope();
            var errors = new java.io.PrintStream(new java.io.ByteArrayOutputStream()))
        {
            int result = Scheduler.SharedSecrets.run(scope, arguments.toArray(String[]::new),
                System.in, System.out, errors, "Mac OS X", (services, settings) -> calls.incrementAndGet());
            requireThat(result, "missingBazelAuthority").isEqualTo(2);
            requireThat(calls.get(), "noNativeAcquisition").isEqualTo(0);
        }
    }

    /** Rejects custom Java streams before native Mac Bazel acquisition. */
    @Test public void rejectsMacBazelCustomStreams()
    {
        var calls = new java.util.concurrent.atomic.AtomicInteger();
        try (var scope = new com.holdmyspot.codexunleashed.tooling.DefaultToolingScope();
            var errors = new java.io.PrintStream(new java.io.ByteArrayOutputStream()))
        {
            int result = Scheduler.SharedSecrets.run(scope, options("bazel").toArray(String[]::new),
                System.in, System.out, errors, "Mac OS X", (services, settings) -> calls.incrementAndGet());
            requireThat(result, "customBazelStreams").isEqualTo(1);
            requireThat(calls.get(), "noStreamlessNativeAcquisition").isEqualTo(0);
        }
    }

    /** Dispatches the Linux Bazel boundary with the original services, document and literal arguments. */
    @Test public void dispatchesLinuxBazelAndPreservesStatus()
    {
        var calls = new java.util.concurrent.atomic.AtomicInteger();
        try (var scope = new com.holdmyspot.codexunleashed.tooling.DefaultToolingScope())
        {
            int result = Scheduler.SharedSecrets.run(scope, options("bazel").toArray(String[]::new),
                System.in, System.out, System.err, "Linux", (services, settings) ->
                {
                    calls.incrementAndGet();
                    requireThat(services == scope, "originalBorrowedServices").isTrue();
                    requireThat(settings.bazelLaunchConfiguration(), "originalBazelDocument")
                        .isEqualTo(java.nio.file.Path.of("bazel launch.json").toAbsolutePath().normalize());
                    requireThat(settings.arguments(), "literalBazelArguments").isEqualTo(List.of("build", "a b", ""));
                    return 23;
                });
            requireThat(result, "originalBazelStatus").isEqualTo(23);
            requireThat(calls.get(), "oneBazelBoundary").isEqualTo(1);
        }
    }

    /** Rejects absent Linux Bazel authority before acquiring the native execution boundary. */
    @Test public void rejectsMissingLinuxBazelConfiguration()
    {
        var calls = new java.util.concurrent.atomic.AtomicInteger();
        List<String> arguments = options("bazel");
        arguments.subList(0, 2).clear();
        try (var scope = new com.holdmyspot.codexunleashed.tooling.DefaultToolingScope();
            var errors = new java.io.PrintStream(new java.io.ByteArrayOutputStream()))
        {
            int result = Scheduler.SharedSecrets.run(scope, arguments.toArray(String[]::new),
                System.in, System.out, errors, "Linux", (services, settings) -> calls.incrementAndGet());
            requireThat(result, "missingBazelAuthority").isEqualTo(2);
            requireThat(calls.get(), "noNativeAcquisition").isEqualTo(0);
        }
    }

    /** Rejects custom Java streams before native Linux Bazel acquisition. */
    @Test public void rejectsLinuxBazelCustomStreams()
    {
        var calls = new java.util.concurrent.atomic.AtomicInteger();
        try (var scope = new com.holdmyspot.codexunleashed.tooling.DefaultToolingScope();
            var errors = new java.io.PrintStream(new java.io.ByteArrayOutputStream()))
        {
            int result = Scheduler.SharedSecrets.run(scope, options("bazel").toArray(String[]::new),
                System.in, System.out, errors, "Linux", (services, settings) -> calls.incrementAndGet());
            requireThat(result, "customBazelStreams").isEqualTo(1);
            requireThat(calls.get(), "noStreamlessNativeAcquisition").isEqualTo(0);
        }
    }

    /**
     * Supplies independent complete scheduling options and literal tool arguments.
     * @param tool selected build tool
     * @return mutable application argument list
     */
    private static List<String> options(String tool)
    {
        return new ArrayList<>(List.of("--bazel-launch-config", "bazel launch.json", "--tool", tool,
            "--workspace", ".", "--scratch", ".", "--frida-library", "frida.so", "--headroom-bytes", "0",
            "--max-jobs", "2", "--control-timeout-ms", "1000", "--", "build", "a b", ""));
    }
}
