package com.holdmyspot.codexunleashed.tooling;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import org.testng.annotations.Test;
import tools.jackson.databind.JsonNode;

import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/**
 * Exercises the read-only retention preview through the supported command dispatcher.
 */
public final class RetentionPreviewTest
{
	/**
	 * Creates preview tests.
	 */
	public RetentionPreviewTest()
	{
	}

	/**
	 * Protects the newest two stable releases and manifests associated with stable or main baselines.
	 */
	@Test
	public void previewsSharedAliasesAndProtectedBaselines()
	{
		String inventory = """
			{
			  "releases": [
			    {"tag_name":"rust-v0.9.0","draft":false,"prerelease":false},
			    {"tag_name":"rust-v0.10.0","draft":false,"prerelease":false},
			    {"tag_name":"rust-v0.8.0","draft":false,"prerelease":false},
			    {"tag_name":"rust-v0.12.0","draft":true,"prerelease":false},
			    {"tag_name":"rust-v0.11.0","draft":false,"prerelease":true}
			  ],
			  "protected_upstream_refs": ["rust-v0.1.0", "main", "main"],
			  "package_versions": [
			    {"id":1,"metadata":{"container":{"tags":["cargo-release-a-rust-v0.10.0"]}}},
			    {"id":2,"metadata":{"container":{"tags":["cargo-release-b-rust-v0.8.0","cargo-release-c-rust-v0.1.0"]}}},
			    {"id":3,"metadata":{"container":{"tags":["cargo-v3-target-parts-v2-partial","cargo-release-d-rust-v0.8.0"]}}},
			    {"id":4,"metadata":{"container":{"tags":["unrelated"]}}},
			    {"id":5,"metadata":{"container":{"tags":[]}}},
			    {"id":6,"metadata":{"container":{"tags":["cargo-release-e-rust-v0.9.0"]}}},
			    {"id":7,"metadata":{"container":{"tags":["cargo-release-f-main","cargo-v3-shared-partial"]}}},
			    {"id":8,"metadata":{"container":{"tags":["cargo-release-g-main-feature"]}}}
			  ]
			}
			""";
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		ByteArrayOutputStream diagnostics = new ByteArrayOutputStream();
		try (PrintStream out = new PrintStream(output, true, StandardCharsets.UTF_8);
			PrintStream err = new PrintStream(diagnostics, true, StandardCharsets.UTF_8))
		{
			int status = Main.run(new String[]{"preview-ghcr-retention"},
				new ByteArrayInputStream(inventory.getBytes(StandardCharsets.UTF_8)), out, err);
			requireThat(status, "status")
				.withContext(diagnostics.toString(StandardCharsets.UTF_8), "diagnostic")
				.isEqualTo(0);
		}
		JsonNode result;
		try (ToolingScope scope = new DefaultToolingScope())
		{
			result = scope.getLeaderJsonMapper().readTree(output.toString(StandardCharsets.UTF_8));
		}
		requireThat(result.path("retained_releases").toString(), "result")
			.isEqualTo("[\"rust-v0.10.0\",\"rust-v0.9.0\",\"rust-v0.1.0\",\"main\"]");
		requireThat(result.path("retained_version_ids").toString(), "result").isEqualTo("[1,2,6,7]");
		requireThat(result.path("obsolete_version_ids").toString(), "result").isEqualTo("[3,5,8]");
		requireThat(result.path("unmanaged_version_ids").toString(), "result").isEqualTo("[4]");
		requireThat(result.path("dry_run").asBoolean(), "result").isTrue();
	}

	/**
	 * Refuses malformed or incomplete inventory without emitting a partial deletion candidate list.
	 */
	@Test
	public void refusesInvalidInventoriesWithoutOutput()
	{
		assertRefused("{\"releases\":[]}", "No published stable upstream release");
		assertRefused("{\"releases\":null}", "must be an array: releases");
		assertRefused("{}", "must be an array: releases");
		assertRefused("{\"releases\":", "exactly one JSON object");
		String prefix = """
			{"releases":[{"tag_name":"rust-v0.10.0","draft":false,"prerelease":false}],
			 "protected_upstream_refs":[],"package_versions":
			""";
		assertRefused(prefix + "[{\"id\":1,\"metadata\":{\"container\":{}}}]}", "must be an array: tags");
		assertRefused(prefix + "[{\"id\":1,\"metadata\":{\"container\":{\"tags\":[]}}}," +
			"{\"id\":1,\"metadata\":{\"container\":{\"tags\":[]}}}]}", "Duplicate package version id: 1");
		assertRefused(prefix + "[{\"id\":1.0,\"metadata\":{\"container\":{\"tags\":[]}}}]}",
			"id must be a positive integer");
		String protectedReferencePrefix = """
			{"releases":[{"tag_name":"rust-v0.10.0","draft":false,"prerelease":false}],
			 "package_versions":[],"protected_upstream_refs":
			""";
		assertRefused(protectedReferencePrefix + "[\"main-feature\"]}",
			"Protected reference must be a stable upstream tag or main: main-feature");
		assertRefused(protectedReferencePrefix + "[\" main\"]}",
			"Protected reference must be a stable upstream tag or main:  main");
	}

	/**
	 * Runs an invalid inventory through the command and requires a diagnostic with no preview.
	 *
	 * @param inventory caller-supplied JSON
	 * @param expectedDiagnostic diagnostic fragment identifying the rejected constraint
	 */
	private static void assertRefused(String inventory, String expectedDiagnostic)
	{
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		ByteArrayOutputStream diagnostics = new ByteArrayOutputStream();
		try (PrintStream out = new PrintStream(output, true, StandardCharsets.UTF_8);
			PrintStream err = new PrintStream(diagnostics, true, StandardCharsets.UTF_8))
		{
			int status = Main.run(new String[]{"preview-ghcr-retention"},
				new ByteArrayInputStream(inventory.getBytes(StandardCharsets.UTF_8)), out, err);
			requireThat(status, "status").isEqualTo(1);
		}
		requireThat(output.size(), "output.size()").isEqualTo(0);
		requireThat(diagnostics.toString(StandardCharsets.UTF_8).contains(expectedDiagnostic), "diagnostics")
			.withContext(diagnostics.toString(StandardCharsets.UTF_8), "diagnostic")
			.isTrue();
	}
}
