#include <stdio.h>
#include <wchar.h>
#include <fcntl.h>
#include <io.h>
#include <windows.h>
/** Generates a small C compilation unit through the real authenticated action. */
int wmain(int argc, wchar_t **argv) {
  if (argc != 2) return 91;
  FILE *output = NULL;
  if (_wfopen_s(&output, argv[1], L"wb") != 0) return 92;
  if (!output) return 92;
  const char generated[] = "int generated_checkpoint_three(void) { return 23; }\n";
  if (fwrite(generated, 1, sizeof(generated)-1, output) != sizeof(generated)-1) return 93;
  if (fclose(output) != 0) return 94;
  _setmode(_fileno(stdout), _O_BINARY);
  _setmode(_fileno(stderr), _O_BINARY);
  const unsigned char out[] = {0, 255, 23, 10};
  const unsigned char err[] = {1, 254, 42, 10};
  if (fwrite(out, 1, sizeof(out), stdout) != sizeof(out)) return 95;
  if (fwrite(err, 1, sizeof(err), stderr) != sizeof(err)) return 96;
  wchar_t requested[3];
  return GetEnvironmentVariableW(L"CP3_EXIT", requested, 3) == 2 && wcscmp(requested, L"23") == 0 ? 23 : 0;
}
