package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import com.holdmyspot.codexunleashed.tooling.Sha256;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/** Runs the real Windows composition against an actual native source generator. */
public final class WindowsBazelConsumerNativeGate
{
    /** Prevents construction of this native acceptance command. */
    private WindowsBazelConsumerNativeGate() {}

    /**
     * Establishes explicit identities and executes the real public caller's Windows composition.
     * @param args existing owned native root, native Frida DLL and mode prepare, prepare23, run or run23
     * @throws IOException if fixture, native scheduling, output or cleanup fails
     */
    public static void main(String[] args) throws IOException
    {
        Path root = Path.of(args[0]).toAbsolutePath().normalize();
        Path frida = Path.of(args[1]).toAbsolutePath().normalize();
        Path work = root.resolve("connected-workspace"), scratch = root.resolve("connected-scratch");
        Path toolchain = root.resolve("action-toolchain"), profile = root.resolve("connected-profile.json");
        try (DefaultToolingScope scope = new DefaultToolingScope())
        {
            if (args[2].startsWith("prepare"))
            {
                Files.createDirectories(work);
                Files.createDirectories(scratch);
                Files.writeString(work.resolve("MODULE.bazel"), "module(name = 'windows_connected')\n");
                String executable = toolchain.resolve("generator.exe").toString().replace('\\', '/');
                String actionEnvironment = scope.getJsonMapper().writeValueAsString(Map.of(
                    "SystemRoot", System.getenv("SystemRoot"), "LOCALAPPDATA", System.getenv("LOCALAPPDATA"),
                    "CP3_EXIT", args[2].equals("prepare23") ? "23" : "0"));
                Files.writeString(work.resolve("defs.bzl"),
                    "def _generate(ctx):\n    out = ctx.actions.declare_file(ctx.label.name + '.c')\n" +
                    "    ctx.actions.run(executable = '" + executable + "', arguments = [out.path], outputs = [out], env = " + actionEnvironment + ", mnemonic = 'ConnectedGenerator')\n" +
                    "    return [DefaultInfo(files = depset([out]))]\ngenerate = rule(implementation = _generate)\n");
                Files.writeString(work.resolve("BUILD.bazel"), "load(':defs.bzl', 'generate')\ngenerate(name = 'useful')\n");
                Map<String, String> environment = new HashMap<>(System.getenv());
                for (String name : List.copyOf(environment.keySet()))
                    if (List.of("JAVA_TOOL_OPTIONS", "_JAVA_OPTIONS", "JDK_JAVA_OPTIONS").stream().anyMatch(name::equalsIgnoreCase))
                        environment.remove(name);
                Map<String, Object> document = new HashMap<>();
                document.put("schema", 1);
                document.put("distribution", root.resolve("products").toString());
                document.put("bazel", root.resolve("bazel.exe").toString());
                document.put("toolchainRoot", toolchain.toString());
                document.put("environment", environment);
                document.put("identities", Map.of("bazel", Sha256.digest(root.resolve("bazel.exe")),
                    "toolchain", LinuxCargoLaunchConfiguration.toolchainDigest(toolchain), "frida", Sha256.digest(frida),
                    "javaRuntime", Sha256.digest(Path.of(System.getProperty("java.home"), "lib", "modules"))));
                document.put("backendIdentity", "windows-connected-native-generator");
                document.put("casBytes", 67108864L);
                document.put("actionCacheBytes", 67108864L);
                document.put("cachePolicy", "UNCACHED_RECOVERY");
                Files.writeString(profile, scope.getJsonMapper().writeValueAsString(document));
                System.out.println("PREPARED actual Windows launch identities");
                return;
            }
            String[] command = {"--tool", "bazel", "--workspace", work.toString(), "--scratch", scratch.toString(),
                "--frida-library", frida.toString(), "--headroom-bytes", "0", "--max-jobs", "2", "--control-timeout-ms", "30000",
                "--bazel-launch-config", profile.toString(), "--", "--batch", "build", "//:useful", "--noshow_progress"};
            int status = WindowsBazelSchedule.run(scope, Scheduler.parse(command));
            if (args[2].equals("run23"))
            {
                requireThat(status, "originalBazelOrdinaryFailureStatus").isEqualTo(1);
                boolean original23 = false;
                try (var paths = Files.list(scratch))
                {
                    for (Path eventFile : paths.filter(path -> path.getFileName().toString().endsWith("-events.jsonl")).toList())
                        for (String line : Files.readAllLines(eventFile))
                        {
                            var event = scope.getJsonMapper().readTree(line);
                            if (event.path("event").asString().equals("action-result") &&
                                event.path("payload").path("exit").asInt() == 23) original23 = true;
                        }
                }
                requireThat(original23, "authenticOrdinary23ActionResponse").isTrue();
                System.out.println("PASS original action23 remains ordinary failure, original Bazel1 and cleanup");
                return;
            }
            requireThat(status, "originalBazelStatus").isEqualTo(0);
            requireThat(Files.readString(work.resolve("bazel-bin/useful.c")), "usefulGeneratedSource")
                .isEqualTo("int generated_checkpoint_three(void) { return 23; }\n");
            System.out.println("PASS connected useful native source generation, original Bazel zero and cleanup");
        }
    }
}
