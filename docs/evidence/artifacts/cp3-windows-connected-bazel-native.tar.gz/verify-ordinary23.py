"""Verify the latest ordinary failure had one original attempt and no memory retry."""
from pathlib import Path
import subprocess,sys,shlex,zlib,base64
root=Path(__file__).resolve().parent
code="from pathlib import Path;import json;p=max(Path('connected-scratch').glob('*-events.jsonl'),key=lambda p:p.stat().st_mtime_ns);e=[json.loads(s) for s in p.read_text().splitlines()];c=[x for x in e if x['event'] in ['attempt-started','blocked','attempt-rollback','action-result','terminal']];print(json.dumps(c));assert sum(x['event']=='attempt-started' for x in c)==1;assert not any(x['event'] in ['blocked','attempt-rollback'] for x in c)"
command='python3 -c '+shlex.quote("import zlib,base64;exec(zlib.decompress(base64.b64decode("+repr(base64.b64encode(zlib.compress(code.encode())).decode())+")))")
raise SystemExit(subprocess.run([sys.executable,str(root/('native2-'+sys.argv[1])/'remote.py'),command]).returncode)
