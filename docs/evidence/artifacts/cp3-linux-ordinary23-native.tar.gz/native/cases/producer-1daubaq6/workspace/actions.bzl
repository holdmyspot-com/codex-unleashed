def _run(ctx):
    output = ctx.actions.declare_file(ctx.label.name + ".o")
    ctx.actions.run(executable = "./thread-case", tools = [ctx.file.tool], outputs = [output], arguments = [], env = {"PATH": ".:/usr/bin:/bin", "LANG": "C.UTF-8", "HOME": "/tmp", "TMPDIR": "/tmp"}, mnemonic = "NativeOrdinaryRoot23")
    return [DefaultInfo(files = depset([output]))]
native_exit23 = rule(implementation = _run, attrs = {"tool": attr.label(allow_single_file = True)})
