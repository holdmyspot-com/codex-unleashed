"""Compile a genuine C object with the unchanged static Zig executable."""
def _compile(ctx):
    output = ctx.actions.declare_file(ctx.label.name + ".o")
    ctx.actions.run(
        executable = "./zig",
        tools = [ctx.file.zig],
        inputs = depset([ctx.file.source] + ctx.files.runtime),
        outputs = [output],
        arguments = ["cc", "-c", ctx.file.source.path, "-o", output.path],
        env = {"PATH": ".:/usr/bin:/bin", "LANG": "C.UTF-8", "HOME": "/tmp",
               "TMPDIR": "/tmp", "ZIG_GLOBAL_CACHE_DIR": "/tmp/zig-global",
               "ZIG_LOCAL_CACHE_DIR": "/tmp/zig-local"},
        mnemonic = "StaticZigCompile",
    )
    return [DefaultInfo(files = depset([output]))]
static_zig_compile = rule(implementation = _compile, attrs = {
    "zig": attr.label(allow_single_file = True),
    "source": attr.label(allow_single_file = True),
    "runtime": attr.label_list(allow_files = True),
})
