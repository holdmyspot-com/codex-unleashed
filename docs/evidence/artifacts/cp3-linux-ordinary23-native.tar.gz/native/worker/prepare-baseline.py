"""Compose exact accepted Java source over preserved native-compatible dependency payloads."""
from pathlib import Path
import os,subprocess,tarfile,zipfile,shutil,json,hashlib
w=Path(os.environ['CP3_WORK']);jdk=w/'zulu27.30.109-ca-jdk27.0.1.0.3-linux_x64';source=w/'source';source.mkdir()
with (w/'source.tar.gz').open('wb') as f:subprocess.run(['gh','api','repos/holdmyspot-com/codex-unleashed/tarball/5217d87166'],stdout=f,check=True)
with tarfile.open(w/'source.tar.gz') as t:
 members=t.getmembers();prefix=members[0].name.split('/')[0]
 for m in members:
  parts=Path(m.name).parts
  if len(parts)>1:
   m.name=str(Path(*parts[1:]));t.extract(m,source,filter='data')
base=w/'shared/public-dispatch/producer.jar';classes=w/'baseline-classes';classes.mkdir()
files=sorted(f for f in (source/'tooling/cli/src/main/java').rglob('*.java') if f.name!='module-info.java')
args=[str(jdk/'bin/javac'),'--release','27','-cp',str(base),'-d',str(classes)]+[str(f) for f in files]
with (w/'baseline-compile.log').open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0,(w/'baseline-compile.log').read_text()
with zipfile.ZipFile(base) as before,zipfile.ZipFile(w/'producer.jar','w',zipfile.ZIP_DEFLATED) as after:
 names={str(f.relative_to(classes)):f for f in classes.rglob('*.class')}
 for entry in before.infolist():
  if entry.filename not in names:after.writestr(entry,before.read(entry))
 for name,f in names.items():after.writestr(name,f.read_bytes())
(w/'baseline-composition.json').write_text(json.dumps({'baseline':'5217d87166','sourceCount':len(files),'command':args,'updatedClassCount':len(names),'baseJar':str(base),'jarSha256':hashlib.file_digest((w/'producer.jar').open('rb'),'sha256').hexdigest()},indent=2))
# Reuse exact seven validated products and immutable support libraries.
shutil.copytree(w/'shared/shared-staging/native-products',w/'backend')
for name in ['bin','packages','profile-frida']:shutil.copytree(w/'assets'/name,w/name)
# Fixture compilation is necessary because its predecessor executable was not published.
args=[str(w/'zig-linux-x86_64-0.14.0/zig'),'cc','-target','x86_64-linux-musl','-static','-O2',str(w/'terminal/ordinary-root.c'),'-o',str(w/'ordinary-root')]
with (w/'ordinary-fixture-compile.log').open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
print('baseline-ready',flush=True)
