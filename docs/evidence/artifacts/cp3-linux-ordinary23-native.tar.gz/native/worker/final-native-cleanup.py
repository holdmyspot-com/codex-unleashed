"""Verify owned native identities, whole-tree zero and compiler-free staged product equivalence."""
from pathlib import Path
import os,json,hashlib,stat
w=Path(os.environ['CP3_WORK']);base=w/'backend';stage=w/'maven-output/runtime/lib/bazel-backend/native';matches=[]
for f in base.rglob('*'):
 if f.is_file():
  other=stage/f.relative_to(base);a=hashlib.file_digest(f.open('rb'),'sha256').hexdigest();b=hashlib.file_digest(other.open('rb'),'sha256').hexdigest();assert a==b;(matches.append({'path':str(f.relative_to(base)),'sha256':a,'stagedEqual':True}))
assert len([r for r in matches if os.access(base/r['path'],os.X_OK)])==7
zero=[]
for p in Path('/sys/fs/cgroup/cp3-ordinary23-ENa0X9').rglob('cgroup.events'):
 values=dict(s.split() for s in p.read_text().splitlines());assert values['populated']=='0';zero.append({'path':str(p),'values':values})
zig=w/'zig-linux-x86_64-0.14.0/zig';digest=hashlib.file_digest(zig.open('rb'),'sha256').hexdigest();assert digest=='77340932066b76bc9f3a4ac120288f21790ed2836e5cd5a003f4a3c12f37d765'
receipt={'stagedProducts':matches,'cgroups':zero,'unchangedStaticZigSha256':digest,'ownedNativeResources':'all case cgroup trees zero; original Java identities absent per ordinary23-native-receipt; owned shell jobs explicitly waited','nativeBackendBuilds':0};(w/'final-native-cleanup.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
