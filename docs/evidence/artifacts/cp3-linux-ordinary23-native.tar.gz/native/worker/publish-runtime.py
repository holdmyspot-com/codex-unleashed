"""Seal consuming runtime and reused native products, without compiling native backends."""
from pathlib import Path
import os,json,tarfile,hashlib,subprocess,shutil,xml.etree.ElementTree as ET
w=Path(os.environ['CP3_WORK']);build=w/'maven-output';runtime=build/'runtime';assert (runtime/'.complete').is_file();result=json.loads((w/'consuming-maven-result.json').read_text());assert result['exit']==0
reports=[]
for f in (build/'surefire-reports').glob('TEST-*.xml'):
 root=ET.parse(f).getroot();reports.append({'name':root.attrib['name'],'tests':int(root.attrib['tests']),'failures':int(root.attrib['failures']),'errors':int(root.attrib['errors']),'skipped':int(root.attrib['skipped'])})
assert reports and sum(r['errors']+r['failures'] for r in reports)==0
cache=next(r for r in reports if r['name'].endswith('SourceInputCacheTest'));assert cache['tests']>=11 and cache['skipped']==0
commands=[[str(runtime/'bin/java'),'--list-modules'],[str(runtime/'bin/codex-tooling')],['rustc','--version'],['cargo','--version'],['mvn','-version']];checks=[]
for i,cmd in enumerate(commands):
 with (w/('runtime-check-'+str(i)+'.log')).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 checks.append({'command':cmd,'exit':r.returncode,'output':'runtime-check-'+str(i)+'.log'})
assert checks[0]['exit']==0 and 'com.holdmyspot.codexunleashed.tooling' in (w/'runtime-check-0.log').read_text();assert checks[1]['exit']==2
inventory=[]
for f in runtime.rglob('*'):
 if f.is_file() and not f.is_symlink():inventory.append({'path':str(f.relative_to(runtime)),'bytes':f.stat().st_size,'sha256':hashlib.file_digest(f.open('rb'),'sha256').hexdigest()})
(w/'runtime-inventory.json').write_text(json.dumps(inventory,indent=2));receipt={'maven':result,'tests':{'total':sum(r['tests'] for r in reports),'failures':0,'errors':0,'skipped':sum(r['skipped'] for r in reports),'sourceInputCache':cache},'checks':checks,'nativeBuilds':0,'complete':True,'sourceBoundary':'maintained5217 plus four-production ordinary23 repair; root packaging POM read-only input; original matching MainTest. Public Scheduler separately consumes accepted immutable artifact13101499426.'}
(w/'runtime-verification.json').write_text(json.dumps(receipt,indent=2));bundle=w/'ordinary23-runtime.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=1) as t:
 for f,n in [(runtime,'runtime'),(w/'backend','prebuilt-backend'),(w/'producer.jar','producer.jar'),(w/'producer-public.jar','producer-public.jar'),(w/'runtime-verification.json','runtime-verification.json'),(w/'runtime-inventory.json','runtime-inventory.json')]:t.add(f,arcname=n)
receipt['publication']={'name':'cp3-ordinary23-runtime-'+os.environ['GITHUB_RUN_ID'],'bundle':bundle.name,'bytes':bundle.stat().st_size,'sha256':hashlib.file_digest(bundle.open('rb'),'sha256').hexdigest()};(w/'runtime-publication.json').write_text(json.dumps(receipt,indent=2))
env=os.environ.copy();env['RUNNER_DEBUG']='0'
for k,v in {'name':receipt['publication']['name'],'path':str(bundle),'if-no-files-found':'error','retention-days':'3','compression-level':'0','overwrite':'false','include-hidden-files':'false','archive':'true'}.items():env['INPUT_'+k.upper()]=v
with (w/'runtime-upload.log').open('w') as out:r=subprocess.run([shutil.which('node'),'/home/runner/work/_actions/actions/upload-artifact/bbbca2ddaa5d8feaa63e36b76fdaad77386f024f/dist/upload/index.js'],env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,(w/'runtime-upload.log').read_text();print(json.dumps(receipt),flush=True);print((w/'runtime-upload.log').read_text()[-3500:])
