package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.locks.LockSupport;
import tools.jackson.databind.JsonNode;

import java.time.Duration;
import java.util.UUID;
import com.holdmyspot.codexunleashed.scheduler.LinuxBazelProducer.Configuration;
import com.holdmyspot.codexunleashed.scheduler.LinuxBazelProducer.Runtime;
import com.holdmyspot.codexunleashed.scheduler.LinuxBazelProducer.Audit;

/**
 * Evaluation-only production composition for authentic signal delivery and held-denial cancellation.
 * Fixture-only modes retain the genuine backend, action, queue and original native parent.
 */
final class NativeTerminalNoRetryCase
{
    /** Prevents construction of this evaluation entry point. */
    private NativeTerminalNoRetryCase() {}

    /**
     * Runs the genuine scheduler with the selected synchronous external controller boundary.
     * @param arguments profile, fresh control directory, fixture mode, then ordinary scheduler arguments
     * @throws IOException if configuration, execution, evidence or acknowledged cleanup fails
     */
    public static void main(String[] arguments) throws IOException
    {
        if (arguments.length < 4) throw new IllegalArgumentException("profile control-directory SIGNAL|CANCEL|EXEC23 scheduler-arguments");
        Path control = Path.of(arguments[1]);
        if (!control.isAbsolute()) throw new IllegalArgumentException("Control directory must be absolute");
        Files.createDirectory(control);
        Files.setPosixFilePermissions(control, PosixFilePermissions.fromString("rwx------"));
        Scheduler.Settings settings = Scheduler.parse(Arrays.copyOfRange(arguments, 3, arguments.length));
        if (!settings.tool().equals("bazel")) throw new IllegalArgumentException("Bazel scheduler required");
        Mode mode = Mode.valueOf(arguments[2]);
        int result;
        try (ToolingScope scope = new DefaultToolingScope())
        {
            try
            {
                result = run(scope, LinuxBazelProducer.configuration(scope, settings, Path.of(arguments[0])),
                    System.out, System.err, control, mode);
                if (mode == Mode.CANCEL) throw new IOException("Expected interruption did not occur");
            }
            catch (ExpectedCancellation cancellation)
            {
                if (mode != Mode.CANCEL || !Thread.currentThread().isInterrupted()) throw cancellation;
                result = 0;
            }
        }
        System.exit(result);
    }

    /**
     * Retains every original resource and scope until cleanup actually acknowledges retirement.
     * @param ownership exact original acquisition owner
     * @param failure first cleanup failure
     */
    private static void retire(Ownership ownership, Throwable failure)
    {
        System.err.println("Fixture retains original resources after cleanup failure: " + failure);
        boolean interrupted = Thread.interrupted();
        try
        {
            for (;;)
            {
                try { ownership.close(); return; }
                catch (IOException | RuntimeException | Error retry)
                {
                    System.err.println("Fixture cleanup still pending: " + retry);
                    LockSupport.parkNanos(1_000_000_000L);
                    interrupted |= Thread.interrupted();
                }
            }
        }
        finally { if (interrupted) Thread.currentThread().interrupt(); }
    }

    /**
     * Composes the same backend, runner, original invocation, policy and coordinator as production.
     * @param scope retained Pouch scope
     * @param configuration actual trusted production profile
     * @param out borrowed original stdout
     * @param err borrowed original stderr
     * @param control freshly owned external handshake directory
     * @param mode fixture-only terminal scenario
     * @return actual original consumer result
     * @throws IOException on actual acquisition, execution or evidence failure
     */
    static int run(ToolingScope scope, Configuration configuration, PrintStream out, PrintStream err, Path control, Mode mode) throws IOException
    {
        Objects.requireNonNull(out, "out");
        Objects.requireNonNull(err, "err");
        Scheduler.Settings settings = configuration.settings();
        Runtime runtime = configuration.runtime();
        Path invocation = Files.createTempDirectory(settings.scratch(), "bazel-producer-");
        Files.setPosixFilePermissions(invocation, PosixFilePermissions.fromString("rwx--x--x"));
        Path backendRoot = Files.createDirectory(invocation.resolve("backend-root"));
        Files.setPosixFilePermissions(backendRoot, PosixFilePermissions.fromString("rwx------"));
        Path buildRoot = Files.createDirectory(backendRoot.resolve("worker-builds"));
        Files.setPosixFilePermissions(buildRoot, PosixFilePermissions.fromString("rwx------"));
        Files.setAttribute(buildRoot, "unix:uid", runtime.trustedUid());
        Files.setAttribute(buildRoot, "unix:gid", runtime.trustedGid());
        LinuxBazelBackend.Credentials credentials = LinuxBazelBackend.Credentials.generate(
            backendRoot.resolve("credentials"), runtime.javaExecutable().getParent().resolve("keytool"));
        for (Path path : credentials.paths())
        {
            Files.setAttribute(path, "unix:uid", runtime.trustedUid());
            Files.setAttribute(path, "unix:gid", runtime.trustedGid());
        }
        Files.setAttribute(backendRoot.resolve("credentials"), "unix:uid", runtime.trustedUid());
        Files.setAttribute(backendRoot.resolve("credentials"), "unix:gid", runtime.trustedGid());
        Files.setAttribute(backendRoot, "unix:uid", runtime.trustedUid());
        Files.setAttribute(backendRoot, "unix:gid", runtime.trustedGid());
        LinuxBazelRunner runner = new LinuxBazelRunner(buildRoot, new LinuxBazelRunner.Credentials(credentials.certificateAuthority(),
            credentials.serverCertificate(), credentials.serverKey(), credentials.workerCertificate()));
        Audit audit = new Audit(scope, invocation.resolve("producer-events.jsonl"));
        Ownership ownership = new Ownership(scope, runner, audit);
        ControlledObserver observer = new ControlledObserver(scope, audit, control, settings.controlTimeout(), mode);
        try
        {
            audit.record("invocation", Map.of("arguments", settings.arguments(),
                "workspace", settings.workspace().toString(), "backendIdentity", runtime.backendIdentity(),
                "cachePolicy", configuration.cachePolicy().name(), "jobs", settings.budget().jobs()));
            runner.start();
            LinuxBazelBackend.Configuration backendSettings = new LinuxBazelBackend.Configuration(configuration.distribution(), backendRoot,
                runner.endpoint(), credentials, settings.budget().jobs(), runtime.trustedUid(), runtime.trustedGid(),
                configuration.casBytes(), configuration.actionCacheBytes(), configuration.cachePolicy());
            try { ownership.backend = LinuxBazelBackend.start(scope, backendSettings, ownership::closeActions, runner.workerReadiness()); }
            catch (LinuxBazelBackend.AcquisitionFailure failure)
            {
                ownership.backend = failure.backend();
                throw failure;
            }
            Path launcher = LinuxBazelProducer.bazelLauncher(invocation.resolve("bazel"), configuration.bazelExecutable(),
                ownership.backend.startupRc());
            Map<String, String> environment = new HashMap<>(configuration.environment());
            environment.put("CODEX_BAZEL_BIN", launcher.toString());
            List<String> command = new ArrayList<>(settings.arguments());
            Path selected = executable(command.getFirst(), environment, settings.workspace());
            if (Files.isSameFile(selected, configuration.bazelExecutable())) selected = launcher;
            command.set(0, selected.toString());
            Path stdout = invocation.resolve("consumer.stdout");
            Path stderr = invocation.resolve("consumer.stderr");
            LinuxProcessTree.Launch launch = new LinuxProcessTree.Launch(runtime.cgroupParent(), invocation, runtime.javaExecutable(),
                runtime.classPath(), command, environment, settings.workspace(), runtime.trustedUid(), runtime.trustedGid());
            LinuxProcessTree.StandardFiles files = new LinuxProcessTree.StandardFiles(Path.of("/dev/null"), stdout, stderr);
            LinuxAuthority.Settings authority = new LinuxAuthority.Settings(runtime.javaExecutable(), runtime.unshare(), runtime.libcgroup(),
                invocation, Path.of("/sys/fs/cgroup"), Path.of("/proc"), runtime.cgroupParent(), runtime.helperParent(),
                settings.controlTimeout());
            ownership.original = new LinuxBazelInvocation(scope, new LinuxBazelInvocation.ProductionConfiguration(runner, launch,
                files, authority, invocation, runtime, settings.controlTimeout(), observer));
            ownership.original.start();
            SchedulerCoordinator<LinuxBazelControl.Result> coordinator = new SchedulerCoordinator<>(ownership.original.session(), settings.budget(),
                () -> LockSupport.parkNanos(1_000_000), observer);
            int result = coordinator.run();
            ownership.close();
            audit.verify();
            observer.verify();
            copy(stdout, out);
            copy(stderr, err);
            return result;
        }
        catch (IOException | RuntimeException | Error cause)
        {
            try { ownership.close(); }
            catch (IOException | RuntimeException | Error cleanup)
            {
                if (cleanup != cause) cause.addSuppressed(cleanup);
            }
            cause.printStackTrace(System.err);
            throw cause;
        }
    }

    /** Retains original resources in the same cleanup order as production. */
    private static final class Ownership implements AutoCloseable
    {
        /** Original shared runtime scope; caller must retain it while this owner remains live. */
        private final ToolingScope scope;
        /** Exact authenticated service, also retained when binding fails. */
        private final LinuxBazelRunner runner;
        /** Durable evidence outside action roots, closed only after the native owners. */
        private final Audit audit;
        /** Exact backend after acknowledged successful acquisition. */
        private LinuxBazelBackend backend;
        /** Original independent Bazel root and every transferred native action lease. */
        private LinuxBazelInvocation original;
        /** Indicates every original resource acknowledged closure. */
        private boolean closed;

        /**
         * Retains pre-acquisition owners before a native operation can fail.
         * @param scope borrowed original Pouch scope
         * @param runner original service owner
         * @param audit retained durable event writer
         */
        private Ownership(ToolingScope scope, LinuxBazelRunner runner, Audit audit)
        {
            this.scope = scope;
            this.runner = runner;
            this.audit = audit;
        }

        /**
         * Withdraws admission and closes the original consumer/actions before backend termination.
         * @throws IOException if native actions retain namespace, helper or containment ownership
         */
        private void closeActions() throws IOException
        {
            runner.stopAccepting();
            if (original != null) original.close();
        }

        /**
         * Closes dependencies only after complete original action cleanup succeeds.
         * @throws IOException if any original cleanup lease remains unresolved
         */
        @Override public void close() throws IOException
        {
            if (closed) return;
            closeActions();
            if (backend != null) backend.close();
            runner.close();
            audit.record("owned-cleanup", Map.of("complete", true));
            audit.close();
            closed = true;
        }
    }

    /**
     * Resolves the unchanged original consumer executable.
     * @param value caller executable
     * @param environment original environment
     * @param directory original cwd
     * @return existing direct executable
     * @throws IOException if unavailable
     */
    private static Path executable(String value, Map<String, String> environment, Path directory) throws IOException
    {
        if (value.contains("/"))
        {
            Path path = directory.resolve(value).normalize();
            if (Files.isRegularFile(path) && Files.isExecutable(path)) return path.toRealPath();
        }
        else
            for (String entry : environment.getOrDefault("PATH", "").split(":", -1))
            {
                Path path = directory.resolve(entry).resolve(value).normalize();
                if (Files.isRegularFile(path) && Files.isExecutable(path)) return path.toRealPath();
            }
        throw new IOException("Original consumer executable is unavailable: " + value);
    }

    /**
     * Copies a collected stream while retaining the caller stream.
     * @param path original collected stream
     * @param output borrowed caller stream
     * @throws IOException on read failure
     */
    private static void copy(Path path, PrintStream output) throws IOException
    {
        try (java.io.InputStream input = Files.newInputStream(path)) { input.transferTo(output); }
    }

    /** Explicit evaluation modes; none is exposed as a product option. */
    private enum Mode
    {
        /** Deliver a real SIGTRAP to the independently authenticated contained static task. */
        SIGNAL,
        /** Interrupt the coordinator while a genuine denied return remains held. */
        CANCEL,
        /** Observe authentic original nonleader exec exit23 through the production invocation. */
        EXEC23
    }

    /** Expected interruption after independent held-denial verification. */
    private static final class ExpectedCancellation extends java.io.InterruptedIOException
    {
        /** Stable serialization identity for the checked interruption subtype. */
        private static final long serialVersionUID = 1L;

        /** Creates the fixture boundary failure consumed by ordinary coordinator cleanup. */
        private ExpectedCancellation() { super("Fixture coordinator interrupted with native denied return held"); }
    }

    /** Owner-thread evidence decorator; no synthetic submissions, denials or completions. */
    private static final class ControlledObserver implements SchedulerCoordinator.Observer
    {
        /** Borrowed scope mapper. */
        private final tools.jackson.databind.json.JsonMapper mapper;
        /** Original durable production audit. */
        private final Audit audit;
        /** Controller files outside every action namespace. */
        private final Path control;
        /** Existing production external-control deadline. */
        private final Duration timeout;
        /** Exact selected logical action, captured before its initial CREATE. */
        private String selected;
        /** First controller-authenticated original waiter identity. */
        private JsonNode capped;
        /** Explicit fixture-only terminal scenario. */
        private final Mode mode;
        /** Whether genuine SIGNAL5 was copied from the original native completion. */
        private boolean signalObserved;
        /** Whether controller verification preceded cancellation. */
        private boolean cancellationRequested;
        /** Actual mapped-attempt count for the selected exit23 action. */
        private int execMappings;
        /** Actual non-aborted native exit23 completions observed before original delivery. */
        private int execCompletions;
        /** Actual output publication events for the selected exit23 action. */
        private int execPublications;

        /**
         * Retains shared evidence and an explicit controller boundary.
         * @param scope original Pouch scope
         * @param audit real production evidence writer
         * @param control owned controller directory
         * @param timeout existing production control timeout
         * @param mode fixture-only terminal scenario
         */
        private ControlledObserver(ToolingScope scope, Audit audit, Path control, Duration timeout, Mode mode)
        {
            mapper = scope.getJsonMapper();
            this.audit = audit;
            this.control = control;
            this.timeout = timeout;
            this.mode = mode;
        }

        @Override public void record(String event, Object payload) throws IOException
        {
            audit.record(event, payload);
            if (event.equals("attempt-mapped") && selected == null)
            {
                if (!(payload instanceof Map<?, ?> fields) || !(fields.get("name") instanceof String name))
                    throw new IOException("Production attempt mapping lacks its action identity");
                selected = name;
                if (mode == Mode.CANCEL) capped = handshake("cap", payload, "209715200");
            }
            if (mode == Mode.EXEC23)
            {
                if (event.equals("attempt-mapped") && payload instanceof Map<?, ?> fields &&
                    selected != null && selected.equals(fields.get("name")))
                {
                    execMappings = Math.incrementExact(execMappings);
                    if (execMappings != 1) throw new IOException("Original exit23 action was retried");
                }
                if (event.equals("publication") && payload instanceof Map<?, ?> fields &&
                    selected != null && selected.equals(fields.get("name")))
                {
                    if (!Boolean.FALSE.equals(fields.get("published")))
                    {
                        execPublications = Math.incrementExact(execPublications);
                        throw new IOException("Original failed exit23 action published output or lacks its no-publication receipt");
                    }
                }
                if (event.equals("completion-before") && payload instanceof JobQueue.Completion<?> completion &&
                    completion.name().equals(selected))
                {
                    execCompletions = Math.incrementExact(execCompletions);
                    if (execCompletions != 1 || completion.outcome().aborted() ||
                        !(completion.outcome().result() instanceof LinuxBazelControl.Result result) ||
                        result.signaled() || result.status() != 23)
                        throw new IOException("Original native completion did not preserve exactly one ordinary exit23");
                }
            }
            if (mode == Mode.SIGNAL && event.equals("authenticated-hooks-ready-original-resumed") &&
                payload instanceof Map<?, ?> fields && selected != null && selected.equals(fields.get("name")))
                handshake("signal", payload, "unchanged");
            if (mode == Mode.SIGNAL && event.equals("completion-before") &&
                payload instanceof JobQueue.Completion<?> completion && completion.name().equals(selected))
            {
                if (completion.outcome().aborted() ||
                    !(completion.outcome().result() instanceof LinuxBazelControl.Result result) ||
                    !result.signaled() || result.status() != 5)
                    throw new IOException("Original native completion did not preserve genuine SIGNAL5");
                signalObserved = true;
            }
            if (mode == Mode.CANCEL && event.equals("blocked") &&
                payload instanceof SchedulerCoordinator.Blocked blocked && blocked.name().equals(selected))
            {
                JsonNode acknowledgment = handshake("held", Map.of("name", blocked.name(),
                    "attemptSequence", blocked.attemptSequence(), "waitSequence", blocked.waitSequence(),
                    "originalWaiter", capped), "209715200");
                if (acknowledgment.path("pid").asLong() != capped.path("pid").asLong() ||
                    acknowledgment.path("birthTicks").asLong() != capped.path("birthTicks").asLong() ||
                    !acknowledgment.path("deniedReturnHeld").asBoolean())
                    throw new IOException("Controller did not verify original waiter and real held denial");
                cancellationRequested = true;
                audit.record("fixture-cancellation-requested", Map.of("name", selected,
                    "attemptSequence", blocked.attemptSequence(), "waitSequence", blocked.waitSequence()));
                Thread.currentThread().interrupt();
                throw new ExpectedCancellation();
            }
        }

        /**
         * Publishes one CREATE_NEW request and waits for a matching external acknowledgment.
         * @param phase cap, real signal delivery, or verification of a genuine held denied return
         * @param context copied actual production event
         * @param soft required soft address-space limit in bytes, or unchanged for signal delivery
         * @return controller's authenticated original waiter receipt
         * @throws IOException if deadline, acknowledgment or independent receipt validation fails
         */
        private JsonNode handshake(String phase, Object context, String soft) throws IOException
        {
            String nonce = UUID.randomUUID().toString();
            Map<String, Object> request = Map.of("phase", phase, "nonce", nonce,
                "softAddressSpace", soft, "hardAddressSpace", phase.equals("signal") ? "unchanged" : "unlimited", "context", context);
            Path requestFile = control.resolve(phase + ".request.json");
            Path acknowledgmentFile = control.resolve(phase + ".ack.json");
            Path pending = control.resolve(phase + ".request.pending");
            Files.writeString(pending, mapper.writeValueAsString(request), StandardOpenOption.CREATE_NEW);
            Files.move(pending, requestFile, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            audit.record("controller-request", request);
            long start = System.nanoTime();
            while (!Files.isRegularFile(acknowledgmentFile, LinkOption.NOFOLLOW_LINKS))
            {
                if (Thread.currentThread().isInterrupted()) throw new IOException("Controller wait interrupted");
                if (System.nanoTime() - start >= timeout.toNanos())
                    throw new IOException("Controller acknowledgment timed out: " + phase);
                LockSupport.parkNanos(1_000_000L);
            }
            JsonNode acknowledgment = mapper.readTree(Files.readString(acknowledgmentFile));
            if (!acknowledgment.path("nonce").asString().equals(nonce) ||
                !acknowledgment.path("phase").asString().equals(phase) ||
                !acknowledgment.path("softAddressSpace").asString().equals(soft) ||
                !acknowledgment.path("hardAddressSpace").asString().equals(
                    phase.equals("signal") ? "unchanged" : "unlimited") ||
                !acknowledgment.path("independentlyAuthenticated").asBoolean() ||
                acknowledgment.path("pid").asLong() <= 0 || acknowledgment.path("birthTicks").asLong() <= 0)
                throw new IOException("Controller acknowledgment lacks matching authenticated native-limit receipt");
            if (phase.equals("signal") && (!acknowledgment.path("signalSent").asBoolean() ||
                acknowledgment.path("signal").asInt() != 5 ||
                acknowledgment.path("containedTaskPid").asLong() <= 0 ||
                acknowledgment.path("containedTaskBirthTicks").asLong() <= 0))
                throw new IOException("Controller did not authenticate and signal the actual contained static task");
            audit.record("controller-acknowledgment", acknowledgment);
            return acknowledgment;
        }

        /**
         * Requires the selected genuine terminal observation after all native ownership has retired.
         * @throws IOException if this execution did not exercise the selected terminal scenario
         */
        private void verify() throws IOException
        {
            if (mode == Mode.SIGNAL && !signalObserved)
                throw new IOException("No original SIGNAL5 completion was observed");
            if (mode == Mode.CANCEL && !cancellationRequested)
                throw new IOException("No held-denial cancellation was requested");
            if (mode == Mode.EXEC23 && (execMappings != 1 || execCompletions != 1 || execPublications != 0))
                throw new IOException("Incomplete original exit23 observation or unexpected retry/publication");
        }
    }
}
