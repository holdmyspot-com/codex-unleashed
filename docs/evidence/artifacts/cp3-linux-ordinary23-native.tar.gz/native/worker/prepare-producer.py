"""Prepare one root-owned Linux x64 producer fixture; do not execute native work.

Usage: sudo python3 prepare-producer.py INPUT.json
INPUT supplies taskRoot (existing root-owned /var/lib task directory), jdk (JDK27
directory), jar (completed producer fat JAR), distribution (existing seven-binary
backend with backend-manifest.json), bazel, zigRoot (Zig0.14.0 with zig and lib),
frida (pinned library file), libcgroup (installed libcgroup library), cgroupRoot
(delegated empty parent with memory enabled), trustedUid/trustedGid and distinct
actionUid/actionGid. All source paths must already exist. No native build occurs.

Creates a fresh producer-* child, copies immutable runtime inputs, creates a
minimal actual Zig compilation workspace and fresh actions/helpers cgroup roots,
and writes profile.json plus command.json. The caller owns these retained inputs
until native acceptance and acknowledged process/cgroup cleanup finish. On setup
failure ownership.json retains the cleanup locations; nothing is silently removed.
Run command.json's argv as root with its environment and cwd, retaining its authentic
exit status. Then run check-output.py with the new child path. That check proves
only successful object publication; denial/retry requires the producer event log.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import sys
import tempfile
import subprocess


def digest(path):
    """Return SHA256 of one supplied regular file without loading it all at once."""
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def seal(path):
    """Match LinuxBazelNamespaceHooks.seal for a symlink-free immutable tree."""
    path = Path(path)
    if path.is_file():
        return digest(path)
    work = Path(os.environ['CP3_WORK'])
    java = work / 'zulu27.30.109-ca-jdk27.0.1.0.3-linux_x64/bin/java'
    classpath = str(work / 'fixture-classes') + ':' + str(work / 'producer.jar')
    return subprocess.check_output([str(java), '-cp', classpath,
        'com.holdmyspot.codexunleashed.scheduler.SealTree', str(path)], text=True).strip()


def trusted(path):
    """Reject symbolic, mutable or non-root-owned ancestry before privileged use."""
    for entry in [path, *path.parents]:
        value = entry.lstat()
        if stat.S_ISLNK(value.st_mode) or value.st_uid != 0 or value.st_mode & 0o022:
            raise ValueError('Untrusted pathname: ' + str(entry))


def copy_file(source, target):
    """Copy an existing input byte-for-byte and retain executable permission."""
    shutil.copy2(source, target, follow_symlinks=True)
    os.chown(target, 0, 0)
    target.chmod(target.stat().st_mode & ~0o022)
    if digest(source) != digest(target):
        raise ValueError('Copied input differs: ' + str(source))


def main():
    """Create the fresh fixture from the explicit JSON input and print its handoff."""
    if os.getuid() != 0:
        raise ValueError('Preparation requires root')
    config = json.loads(Path(sys.argv[1]).read_text())
    task = Path(config['taskRoot'])
    if not task.is_absolute() or task.resolve() != task or not task.is_relative_to('/var/lib'):
        raise ValueError('taskRoot must be a canonical existing /var/lib task directory')
    trusted(task)
    tu, tg, au, ag = [int(config[key]) for key in
        ['trustedUid', 'trustedGid', 'actionUid', 'actionGid']]
    if min(tu, tg, au, ag) <= 0 or tu == au:
        raise ValueError('Backend and action require distinct positive UIDs')
    root = Path(tempfile.mkdtemp(prefix='producer-', dir=task))
    root.chmod(0o755)
    cgroup = Path(config['cgroupRoot']) / root.name
    ownership = {'root': str(root), 'cgroup': str(cgroup),
        'owner': 'linux_static_java_trace', 'state': 'setup-in-progress',
        'cleanup': 'Retain until native owners are collected and cgroup populated=0; remove only this fresh root and its empty cgroup descendants.'}
    (root / 'ownership.json').write_text(json.dumps(ownership, indent=2) + '\n')
    runtime = root / 'runtime'
    runtime.mkdir()
    shutil.copytree(config['jdk'], runtime / 'jdk', symlinks=False)
    copy_file(Path(config['jar']), runtime / 'producer.jar')
    copy_file(Path(config['frida']), runtime / 'libfrida-core.so')
    distribution = runtime / 'backend'
    distribution.mkdir()
    original = Path(config['distribution'])
    manifest = json.loads((original / 'backend-manifest.json').read_text())
    names = {'bb_storage', 'bb_scheduler', 'bb_worker', 'linux-bazel-action-owner',
        'linux-bazel-action-waiter', 'codex-tooling', 'codex-cargo-wrapper-linux'}
    if set(manifest['executables']) != names:
        raise ValueError('Distribution executable set differs')
    for name in sorted(names):
        item = manifest['executables'][name]
        if item['path'] != name or digest(original / name) != item['sha256']:
            raise ValueError('Distribution manifest mismatch: ' + name)
        copy_file(original / name, distribution / name)
        with (distribution / name).open('rb') as stream:
            header = stream.read(64)
        if header[:6] != b'\x7fELF\x02\x01' or int.from_bytes(header[18:20], 'little') != 62:
            raise ValueError('Expected native little-endian x86-64 ELF: ' + name)
    copy_file(original / 'backend-manifest.json', distribution / 'backend-manifest.json')
    copy_file(Path(config['bazel']), runtime / 'bazel')
    for entry in [runtime, *runtime.rglob('*')]:
        if entry.is_symlink():
            raise ValueError('Runtime copy contains a symbolic link: ' + str(entry))
        os.chown(entry, 0, 0)
        entry.chmod(entry.stat().st_mode & ~0o022)
    workspace = root / 'workspace'
    workspace.mkdir()
    copy_file(Path(config['zigRoot']) / 'zig', workspace / 'zig')
    shutil.copytree(Path(config['zigRoot']) / 'lib', workspace / 'lib', symlinks=False)
    (workspace / 'MODULE.bazel').write_text('module(name = "static_zig_producer")\n')
    (workspace / 'tiny.c').write_text('int answer(void) { return 42; }\n')
    (workspace / 'actions.bzl').write_text('''"""Compile a genuine C object with the unchanged static Zig executable."""
def _compile(ctx):
    output = ctx.actions.declare_file(ctx.label.name + ".o")
    ctx.actions.run(
        executable = "./zig",
        tools = [ctx.file.zig],
        inputs = depset([ctx.file.source] + ctx.files.runtime),
        outputs = [output],
        arguments = ["cc", "-c", ctx.file.source.path, "-o", output.path],
        env = {"PATH": ".:/usr/bin:/bin", "LANG": "C.UTF-8", "HOME": "/tmp",
               "TMPDIR": "/tmp", "ZIG_GLOBAL_CACHE_DIR": "/tmp/zig-global",
               "ZIG_LOCAL_CACHE_DIR": "/tmp/zig-local"},
        mnemonic = "StaticZigCompile",
    )
    return [DefaultInfo(files = depset([output]))]
static_zig_compile = rule(implementation = _compile, attrs = {
    "zig": attr.label(allow_single_file = True),
    "source": attr.label(allow_single_file = True),
    "runtime": attr.label_list(allow_files = True),
})
''')
    (workspace / 'BUILD.bazel').write_text('''load(":actions.bzl", "static_zig_compile")
static_zig_compile(name = "tiny", zig = "zig", source = "tiny.c", runtime = glob(["lib/**"]))
''')
    for entry in [workspace, *workspace.rglob('*')]:
        os.chown(entry, tu, tg)
    for name in ['home', 'consumer-tmp', 'bazel-user', 'bazel-output']:
        entry = root / name
        entry.mkdir()
        os.chown(entry, tu, tg)
        entry.chmod(0o755)
    scratch = root / 'scratch'
    scratch.mkdir(mode=0o755)
    parent = Path(config['cgroupRoot'])
    if 'memory' not in (parent / 'cgroup.subtree_control').read_text().split():
        raise ValueError('cgroupRoot must already delegate memory; do not mutate shared ancestors')
    cgroup.mkdir()
    (cgroup / 'cgroup.subtree_control').write_text('+memory')
    for name in ['actions', 'helpers']:
        entry = cgroup / name
        entry.mkdir()
        (entry / 'cgroup.subtree_control').write_text('+memory')
    # glibc waiter and JDK use the system loader/libraries. Bind canonical sources
    # at their original ABI names; action inputs and /tmp remain privately mapped.
    libraries = Path('/usr/lib/x86_64-linux-gnu').resolve(strict=True)
    loader = Path('/lib64/ld-linux-x86-64.so.2').resolve(strict=True)
    bindings = [{'source': str(runtime), 'target': str(runtime)},
        {'source': str(libraries), 'target': '/usr/lib/x86_64-linux-gnu'},
        {'source': str(libraries), 'target': '/lib/x86_64-linux-gnu'},
        {'source': str(loader), 'target': '/lib64/ld-linux-x86-64.so.2'}]
    for name in ['null', 'zero', 'random', 'urandom']:
        bindings.append({'source': '/dev/' + name, 'target': '/dev/' + name})
    java = runtime / 'jdk/bin/java'
    jar = runtime / 'producer.jar'
    nsenter = Path('/usr/bin/nsenter').resolve(strict=True)
    unshare = Path('/usr/bin/unshare').resolve(strict=True)
    profile = {'schema': 1, 'java': str(java), 'classpath': str(jar),
        'runtimeRoot': str(runtime), 'runtimeRootSha256': seal(runtime),
        'javaSha256': seal(java), 'classpathSha256': seal(jar),
        'nsenter': str(nsenter), 'nsenterSha256': seal(nsenter),
        'unshare': str(unshare), 'fridaSha256': seal(runtime / 'libfrida-core.so'),
        'libcgroup': str(Path(config['libcgroup']).resolve(strict=True)),
        'cgroupParent': str(cgroup / 'actions'), 'helperParent': str(cgroup / 'helpers'),
        'actionOwner': str(distribution / 'linux-bazel-action-owner'),
        'distribution': str(distribution), 'bazel': str(runtime / 'bazel'),
        'bindings': bindings, 'trustedUid': tu, 'trustedGid': tg,
        'actionUid': au, 'actionGid': ag,
        'backendIdentity': digest(distribution / 'backend-manifest.json'),
        'casBytes': 8589934592, 'actionCacheBytes': 67108864,
        'cachePolicy': 'UNCACHED_RECOVERY'}
    profile_path = root / 'profile.json'
    profile_path.write_text(json.dumps(profile, indent=2) + '\n')
    profile_path.chmod(0o600)
    environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8',
        'HOME': str(root / 'home'), 'TMPDIR': str(root / 'consumer-tmp')}
    argv = [str(java), '--enable-native-access=ALL-UNNAMED', '-cp', str(jar),
        'com.holdmyspot.codexunleashed.scheduler.LinuxBazelProducer', str(profile_path),
        '--tool', 'bazel', '--workspace', str(workspace), '--scratch', str(scratch),
        '--frida-library', str(runtime / 'libfrida-core.so'), '--headroom-bytes', '268435456',
        '--max-jobs', '2', '--control-timeout-ms', '30000', '--',
        str(runtime / 'bazel'), '--batch', '--output_user_root=' + str(root / 'bazel-user'),
        '--output_base=' + str(root / 'bazel-output'), 'build', '--enable_bzlmod',
        '--enable_workspace=false', '--repository_cache=' + str(root / 'home/repository-cache'),
        '//:tiny']
    (root / 'command.json').write_text(json.dumps({'argv': argv,
        'environment': environment, 'cwd': str(workspace)}, indent=2) + '\n')
    ownership['state'] = 'prepared-native-execution-unrun'
    ownership['prerequisites'] = ['Producer candidate accepts native x64 manifest target and ELF machine62',
        'libcgroup dependency is provisioned and namespace prerequisites are enabled',
        'Candidate static tracer and denial/retry controls are installed in the supplied JAR']
    (root / 'ownership.json').write_text(json.dumps(ownership, indent=2) + '\n')
    print(json.dumps({'root': str(root), 'profile': str(profile_path),
        'command': str(root / 'command.json'), 'zigSha256': digest(workspace / 'zig'),
        'nativeExecution': 'unrun'}))


if __name__ == '__main__':
    main()
