"""Retain complete nonnative native-case records through the runner's existing artifact action."""
from pathlib import Path
import os,json,tarfile,hashlib,subprocess,shutil
w=Path(os.environ['CP3_WORK']);bundle=w/'ordinary23-evidence.tar.gz';members=[]
with tarfile.open(bundle,'w:gz') as t:
 for f in w.iterdir():
  if f.is_file() and f.suffix in ('.py','.json','.log','.java') and f.name not in ('profile-input.json','profile-public-input.json'):
   t.add(f,arcname='worker/'+f.name);members.append('worker/'+f.name)
 for root in [Path('/var/lib/cp3-ordinary23-ENa0X9/producer-djle6iwt'),Path('/var/lib/cp3-ordinary23-ENa0X9/producer-s9jp35z2'),Path('/var/lib/cp3-o23-ENa0X9/producer-1daubaq6'),Path('/var/lib/cp3-o23-ENa0X9/producer-36ck8vza')]:
  for f in root.rglob('*'):
   if not f.is_file() or f.is_symlink() or f.stat().st_size>4000000:continue
   rel=f.relative_to(root)
   if any(s in rel.parts for s in ['runtime','bazel-user','bazel-output','store','blobs']):continue
   if f.suffix in ('.json','.jsonl','.log','.stdout','.stderr','.bzl','.bazel') or f.name in ['stdout','stderr','private.stdout','private.stderr','consumer.stdout','consumer.stderr']:
    n='cases/'+root.name+'/'+str(rel);t.add(f,arcname=n);members.append(n)
 for f in (w/'maven-output/surefire-reports').glob('*.xml'):t.add(f,arcname='maven-reports/'+f.name);members.append('maven-reports/'+f.name)
receipt={'name':'cp3-ordinary23-evidence-'+os.environ['GITHUB_RUN_ID'],'bundle':bundle.name,'bytes':bundle.stat().st_size,'sha256':hashlib.file_digest(bundle.open('rb'),'sha256').hexdigest(),'members':sorted(members)};(w/'evidence-publication.json').write_text(json.dumps(receipt,indent=2))
env=os.environ.copy();env['RUNNER_DEBUG']='0'
for k,v in {'name':receipt['name'],'path':str(bundle),'if-no-files-found':'error','retention-days':'3','compression-level':'0','overwrite':'false','include-hidden-files':'false','archive':'true'}.items():env['INPUT_'+k.upper()]=v
with (w/'evidence-upload.log').open('w') as out:r=subprocess.run([shutil.which('node'),'/home/runner/work/_actions/actions/upload-artifact/bbbca2ddaa5d8feaa63e36b76fdaad77386f024f/dist/upload/index.js'],env=env,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,(w/'evidence-upload.log').read_text();print(json.dumps(receipt),flush=True);print((w/'evidence-upload.log').read_text()[-3500:])
