from pathlib import Path
import os,zipfile,json
w=Path(os.environ['CP3_WORK']);m=json.loads((w/'public-caller-composition.json').read_text());p='com/holdmyspot/codexunleashed/scheduler/Scheduler';rows=[]
with zipfile.ZipFile(w/'producer.jar') as base,zipfile.ZipFile(w/'producer-public.jar') as actual:
 for n in m['updatedClasses']:
  if n!=p+'.class' and not n.startswith(p+'$'):rows.append({'path':n,'unchanged':base.read(n)==actual.read(n)})
(w/'public-extra-equivalence.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows));assert all(r['unchanged'] for r in rows)
