"""Compile the exact focused native repair over the accepted maintained Java runtime."""
from pathlib import Path
import os,json,tarfile,hashlib,subprocess,zipfile,shutil
w=Path(os.environ['CP3_WORK']);patch=w/'repair';patch.mkdir()
with tarfile.open(w/'native-repair-source.tar.gz') as t:t.extractall(patch,filter='data')
manifest=json.loads((patch/'manifest.json').read_text());sources=[]
for item in manifest:
 original=w/'source'/item['path'];assert hashlib.sha256(original.read_bytes()).hexdigest()==item['beforeSha256']
 f=patch/original.name;assert hashlib.sha256(f.read_bytes()).hexdigest()==item['sha256'];shutil.copyfile(f,original);sources.append(str(f))
baseline=w/'producer-baseline.jar';shutil.copyfile(w/'producer.jar',baseline)
classes=w/'repair-classes';classes.mkdir();cmd=[str(w/'zulu27.30.109-ca-jdk27.0.1.0.3-linux_x64/bin/javac'),'--release','27','-Xlint:all,-processing','-Werror','-Xdoclint:all/private','-cp',str(baseline),'-d',str(classes)]+sources
with (w/'repair-compile.log').open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,(w/'repair-compile.log').read_text()
updates={str(f.relative_to(classes)):f for f in classes.rglob('*.class')};unchanged=0
with zipfile.ZipFile(baseline) as original,zipfile.ZipFile(w/'producer.jar','w',zipfile.ZIP_DEFLATED) as result:
 for entry in original.infolist():
  if entry.filename not in updates:result.writestr(entry,original.read(entry));unchanged+=1
 for name,f in updates.items():result.writestr(name,f.read_bytes())
with zipfile.ZipFile(baseline) as original,zipfile.ZipFile(w/'producer.jar') as result:
 for entry in original.infolist():
  if entry.filename not in updates:assert original.read(entry)==result.read(entry)
(w/'repair-composition.json').write_text(json.dumps({'command':cmd,'source':manifest,'updatedClasses':sorted(updates),'unchangedPayloads':unchanged,'jarSha256':hashlib.file_digest((w/'producer.jar').open('rb'),'sha256').hexdigest()},indent=2));print('repair-ready',flush=True)
