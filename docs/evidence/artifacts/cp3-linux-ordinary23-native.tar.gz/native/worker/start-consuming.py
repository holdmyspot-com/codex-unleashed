from pathlib import Path
import os,tarfile,json,subprocess
w=Path(os.environ['CP3_WORK']);src=w/'source'
with tarfile.open(w/'consumer-overlay.tar.gz') as t:t.extractall(src,filter='data')
cmd=['mvn','-B','-ntp','-f',str(src/'tooling/cli/pom.xml'),'-P','runtime,bazel-native-backend','-Dbazel.backend.directory='+str(w/'backend'),'-Dtooling.build.directory='+str(w/'maven-output'),'-Dparallel=methods','-DthreadCount=8','verify']
(w/'consuming-command.json').write_text(json.dumps(cmd,indent=2))
with (w/'consuming-maven.log').open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
(w/'consuming-maven-result.json').write_text(json.dumps({'command':cmd,'exit':r.returncode}));print('maven_exit',r.returncode,flush=True)
