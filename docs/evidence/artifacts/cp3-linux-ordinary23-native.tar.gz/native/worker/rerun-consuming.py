from pathlib import Path
import os,tarfile,json,subprocess
w=Path(os.environ['CP3_WORK']);src=w/'source'
import shutil
shutil.copyfile(w/'MainTest.baseline.java',src/'tooling/cli/src/test/java/com/holdmyspot/codexunleashed/tooling/MainTest.java')
for name in ['consuming-maven.log','consuming-maven-result.json']:
 p=w/name
 if p.exists():p.rename(w/('initial-'+name))
cmd=['mvn','-B','-ntp','-f',str(src/'tooling/cli/pom.xml'),'-P','runtime,bazel-native-backend','-Dbazel.backend.directory='+str(w/'backend'),'-Dtooling.build.directory='+str(w/'maven-output'),'-Dparallel=methods','-DthreadCount=8','verify']
(w/'consuming-command.json').write_text(json.dumps(cmd,indent=2))
with (w/'consuming-maven.log').open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
(w/'consuming-maven-result.json').write_text(json.dumps({'command':cmd,'exit':r.returncode}));print('maven_exit',r.returncode,flush=True)
