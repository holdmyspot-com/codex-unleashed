"""Prepare the accepted original-root fixture without changing production entry points."""
from pathlib import Path
import os,json,shutil,subprocess
w=Path(os.environ['CP3_WORK']);jdk=w/'zulu27.30.109-ca-jdk27.0.1.0.3-linux_x64';task=Path('/var/lib/cp3-ordinary23-ENa0X9');group=Path('/sys/fs/cgroup/cp3-ordinary23-ENa0X9')
task.mkdir(mode=0o755,exist_ok=True);group.mkdir(exist_ok=True);(group/'cgroup.subtree_control').write_text('+memory')
lib=task/'libcgroup.so.2'
if not lib.exists():shutil.copy2(w/'packages/lib/x86_64-linux-gnu/libcgroup.so.2.0.2',lib)
classes=w/'fixture-classes';classes.mkdir(exist_ok=True)
args=[str(jdk/'bin/javac'),'--release','27','-Xlint:all,-processing','-Werror','-Xdoclint:all/private','-cp',str(w/'producer.jar'),'-d',str(classes),str(w/'SealTree.java'),str(w/'NativeTerminalNoRetryCase.java')]
with (w/'fixture-compile.log').open('w') as out:r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,(w/'fixture-compile.log').read_text()
inputs={'taskRoot':str(task),'jdk':str(jdk),'jar':str(w/'producer.jar'),'distribution':str(w/'backend'),'bazel':str(w/'bin/bazel-9.1.0'),'zigRoot':str(w/'zig-linux-x86_64-0.14.0'),'frida':str(w/'profile-frida/libfrida-core.so'),'libcgroup':str(lib),'cgroupRoot':str(group),'trustedUid':1001,'trustedGid':1001,'actionUid':1002,'actionGid':1002}
(w/'profile-input.json').write_text(json.dumps(inputs,indent=2))
with (w/'prepare-producer.log').open('w') as out:r=subprocess.run(['python3',str(w/'prepare-producer.py'),str(w/'profile-input.json')],stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,(w/'prepare-producer.log').read_text()
root=Path(json.loads((w/'prepare-producer.log').read_text().splitlines()[-1])['root']);profile=json.loads((root/'profile.json').read_text());workspace=root/'workspace'
p=workspace/'thread-case';shutil.copy2(w/'ordinary-root',p)
(workspace/'actions.bzl').write_text('''def _run(ctx):
    output = ctx.actions.declare_file(ctx.label.name + ".o")
    ctx.actions.run(executable = "./thread-case", tools = [ctx.file.tool], outputs = [output], arguments = [], env = {"PATH": ".:/usr/bin:/bin", "LANG": "C.UTF-8", "HOME": "/tmp", "TMPDIR": "/tmp"}, mnemonic = "NativeOrdinaryRoot23")
    return [DefaultInfo(files = depset([output]))]
native_exit23 = rule(implementation = _run, attrs = {"tool": attr.label(allow_single_file = True)})
''')
(workspace/'BUILD.bazel').write_text('load(":actions.bzl", "native_exit23")\nnative_exit23(name = "tiny", tool = "thread-case")\n')
for f in [p,workspace/'actions.bzl',workspace/'BUILD.bazel']:os.chown(f,profile['trustedUid'],profile['trustedGid'])
s=(w/'run-terminal.py').read_text().replace('com.holdmyspot.codexunleashed.scheduler.NativeTerminalCase','com.holdmyspot.codexunleashed.scheduler.NativeTerminalNoRetryCase').replace("assert mode in ('SIGNAL','CANCEL')", "assert mode in ('SIGNAL','CANCEL','EXEC23')").replace("for phase in (['signal'] if mode=='SIGNAL' else ['cap','held']):", "for phase in ([] if mode=='EXEC23' else ['signal'] if mode=='SIGNAL' else ['cap','held']):").replace('status=child.wait()','status=child.wait(timeout=180)')
(w/'run-exec23.py').write_text(s)
print(json.dumps({'root':str(root),'fixture':str(p),'entry':'NativeTerminalNoRetryCase EXEC23','nativeExecution':'unrun'}),flush=True)
