"""Exercise actual public scheduling against the unchanged useful Zig workspace recipe."""
from pathlib import Path
import os,json,subprocess,hashlib
w=Path(os.environ['CP3_WORK'])
with (w/'prepare-public.log').open('w') as out:subprocess.run(['python3',str(w/'prepare-producer.py'),str(w/'profile-input.json')],stdout=out,stderr=subprocess.STDOUT,check=True)
root=Path(json.loads((w/'prepare-public.log').read_text().splitlines()[-1])['root']);command=json.loads((root/'command.json').read_text());argv=command['argv'];i=argv.index('com.holdmyspot.codexunleashed.scheduler.LinuxBazelProducer');profile=argv[i+1];argv[i:i+2]=['com.holdmyspot.codexunleashed.tooling.Main','schedule','--bazel-launch-config',profile]
(root/'public-command.json').write_text(json.dumps(command,indent=2))
with (root/'public.stdout').open('w') as out,(root/'public.stderr').open('w') as err:r=subprocess.run(argv,cwd=command['cwd'],env=command['environment'],stdout=out,stderr=err,timeout=240)
events=list((root/'scratch').glob('bazel-producer-*/producer-events.jsonl'));assert len(events)==1
rows=[json.loads(l) for l in events[0].read_text().splitlines()];pub=[e for e in rows if e['event']=='publication'];completions=[e for e in rows if e['event']=='completion-after'];cleanup=[e for e in rows if e['event']=='owned-cleanup'];objects=list((root/'workspace').glob('bazel-bin/tiny.o'))
receipt={'root':str(root),'command':command,'exit':r.returncode,'publications':pub,'completions':completions,'cleanup':cleanup,'outputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'elf':p.read_bytes()[:4].hex()} for p in objects]}
(root/'public-result.json').write_text(json.dumps(receipt,indent=2));(w/'public-result.json').write_text(json.dumps(receipt,indent=2));assert r.returncode==0,receipt;assert len(pub)==1 and pub[0]['payload']['published'];assert len(completions)==1 and not completions[0]['payload']['aborted'];assert cleanup[-1]['payload']['complete'];assert len(objects)==1 and objects[0].read_bytes()[:4]==b'\x7fELF';print(json.dumps(receipt),flush=True)
