"""Seal actual native receipts and owned cleanup, retaining failures independently."""
from pathlib import Path
import os,json,hashlib,tarfile
w=Path(os.environ['CP3_WORK']);green=Path('/var/lib/cp3-o23-ENa0X9/producer-1daubaq6');roots=[Path('/var/lib/cp3-ordinary23-ENa0X9/producer-djle6iwt'),Path('/var/lib/cp3-ordinary23-ENa0X9/producer-s9jp35z2'),green]
rows=[json.loads(s) for s in next((green/'scratch').glob('bazel-producer-*/producer-events.jsonl')).read_text().splitlines()]
matched={name:[e for e in rows if e['event']==name] for name in ['attempt-mapped','completion-after','publication','owned-cleanup']};assert len(matched['attempt-mapped'])==len(matched['completion-after'])==len(matched['publication'])==1
assert matched['completion-after'][0]['payload']['result']=={'signaled':False,'status':23};assert not matched['completion-after'][0]['payload']['aborted'];assert not matched['publication'][0]['payload']['published'];assert matched['owned-cleanup'][-1]['payload']['complete']
cleanup=[]
for root in roots:
 launch=json.loads((root/'terminal-launch.json').read_text());pid=launch['pid'];proc=Path('/proc',str(pid));same=False
 if proc.exists():
  s=(proc/'stat').read_text();same=int(s[s.rfind(')')+2:].split()[19])==launch['birthTicks']
 assert not same,launch;cleanup.append({'root':str(root),'originalJava':launch,'originalIdentityAbsent':not same})
cgroups=[]
for g in Path('/sys/fs/cgroup/cp3-ordinary23-ENa0X9').rglob('cgroup.events'):
 events=dict(s.split() for s in g.read_text().splitlines());assert events.get('populated')=='0',(g,events);cgroups.append({'path':str(g),'events':events})
textHits=[]
for f in green.rglob('*'):
 if f.is_file() and f.stat().st_size<3000000:
  try:
   b=f.read_bytes()
   if b'DESCENDANT_COMPLETED' in b and b'\x00' not in b:textHits.append(str(f))
  except OSError:pass
receipt={'gate':'genuine original ordinary23 after forked child exec0','result':'pass','fixtureResult':json.loads((green/'terminal-result.json').read_text()),'events':matched,'descendantOutputFiles':textHits,'ownedCleanup':cleanup,'cgroups':cgroups,'nativeBackendBuilds':0,'fixtureBuild':'zig cc -target x86_64-linux-musl -static -O2 terminal/ordinary-root.c -o ordinary-root'}
assert textHits,receipt;(w/'ordinary23-native-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
