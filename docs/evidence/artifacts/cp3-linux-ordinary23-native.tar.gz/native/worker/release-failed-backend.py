"""Collect only authenticated original native backend children after a failed-case graceful-close stall."""
from pathlib import Path
import os,json,signal
root=Path('/var/lib/cp3-ordinary23-ENa0X9/producer-djle6iwt');launch=json.loads((root/'terminal-launch.json').read_text());pid=launch['pid'];proc=Path('/proc',str(pid));stat=(proc/'stat').read_text();assert int(stat[stat.rfind(')')+2:].split()[19])==launch['birthTicks']
records=[]
children=set()
for task in (proc/'task').iterdir():
 try:children.update(map(int,(task/'children').read_text().split()))
 except FileNotFoundError:pass
for child in children:
 p=Path('/proc',str(child));exe=os.readlink(p/'exe')
 if not (Path(exe).name.startswith('bb_') and str(root) in exe):continue
 text=(p/'stat').read_text();fields=text[text.rfind(')')+2:].split();assert int(fields[1])==pid
 record={'pid':child,'birthTicks':int(fields[19]),'parent':pid,'executable':exe,'intervention':'SIGKILL after actual original failed-case graceful daemon collection stalled; not accepted cleanup evidence'}
 assert os.readlink(p/'exe')==exe;os.kill(child,signal.SIGKILL);records.append(record)
(root/'failed-backend-collection-intervention.json').write_text(json.dumps(records,indent=2));print(json.dumps(records),flush=True)
