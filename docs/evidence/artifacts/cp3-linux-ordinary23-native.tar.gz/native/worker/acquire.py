"""Reuse accepted immutable native products; acquire only pinned public JDK/Zig archives."""
from pathlib import Path
import os,subprocess,zipfile,tarfile,hashlib,json,concurrent.futures
w=Path(os.environ['CP3_WORK'])
def artifact(identifier,member,expected,destination):
 p=w/(str(identifier)+'.zip')
 with p.open('wb') as f:subprocess.run(['gh','api','repos/holdmyspot-com/codex-unleashed/actions/artifacts/'+str(identifier)+'/zip'],stdout=f,check=True)
 with zipfile.ZipFile(p) as z:
  assert z.namelist()==[member],z.namelist()
  z.extract(member,w)
 t=w/member;assert hashlib.file_digest(t.open('rb'),'sha256').hexdigest()==expected
 target=w/destination;target.mkdir()
 with tarfile.open(t) as archive:archive.extractall(target,filter='data')
 print('artifact',identifier,'verified',flush=True)
def public(url,name,expected):
 p=w/name;subprocess.run(['curl','-fLsS',url,'-o',str(p)],check=True)
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==expected
 with tarfile.open(p) as t:t.extractall(w,filter='data')
 print('public',name,'verified',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
 jobs=[pool.submit(artifact,13101499426,'runtime-shared-final.tar','3664ec07a4879b3fccf43d366fa185a3e58fcac0134dd63701541fcc3efdc5c3','shared'),pool.submit(artifact,13095214026,'runtime-assets.tar','9720f7922f802785bc83d75cb9ad28da495232705345998da798fe9752d7c45c','assets'),pool.submit(artifact,13100417339,'runtime-signal-final.tar','82f7d405a68fb48a2b637ff780db954efaca04d0b61ea844b177c93239730e0b','terminal'),pool.submit(public,'https://cdn.azul.com/zulu/bin/zulu27.30.109-ca-jdk27.0.1.0.3-linux_x64.tar.gz','jdk.tar.gz','c128817926e4eebb30868b6ba082028f493afa716e459e34049bde0ab49a9829'),pool.submit(public,'https://ziglang.org/download/0.14.0/zig-linux-x86_64-0.14.0.tar.xz','zig.tar.xz','473ec26806133cf4d1918caf1a410f8403a13d979726a9045b421b685031a982')]
 for j in jobs:j.result()
