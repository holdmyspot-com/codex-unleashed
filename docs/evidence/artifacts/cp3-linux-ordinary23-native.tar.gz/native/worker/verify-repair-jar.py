from pathlib import Path
import os,zipfile,hashlib,json
w=Path(os.environ['CP3_WORK']);updates={str(f.relative_to(w/'repair-classes')):f for f in (w/'repair-classes').rglob('*.class')};unchanged=0
with zipfile.ZipFile(w/'producer-baseline.jar') as original,zipfile.ZipFile(w/'producer.jar') as result:
 for name in original.namelist():
  if name not in updates:assert original.read(name)==result.read(name);unchanged+=1
 for name,f in updates.items():assert result.read(name)==f.read_bytes()
(w/'repair-composition.json').write_text(json.dumps({'source':json.loads((w/'repair/manifest.json').read_text()),'updatedClasses':sorted(updates),'unchangedPayloads':unchanged,'jarSha256':hashlib.file_digest((w/'producer.jar').open('rb'),'sha256').hexdigest()},indent=2));print('repair-ready',flush=True)
