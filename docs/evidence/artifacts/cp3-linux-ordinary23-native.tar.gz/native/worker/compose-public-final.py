"""Restore the accepted public Scheduler bytecode without modifying the maintained source gate."""
from pathlib import Path
import os,zipfile,json,hashlib
w=Path(os.environ['CP3_WORK']);base=w/'producer.jar';out=w/'producer-public.jar';accepted=w/'shared/public-dispatch/producer.jar';prefix='com/holdmyspot/codexunleashed/scheduler/Scheduler'
with zipfile.ZipFile(accepted) as a:updates={n:a.read(n) for n in a.namelist() if (n==prefix+'.class' or n.startswith(prefix+'$')) and n.endswith('.class')}
with zipfile.ZipFile(base) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as target:
 for n in z.namelist():
  if n not in updates:target.writestr(n,z.read(n))
 for n,b in updates.items():target.writestr(n,b)
with zipfile.ZipFile(base) as z,zipfile.ZipFile(out) as t:
 for n in z.namelist():
  if n not in updates:assert z.read(n)==t.read(n)
(w/'public-caller-composition.json').write_text(json.dumps({'acceptedSourceArtifact':13101499426,'updatedClasses':{n:hashlib.sha256(b).hexdigest() for n,b in updates.items()},'jar':str(out),'sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest()},indent=2))
p=json.loads((w/'profile-input.json').read_text());p['jar']=str(out);(w/'profile-public-input.json').write_text(json.dumps(p))
s=(w/'run-public-green.py').read_text().replace("w/'profile-input.json'","w/'profile-public-input.json'");(w/'run-public-final.py').write_text(s);print('public-caller-ready',flush=True)
