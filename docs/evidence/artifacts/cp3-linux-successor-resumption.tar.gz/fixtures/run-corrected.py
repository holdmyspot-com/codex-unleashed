"""Execute bounded native commands serially and stop at the first failed handoff.

Each command uses the owned foreground channel's documented receipt boundary.
Earlier native outputs remain intact. No next operation consumes an unsuccessful
copy or compile operation; driver failure still receives independent validation.
"""
from pathlib import Path
import subprocess
import sys


def main():
    """Install transferred final fixtures and execute one coherent native lifecycle."""
    worker = Path(sys.argv[1])
    commands = [
        'export P="$NATIVE_ROOT/product"; export I="$CAPTURE_WORK/incoming"',
        'sudo cp "$P/successor-resumption.py" "$P/successor-resumption.attempt-4.py"',
        'sudo cp "$P/successor-resumption.json" "$P/successor-resumption.json.attempt-4"',
        'sudo mv "$P/cases/controller-death" "$P/cases/controller-death-attempt-4"',
        'sudo cp "$I/successor-resumption-v4.py" "$P/successor-resumption.py"',
        'sudo cp "$I/validate-successor-resumption-v4.py" "$P/validate-successor-resumption.py"',
        'sudo mv "$P/successor-resumption.json" "$P/successor-resumption.json.previous-attempt-4"',
        'sudo python3 -m py_compile "$P/successor-resumption.py" "$P/validate-successor-resumption.py"']
    with (worker / 'corrected-serial-command.log').open('x') as output:
        for command in commands:
            subprocess.run(['python3', str(worker / 'remote.py'), command], stdout=output, stderr=output, check=True)
        first = subprocess.run(['python3', str(worker / 'remote.py'),
            'sudo python3 "$P/successor-resumption.py" > "$CAPTURE_WORK/driver-v5.stdout" 2> "$CAPTURE_WORK/driver-v5.stderr"'], stdout=output, stderr=output)
        second = subprocess.run(['python3', str(worker / 'remote.py'),
            'sudo python3 "$P/validate-successor-resumption.py" > "$CAPTURE_WORK/validator-v5.stdout" 2> "$CAPTURE_WORK/validator-v5.stderr"'], stdout=output, stderr=output)
    print(dict(driver=first.returncode, validator=second.returncode))
    raise SystemExit(first.returncode or second.returncode)


if __name__ == '__main__':
    main()
