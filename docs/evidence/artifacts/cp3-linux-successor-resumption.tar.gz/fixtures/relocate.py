"""Move only the owned product to a protected native namespace and retain failure1.

Root supplies the original worker root. Prints the fresh root-owned task paths;
all ancestor creation is exclusive to this operation. Runtime bytes stay intact.
"""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys


def main():
    """Create a root-owned CAT_TEMP child and relocate owned payload without rebuilding."""
    old = Path(sys.argv[1]).resolve()
    prefix = Path(subprocess.check_output(['mktemp', '-d', '-p', '/var/lib', 'codex-successor-XXXXXX'], text=True).strip())
    temporary = prefix / '.cat/work/temp'
    temporary.mkdir(parents=True)
    root = Path(subprocess.check_output(['mktemp', '-d', '-p', str(temporary), 'native-XXXXXX'], text=True).strip())
    for path in [prefix, prefix / '.cat', prefix / '.cat/work', temporary, root]:
        path.chmod(0o711)
    shutil.move(str(old / 'product'), root / 'product')
    product = root / 'product'
    for name in ['launch.json', 'bundle-result.json']:
        path = product / name
        original = path.read_text()
        (product / (name + '.pre-relocation')).write_text(original)
        path.write_text(original.replace(str(old), str(root)))
    (product / 'cases/controller-death').rename(product / 'cases/controller-death-attempt-1')
    for name in ['successor-resumption.json', 'successor-resumption-validation.json']:
        path = product / name
        if path.exists():path.rename(product / (name + '.attempt-1'))
    for name in ['driver.stdout', 'driver.stderr', 'validator.stdout', 'validator.stderr']:
        if (old / name).exists():shutil.copyfile(old / name, root / (name + '.attempt-1'))
    receipt = dict(originalRoot=str(old), protectedTaskRoot=str(prefix), CAT_TEMP=str(temporary),
        ownedNativeRoot=str(root), runtimeRebuilt=False, reason='Original ancestor is runner-owned; public launch rejected before compiler work')
    (old / 'relocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (root / 'relocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
