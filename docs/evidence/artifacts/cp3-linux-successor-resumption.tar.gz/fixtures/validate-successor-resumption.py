"""Independently reject incomplete installed Main crash/successor evidence.

Run with a product root, defaulting to this file's directory. Reads native raw
process journals, supervisor XML and artifact identities. Writes a complete
predicate report and exits1 when any required lifecycle outcome is absent.
"""
from pathlib import Path
import base64
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET


def check(gates, name, condition, evidence):
    """Record one required observable predicate and its determining evidence."""
    gates[name] = dict(passed=bool(condition), evidence=evidence)


def crates(processes, rustc):
    """Select genuine native rustc invocations by exact image and crate argument."""
    result = {}
    for native in processes:
        arguments = [base64.b64decode(v) for v in native['arguments']]
        if native['image'] == rustc and b'--crate-name' in arguments:
            name = arguments[arguments.index(b'--crate-name') + 1].decode()
            result.setdefault(name, []).append(native)
    return result


def validate(root):
    """Verify every connected lifecycle boundary from native run records."""
    record = json.loads((root / 'successor-resumption.json').read_text())
    gates = {}
    check(gates, 'driverCompleted', 'failure' not in record, record.get('failure'))
    first = record['first']
    second = record['successor']
    kill = record['kill']
    launch = json.loads((root / 'launch.json').read_text())
    first_crates = crates(first['processes'], launch['rustc'])
    second_crates = crates(second['processes'], launch['rustc'])
    check(gates, 'sameSupportedPublicCommand', first['command'] == second['command'] and
        first['command'][1:4] == ['schedule', '--tool', 'cargo'], first['command'])
    check(gates, 'pinnedRuntimeInput', record['sourceCommit'] == record['runtime']['sourceCommit'] ==
        'fb430f61e5bc8f518e2e823bf8ad98ce29cfd15f', record['runtime'])
    arguments = [base64.b64decode(v) for v in kill['controller']['arguments']]
    check(gates, 'actualInstalledMainTarget',
        b'com.holdmyspot.codexunleashed.tooling.Main' in b'\0'.join(arguments) and
        kill['controller']['pid'] == first['controllerPid'], kill['controller'])
    check(gates, 'authenticSIGKILLExit', kill['signal'] == 9 and first['exit'] == -9 and
        kill['observed'] <= kill['before'] <= kill['sent'] < first['extinctObserved'],
        dict(signal=kill['signal'], exit=first['exit'], sent=kill['sent'], extinct=first['extinctObserved']))
    active = kill['activeCompiler']
    check(gates, 'realCompilerActiveAtDeath', active in first_crates.get(kill.get('activeCrate', 'b'), []) and
        bool(kill['activeWorkers']) and any(w['ticks'] > 0 for w in kill['activeWorkers']), active)
    completed = kill['completedArtifacts']
    check(gates, 'completedUsefulWorkBeforeDeath', bool(first_crates.get('a')) and
        any(n.endswith('.rlib') for n in completed) and
        bool(kill['completedCompilers']), completed)
    check(gates, 'failedPartialOutputPresent', bool(kill['failedPartialArtifacts']), kill['failedPartialArtifacts'])
    credential_keys = []
    for native in first['processes'] + second['processes']:
        entries = base64.b64decode(native['environment']).split(b'\0')
        credential_keys.extend(entry.split(b'=', 1)[0].decode(errors='replace') for entry in entries
            if entry.split(b'=', 1)[0] in [b'GH_TOKEN', b'GITHUB_TOKEN', b'ACTIONS_RUNTIME_TOKEN', b'ACTIONS_ID_TOKEN_REQUEST_TOKEN'])
    check(gates, 'providerCredentialsExcludedFromCapturedProcesses', credential_keys == [], credential_keys)
    completed_native_results = []
    for receipt in first['receipts'].values():
        file = root / 'cases/controller-death' / receipt['file']
        values = {v.attrib['key']: v.text for v in ET.fromstring(file.read_bytes()).findall('entry')}
        if values.get('phase') == 'RESULT':
            completed_native_results.append(values)
    a_pids = {str(v['pid']) for v in kill['completedCompilers']}
    check(gates, 'completedUsefulNativeResult', any(v.get('root.pid') in a_pids and
        v.get('root.exit') == '0' and v.get('instrumentation.closed') == 'true' for v in completed_native_results),
        completed_native_results)

    check(gates, 'noObserverDeletionBeforeSuccessor', record['observerCleanupBetweenInvocations'] == [],
        record['observerCleanupBetweenInvocations'])
    before = record['retainedBeforeSuccessor']
    check(gates, 'completedStateRetainedThroughCrash', completed == before['completed'], before['completed'])
    check(gates, 'failedStateRetainedThroughCrash', set(kill['failedPartialArtifacts']).issubset(before['partial']), before['partial'])
    check(gates, 'wholeOwnedWorkloadExtinct', first['survivors'] == [] and first['populated'] == [],
        dict(survivors=first['survivors'], populated=first['populated']))
    first_supervisors = set()
    for text in re.findall(r'registered root=\d+ supervisor=(\d+) group=\S+',
            (root / 'cases/controller-death/stderr').read_text()):
        if int(text) in {v['pid'] for v in kill['liveOwnedAtKill']}:
            first_supervisors.add(int(text))
    reaped = {row['pid'] for row in first['reapedAdopted']}
    # Supervisors adopted by the observer must be explicitly waited, not only disappear.
    check(gates, 'nativeSupervisorReaping', bool(first_supervisors) and first_supervisors.issubset(reaped),
        dict(supervisors=sorted(first_supervisors), reaped=first['reapedAdopted']))
    check(gates, 'freshControllerBirth', first['controllerPid'] != second['controllerPid'],
        dict(first=first['controllerPid'], successor=second['controllerPid']))
    groups = []
    for name in ['controller-death', 'successor']:
        stderr = (root / 'cases' / name / 'stderr').read_text()
        values = re.findall(r'registered root=\d+ supervisor=\d+ group=(\S+)', stderr)
        groups.append({v.split('/actions/')[0] for v in values})
    check(gates, 'freshAuthorityContainment', bool(groups[0]) and bool(groups[1]) and
        groups[0].isdisjoint(groups[1]), [sorted(v) for v in groups])
    check(gates, 'completedWorkReused', completed == record['completedAfterSuccessor'] and
        'a' not in second_crates, dict(artifacts=record['completedAfterSuccessor'], compiled=list(second_crates)))
    check(gates, 'failedActionRecompiled', bool(second_crates.get(kill.get('activeCrate', 'b'))), second_crates.get(kill.get('activeCrate', 'b')))
    replacements = record['failedCrateAfterSuccessor']
    replaced = {name: name in replacements and replacements[name]['mtimeNs'] > state['mtimeNs']
        for name, state in before['partial'].items()}
    check(gates, 'failedPartialOutputsExcluded', bool(replaced) and all(replaced.values()), replaced)
    completed_results = []
    for receipt in second['receipts'].values():
        file = root / 'cases/successor' / receipt['file']
        values = {v.attrib['key']: v.text for v in ET.fromstring(file.read_bytes()).findall('entry')}
        if values.get('phase') == 'RESULT':
            completed_results.append(values)
    b_pids = {str(v['pid']) for v in second_crates.get(kill.get('activeCrate', 'b'), [])}
    check(gates, 'freshCompilerSuccessfulNativeResult', any(v.get('root.pid') in b_pids and
        v.get('root.exit') == '0' and v.get('instrumentation.closed') == 'true' for v in completed_results),
        completed_results)
    check(gates, 'publicSuccessAndOriginalStreams', second['exit'] == 0 and second['stdoutHex'] == '',
        dict(exit=second['exit'], stdoutHex=second['stdoutHex']))
    useful = record['usefulOutput']
    check(gates, 'usefulFinalOutput', record['usefulOutputCommand']['exit'] == 0 and
        useful['exit'] == 7 and useful['inputHex'] == '4100ff0a' and
        useful['stdoutHex'] == '47415445004100ff0a' and useful['stderrHex'] == '45525200', useful)
    return dict(task_contract='acknowledged', passed=all(v['passed'] for v in gates.values()), gates=gates)


def main():
    """Write the final report even when evidence is missing or malformed."""
    root = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else Path(__file__).resolve().parent
    try:
        result = validate(root)
    except (KeyError, OSError, ValueError, ET.ParseError) as error:
        result = dict(task_contract='acknowledged', passed=False, missingBoundary=str(error))
    (root / 'successor-resumption-validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    raise SystemExit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()
