"""Run the final evidence validator and seal only after its recorded success."""
from pathlib import Path
import subprocess
import sys


def main():
    """Preserve the predecessor validator, verify final source, and export native evidence."""
    worker = Path(sys.argv[1])
    commands = [
        'sudo cp "$P/validate-successor-resumption.py" "$P/validate-successor-resumption.pre-final.py"',
        'sudo cp "$I/validate-successor-final.py" "$P/validate-successor-resumption.py"',
        'sudo python3 -m py_compile "$P/validate-successor-resumption.py" "$I/export-successor.py"',
        'sudo python3 "$P/validate-successor-resumption.py" > "$CAPTURE_WORK/validator-final.stdout" 2> "$CAPTURE_WORK/validator-final.stderr"',
        'sudo --preserve-env=GH_TOKEN,GITHUB_TOKEN,ACTIONS_RUNTIME_TOKEN,ACTIONS_ID_TOKEN_REQUEST_TOKEN python3 "$I/export-successor.py" "$CAPTURE_WORK" "$NATIVE_ROOT"']
    with (worker / 'seal-native.log').open('x') as output:
        for command in commands:
            subprocess.run(['python3', str(worker / 'remote.py'), command], stdout=output, stderr=output, check=True)
    print((worker / 'seal-native.log').read_text()[-1800:])


if __name__ == '__main__':
    main()
