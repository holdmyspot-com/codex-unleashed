"""Remove only recorded owned roots after successful connected native acceptance.

Root supplies the original transport root and protected native root. Refuse any
live recorded process birth or populated owned cgroup. Print the terminal receipt
after removing the owned inert containment and task directories; the local channel
owner preserves it, exits the hosted shell, and collects provider cleanup.
"""
from pathlib import Path
import json
import shutil
import sys


def main():
    """Verify owned workloads terminal and retire their exclusively owned resources."""
    transport, native = map(Path, sys.argv[1:])
    product = native / 'product'
    validation = json.loads((product / 'successor-resumption-validation.json').read_text())
    if not validation['passed']:
        raise RuntimeError('Native acceptance is incomplete; retain the worker and partial state')
    observed = {}
    for path in (product / 'cases').glob('*/processes.jsonl'):
        for line in path.read_text().splitlines():
            entry = json.loads(line)
            observed[(entry['pid'], entry['birth'])] = entry
    survivors = []
    for pid, birth in observed:
        try:
            text = Path('/proc', str(pid), 'stat').read_text()
            current = int(text[text.rfind(')') + 2:].split()[19])
            if current == birth:survivors.append(dict(pid=pid, birth=birth))
        except (FileNotFoundError, ProcessLookupError):
            pass
    if survivors:
        raise RuntimeError('Owned process births remain active: ' + repr(survivors))
    launch = json.loads((product / 'launch.json').read_text())
    delegation = Path(launch['delegationParent'])
    if delegation.parent != Path('/sys/fs/cgroup') or not delegation.name.startswith('codex-successor-'):
        raise RuntimeError('Containment ownership does not match this task')
    populated = [str(p) for p in delegation.rglob('cgroup.events') if 'populated 1' in p.read_text()]
    if populated:raise RuntimeError('Owned containment remains populated: ' + repr(populated))
    directories = sorted([p for p in delegation.rglob('*') if p.is_dir()], key=lambda p: len(p.parts), reverse=True)
    for directory in directories:directory.rmdir()
    delegation.rmdir()
    relocation = json.loads((transport / 'relocation.json').read_text())
    scratch = json.loads((product / 'fixture-paths.json').read_text())
    roots = [Path(relocation['protectedTaskRoot']), Path(scratch['CAT_TEMP']), transport]
    if roots[0].parent != Path('/var/lib') or not roots[0].name.startswith('codex-successor-'):
        raise RuntimeError('Protected task root ownership differs')
    if roots[1].parent != Path('/var/lib') or not roots[1].name.startswith('cs-'):
        raise RuntimeError('Short scratch ownership differs')
    if not roots[2].name.startswith('successor-'):
        raise RuntimeError('Transport ownership differs')
    receipt = dict(passed=True, recordedNativeBirths=len(observed), survivors=[],
        populatedOwnedGroups=[], removedContainment=str(delegation),
        removedRoots=[str(p) for p in roots], terminalGates=len(validation['gates']))
    for directory in roots:shutil.rmtree(directory)
    print('CLEANUP_JSON=' + json.dumps(receipt))


if __name__ == '__main__':
    main()
