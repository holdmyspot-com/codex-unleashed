"""Kill actual installed Main during native Cargo work and exercise its successor.

Run as root in the prepared, exclusively owned product directory. Reuses Case's
supported command, process authentication and transient XML capture. No scheduler
message, output, estimate or termination is fabricated. Retained source, target,
history, scratch and cgroups are never deleted between invocations. The worker
owner retains all state on failure and removes it only after evidence handoff.
"""
from pathlib import Path
import ctypes
import importlib.util
import json
import os
import re
import signal
import subprocess
import sys
import time
import traceback


def load_predecessor(root):
    """Load the accepted public CLI producer from its owned product root."""
    spec = importlib.util.spec_from_file_location('paired', root / 'paired-cli-build.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def artifacts(root, crate, module):
    """Describe actual Cargo outputs for one crate without copying native bodies."""
    directory = root / 'fixture' / 'target'
    result = {}
    for path in directory.rglob('*'):
        named_crate = path.name.startswith((crate + '-', 'lib' + crate + '-'))
        if path.is_file() and named_crate:
            stat = path.stat()
            result[path.relative_to(root).as_posix()] = dict(sha256=module.sha(path),
                bytes=stat.st_size, mtimeNs=stat.st_mtime_ns, inode=stat.st_ino)
    return result


def live_birth(module, native):
    """Indicate whether the retained PID still has its authenticated birth."""
    try:
        current = module.identity(native['pid'])
        return current['birth'] == native['birth']
    except (FileNotFoundError, ProcessLookupError):
        return False


def observe(root, case, module, journal):
    """Capture owned processes, supervisor XML and independently named supervisors."""
    case.snapshot(journal)
    case.archive()
    log = (case.path / 'stderr').read_text(errors='replace')
    for match in re.finditer(r'registered root=(\d+) supervisor=(\d+) group=(\S+)', log):
        pid = int(match[2])
        try:
            native = module.identity(pid)
            key = str(pid) + ':' + str(native['birth']) + ':supervisor'
            if key not in case.records:
                case.records[key] = native
                case.result['processes'].append(module.printable(native))
                journal.write(json.dumps(module.printable(native)) + '\n')
                journal.flush()
        except (FileNotFoundError, ProcessLookupError):
            pass
    return log


def reap_adopted(record):
    """Reap only this observer's exited adopted descendants and retain raw statuses."""
    while True:
        try:
            pid, status = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            return
        if pid == 0:
            return
        record.append(dict(pid=pid, waitStatus=status, exit=os.waitstatus_to_exitcode(status)))


def completed_a(root, case, module):
    """Find completed real a compiler work while another real compiler remains active."""
    complete = artifacts(root, 'a', module)
    if not any(name.endswith('.rlib') for name in complete):
        return None
    compilers = {}
    for native in case.records.values():
        args = native['arguments']
        if native['image'] == case.configuration['rustc'] and b'--crate-name' in args:
            crate = args[args.index(b'--crate-name') + 1].decode()
            compilers.setdefault(crate, []).append(native)
    if 'a' not in compilers:
        return None
    a_terminal = all(not live_birth(module, native) for native in compilers['a'])
    if not a_terminal:
        return None
    for crate in ['b', 'app']:
        active = [native for native in compilers.get(crate, []) if live_birth(module, native)]
        partial = artifacts(root, crate, module)
        if len(active) == 1 and partial:
            native = active[0]
            if module.workers(native['pid']):
                return dict(completedArtifacts=complete, failedPartialArtifacts=partial,
                    completedCompilers=[module.printable(item) for item in compilers['a']],
                    activeCrate=crate, activeCompiler=module.printable(native),
                    activeWorkers=module.workers(native['pid']), observed=time.monotonic())
    return None


def invoke(root, module, name, environment, outcome, kill_controller):
    """Run the predecessor's actual command, optionally killing its exact live Main.

    Return only after the public controller and its adopted descendants are
    terminal. A timeout retains all state and fails; it never counts as extinction.
    """
    case = module.Case(root, name)
    paths = json.loads((root / 'fixture-paths.json').read_text())
    case.scratch = Path(paths['scratch'])
    case.result['command'][case.result['command'].index('--scratch') + 1] = str(case.scratch)
    case.result['fault'] = 'SIGKILL of authenticated installed Main' if kill_controller else 'none'
    deadline = time.monotonic() + 600
    with (case.path / 'stdin').open('wb') as stream:
        stream.write(b'A\0\xff\n')
    with (case.path / 'stdin').open('rb') as stdin, (case.path / 'stdout').open('wb') as stdout, \
            (case.path / 'stderr').open('wb') as stderr, (case.path / 'processes.jsonl').open('w') as journal:
        case.process = subprocess.Popen(case.result['command'], stdin=stdin, stdout=stdout,
            stderr=stderr, env=environment)
        case.result['controllerPid'] = case.process.pid
        killed = False
        while case.process.poll() is None:
            observe(root, case, module, journal)
            if kill_controller and not killed:
                selected = completed_a(root, case, module)
                if selected is not None:
                    controller = module.identity(case.process.pid)
                    command = b'\0'.join(controller['arguments'])
                    if b'com.holdmyspot.codexunleashed.tooling.Main' not in command:
                        raise RuntimeError('Kill target is not installed Main: ' + repr(command))
                    before = module.identity(controller['pid'])
                    if before['birth'] != controller['birth']:
                        raise RuntimeError('Main birth changed before SIGKILL')
                    outcome['kill'] = dict(selected, controller=module.printable(controller),
                        signal=signal.SIGKILL, liveOwnedAtKill=[module.printable(v) for v in case.records.values() if live_birth(module, v)], before=time.monotonic(),
                        command=case.result['command'])
                    module.save(root / 'successor-resumption.json', outcome)
                    os.kill(controller['pid'], signal.SIGKILL)
                    outcome['kill']['sent'] = time.monotonic()
                    killed = True
            if time.monotonic() > deadline:
                raise TimeoutError('Installed Main exceeded the lifecycle fixture deadline')
            time.sleep(.005)
        case.result['exit'] = case.process.wait()
        observe(root, case, module, journal)
        if kill_controller and not killed:
            raise RuntimeError('Main completed before completed-work plus active-compiler boundary')

        reaped = []
        while True:
            reap_adopted(reaped)
            survivors = [module.printable(v) for v in case.records.values() if live_birth(module, v)]
            populated = [str(p.relative_to(case.delegation)) for p in case.delegation.rglob('cgroup.events')
                if 'populated 1' in p.read_text()]
            if not survivors and not populated:
                break
            if time.monotonic() > deadline:
                outcome['survivors'] = survivors
                outcome['populated'] = populated
                raise TimeoutError('Owned workload did not become extinct and reaped after Main exit')
            observe(root, case, module, journal)
            time.sleep(.01)
    case.result.update(stdoutHex=(case.path / 'stdout').read_bytes().hex(),
        stderrSha256=module.sha(case.path / 'stderr'), passedExecution=not kill_controller,
        reapedAdopted=reaped, extinctObserved=time.monotonic(), survivors=[], populated=[])
    case.persist()
    return case


def main():
    """Record the connected crash/successor outcome and propagate any failed gate."""
    root = Path(__file__).resolve().parent
    if os.geteuid() != 0:
        raise RuntimeError('Native lifecycle observation requires the owned root controller')
    module = load_predecessor(root)
    outcome = dict(task_contract='acknowledged', gates={}, sourceCommit='fb430f61e5bc8f518e2e823bf8ad98ce29cfd15f',
        runtime=json.loads((root / 'bundle-result.json').read_text()),
        observerCleanupBetweenInvocations=[], reaping='PR_SET_CHILD_SUBREAPER and waitpid owned descendants')
    if ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), 'PR_SET_CHILD_SUBREAPER failed')
    environment = dict(PATH='/usr/bin:/bin', HOME=str(root / 'cargo-home'),
        TMPDIR=str(root / 'cargo-home'), LANG='C.UTF-8')
    outcome['controllerEnvironment'] = environment
    retained = root / 'successor-resumption.json'
    if retained.exists():
        prior = json.loads(retained.read_text())
        if prior.get('gates', {}).get('authenticatedMainSIGKILL'):
            outcome = prior
            outcome['kill'].setdefault('activeCrate', 'b')
            outcome.setdefault('observerFailures', []).append(outcome.pop('failure'))
    # Different compilation times make a complete useful action observable before b finishes.
    if 'first' not in outcome:
        for crate, count, value in [('a', 1000, 2), ('b', 200000, 3)]:
            source = root / 'fixture' / crate / 'src/lib.rs'
            source.write_text('pub fn value() -> u64 { ' + str(value) + ' }\n' + ''.join(
                'pub fn probe_padding_' + str(i) + '() -> u64 { ' + str(i) + ' }\n' for i in range(count)))
        outcome['fixtureInputs'] = {p.relative_to(root / 'fixture').as_posix(): module.sha(p)
            for p in (root / 'fixture').rglob('*') if p.is_file() and 'target' not in p.relative_to(root / 'fixture').parts}
        app = root / 'fixture/app/src/main.rs'
        text = app.read_text().split('// OBSERVATION_WINDOW')[0]
        app.write_text(text + '// OBSERVATION_WINDOW\n#[allow(dead_code)] mod observation_window {\n' + ''.join(
            'pub fn padding_' + str(i) + '() -> u64 { ' + str(i) + ' }\n' for i in range(30000)) + '}\n')
        outcome['fixtureInputs']['app/src/main.rs'] = module.sha(app)
    try:
        if 'first' not in outcome:
            first = invoke(root, module, 'controller-death', environment, outcome, True)
            outcome['first'] = first.result
            outcome['gates']['authenticatedMainSIGKILL'] = first.result['exit'] == -signal.SIGKILL
            outcome['gates']['ownedWorkloadExtinctAndReaped'] = True
        else:
            first = module.Case.__new__(module.Case)
            first.scratch = Path(json.loads((root / 'fixture-paths.json').read_text())['scratch'])
            first.delegation = Path(json.loads((root / 'launch.json').read_text())['delegationParent'])
        outcome['retainedBeforeSuccessor'] = dict(
            scratchBase=str(first.scratch), scratch=sorted(p.relative_to(first.scratch).as_posix() for p in first.scratch.rglob('*')),
            containment=sorted(str(p) for p in first.delegation.rglob('*') if p.is_dir()),
            completed=artifacts(root, 'a', module), partial=artifacts(root, outcome['kill']['activeCrate'], module),
            history={p.relative_to(root).as_posix(): module.sha(p) for p in (root / 'history').rglob('*') if p.is_file()})
        module.save(root / 'successor-resumption.json', outcome)
        successor = invoke(root, module, 'successor', environment, outcome, False)
        outcome['successor'] = successor.result
        outcome['completedAfterSuccessor'] = artifacts(root, 'a', module)
        outcome['failedCrateAfterSuccessor'] = artifacts(root, outcome['kill']['activeCrate'], module)
        outcome['gates']['supportedSuccessorExitZero'] = successor.result['exit'] == 0
        result = subprocess.run(['python3', str(root / 'verify-useful-output.py'), 'successor'],
            capture_output=True, text=True, env=environment)
        outcome['usefulOutputCommand'] = dict(command=['python3', str(root / 'verify-useful-output.py'), 'successor'],
            exit=result.returncode, stdout=result.stdout, stderr=result.stderr)
        result.check_returncode()
        outcome['usefulOutput'] = json.loads((successor.path / 'useful-output.json').read_text())
    except BaseException as error:
        outcome['failure'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
        raise
    finally:
        module.save(root / 'successor-resumption.json', outcome)
    print(json.dumps(dict(record='successor-resumption.json', gates=outcome['gates'])))


if __name__ == '__main__':
    main()
