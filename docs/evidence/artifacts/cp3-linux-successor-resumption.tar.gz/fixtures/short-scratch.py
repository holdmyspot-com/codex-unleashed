"""Create exclusively owned short protected scratch and preserve launch failure2.

The public wrapper uses Unix sockets, whose pathname capacity requires a short
scratch argument. Preserve packaged runtime and every existing receipt unchanged.
"""
from pathlib import Path
import json
import subprocess
import sys


def main():
    """Record a fresh root-owned CAT_TEMP child for the public scratch option."""
    product = Path(sys.argv[1]) / 'product'
    temporary = Path(subprocess.check_output(['mktemp', '-d', '-p', '/var/lib', 'cs-XXXXXX'], text=True).strip())
    temporary.chmod(0o711)
    scratch = Path(subprocess.check_output(['mktemp', '-d', '-p', str(temporary), 's-XXXXXX'], text=True).strip())
    scratch.chmod(0o711)
    record = dict(CAT_TEMP=str(temporary), scratch=str(scratch), cleanupOwner='/root/linux_pressure_capture')
    (product / 'fixture-paths.json').write_text(json.dumps(record, indent=2) + '\n')
    (product / 'cases/controller-death').rename(product / 'cases/controller-death-attempt-2')
    for name in ['successor-resumption.json', 'successor-resumption-validation.json']:
        path = product / name
        if path.exists():path.rename(product / (name + '.attempt-2'))
    print(json.dumps(record))


if __name__ == '__main__':
    main()
