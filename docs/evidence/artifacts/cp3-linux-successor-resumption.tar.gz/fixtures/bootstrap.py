"""Build the committed installed runtime in an exclusively owned native root.

Run as root with native architecture x64 or arm64. Retains all setup/build
receipts and valid outputs on failure. Downloads/extractions stay inside root.
The outer worker owner collects and removes this root after final acceptance.
"""
from pathlib import Path
import hashlib,io,json,os,shutil,subprocess,sys,tarfile

def run(root,name,command,environment):
 """Run a foreground setup operation and preserve complete streams and exit."""
 with (root/(name+'.stdout')).open('wb')as out,(root/(name+'.stderr')).open('wb')as err:
  result=subprocess.run(command,stdout=out,stderr=err,env=environment)
 (root/(name+'.command.json')).write_text(json.dumps(dict(command=command,exit=result.returncode),indent=2)+'\n')
 result.check_returncode()

def main():
 """Materialize pinned source and predecessor fixture, then package through Maven."""
 root=Path(__file__).resolve().parent.parent;arch=sys.argv[1]
 product=root/'product';product.mkdir()
 with tarfile.open(root/'source.tar.gz')as archive:archive.extractall(root/'upstream',filter='data')
 source=root/'upstream/codex-unleashed-fb430f61e5bc8f518e2e823bf8ad98ce29cfd15f'
 with tarfile.open(source/'docs/evidence/artifacts/cp3-linux-exact-pressure.tar.gz')as archive:
  with tarfile.open(fileobj=io.BytesIO(archive.extractfile(arch+'/shareable-evidence.tar.gz').read()))as evidence:
   for name in ['paired-cli-build.py','prepare-paired.py','verify-useful-output.py','dependencies.json','rust-components.json','small-fixture.json','fixture-manifest.json']:
    (product/name).write_bytes(evidence.extractfile('product/'+name).read())
 shutil.copyfile(root/'incoming/setup-native.py',product/'setup-native.py')
 shutil.copytree(source/'tooling',product/'source/tooling')
 manifest={p.relative_to(product/'source').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in (product/'source/tooling/cli').rglob('*')if p.is_file()}
 (product/'cli-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 environment={k:v for k,v in os.environ.items()if k in ['PATH','HOME','LANG','LC_ALL']}
 environment['TMPDIR']=str(root)
 run(root,'native-setup',['python3',str(product/'setup-native.py'),'1001','1001'],environment)
 jdk=next((product/'jdk').glob('zulu*'))
 environment['JAVA_HOME']=str(jdk);environment['PATH']=str(jdk/'bin')+':'+environment['PATH']
 run(root,'maven',['mvn','-B','-ntp','-e','-f',str(product/'source/tooling/cli/pom.xml'),'-Pruntime','-DskipTests','-Dmaven.repo.local='+str(root/'maven'),'-Djava.io.tmpdir='+str(root),'package'],environment)
 runtime=product/'source/.cat/work/temp/build-caches/maven/source-cache/runtime'
 if not (runtime/'bin/codex-tooling').is_file():raise RuntimeError('Maven runtime output absent')
 (product/'bundle-result.json').write_text(json.dumps(dict(runtime=str(runtime),cli=str(runtime/'bin/codex-tooling'),wrapper=str(runtime/'bin/codex-cargo-wrapper-linux'),sourceCommit='fb430f61e5bc8f518e2e823bf8ad98ce29cfd15f',identities={str(p.relative_to(product)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [runtime/'bin/codex-tooling',runtime/'lib/modules']},sourceManifestSha256=hashlib.sha256((product/'cli-source-manifest.json').read_bytes()).hexdigest()),indent=2)+'\n')
 preparation=(product/'prepare-paired.py').read_text().replace('codex-pressure-capture-10aFMY','codex-'+root.name)
 (product/'prepare-paired.py').write_text(preparation)
 run(root,'prepare',['python3',str(product/'prepare-paired.py')],environment)
 for path in [root,*root.rglob('*')]:
  if path.is_dir():path.chmod(path.stat().st_mode|0o055)
 print(json.dumps(dict(nativeRuntimeReady=True,root=str(root))))

if __name__=='__main__':main()
