"""Record owned GitHub terminal jobs, accepting only expected deliberate failure.

Exit75 while a run remains live. Exit0 only when its native debug job is terminal,
the original deliberate failure remains visible, and every post cleanup succeeds.
"""
from pathlib import Path
import json
import subprocess
import sys


def main():
    """Retrieve the owned run through its documented provider status boundary."""
    root = Path(__file__).resolve().parent
    pending = False
    for arch in ['x64', 'arm64']:
        worker = root / arch
        run = json.loads((worker / 'provider-run.json').read_text())['id']
        result = json.loads(subprocess.check_output(['gh', 'run', 'view', str(run), '--json', 'jobs,status,conclusion']))
        (worker / 'provider-terminal.json').write_text(json.dumps(result, indent=2) + '\n')
        if result['status'] != 'completed':
            pending = True
            continue
        jobs = [job for job in result['jobs'] if job['name'].startswith('Debug - ')]
        if len(jobs) != 1:raise RuntimeError('Owned native debug job is not uniquely identified')
        job = jobs[0]
        failure = [step for step in job['steps'] if step['name'] == 'Record the deliberate build failure']
        posts = [step for step in job['steps'] if step['name'].startswith('Post ')]
        valid = result['conclusion'] == 'failure' and len(failure) == 1 and failure[0]['conclusion'] == 'failure' and bool(posts) and all(v['conclusion'] == 'success' for v in posts)
        if not valid:raise RuntimeError('Provider terminal result differs from deliberate failure plus successful cleanup: ' + repr(job))
        print(arch, run, job['databaseId'], 'deliberate failure retained; every post succeeded')
    raise SystemExit(75 if pending else 0)


if __name__ == '__main__':
    main()
