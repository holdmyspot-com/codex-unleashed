"""Seal determining native lifecycle sources and raw evidence without native bodies.

Root receives the original transport root and protected native root. Every regular
member is inventoried by size/hash; provider environment values are checked for
omission before publication. Workers and private connection files remain remote.
"""
from pathlib import Path
import hashlib
import io
import json
import os
import sys
import tarfile


def main():
    """Export complete fixture/source/control evidence and reject leaked credentials."""
    transport, native = map(Path, sys.argv[1:])
    product = native / 'product'
    files = {}

    def include(path, name):
        """Include one nonsymlink regular payload after rejecting executable bodies."""
        if path.is_symlink() or not path.is_file():
            raise ValueError('Evidence input is not a regular nonsymlink file: ' + str(path))
        data = path.read_bytes()
        if data.startswith((b'\x7fELF', b'MZ')):
            raise ValueError('Native executable body cannot be exported: ' + str(path))
        files[name] = data

    for path in product.iterdir():
        if path.is_file() and (path.suffix in ['.py', '.json'] or '.attempt-' in path.name or '.pre-relocation' in path.name):
            include(path, 'product/' + path.name)
    manifest = json.loads((product / 'cli-source-manifest.json').read_text())
    for name, expected in manifest.items():
        path = product / 'source' / name
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Committed source identity changed: ' + name)
        include(path, 'product/source/' + name)
    for directory in ['cases', 'history']:
        for path in (product / directory).rglob('*'):
            if path.is_file():include(path, 'product/' + path.relative_to(product).as_posix())
    for name in json.loads((product / 'successor-resumption.json').read_text()).get('fixtureInputs', {}):
        include(product / 'fixture' / name, 'product/fixture/' + name)
    for path in transport.iterdir():
        if path.is_file() and path.suffix in ['.stdout', '.stderr', '.json']:
            include(path, 'transport/' + path.name)
    for path in (transport / 'incoming').iterdir():
        if path.is_file() and path.suffix == '.py':include(path, 'transport/incoming/' + path.name)
    provider_names = [name for name in os.environ if any(word in name for word in ['TOKEN', 'PASSWORD', 'SECRET'])]
    values = [os.environ[name].encode() for name in provider_names if len(os.environ[name]) >= 12]
    leaks = [(name, index) for name, data in files.items() for index, value in enumerate(values) if value in data]
    if leaks:raise ValueError('Provider credential bytes detected in selected evidence')
    files['credential-omission.json'] = (json.dumps(dict(passed=True,
        providerValuesChecked=len(values), membersChecked=len(files),
        privateConnectionFilesSelected=False), indent=2) + '\n').encode()
    inventory = {name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(files.items())}
    files['inventory.json'] = (json.dumps(dict(task_contract='acknowledged',
        sourceCommit='fb430f61e5bc8f518e2e823bf8ad98ce29cfd15f', files=inventory,
        excluded=['native executable bodies', 'Maven cache', 'Rust/JDK/Frida downloads and extracted native toolchains',
            'Cargo target native bodies', 'provider connection details and keys']), indent=2) + '\n').encode()
    output = transport / 'connected-evidence.tar.gz'
    with tarfile.open(output, 'w:gz') as archive:
        for name, data in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            member.mtime = 0
            archive.addfile(member, io.BytesIO(data))
    receipt = dict(bytes=output.stat().st_size, sha256=hashlib.sha256(output.read_bytes()).hexdigest(), members=len(files))
    (transport / 'connected-evidence.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
