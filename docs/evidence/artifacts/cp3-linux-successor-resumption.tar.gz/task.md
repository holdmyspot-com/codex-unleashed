# Installed Main controller death and supported successor

## Design Goals

- Prove that actual installed-controller death stops owned work and permits a supported successor to reuse completed work while excluding failed output on both Linux architectures.
- Confine fixture execution and evidence to exclusively owned resources and return decisive native acceptance and cleanup evidence without changing maintained production inputs.

## Guidance

Owner: `/root/linux_pressure_capture`. Root integrates the result. You are not alone in this repository; preserve others' edits and do not touch the static Bazel owner's tree, worker or channels.

## Outcome and boundary

Complete the missing Linux checkpoint 3 behavior: an actual installed `codex-tooling schedule` controller dies while real compiler work is active, its owned workload stops and is reaped, and a supported fresh public invocation succeeds using retained valid completed work while rejecting failed partial output. Run x64 and ARM64 independently in parallel where native capacity permits. This is one connected lifecycle acceptance unit, not another standalone supervisor demonstration.

The predecessor shutdown fixture already proves diagnostic-controller extinction; do not repeat it as completion. Immediate automatic removal of inert outer cgroups/storage is not a requirement. Preserve those resources until the successor has exercised the supported path. Never let observer deletion establish production resumption. Demonstrate whether fresh invocation succeeds without special cleanup; if stale state obstructs it, record the exact failing supported boundary and return the required production change closure for root assignment.

## Immutable inputs

- Committed current baseline: `fb430f61e5bc8f518e2e823bf8ad98ce29cfd15f` on `main.new`.
- Accepted pressure receipt: `docs/evidence/cp3-linux-exact-pressure.json`.
- Shareable fixture/evidence archive: `docs/evidence/artifacts/cp3-linux-exact-pressure.tar.gz` (receipt supplies identity). Its `x64/shareable-evidence.tar.gz` and ARM counterpart contain `product/paired-cli-build.py`; `Case.run()` invokes the installed public entry point and retains target/history across invocations. Reuse that producer, rather than inventing a separate scheduler harness.
- Accepted runtime composition/retrieval: `docs/evidence/cp3-runtime-final-maven.json`, `docs/evidence/cp3-runtime-integration.json`, `docs/evidence/cp3-runtime-maintained-source-manifest.json`. Use committed production inputs; build native installed runtime remotely using the actual Maven runtime profile if a fresh host needs packaging. No unchanged full Maven suite for reassurance.
- Original owner scope: `docs/evidence/cp3-acceptance-scope.json`.
- Prior shutdown observer: `docs/evidence/linux-controller-death.json`; reuse only what helps observe actual installed Main. Its diagnostic controller is not the behavior under test.

## Exact authority

Local write allowlist: this task directory and fresh children under your own session CAT_TEMP. Fixtures, task records, transport records, reports and safe source/evidence archives only. No maintained source, tests, workflow, plan or evidence edits. No dependency or upstream source changes. No local Rust/Bazel/Go outputs, builds, caches or native binary extraction. Local Java fixture compilation is allowed. Read archive sources in memory or selectively extract source/text only.

Workspace mode: immutable committed native source in exclusively owned fresh remote directories; no shared mutable workspace. Remote write authority covers only your recorded task roots, owned fixture outputs and owned containment. Use the existing committed debug workflow and CAT remote-runner-session skill. Check its current contract before dispatch. Create remote CAT workflow state under the runner's actual CAT_TEMP; record that path and ownership. Retain and reuse each live worker through fixes. Use free standard GitHub runners only. Inspect only processes you launched. No other agent's native commands.

Strip inherited provider credentials from fixture/controller environments before capture. Preserve only values required by the actual invocation. Do not emit credentials or private keys into outputs or shareable archives.

Reuse the accepted predecessor's protected-path placement: the production launch validates every ancestor, so a task directory beneath a runner-owned checkout fails before compiler execution. The pressure predecessor already established root-owned `/var/lib` task projects as the remedy. Establish an exclusively owned root-owned remote project there with its own CAT_TEMP children; record those identities and keep required administrative ancestors nonwritable by the compiler identity. Reuse existing runtime/build outputs through the established transfer rather than rebuilding them. The earlier protected-ancestor failures remain fixture failures, not new product defects.

## Acceptance and commands

First acknowledge the objective, exact write allowlist, workspace mode and checks. Within this scope own fixture implementation, focused verification and routine repairs through this complete gate; no parent approval stops for resolved primitives.

Use the predecessor's actual supported public command construction and record the literal resulting command in each receipt. Add a case whose observer waits for independently authenticated real compiler births and one completed useful action before SIGKILL of the exact installed Main PID/birth. Observe authentic workload extinction/reaping without deleting retained partial state. Launch the same supported public command through a fresh controller against the retained project/target/history; establish fresh authority and actual valid completed-work reuse, failed-attempt output exclusion, success and useful final output. Preserve original streams and exit semantics.

For fixture verification, run `python3 -m py_compile <each changed Python fixture>`; if Java fixtures change, strict JDK27 `javac --release 27 -Xlint:all,-processing -Werror -Xdoclint:all/private` on those sources. Record exact paths and full outputs. The native acceptance commands are the new case driver and its independent validator; choose their literal paths in the task record before execution. The validator must fail when any required boundary is absent and inspect actual installed-Main/native outcomes, not source text. Do not add schema or primitive checks unrelated to this lifecycle outcome. Test-only fixture changes need no new project suite.

Report one machine-readable JSON file with `task_contract: acknowledged` (or `unreadable` and no edits). Each claim names its decisive command/observation, result and complete output path. Include exact input/source/runtime identities, native run/job identities, initial failure and any focused correction, per-architecture gate states, complete safe source/raw output retrieval, cleanup ownership and terminal receipts. Keep product success distinct from deliberate debug workflow exit17. If a production defect prevents acceptance, retain the worker and partial state for a named repair consumer, return the exact failure and proposed complete write closure, and do not implement outside this allowlist. Parent accepts the coherent unit once; you do not integrate it.

Root owns this local task directory after final safe handoff and removes it only after durable integration and the last named consumer.
