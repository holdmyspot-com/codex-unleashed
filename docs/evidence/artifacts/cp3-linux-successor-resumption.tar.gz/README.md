# Installed Main death and supported successor

Both Linux architectures passed all 23 final predicates against committed input `fb430f61e5bc8f518e2e823bf8ad98ce29cfd15f`. Read `report.json` for the gate evidence, source/runtime identities, retained historical limitations and cleanup ownership. Product acceptance is separate from the debug workflow’s intentional failure step. Both jobs are terminal and their post steps succeeded.

For each architecture, `native-evidence.tar.gz` contains the complete source/control archive, including `product/successor-resumption-validation.json`, `product/successor-resumption.json`, native process/XML histories and original transport streams. `retrieval-verification.json` records checked hashes and member counts. Its `credential-omission.json` records the native scan against two provider credential values. Native executable bodies and caches are excluded.

To independently replay the final validator from these safe inputs, extract this handoff into a fresh directory, then run:

```sh
mkdir x64/evidence arm64/evidence
 tar -xzf x64/native-evidence.tar.gz -C x64/evidence
 tar -xzf arm64/native-evidence.tar.gz -C arm64/evidence
python3 fixtures/validate-successor-resumption.py x64/evidence/product
python3 fixtures/validate-successor-resumption.py arm64/evidence/product
```

Both commands must exit zero and report all 23 gates passed. Stored `clean-validation.json` files record this replay after the native archives were retrieved. This replays evidence validation; it does not rerun native behavior.

To reproduce native behavior, use CAT’s remote-runner-session skill with a separately owned free standard native worker per architecture and the pinned source archive. Establish a short root-owned project under `/var/lib` with protected ancestors and record its own CAT_TEMP before setup. `fixtures/bootstrap.py` expects the pinned GitHub source archive as `source.tar.gz` beside `incoming/`, and the architecture’s archived `transport/incoming/setup-native.py` in `incoming/`; run it as root with `x64` or `arm64`. It resolves the declared inputs, reuses the committed predecessor fixtures and packages the unchanged Maven runtime profile. Before the connected case, record a supported short protected scratch path in `product/fixture-paths.json`; the exact accepted shape is included in the native archive. Copy the final driver and validator into `product`, run their Python compilation checks, then run `sudo python3 product/successor-resumption.py` followed by `sudo python3 product/validate-successor-resumption.py`. Retain project, target, history and authority state between death and successor; the driver owns this transition. Exact accepted native commands are preserved in the command logs.

Export and verify safe source/control evidence before cleanup. `cleanup.json` and its raw receipt record extinction checks and removal of only owned task roots and containment. SSH owners exited zero, local private keypairs/FIFOs were removed, and provider terminal receipts show completed post cleanup. Private connection originals remain outside this handoff in the root-owned task directory until durable integration.
