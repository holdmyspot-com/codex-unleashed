"""Check same-pin musl-server attachment to one owned suspended static Zig.

Run with the fixture directory as the sole argument. Only this client may resume
its spawned target, after receiving its identity-exact script-ready message.
Always kill any remaining owned target before detaching and collect the server.
The JSON result distinguishes attachment from untested production allocation and
descendant behavior. It does not infer a target exit code from session detachment.
"""
import hashlib, json, os, secrets, subprocess, sys, threading, time, traceback
from pathlib import Path
import frida

root = Path(sys.argv[1]).resolve()
loader = Path('/usr/lib/x86_64-linux-musl/libc.so')
server_path = root / 'frida-server'
zig = root / 'zig-linux-x86_64-0.14.0/zig'
receipt = {'frida': frida.__version__, 'attach': 'UNRUN', 'scriptReady': 'UNRUN',
           'productionAllocationHook': 'UNRUN', 'descendants': 'UNRUN',
           'resumeCount': 0, 'targetExitCode': None, 'messages': [], 'output': []}
for name, path in [('loader', loader), ('server', server_path), ('zig', zig)]:
    receipt[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
assert receipt['zig']['sha256'] == '77340932066b76bc9f3a4ac120288f21790ed2836e5cd5a003f4a3c12f37d765'
assert receipt['server']['sha256'] == 'fa5e2487ca266878d297372759de26b4785f3bbe084d5de75fc6ede1e7301c53'
address = '127.0.0.1:27042'
token = secrets.token_hex(32)
manager = frida.get_device_manager()
device = session = script = server = None
pid = None
ready, ended = threading.Event(), threading.Event()
cancellable = frida.Cancellable()
timer = threading.Timer(40, cancellable.cancel)


def message_received(message, data):
    """Retain every script message; accept READY only for the owned PID."""
    receipt['messages'].append(message)
    if message.get('type') == 'send' and message.get('payload') == {'event': 'ready', 'pid': pid}:
        ready.set()


def detached(reason, crash):
    """Record the observed terminal session event without inventing an exit code."""
    receipt['detached'] = {'reason': reason, 'crash': str(crash) if crash else None}
    ended.set()


def output_received(output_pid, fd, data):
    """Retain exact binary output for this single target."""
    receipt['output'].append({'pid': output_pid, 'fd': fd, 'hex': data.hex()})


status = 1
with (root / 'server.stdout').open('wb') as out, (root / 'server.stderr').open('wb') as err:
    try:
        server = subprocess.Popen([str(server_path), '--listen=' + address,
                                   '--token=' + token, '--directory=' + str(root)],
                                  cwd=root, stdout=out, stderr=err)
        receipt['serverPid'] = server.pid
        receipt['serverExe'] = os.readlink('/proc/' + str(server.pid) + '/exe')
        timer.start()
        with cancellable:
            for attempt in range(100):
                try:
                    device = manager.add_remote_device(address, token=token)
                    device.enumerate_processes()
                    break
                except frida.ServerNotRunningError:
                    if server.poll() is not None:
                        raise RuntimeError('Owned server exited before connection')
                    time.sleep(0.1)
            if device is None:
                raise RuntimeError('Owned server did not become available')
            mappings = Path('/proc/' + str(server.pid) + '/maps').read_text()
            (root / 'server.maps').write_text(mappings)
            assert str(loader) in mappings, 'Owned server does not map the selected musl loader'
            device.on('output', output_received)
            pid = device.spawn([str(zig), 'version'], cwd=str(root), stdio='pipe')
            receipt['pid'] = pid
            receipt['spawnStat'] = Path('/proc/' + str(pid) + '/stat').read_text()
            receipt['attach'] = 'FAILED'
            session = device.attach(pid)
            receipt['attach'] = 'PASSED'
            session.on('detached', detached)
            script = session.create_script("send({event: 'ready', pid: Process.id});")
            script.on('message', message_received)
            script.load()
            if not ready.wait(10):
                raise RuntimeError('Identity-exact script READY was not received')
            receipt['scriptReady'] = 'PASSED'
            device.resume(pid)
            receipt['resumeCount'] += 1
            if not ended.wait(10):
                raise RuntimeError('Resumed target did not produce a terminal session event')
            stdout = b''.join(bytes.fromhex(item['hex']) for item in receipt['output']
                              if item['pid'] == pid and item['fd'] == 1)
            assert stdout == b'0.14.0\n', repr(stdout)
            assert receipt['detached'] == {'reason': 'process-terminated', 'crash': None}
            receipt['versionOutput'] = 'PASSED'
            status = 0
    except BaseException as error:
        receipt['error'] = {'type': type(error).__name__, 'message': str(error),
                            'traceback': traceback.format_exc()}
    finally:
        timer.cancel()
        if pid is not None and device is not None:
            try:
                device.kill(pid)
                receipt['targetCleanup'] = 'owned target killed'
            except frida.ProcessNotFoundError:
                receipt['targetCleanup'] = 'owned target already absent'
            except BaseException as error:
                receipt['targetCleanupError'] = repr(error)
                status = 1
        if session is not None:
            try:
                session.detach()
            except frida.InvalidOperationError:
                pass
        if device is not None:
            manager.remove_remote_device(address)
        if server is not None:
            server.terminate()
            try:
                receipt['serverExit'] = server.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server.kill()
                receipt['serverExit'] = server.wait()
                receipt['serverForcedKill'] = True
        receipt['result'] = 'PASSED' if status == 0 else 'FAILED'
        (root / 'connected-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(status)
