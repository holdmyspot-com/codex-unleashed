"""Prepare the existing connected producer recipe using retained genuine ARM64 products."""
import os,json,subprocess,shutil
from pathlib import Path
w=Path(os.environ['CP3_WORK'])
task=Path('/var/lib/a197f4')
group=Path('/sys/fs/cgroup/a197f4')
task.mkdir(mode=0o755)
group.mkdir()
(group/'cgroup.subtree_control').write_text('+memory')
libs=list((w/'packages/root/lib/aarch64-linux-gnu').glob('libcgroup.so.2.*'))
assert len(libs)==1,libs
shutil.copy2(libs[0],task/'libcgroup.so.2')
os.chown(task/'libcgroup.so.2',0,0)
inputs={'taskRoot':str(task),'jdk':str(w/'zulu27.30.107-ca-jdk27.0.1-linux_aarch64'),'jar':str(w/'arm64-producer.jar'),'distribution':str(w/'prebuilt/backend'),'bazel':str(w/'prebuilt/native-build/bazel-9.1.0'),'zigRoot':str(w/'zig-linux-aarch64-0.14.0'),'frida':os.environ['CP3_FRIDA_FILE'],'libcgroup':str(task/'libcgroup.so.2'),'cgroupRoot':str(group),'trustedUid':1001,'trustedGid':1001,'actionUid':1002,'actionGid':1002}
(w/'profile-input.json').write_text(json.dumps(inputs,indent=2))
with (w/'prepare-producer.log').open('w') as out:
 r=subprocess.run(['python3',str(w/'prepare-producer-arm64.py'),str(w/'profile-input.json')],stdout=out,stderr=subprocess.STDOUT)
print((w/'prepare-producer.log').read_text())
raise SystemExit(r.returncode)
