"""Seal exact owned ARM acceptance sources, independent receipts and original failures."""
import pathlib,json,hashlib,shutil,os
w=pathlib.Path.cwd();d=w/'final-evidence';d.mkdir()
roles={'original-retry':'5tsy_2jy','SIGNAL':'jea5bw7c','CANCEL':'mjog3hep','EXEC23':'hru3jpkj','original-final-failure':'4sr6ci3m','repaired-retry':'kr3kg_j1','MAIN':'sk0_k74c'}
summary={'task_contract':'acknowledged','runtimeSha256':hashlib.sha256((w/'arm64-producer.jar').read_bytes()).hexdigest(),'gates':{},'owners':{},'cgroups':{}}
for role,suffix in roles.items():
 r=pathlib.Path('/var/lib/a197f4/producer-'+suffix);out=d/role;out.mkdir()
 paths=list((r/'scratch').glob('bazel-producer-*/producer-events.jsonl'));assert len(paths)==1,(role,paths)
 e=[json.loads(x) for x in paths[0].read_text().splitlines()]
 shutil.copy2(paths[0],out/'producer-events.jsonl')
 def events(name):return [x['payload'] for x in e if x['event']==name]
 if role in ('original-retry','repaired-retry'):
  assert len(events('blocked'))==1
  assert [p['attemptSequence'] for p in events('attempt-mapped')]==[0,1]
  assert [p['attemptSequence'] for p in events('publication') if p['published']]==[1]
  assert events('terminal')==[0]
 if role in ('SIGNAL','EXEC23'):
  expected=5 if role=='SIGNAL' else 23;c=events('completion-before');assert len(c)==1
  assert c[0]['result']=={'signaled':role=='SIGNAL','status':expected} and not c[0]['aborted']
  assert len(events('attempt-mapped'))==1 and all(not x['published'] for x in events('publication'))
  assert events('terminal')==[1]
 if role=='CANCEL':
  assert len(events('fixture-cancellation-requested'))==1 and not events('publication')
  assert not events('terminal') and not events('completion-before')
 if role=='MAIN':assert events('terminal')==[0]
 if role!='original-final-failure':assert events('owned-cleanup')==[{'complete':True}]
 for name in ['controller-observations.json','held-native-trap.json','denial-result.json','terminal-result.json','terminal-launch.json','main-result.json','main-launch.json','denial.stderr','signal.stderr','cancel.stderr','exec23.stderr','main.stderr','command.json']:
  p=r/name
  if p.is_file():shutil.copy2(p,out/name)
 ids=set()
 obs=r/'controller-observations.json'
 if obs.exists():
  for o in json.loads(obs.read_text()):
   n=o['nativeEvidence'];ids.update([n['pid'],n['helper']['pid'],n['helper']['parent']])
   if 'target' in o:ids.add(o['target']['pid'])
   ids.update(x['pid'] for x in o.get('heldDescendantsBeforeRootDeath',[]))
 for name in ['terminal-launch.json','main-launch.json']:
  p=r/name
  if p.exists():ids.add(json.loads(p.read_text())['pid'])
 assert all(not pathlib.Path('/proc',str(i)).exists() for i in ids),(role,ids)
 summary['owners'][role]={'absentPids':sorted(ids),'forcedCleanup':False}
 g=pathlib.Path('/sys/fs/cgroup/a197f4/producer-'+suffix)
 groups=[g]+[x for x in g.rglob('*') if x.is_dir()] if g.exists() else []
 states={str(x):{'events':(x/'cgroup.events').read_text(),'procs':(x/'cgroup.procs').read_text()} for x in groups}
 assert all(x['procs']=='' and 'populated 0' in x['events'] for x in states.values()),role
 summary['cgroups'][role]=states
 summary['gates'][role]='preserved failure superseded by repaired-retry' if role=='original-final-failure' else 'PASSED'
 if role in ('original-retry','repaired-retry','MAIN'):
  b=(r/'workspace/bazel-bin/tiny.o').read_bytes();assert b[:4]==b'\x7fELF' and int.from_bytes(b[18:20],'little')==183
  summary['gates'][role]={'status':'PASSED','elfMachine':183,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for role in ['shared-case','exec-case']:
 r=pathlib.Path('/var/lib/a197f4')/role;out=d/role;out.mkdir()
 for p in r.iterdir():
  if p.is_file() and p.suffix in ('.json','.log','.stdout','.stderr'):shutil.copy2(p,out/p.name)
 j=json.loads((r/'result.json').read_text());assert j['status'].startswith('PASSED_NATIVE_')
 summary['gates'][role]=j['status']
source=d/'source';source.mkdir()
for name in ['LinuxAllocationTrace.java','LinuxAarch64Trace.java','LinuxBazelHelperMain.java','LinuxBazelNamespaceHooks.java','LinuxAarch64TraceTest.java','LinuxAarch64TraceNativeTest.java','LinuxBazelStaticImageTest.java','TestRequirements.java']:
 shutil.copy2(w/'terminal-arm'/name,source/name)
for name in ['LinuxBazelTraceHelper.java','LinuxBazelHelperMainTest.java']:shutil.copy2(w/'leader-exec'/name,source/name)
summary['sourceSha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir()}
summary['pinnedInputs']={'backendArchiveSha256':'22a203a498d6991a7c02420c1afa29dffe65364374ef8d36fef9cf8300baed8e','sharedRuntimeArtifact':13100417339,'sharedRuntimeJarSha256':'c191680b79d133e8faf3c1b3b13c0743b02779f7089f5743c34e002b9b7fcc74','leaderRepairSha256':'df80ee2071e130e4a6b5bda525a617f0038829054de40502548e0476aa056fd2','retainedIngressArtifact':13100047144,'retentionDays':1}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
