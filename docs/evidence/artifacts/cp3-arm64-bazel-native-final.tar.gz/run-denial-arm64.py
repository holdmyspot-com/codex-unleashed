"""Observe only owned native processes and set a fixture-only inherited soft AS cap."""
import os,json,subprocess,time,resource,hashlib
from pathlib import Path
w=Path(os.environ['CP3_WORK']);prepared=json.loads((w/'prepare-producer.log').read_text().strip().splitlines()[-1]);root=Path(prepared['root']);profile=json.loads((root/'profile.json').read_text());command=json.loads((root/'command.json').read_text());control=root/'denial-control'
argv=command['argv'];entry=argv.index('com.holdmyspot.codexunleashed.scheduler.LinuxBazelProducer');argv[entry]='com.holdmyspot.codexunleashed.scheduler.NativeProducerCase';argv.insert(entry+2,str(control));argv[argv.index('-cp')+1]=str(w/'fixture-classes')+':'+argv[argv.index('-cp')+1]
owner=Path(profile['actionOwner']);waiter=owner.with_name('linux-bazel-action-waiter');observations=[]
def stat(pid):
    text=Path('/proc',str(pid),'stat').read_text();fields=text[text.rfind(')')+2:].split();return int(fields[1]),int(fields[19])
def snapshot(pid):
    proc=Path('/proc',str(pid));parent,birth=stat(pid);status={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in (proc/'status').read_text().splitlines() if ':' in line}
    return {'pid':pid,'parent':parent,'birthTicks':birth,'uid':list(map(int,status['Uid'].split())),'gid':list(map(int,status['Gid'].split())),'nspid':list(map(int,status['NSpid'].split())),'pidNamespace':os.readlink(proc/'ns/pid'),'mountNamespace':os.readlink(proc/'ns/mnt'),'exeSha256':hashlib.sha256((proc/'exe').read_bytes()).hexdigest(),'cgroup':(proc/'cgroup').read_text().strip()}
def authenticate(request,java_pid,prior):
    merged=Path(request['context']['merged']) if request['phase']=='cap' else Path(prior['merged']);parts=merged.parts;assert parts[:2]==('/','proc') and parts[3]=='root',parts;helper=int(parts[2]);helper_proc=Path('/proc',str(helper));h=snapshot(helper);assert h['parent']==java_pid and h['uid']==[0]*4;assert os.path.samefile(helper_proc/'exe',owner)
    args=(helper_proc/'cmdline').read_bytes().split(b'\0');assert args[1]==b'--launch';assert int(args[2])==profile['actionUid'] and int(args[3])==profile['actionGid'];owner_group=Path(os.fsdecode(args[4]));namespace_root=Path(os.fsdecode(args[5]));assert os.path.samefile(os.fsdecode(args[7]),waiter);assert owner_group.is_relative_to(profile['helperParent']);assert str(namespace_root) in str(merged)
    children=list(map(int,(helper_proc/'task'/str(helper)/'children').read_text().split()));matches=[pid for pid in children if os.path.samefile(Path('/proc',str(pid),'exe'),waiter)];assert len(matches)==1,matches;pid=matches[0];s=snapshot(pid);assert s['parent']==helper and s['uid']==[profile['actionUid']]*4 and s['gid']==[profile['actionGid']]*4 and s['nspid'][-1]==1;assert s['mountNamespace']==h['mountNamespace'] and s['pidNamespace']!=h['pidNamespace'];assert os.path.samefile(Path('/proc',str(pid),'root'),helper_proc/'root'/str(namespace_root).lstrip('/'));assert s['cgroup']=='0::'+'/'+str(owner_group.relative_to('/sys/fs/cgroup'))
    if prior:assert pid==prior['pid'] and s['birthTicks']==prior['birthTicks'] and s['exeSha256']==prior['exeSha256']
    assert snapshot(pid)==s;return s|{'merged':str(merged),'helper':h,'ownerGroup':str(owner_group)}
def held_snapshot(group):
    tids=list(map(int,(group/'cgroup.threads').read_text().split()));assert tids,'Denied containment has no live tracee';tasks=[];traps=[]
    for tid in tids:
        proc=Path('/proc',str(tid));lines=(proc/'status').read_text().splitlines();status={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in lines if ':' in line};assert status['State'].startswith('t'),(tid,status['State']);tracer=int(status['TracerPid']);assert tracer>0;assert os.path.samefile(Path('/proc',str(tracer),'exe'),profile['java'])
        syscall=(proc/'syscall').read_text().strip();task={'tid':tid,'birthTicks':stat(tid)[1],'state':status['State'],'tracerPid':tracer,'syscall':syscall};tasks.append(task)
        fields=syscall.split()
        if len(fields)==3 and fields[0]=='-1':
            pc=int(fields[-1],0)
            with (proc/'mem').open('rb',buffering=0) as memory:memory.seek(pc);instruction=memory.read(4)
            if instruction==b'\x00\x00\x20\xd4':
                mapping=next(line for line in (proc/'maps').read_text().splitlines() if int(line.split()[0].split('-')[0],16)<=pc<int(line.split()[0].split('-')[1],16));parts=mapping.split();assert parts[1]=='r-xp',mapping;offset=int(parts[2],16)+pc-int(parts[0].split('-')[0],16)
                with (proc/'exe').open('rb') as executable:executable.seek(offset);original=executable.read(4)
                digest=hashlib.sha256((proc/'exe').read_bytes()).hexdigest();assert digest==hashlib.sha256((Path(os.environ['CP3_WORK'])/'zig-linux-aarch64-0.14.0/zig').read_bytes()).hexdigest();assert original!=instruction
                traps.append(task|{'trapPc':pc,'executedInstructionAddress':pc,'memoryByte':instruction.hex(),'originalDiskByte':original.hex(),'mapping':mapping,'executableSha256':digest})
    assert len(traps)==1,traps;return {'tasks':tasks,'executedTraps':traps}
with (root/'denial.stdout').open('w') as out,(root/'denial.stderr').open('w') as err:
    child=subprocess.Popen(argv,cwd=command['cwd'],env=command['environment'],stdout=out,stderr=err)
    prior=None;failure=None
    try:
        for phase in ['cap','restore']:
            request_path=control/(phase+'.request.json')
            while not request_path.exists():
                if child.poll() is not None:raise RuntimeError('Producer exited before '+phase)
                time.sleep(.02)
            request=json.loads(request_path.read_text())
            if phase=='restore':
                cap_request=json.loads((control/'cap.request.json').read_text());group=Path(cap_request['context']['containment']);first=held_snapshot(group);time.sleep(2);second=held_snapshot(group);assert first==second;(root/'held-native-trap.json').write_text(json.dumps({'first':first,'second':second,'heldSeconds':2},indent=2))
            s=authenticate(request,child.pid,prior);pid=s['pid'];before=resource.prlimit(pid,resource.RLIMIT_AS);assert before[1]==resource.RLIM_INFINITY,before
            soft=209715200 if phase=='cap' else resource.RLIM_INFINITY
            resource.prlimit(pid,resource.RLIMIT_AS,(soft,resource.RLIM_INFINITY));after=resource.prlimit(pid,resource.RLIMIT_AS);assert after==(soft,resource.RLIM_INFINITY);assert stat(pid)[1]==s['birthTicks']
            receipt={'phase':phase,'nonce':request['nonce'],'softAddressSpace':str(soft) if soft!=-1 else 'unlimited','hardAddressSpace':'unlimited','independentlyAuthenticated':True,'pid':pid,'birthTicks':s['birthTicks'],'nativeEvidence':s,'before':before,'after':after}
            observations.append(receipt);(root/'controller-observations.json').write_text(json.dumps(observations,indent=2));temporary=control/(phase+'.ack.tmp');temporary.write_text(json.dumps(receipt));temporary.rename(control/(phase+'.ack.json'));prior=s
    except BaseException as error:
        failure=repr(error);(root/'controller-failure.json').write_text(json.dumps({'failure':failure,'javaPid':child.pid,'observations':observations},indent=2))
    status=child.wait()
(root/'denial-result.json').write_text(json.dumps({'argv':argv,'exit':status,'controllerFailure':failure,'acknowledgments':len(observations)},indent=2));print('producer_root',root,'exit',status,'controller_failure',failure);print((root/'denial.stderr').read_text()[-15000:]);raise SystemExit(status or (1 if failure else 0))
