package com.holdmyspot.codexunleashed.scheduler;
import java.io.IOException;
import java.nio.file.Path;
/** Invokes the actual production seal for fixture input preparation. */
final class SealTree
{
    /** Prevents construction. */
    private SealTree() {}
    /**
     * Prints the production seal of one existing immutable input.
     * @param arguments exact absolute input path
     * @throws IOException if the input is untrusted or unreadable
     */
    public static void main(String[] arguments) throws IOException
    { System.out.println(LinuxBazelNamespaceHooks.seal(Path.of(arguments[0]))); }
}
