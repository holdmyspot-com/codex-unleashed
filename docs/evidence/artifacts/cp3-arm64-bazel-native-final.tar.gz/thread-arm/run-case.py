"""Retain the unchanged native waiter and compare its real EXIT receipt with production Session collection.

Arguments: packaged waiter, absolute thread-case image, fresh run directory, exec|shared, UID, GID.
TRACE_JDK and TRACE_CLASSPATH explicitly identify the existing worker JDK and current runtime plus fixture classes.
Run as root. Native compilation and execution belong exclusively to the worker owner.
"""
import hashlib,json,os,socket,struct,subprocess,sys
from pathlib import Path
waiter=Path(sys.argv[1]);image=Path(sys.argv[2]);root=Path(sys.argv[3]);mode=sys.argv[4]
uid=int(sys.argv[5]);gid=int(sys.argv[6]);assert mode in ('exec','shared') and os.geteuid()==0
root.mkdir(mode=0o755);sock=root/'owner.sock';cap='c'*64
owner=None;child=None;peer=None;listener=None;observations=[];result={'status':'FAILED'}
def receive():
    """Receive one original waiter's independently framed, bounded ASCII observation."""
    def exact(count):
        """Reject partial original native owner receipts."""
        data=b''
        while len(data)<count:
            part=peer.recv(count-len(data))
            if not part:raise EOFError('original waiter frame')
            data+=part
        return data
    size=struct.unpack('!I',exact(4))[0];assert 0<size<=1048576
    frame=exact(size).decode('ascii');observations.append({'original_waiter_frame':frame});return frame

def send(frame):
    """Send one exact acknowledged original-waiter command."""
    data=frame.encode('ascii');peer.sendall(struct.pack('!I',len(data))+data)
try:
    listener=socket.socket(socket.AF_UNIX);listener.bind(str(sock));os.chmod(sock,0o666);listener.listen(1)
    with (root/'target.stdout').open('wb') as out,(root/'owner.stderr').open('wb') as err:
        owner=subprocess.Popen([str(waiter),str(sock),cap,'--cwd',str(root),'0','--',str(image),str(image),mode],
            cwd=root,env={},stdin=subprocess.DEVNULL,stdout=out,stderr=err,user=uid,group=gid,extra_groups=())
    peer,_=listener.accept();peer.settimeout(60)
    hello=receive().split();assert hello[:2]==['OWNER',cap] and int(hello[2])==owner.pid,hello
    send('CREATE 1');prepared=receive().split();assert prepared[:2]==['PREPARED','1'],prepared
    child=int(prepared[2]);birth=int(prepared[3]);proc=Path('/proc')/str(child)
    stat=(proc/'stat').read_text();fields=stat[stat.rfind(')')+2:].split()
    assert int(fields[19])==birth and int(fields[1])==owner.pid
    observations.append({'prepared_pid':child,'prepared_birth':birth,'parent_pid':owner.pid,
        'status':(proc/'status').read_text(),'namespaces':{n:os.readlink(proc/'ns'/n) for n in ('pid','mnt')},
        'cgroup':(proc/'cgroup').read_text(),'fixture_sha256':hashlib.sha256(image.read_bytes()).hexdigest()})
    command=[str(Path(os.environ['TRACE_JDK'])/'bin/java'),'--enable-native-access=ALL-UNNAMED',
        '-cp',os.environ['TRACE_CLASSPATH'],'com.holdmyspot.codexunleashed.scheduler.ThreadTerminalCase',
        str(child),str(birth),str(image),mode]
    traced=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=55)
    (root/'java.log').write_text(traced.stdout);observations.append({'java_command':command,'java_status':traced.returncode})
    assert traced.returncode==0,traced.stdout
    expected='EXIT 1 EXIT 23' if mode=='exec' else 'EXIT 1 SIGNAL 9'
    receipt=receive();assert receipt==expected,receipt
    status=23 if mode=='exec' else 137
    send('FINAL 1 '+str(status));assert owner.wait(timeout=10)==status,owner.returncode
    assert not proc.exists(),'original child still exists'
    result={'status':'PASSED_NATIVE_'+mode.upper(),'observations':observations,'original_parent_status':owner.returncode}
finally:
    if child is not None:
        try:os.kill(child,9)
        except ProcessLookupError:pass
    if peer:peer.close()
    if listener:listener.close()
    if owner is not None and owner.poll() is None:
        owner.terminate();owner.wait(timeout=10)
    (root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
