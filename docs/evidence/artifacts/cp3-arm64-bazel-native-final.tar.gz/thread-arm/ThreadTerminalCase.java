package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import com.holdmyspot.codexunleashed.tooling.ToolingScope;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.locks.LockSupport;
import java.util.stream.Stream;

/** Evaluates genuine thread exec migration and a shared mmap-return denial through the production native Session. */
final class ThreadTerminalCase
{
    /** Prevents construction of this evaluation entry point. */
    private ThreadTerminalCase() {}

    /**
     * Adopts only the original native waiter's independently authenticated prepared child.
     * @param args original PID, birth, absolute fixture image and exec or shared mode
     * @throws IOException if a native observation or acceptance condition fails
     */
    public static void main(String[] args) throws IOException
    {
        if (args.length != 4) throw new IllegalArgumentException("pid birth fixture-image exec|shared");
        int pid = Integer.parseInt(args[0]);
        long originalBirth = Long.parseLong(args[1]);
        boolean shared = args[3].equals("shared");
        if (!shared && !args[3].equals("exec")) throw new IllegalArgumentException("Unknown fixture mode");
        Path image = Path.of(args[2]);
        try (ToolingScope scope = new DefaultToolingScope())
        {
            LinuxAllocationTrace.Session session = LinuxAllocationTrace.adopt(scope.getNativeLinker(),
                new LinuxAllocationTrace.Identity(pid, originalBirth), image,
                Arrays.asList(Arrays.copyOfRange(args, 2, args.length)), Map.of("PATH", "/usr/bin:/bin"));
            boolean collected = false;
            try
            {
                session.awaitPrepared(Duration.ofSeconds(20));
                require(birth(Path.of("/proc", args[0], "stat")) == originalBirth, "Initial held birth differs");
                require(Files.isSameFile(Path.of("/proc", args[0], "exe"), image), "Initial held image differs");
                System.out.println("PREPARED " + pid + " birth=" + originalBirth);
                session.resume();
                LinuxAllocationTrace.Identity authorized = null;
                boolean migrated = false;
                LinuxAllocationTrace.Identity migratedIdentity = null;
                boolean denied = false;
                Set<Integer> frozen = Set.of();
                long start = System.nanoTime();
                LinuxAllocationTrace.Outcome outcome;
                while ((outcome = session.outcome()) == null)
                {
                    LinuxAllocationTrace.PreExec pre;
                    while ((pre = session.pollPreExec()) != null)
                    {
                        require(!shared && authorized == null && pre.processId() == pid && pre.thread().tid() != pid,
                            "Unexpected or repeated nonleader exec authorization");
                        Path task = Path.of("/proc", Integer.toString(pid), "task", Integer.toString(pre.thread().tid()));
                        long observedBirth = birth(task.resolve("stat"));
                        String group = Files.readAllLines(task.resolve("status")).stream()
                            .filter(line -> line.startsWith("Tgid:")).findFirst().orElseThrow();
                        require(Integer.parseInt(group.substring(5).trim()) == pid &&
                            observedBirth == pre.thread().birthTicks() && observedBirth != originalBirth,
                            "Independent pre-exec thread membership or birth differs");
                        require(Files.isSameFile(task.resolve("exe"), image), "Pre-exec image differs");
                        authorized = pre.thread();
                        System.out.println("PREEXEC_AUTHENTICATED " + pre + " observedBirth=" + observedBirth);
                        session.authorizeExec(authorized);
                    }
                    LinuxAllocationTrace.Held held;
                    while ((held = session.pollHeld()) != null)
                    {
                        long observedLiveBirth = birth(Path.of("/proc", Integer.toString(held.task().tid()), "stat"));
                        System.out.println("HELD_NATIVE " + held + " independentlyObservedLiveBirth=" + observedLiveBirth +
                            " immutablePreparedBirth=" + originalBirth + " authorizedFormerThread=" + authorized);
                        require(!shared && authorized != null && !migrated && held.origin() == 1 &&
                            authorized.equals(held.formerThread()) && held.task().tid() == pid,
                            "Exec migration lacks exact former-TID proof");
                        require(observedLiveBirth == held.task().birthTicks(), "Independent migrated leader birth differs");
                        require(Files.isSameFile(Path.of("/proc", Integer.toString(pid), "exe"), image),
                            "Migrated actual image differs");
                        migratedIdentity = held.task();
                        migrated = true;
                        System.out.println("MIGRATION_AUTHENTICATED " + held);
                        session.releaseHeld(held.task());
                    }
                    LinuxAllocationTrace.Denial denial = session.pollDenial();
                    if (denial != null)
                    {
                        require(shared && !denied, "Unexpected native denial");
                        require(denial.nativeResult() == -12 && denial.requestedBytes() == (1L << 62) &&
                            denial.originalInstructionBits() == 0xd503201f && denial.trapPc() == denial.returnAddress(),
                            "Shared instruction did not execute the genuine ENOMEM trap");
                        System.out.println("DENIAL " + denial);
                        frozen = inspectSharedHold(pid, denial);
                        LockSupport.parkNanos(Duration.ofSeconds(2).toNanos());
                        require(session.outcome() == null, "Native denial escaped its hold");
                        require(inspectSharedHold(pid, denial).equals(frozen), "Held native task set changed");
                        denied = true;
                        session.terminate();
                    }
                    require(System.nanoTime() - start < Duration.ofSeconds(25).toNanos(), "Native outcome timed out");
                    LockSupport.parkNanos(1_000_000);
                }
                collected = true;
                System.out.println("OUTCOME " + outcome);
                require(outcome.root().identity().tid() == pid, "Original native root PID changed");
                if (shared)
                {
                    require(denied && outcome.denied() && (outcome.root().waitStatus() & 127) == 9,
                        "Shared denied attempt did not collect genuine SIGKILL");
                    Set<Integer> actual = new HashSet<>();
                    for (LinuxAllocationTrace.Terminal terminal : outcome.collected()) actual.add(terminal.identity().tid());
                    require(actual.containsAll(frozen), "A frozen original target missed final collection");
                }
                else
                    require(migrated && !outcome.denied() && outcome.root().waitStatus() == (23 << 8) &&
                        outcome.root().identity().equals(migratedIdentity),
                        "Migrated original root did not authentically exit23");
            }
            finally
            {
                session.terminate();
                if (!collected)
                {
                    long start = System.nanoTime();
                    while (session.outcome() == null)
                    {
                        if (System.nanoTime() - start >= Duration.ofSeconds(20).toNanos())
                            throw new IOException("Native owner remains retained; external original-parent controller must collect");
                        LockSupport.parkNanos(1_000_000);
                    }
                }
            }
        }
    }

    /**
     * Independently verifies all stopped tasks and another mmap contender at the exact patched return instruction.
     * @param pid original process leader
     * @param denial authentic copied executed trap
     * @return independently observed frozen original task IDs
     * @throws IOException if task states, shared return instruction or the trap instruction differ
     */
    private static Set<Integer> inspectSharedHold(int pid, LinuxAllocationTrace.Denial denial) throws IOException
    {
        Map<Integer, String> observations = new TreeMap<>();
        boolean otherAtSharedReturn = false;
        Path tasks = Path.of("/proc", Integer.toString(pid), "task");
        try (Stream<Path> entries = Files.list(tasks))
        {
            for (Path task : entries.toList())
            {
                int tid = Integer.parseInt(task.getFileName().toString());
                String stat = Files.readString(task.resolve("stat"));
                require(stat.substring(stat.lastIndexOf(')') + 2).charAt(0) == 't', "Owned task is not tracing-stopped: " + tid);
                String syscall = Files.readString(task.resolve("syscall")).trim();
                observations.put(tid, syscall);
                String[] fields = syscall.split("\\s+");
                if (tid != denial.thread().tid() && fields.length >= 3 && fields[0].equals("222") &&
                    Long.parseUnsignedLong(fields[fields.length - 1].replace("0x", ""), 16) == denial.returnAddress())
                    otherAtSharedReturn = true;
            }
        }
        require(observations.size() >= 3 && otherAtSharedReturn,
            "No independent second mmap contender at the actual shared return instruction: " + observations);
        try (FileChannel memory = FileChannel.open(Path.of("/proc", Integer.toString(pid), "mem")))
        {
            ByteBuffer opcode = ByteBuffer.allocate(4).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            require(memory.read(opcode, denial.returnAddress()) == 4 && opcode.getInt(0) == 0xd4200000,
                "Executed shared return no longer contains BRK");
        }
        System.out.println("SHARED_HOLD " + observations);
        return Set.copyOf(observations.keySet());
    }

    /**
     * Reads the kernel stat birth independently from the copied native event.
     * @param stat actual procfs stat path
     * @return kernel start ticks
     * @throws IOException if the original task cannot be observed
     */
    private static long birth(Path stat) throws IOException
    {
        String text = Files.readString(stat);
        return Long.parseLong(text.substring(text.lastIndexOf(')') + 2).split(" ")[19]);
    }

    /**
     * Requires an independently observed fixture condition.
     * @param condition required native fact
     * @param message concrete failed condition
     * @throws IOException if the condition is false
     */
    private static void require(boolean condition, String message) throws IOException
    {
        if (!condition) throw new IOException(message);
    }
}
