#define _GNU_SOURCE
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <unistd.h>

/* Every mmap contender executes this one syscall and this exact shared return instruction. */
extern long shared_map(void);
extern char shared_mmap_return;
__asm__(".text\n.globl shared_map\n.type shared_map,%function\nshared_map:\n"
        "mov x8,#222\nmov x0,#0\nmov x1,#0x4000000000000000\n"
        "mov x2,#3\nmov x3,#0x22\nmov x4,#-1\nmov x5,#0\n"
        "svc #0\n.globl shared_mmap_return\nshared_mmap_return:\nnop\nret\n"
        ".size shared_map,.-shared_map\n");
static atomic_int ready, go;
static const char *image;

/* Replace this original thread group from a genuine nonleader kernel thread. */
static void *replace_image(void *unused)
{
    (void)unused;
    usleep(80000);
    char *const args[] = {(char *)image, "exit23", NULL};
    execv(image, args);
    _exit(111);
}

/* Stay runnable until all contenders are ready, then enter the same real mmap instruction. */
static void *contender(void *unused)
{
    (void)unused;
    printf("CONTENDER tid=%ld return=%p\n", syscall(SYS_gettid), (void *)&shared_mmap_return);
    fflush(stdout);
    atomic_fetch_add_explicit(&ready, 1, memory_order_release);
    while (!atomic_load_explicit(&go, memory_order_acquire)) __asm__ volatile("yield");
    for (;;) {
        long result = shared_map();
        /* Returning to application code would violate the required held-denial gate. */
        if (result == -12) _exit(112);
        _exit(113);
    }
    return NULL;
}

/* Fixture modes are evaluation-only and do not add a production testing option. */
int main(int argc, char **argv)
{
    if (argc != 2) return 110;
    if (!strcmp(argv[1], "exit23")) return 23;
    image = argv[0];
    if (!strcmp(argv[1], "exec")) {
        pthread_t worker;
        usleep(80000); /* Force former-thread birth to differ from the initial leader. */
        if (pthread_create(&worker, NULL, replace_image, NULL)) return 114;
        for (;;) pause();
    }
    if (strcmp(argv[1], "shared")) return 115;
    pthread_t workers[16];
    for (unsigned i = 0; i < 16; ++i)
        if (pthread_create(&workers[i], NULL, contender, NULL)) return 116;
    while (atomic_load_explicit(&ready, memory_order_acquire) != 16) __asm__ volatile("yield");
    atomic_store_explicit(&go, 1, memory_order_release);
    for (;;) __asm__ volatile("yield");
}
