package com.holdmyspot.codexunleashed.scheduler;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemoryLayout;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.ValueLayout;
import java.lang.invoke.MethodHandle;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.LockSupport;

/**
 * Owns a Linux x86-64 command and every forked or cloned tracee until native collection completes.
 * A dedicated platform thread exclusively spawns, waits for, and resumes its tracees. Standard descriptors are
 * inherited unchanged. The command starts only after tracing is established; it must not already have another tracer.
 * A denied mmap can be reported only after its genuine return executes an injected trap, while the return remains
 * held. This operation supports whole-attempt termination, rather than restoring and retrying the denied instruction.
 */
public final class LinuxAllocationTrace
{
	/** Linux ptrace requests from linux/ptrace.h. */
	private static final int PEEK = 1, POKE = 4, CONT = 7, GETREGS = 12, SYSCALL = 24,
		GETEVENTMSG = 0x4201, SEIZE = 0x4206, INTERRUPT = 0x4207, GET_SYSCALL_INFO = 0x420e;
	/** Trace syscall stops, descendants and exec; kernel kills tracees when their tracing thread exits. */
	private static final long TRACE_OPTIONS = 0x10001f;
	/** Linux wait flags: all traced children, restricted to children of this native thread. */
	private static final int WAIT_OWNED = 0x60000000;
	/** Linux WNOHANG permits caller cancellation to reach the sole tracing thread. */
	private static final int NOHANG = 1;
	/** Linux signals needed by stopped-shell startup, trap recognition, and terminal collection. */
	private static final int KILL = 9, STOP = 19, CONTINUE = 18, TRAP = 5, SYSCALL_TRAP = 133;
	/** Linux mmap syscall and ENOMEM number for the x86-64 syscall ABI. */
	private static final long MMAP = 9, NO_MEMORY = -12;
	/** Constant bootstrap receives cwd and command exclusively through distinct positional arguments. */
	private static final String BOOTSTRAP = "kill -STOP $$; cd -- \"$1\" || exit 125; shift; exec \"$@\"";
	/** Same-call errno offset from the JDK linker-owned capture layout. */
	private static final long ERRNO_OFFSET = Linker.Option.captureStateLayout()
		.byteOffset(MemoryLayout.PathElement.groupElement("errno"));

	/**
	 * Prevents construction of this command owner through an instance.
	 */
	private LinuxAllocationTrace()
	{
	}

	/**
	 * One kernel task's identity, combining its ID with Linux stat field 22 to distinguish PID reuse.
	 * @param tid Linux task ID
	 * @param birthTicks start time in kernel clock ticks since boot
	 */
	public record Identity(int tid, long birthTicks)
	{
		/**
		 * Validates a native task identity.
		 * @param tid positive Linux task ID
		 * @param birthTicks nonnegative start time in clock ticks since boot
		 * @throws IllegalArgumentException if either value is outside its native identity range
		 */
		public Identity
		{
			if (tid <= 0 || birthTicks < 0)
				throw new IllegalArgumentException("Task ID must be positive and birth ticks nonnegative");
		}
	}

	/**
	 * A genuine denied mmap whose next instruction executed INT3 and remains stopped for the handler.
	 * @param thread identity of the stopped allocating thread
	 * @param processId thread-group ID containing that thread
	 * @param syscall native x86-64 syscall number
	 * @param requestedBytes mmap length in bytes
	 * @param nativeResult unmodified kernel return in RAX
	 * @param returnAddress address immediately after the syscall instruction
	 * @param trapPc observed RIP after executing the injected INT3
	 * @param syscallBytes two bytes immediately preceding the return address, as lowercase hexadecimal
	 * @param originalInstructionByte original byte replaced by INT3, as an unsigned value
	 * @param executableMapping native maps record containing the executable return instruction
	 */
	public record Denial(Identity thread, int processId, long syscall, long requestedBytes, long nativeResult,
		long returnAddress, long trapPc, String syscallBytes, int originalInstructionByte, String executableMapping)
	{
		/**
		 * Retains one verified denial observation.
		 * @param thread allocating thread identity
		 * @param processId allocating process ID
		 * @param syscall native syscall number
		 * @param requestedBytes requested mapping length
		 * @param nativeResult unmodified native error result
		 * @param returnAddress native syscall return instruction address
		 * @param trapPc native instruction pointer after INT3
		 * @param syscallBytes native syscall opcode
		 * @param originalInstructionByte unsigned instruction byte replaced by INT3
		 * @param executableMapping executable maps record
		 * @throws NullPointerException if a reference parameter is null
		 * @throws IllegalArgumentException if the observation does not describe an executed denied mmap trap
		 */
		public Denial
		{
			Objects.requireNonNull(thread, "thread");
			Objects.requireNonNull(syscallBytes, "syscallBytes");
			Objects.requireNonNull(executableMapping, "executableMapping");
			if (processId <= 0 || syscall != MMAP || requestedBytes <= 0 || nativeResult != NO_MEMORY ||
				trapPc != returnAddress + 1 || !syscallBytes.equals("0f05") ||
				originalInstructionByte < 0 || originalInstructionByte > 255)
				throw new IllegalArgumentException("Observation must describe mmap ENOMEM and its executed INT3");
		}
	}

	/**
	 * Receives a denial while its allocating thread remains at the executed trap. Returning requests termination
	 * of the complete attempt; throwing also terminates and collects the attempt before propagating the failure.
	 */
	@FunctionalInterface
	public interface DenialHandler
	{
		/**
		 * Examines a held denial before choosing whole-attempt termination by returning.
		 * Runs on the dedicated tracing thread and must return for termination to proceed.
		 * @param denial identity-bound native observation
		 * @throws IOException if the consumer cannot process the observation
		 */
		void terminate(Denial denial) throws IOException;
	}

	/**
	 * Authentic native terminal status collected for one traced task.
	 * @param identity collected kernel task
	 * @param waitStatus unmodified Linux wait status; low seven bits distinguish exit from signal
	 */
	public record Terminal(Identity identity, int waitStatus)
	{
		/**
		 * Retains the collected status.
		 * @param identity collected kernel task
		 * @param waitStatus raw Linux wait status
		 * @throws NullPointerException if {@code identity} is null
		 * @throws IllegalArgumentException if the status describes a stopped task
		 */
		public Terminal
		{
			Objects.requireNonNull(identity, "identity");
			if ((waitStatus & 255) == 127)
				throw new IllegalArgumentException("Terminal status must not describe a stopped task");
		}
	}

	/**
	 * Fully collected attempt, preserving root and descendant native outcomes in collection order.
	 * @param root root task's authentic terminal status
	 * @param collected statuses for every task that this attempt traced
	 * @param denied indicates whether an executed mmap-denial trap was delivered to the handler
	 */
	public record Outcome(Terminal root, List<Terminal> collected, boolean denied)
	{
		/**
		 * Freezes an attempt's collected statuses.
		 * @param root root task's terminal status
		 * @param collected all collected task statuses
		 * @param denied indicates whether a denial reached the handler
		 * @throws NullPointerException if a reference parameter or collected entry is null
		 * @throws IllegalArgumentException if collected statuses omit the root
		 */
		public Outcome
		{
			Objects.requireNonNull(root, "root");
			collected = List.copyOf(collected);
			if (!collected.contains(root))
				throw new IllegalArgumentException("Collected statuses must include the root task");
		}
	}

	/**
	 * Executes one owned command with explicit environment and cwd, inheriting native descriptors 0, 1 and 2.
	 * A positive address-space limit applies only to the child before command execution; zero leaves its limit intact.
	 * On caller interruption the owner kills and collects the attempt before this method throws.
	 * @param linker borrowed JDK native linker, kept available throughout the operation
	 * @param argv executable name followed by its arguments; no element may contain NUL
	 * @param environment complete child environment; keys must be nonempty and contain neither equals nor NUL
	 * @param directory existing child working directory
	 * @param addressSpaceBytes child RLIMIT_AS soft and hard limit in bytes, or zero for no change
	 * @param handler consumer of held genuine allocation failures
	 * @return authentic root and descendant outcomes after every tracee is collected
	 * @throws NullPointerException if a reference parameter, argument, environment key or value is null
	 * @throws IllegalArgumentException if arguments, environment or limit violate their documented form
	 * @throws UnsupportedOperationException if Linux x86-64 or a required libc symbol is unavailable
	 * @throws IOException if native startup, tracing, observation, callback or collection fails
	 * @throws InterruptedException if the caller is interrupted, after native collection completes
	 */
	public static Outcome run(Linker linker, List<String> argv, Map<String, String> environment,
		Path directory, long addressSpaceBytes, DenialHandler handler) throws IOException, InterruptedException
	{
		Objects.requireNonNull(linker, "linker");
		Objects.requireNonNull(directory, "directory");
		Objects.requireNonNull(handler, "handler");
		List<String> command = List.copyOf(argv);
		Map<String, String> variables = Map.copyOf(environment);
		if (command.isEmpty() || command.getFirst().isEmpty() || addressSpaceBytes < 0)
			throw new IllegalArgumentException("Command must name an executable and limit must be nonnegative");
		for (String argument : command)
			validateText(argument);
		for (Map.Entry<String, String> variable : variables.entrySet())
		{
			validateText(variable.getKey());
			validateText(variable.getValue());
			if (variable.getKey().isEmpty() || variable.getKey().contains("="))
				throw new IllegalArgumentException("Environment key must be nonempty and contain no equals sign");
		}
		if (!Files.isDirectory(directory))
			throw new IOException("Child working directory does not exist: " + directory);
		if (!System.getProperty("os.name").equals("Linux") || !System.getProperty("os.arch").equals("amd64"))
			throw new UnsupportedOperationException("Allocation tracing requires Linux x86-64");

		AtomicBoolean cancel = new AtomicBoolean();
		AtomicReference<Outcome> result = new AtomicReference<>();
		AtomicReference<Throwable> failure = new AtomicReference<>();
		Thread owner = Thread.ofPlatform().name("linux-allocation-trace").unstarted(() ->
		{
			try
			{
				result.set(new Attempt(linker, cancel, handler).execute(command, variables, directory,
					addressSpaceBytes));
			}
			catch (Throwable problem)
			{
				// This is the platform-thread result boundary; the caller rethrows the original failure.
				failure.set(problem);
			}
		});
		owner.start();
		boolean interrupted = false;
		while (owner.isAlive())
		{
			try
			{
				owner.join();
			}
			catch (InterruptedException problem)
			{
				interrupted = true;
				cancel.set(true);
			}
		}
		if (interrupted)
		{
			InterruptedException problem = new InterruptedException("Tracing attempt collected after interruption");
			if (failure.get() != null)
				problem.addSuppressed(failure.get());
			throw problem;
		}
		Throwable problem = failure.get();
		if (problem instanceof IOException io)
			throw io;
		if (problem instanceof RuntimeException runtime)
			throw runtime;
		if (problem instanceof Error error)
			throw error;
		if (problem != null)
			throw new IOException("Tracing owner failed", problem);
		return Objects.requireNonNull(result.get(), "Tracing owner supplied no outcome");
	}

	/**
	 * Rejects text that cannot be represented by a native NUL-terminated argument.
	 * @param text argument or environment component
	 * @throws IllegalArgumentException if text contains NUL
	 */
	private static void validateText(String text)
	{
		if (text.indexOf('\0') >= 0)
			throw new IllegalArgumentException("Native argument must contain no NUL character");
	}

	/**
	 * Native result paired with the errno captured by that same downcall.
	 * @param value native scalar return
	 * @param errno captured Linux errno, inspected only when that operation reports failure
	 */
	private record NativeResult(long value, int errno)
	{
	}

	/**
	 * Owns one tracing thread's native calls, task identities, syscall observations and terminal collection.
	 */
	private static final class Attempt
	{
		/** Same-thread cancellation request from the joining caller. */
		private final AtomicBoolean cancel;
		/** Consumer that chooses termination after receiving a held denial. */
		private final DenialHandler handler;
		/** Every tracee remains here until waitpid supplies its terminal status. */
		private final Map<Integer, Identity> owned = new LinkedHashMap<>();
		/** Entry mmap lengths keyed by task ID until the corresponding syscall exit. */
		private final Map<Integer, Long> mmapLengths = new HashMap<>();
		/** Every authentic terminal status, in collection order. */
		private final List<Terminal> collected = new ArrayList<>();
		/** libc ptrace, with promoted variadic pointer arguments on Linux LP64. */
		private final MethodHandle ptrace;
		/** libc waitpid, scoped to this dedicated native thread's children and tracees. */
		private final MethodHandle waitpid;
		/** libc posix_spawn; NULL actions and attributes preserve inherited descriptors. */
		private final MethodHandle spawn;
		/** libc kill for controlled startup and whole-attempt termination. */
		private final MethodHandle kill;
		/** libc prlimit64 limits only the stopped child, never the controller. */
		private final MethodHandle prlimit;
		/** Root identity, retained even after the root exits before its descendants. */
		private Identity root;
		/** Indicates whether the consumer received an executed denial trap. */
		private boolean denied;

		/**
		 * Resolves all libc operations before acquiring a process.
		 * @param linker borrowed JDK native linker
		 * @param cancel caller cancellation request
		 * @param handler held-denial consumer
		 * @throws UnsupportedOperationException if a required libc symbol is absent
		 */
		private Attempt(Linker linker, AtomicBoolean cancel, DenialHandler handler)
		{
			this.cancel = cancel;
			this.handler = handler;
			this.ptrace = bind(linker, "ptrace", FunctionDescriptor.of(ValueLayout.JAVA_LONG,
				ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.ADDRESS), true);
			this.waitpid = bind(linker, "waitpid", FunctionDescriptor.of(ValueLayout.JAVA_INT,
				ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.JAVA_INT), false);
			this.spawn = bind(linker, "posix_spawn", FunctionDescriptor.of(ValueLayout.JAVA_INT,
				ValueLayout.ADDRESS, ValueLayout.ADDRESS, ValueLayout.ADDRESS, ValueLayout.ADDRESS,
				ValueLayout.ADDRESS, ValueLayout.ADDRESS), false);
			this.kill = bind(linker, "kill", FunctionDescriptor.of(ValueLayout.JAVA_INT,
				ValueLayout.JAVA_INT, ValueLayout.JAVA_INT), false);
			this.prlimit = bind(linker, "prlimit64", FunctionDescriptor.of(ValueLayout.JAVA_INT,
				ValueLayout.JAVA_INT, ValueLayout.JAVA_INT, ValueLayout.ADDRESS, ValueLayout.ADDRESS), false);
		}

		/**
		 * Binds one libc symbol with same-call errno capture.
		 * @param linker borrowed ABI linker
		 * @param symbol required libc symbol name
		 * @param descriptor exact Linux x86-64 signature
		 * @param variadic indicates whether arguments after the first are promoted ptrace varargs
		 * @return bound native operation
		 * @throws UnsupportedOperationException if the symbol is absent
		 */
		// These explicitly described Linux x86-64 libc signatures require the restricted FFM downcall API.
		@SuppressWarnings("restricted")
		private static MethodHandle bind(Linker linker, String symbol, FunctionDescriptor descriptor,
			boolean variadic)
		{
			MemorySegment address = linker.defaultLookup().find(symbol)
				.orElseThrow(() -> new UnsupportedOperationException("Missing libc symbol: " + symbol));
			if (variadic)
				return linker.downcallHandle(address, descriptor, Linker.Option.captureCallState("errno"),
					Linker.Option.firstVariadicArg(1));
			return linker.downcallHandle(address, descriptor, Linker.Option.captureCallState("errno"));
		}

		/**
		 * Invokes a resolved native function and retains its scalar result and captured errno.
		 * @param function resolved native operation
		 * @param arguments arguments after the JDK capture-state parameter
		 * @return unmodified native result and errno
		 * @throws IOException if the foreign invocation cannot execute
		 */
		private static NativeResult call(MethodHandle function, Object... arguments) throws IOException
		{
			try (Arena arena = Arena.ofConfined())
			{
				MemorySegment state = arena.allocate(Linker.Option.captureStateLayout());
				List<Object> values = new ArrayList<>();
				values.add(state);
				values.addAll(List.of(arguments));
				try
				{
					long result = ((Number) function.invokeWithArguments(values)).longValue();
					return new NativeResult(result, state.get(ValueLayout.JAVA_INT, ERRNO_OFFSET));
				}
				catch (Throwable problem)
				{
					throw new IOException("libc downcall failed before a native result was obtained", problem);
				}
			}
		}

		/**
		 * Runs and collects the complete attempt, cleaning acquired tasks on every failure.
		 * @param argv command arguments
		 * @param environment complete child environment
		 * @param directory child working directory
		 * @param addressSpaceBytes child-only address-space cap, or zero
		 * @return authentic collected native outcomes
		 * @throws IOException if startup, tracing, callback or cleanup fails
		 */
		private Outcome execute(List<String> argv, Map<String, String> environment, Path directory,
			long addressSpaceBytes) throws IOException
		{
			try
			{
				start(argv, environment, directory, addressSpaceBytes);
				while (!owned.isEmpty())
				{
					if (cancel.get())
						throw new InterruptedIOException("Caller requested tracing cancellation");
					waitOne(true);
				}
				Terminal rootTerminal = collected.stream().filter(item -> item.identity().equals(root))
					.findFirst().orElseThrow(() -> new IOException("Root terminal status was not collected"));
				return new Outcome(rootTerminal, collected, denied);
			}
			catch (IOException | RuntimeException | Error problem)
			{
				try
				{
					terminateAll();
				}
				catch (IOException cleanup)
				{
					problem.addSuppressed(cleanup);
				}
				throw problem;
			}
		}

		/**
		 * Allocates a native argv or envp vector ending in NULL.
		 * @param arena argument lifetime extending through posix_spawn
		 * @param strings argument or environment strings
		 * @return native vector of NUL-terminated strings
		 */
		private static MemorySegment vector(Arena arena, List<String> strings)
		{
			MemorySegment values = arena.allocate(ValueLayout.ADDRESS, strings.size() + 1L);
			for (int index = 0; index < strings.size(); ++index)
				values.setAtIndex(ValueLayout.ADDRESS, index, arena.allocateFrom(strings.get(index)));
			return values;
		}

		/**
		 * Spawns a stopped bootstrap, establishes sole trace ownership and child limit, then releases its exec.
		 * @param argv command arguments
		 * @param environment complete environment
		 * @param directory child working directory
		 * @param addressSpaceBytes child-only limit, or zero
		 * @throws IOException if spawning, stopped readiness, tracing or limiting fails
		 */
		private void start(List<String> argv, Map<String, String> environment, Path directory,
			long addressSpaceBytes) throws IOException
		{
			try (Arena arena = Arena.ofConfined())
			{
				List<String> bootstrap = new ArrayList<>(List.of("sh", "-c", BOOTSTRAP,
					"allocation-bootstrap", directory.toAbsolutePath().toString()));
				bootstrap.addAll(argv);
				List<String> variables = environment.entrySet().stream()
					.map(item -> item.getKey() + "=" + item.getValue()).toList();
				MemorySegment pidValue = arena.allocate(ValueLayout.JAVA_INT);
				NativeResult spawned = call(spawn, pidValue, arena.allocateFrom("/bin/sh"), MemorySegment.NULL,
					MemorySegment.NULL, vector(arena, bootstrap), vector(arena, variables));
				if (spawned.value() != 0)
					throw new IOException("posix_spawn failed with error " + spawned.value());
				int pid = pidValue.get(ValueLayout.JAVA_INT, 0);
				// Register ownership immediately; a failed identity read must still kill and wait for this child.
				owned.put(pid, new Identity(pid, 0));
				root = identify(pid);
				owned.put(pid, root);
				MemorySegment status = arena.allocate(ValueLayout.JAVA_INT);
				NativeResult stopped = call(waitpid, pid, status, 2);
				if (stopped.value() != pid || status.get(ValueLayout.JAVA_INT, 0) != ((STOP << 8) | 127))
					throw new IOException("Bootstrap did not reach its owned SIGSTOP readiness boundary");
				trace(SEIZE, pid, 0, MemorySegment.ofAddress(TRACE_OPTIONS));
				trace(INTERRUPT, pid, 0, MemorySegment.NULL);
				NativeResult interrupted = call(waitpid, pid, status, WAIT_OWNED);
				if (interrupted.value() != pid || (status.get(ValueLayout.JAVA_INT, 0) & 255) != 127)
					throw new IOException("Seized bootstrap did not enter a ptrace stop");
				if (addressSpaceBytes > 0)
				{
					MemorySegment limits = arena.allocate(16, 8);
					limits.set(ValueLayout.JAVA_LONG, 0, addressSpaceBytes);
					limits.set(ValueLayout.JAVA_LONG, 8, addressSpaceBytes);
					NativeResult limited = call(prlimit, pid, 9, limits, MemorySegment.NULL);
					if (limited.value() != 0)
						throw new IOException("Child prlimit64 failed with errno " + limited.errno());
				}
				signal(pid, CONTINUE);
				trace(SYSCALL, pid, 0, MemorySegment.NULL);
			}
		}

		/**
		 * Reads the kernel birth identity of one already-owned task.
		 * @param tid owned kernel task ID
		 * @return task ID paired with stat start ticks
		 * @throws IOException if the native stat record cannot be read
		 */
		private static Identity identify(int tid) throws IOException
		{
			String stat = Files.readString(Path.of("/proc", Integer.toString(tid), "stat"));
			String[] fields = stat.substring(stat.lastIndexOf(')') + 2).split(" ");
			return new Identity(tid, Long.parseLong(fields[19]));
		}

		/**
		 * Invokes ptrace and rejects its same-call error without confusing a valid minus-one data word.
		 * @param operation ptrace request
		 * @param tid owned target task
		 * @param address request address or byte-count argument
		 * @param data request pointer or promoted scalar
		 * @return native ptrace result
		 * @throws IOException if ptrace returns minus one with a captured nonzero errno
		 */
		private long trace(int operation, int tid, long address, MemorySegment data) throws IOException
		{
			NativeResult result = call(ptrace, operation, tid, MemorySegment.ofAddress(address), data);
			if (result.value() == -1 && result.errno() != 0)
				throw new IOException("ptrace request " + operation + " for task " + tid +
					" failed with errno " + result.errno());
			return result.value();
		}

		/**
		 * Sends a signal to an owned task, accepting ESRCH when its terminal status is already pending.
		 * @param tid owned task ID
		 * @param signal native signal number
		 * @throws IOException if kill fails for a reason other than the target already exiting
		 */
		private void signal(int tid, int signal) throws IOException
		{
			NativeResult result = call(kill, tid, signal);
			if (result.value() != 0 && result.errno() != 3)
				throw new IOException("kill for task " + tid + " failed with errno " + result.errno());
		}

		/**
		 * Collects or services one stop, preserving descendant tracking after the root exits.
		 * @param running indicates whether normal syscall tracing remains enabled
		 * @throws IOException if wait, ptrace or a denial callback fails
		 */
		private void waitOne(boolean running) throws IOException
		{
			try (Arena arena = Arena.ofConfined())
			{
				MemorySegment statusValue = arena.allocate(ValueLayout.JAVA_INT);
				NativeResult waited = call(waitpid, -1, statusValue, WAIT_OWNED | NOHANG);
				if (waited.value() == 0)
				{
					LockSupport.parkNanos(1_000_000);
					return;
				}
				if (waited.value() < 0)
				{
					if (waited.errno() == 4)
						return;
					throw new IOException("Owned waitpid failed with errno " + waited.errno());
				}
				int tid = Math.toIntExact(waited.value());
				int status = statusValue.get(ValueLayout.JAVA_INT, 0);
				Identity identity = owned.get(tid);
				if (identity == null)
				{
					identity = identify(tid);
					owned.put(tid, identity);
				}
				boolean stopped = (status & 255) == 127;
				if (!stopped)
				{
					collected.add(new Terminal(identity, status));
					owned.remove(tid);
					mmapLengths.remove(tid);
					return;
				}
				int event = status >>> 16;
				int stopSignal = (status >>> 8) & 255;
				switch (event)
				{
					case 1, 2, 3 ->
					{
						MemorySegment child = arena.allocate(ValueLayout.JAVA_LONG);
						trace(GETEVENTMSG, tid, 0, child);
						int childTid = Math.toIntExact(child.get(ValueLayout.JAVA_LONG, 0));
						owned.putIfAbsent(childTid, identify(childTid));
					}
					case 4 -> mmapLengths.remove(tid);
					default -> { }
				}
				if (!running)
				{
					signal(tid, KILL);
					trace(CONT, tid, 0, MemorySegment.ofAddress(KILL));
					return;
				}
				if (stopSignal == SYSCALL_TRAP)
					handleSyscall(tid, arena);
				if (denied)
				{
					terminateAll();
					return;
				}
				int deliver = switch (stopSignal)
				{
					case SYSCALL_TRAP, STOP, CONTINUE -> 0;
					case TRAP -> event == 0 ? TRAP : 0;
					default -> stopSignal;
				};
				trace(SYSCALL, tid, 0, MemorySegment.ofAddress(deliver));
			}
		}

		/**
		 * Observes mmap entry and exit, injecting a trap only after a genuine ENOMEM return.
		 * @param tid stopped allocating task
		 * @param arena native argument lifetime
		 * @throws IOException if syscall observation fails
		 */
		private void handleSyscall(int tid, Arena arena) throws IOException
		{
			MemorySegment info = arena.allocate(88, 8);
			trace(GET_SYSCALL_INFO, tid, info.byteSize(), info);
			int operation = Byte.toUnsignedInt(info.get(ValueLayout.JAVA_BYTE, 0));
			if (operation == 1)
			{
				mmapLengths.remove(tid);
				if (info.get(ValueLayout.JAVA_LONG, 24) == MMAP)
					mmapLengths.put(tid, info.get(ValueLayout.JAVA_LONG, 40));
			}
			Long requestedBytes = mmapLengths.get(tid);
			boolean deniedMmap = operation == 2 && requestedBytes != null &&
				info.get(ValueLayout.JAVA_LONG, 24) == NO_MEMORY;
			if (deniedMmap)
				holdDeniedReturn(tid, requestedBytes, info.get(ValueLayout.JAVA_LONG, 8), arena);
		}

		/**
		 * Reads one task register block using the Linux x86-64 user_regs_struct ABI.
		 * @param tid owned stopped task
		 * @param arena storage lifetime
		 * @return register bytes, with RAX at offset 80 and RIP at offset 128
		 * @throws IOException if native register access fails
		 */
		private MemorySegment registers(int tid, Arena arena) throws IOException
		{
			MemorySegment registers = arena.allocate(216, 8);
			trace(GETREGS, tid, 0, registers);
			return registers;
		}

		/**
		 * Reads one instruction byte without reading across its aligned native word.
		 * @param tid owned stopped task
		 * @param address instruction address
		 * @return unsigned native instruction byte
		 * @throws IOException if ptrace cannot read the word
		 */
		private int instructionByte(int tid, long address) throws IOException
		{
			long word = trace(PEEK, tid, address & -8L, MemorySegment.NULL);
			int shift = Math.toIntExact((address & 7) * 8);
			return (int) ((word >>> shift) & 255);
		}

		/**
		 * Executes a real INT3 after the denied mmap without modifying the native return register.
		 * @param tid owned allocating thread at syscall exit
		 * @param requestedBytes genuine mmap length observed at entry
		 * @param returnAddress kernel-reported instruction pointer at syscall exit
		 * @param arena native observation lifetime
		 * @throws IOException if opcode, mapping, registers, or executed trap cannot be verified
		 */
		private void holdDeniedReturn(int tid, long requestedBytes, long returnAddress, Arena arena)
			throws IOException
		{
			MemorySegment before = registers(tid, arena);
			String opcode = "%02x%02x".formatted(instructionByte(tid, returnAddress - 2),
				instructionByte(tid, returnAddress - 1));
			if (before.get(ValueLayout.JAVA_LONG, 80) != NO_MEMORY ||
				before.get(ValueLayout.JAVA_LONG, 128) != returnAddress || !opcode.equals("0f05"))
				throw new IOException("Denied mmap did not stop immediately after its x86-64 syscall opcode");
			String mapping = null;
			for (String line : Files.readAllLines(Path.of("/proc", Integer.toString(tid), "maps")))
			{
				String[] fields = line.split("\\s+", 3);
				String[] range = fields[0].split("-");
				long start = Long.parseUnsignedLong(range[0], 16);
				long end = Long.parseUnsignedLong(range[1], 16);
				if (returnAddress >= start && returnAddress < end && fields[1].contains("x"))
				{
					mapping = line;
					break;
				}
			}
			if (mapping == null)
				throw new IOException("Denied mmap return instruction has no executable native mapping");
			long wordAddress = returnAddress & -8L;
			int shift = Math.toIntExact((returnAddress & 7) * 8);
			long originalWord = trace(PEEK, tid, wordAddress, MemorySegment.NULL);
			int originalByte = (int) ((originalWord >>> shift) & 255);
			if (originalByte == 0xcc)
				throw new IOException("Denied mmap return instruction already contains INT3");
			long mask = 255L << shift;
			long patchedWord = (originalWord & ~mask) | (0xccL << shift);
			trace(POKE, tid, wordAddress, MemorySegment.ofAddress(patchedWord));
			trace(CONT, tid, 0, MemorySegment.NULL);
			MemorySegment statusValue = arena.allocate(ValueLayout.JAVA_INT);
			while (true)
			{
				if (cancel.get())
					throw new InterruptedIOException("Caller cancelled before injected trap completed");
				NativeResult waited = call(waitpid, tid, statusValue, WAIT_OWNED | NOHANG);
				if (waited.value() == 0)
				{
					LockSupport.parkNanos(1_000_000);
					continue;
				}
				if (waited.value() != tid)
					throw new IOException("Waiting for injected trap failed with errno " + waited.errno());
				int status = statusValue.get(ValueLayout.JAVA_INT, 0);
				if ((status & 255) != 127)
				{
					collected.add(new Terminal(owned.remove(tid), status));
					throw new IOException("Allocating thread exited before executing its injected trap");
				}
				int stoppedBy = (status >>> 8) & 255;
				if (stoppedBy == TRAP && (status >>> 16) == 0)
					break;
				trace(CONT, tid, 0, MemorySegment.ofAddress(stoppedBy));
			}
			MemorySegment trapped = registers(tid, arena);
			if (trapped.get(ValueLayout.JAVA_LONG, 80) != NO_MEMORY ||
				trapped.get(ValueLayout.JAVA_LONG, 128) != returnAddress + 1)
				throw new IOException("Executed INT3 did not preserve the genuine denied mmap return");
			int processId = 0;
			for (String line : Files.readAllLines(Path.of("/proc", Integer.toString(tid), "status")))
				if (line.startsWith("Tgid:"))
					processId = Integer.parseInt(line.substring(5).strip());
			Denial denial = new Denial(owned.get(tid), processId, MMAP, requestedBytes, NO_MEMORY,
				returnAddress, trapped.get(ValueLayout.JAVA_LONG, 128), opcode, originalByte, mapping);
			denied = true;
			handler.terminate(denial);
		}

		/**
		 * Kills and collects every traced task, including children discovered during terminal collection.
		 * @throws IOException if native killing or collection fails
		 */
		private void terminateAll() throws IOException
		{
			for (int tid : List.copyOf(owned.keySet()))
				signal(tid, KILL);
			while (!owned.isEmpty())
				waitOne(false);
		}
	}
}
