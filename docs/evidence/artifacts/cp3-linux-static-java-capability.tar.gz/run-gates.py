"""Compile only the sealed recreation and exercise its public operation, retaining every exact command and exit."""
import os,json,subprocess,hashlib
from pathlib import Path
root=Path(os.environ['JAVA_TRACE_WORK']);jdk=Path(os.environ['TRACE_JDK']);cp3=Path(os.environ['CP3_WORK'])
recreation=root/'recreation'; expected={'LinuxAllocationTrace.java','dependencies.json','resolution.json'}
assert {p.name for p in recreation.iterdir()}==expected
classes=root/'final-classes';classes.mkdir()
records=[]
def run(name,command):
    """Retain one actual command result; fail only after its command and diagnostics are safely recorded."""
    with (root/(name+'.log')).open('wb') as output:
        result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':str(root)})
    records.append({'gate':name,'command':command,'exit':result.returncode,'log':name+'.log'})
    (root/'gates.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode==0,name
flags=['--release','27','-Xlint:all,-processing','-Werror','-Xdoclint:all/private']
run('final-compile',[str(jdk/'bin/javac'),*flags,'-d',str(classes),str(recreation/'LinuxAllocationTrace.java')])
run('fixture-compile',[str(jdk/'bin/javac'),*flags,'-cp',str(classes),'-d',str(classes),str(root/'TraceFixture.java')])
for gate in ['version','denial','exit23','fork']:
    run('final-'+gate,[str(jdk/'bin/java'),'--enable-native-access=ALL-UNNAMED','-cp',str(classes),'TraceFixture',gate,str(cp3/'zig-linux-x86_64-0.14.0/zig'),str(root)])
    data=(root/('final-'+gate+'.log')).read_text()
    assert 'GATE='+gate+':PASSED' in data
    assert 'REMAINING_OWNED_TASKS=0' in data
    assert 'ZIG_SHA256=77340932066b76bc9f3a4ac120288f21790ed2836e5cd5a003f4a3c12f37d765' in data
    if gate=='version': assert data.splitlines()[0]=='0.14.0'
(root/'jdk-release.txt').write_bytes((jdk/'release').read_bytes())
(root/'source-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in recreation.iterdir()},indent=2)+'\n')
print('ALL_FOUR_NATIVE_GATES_PASSED',flush=True)
