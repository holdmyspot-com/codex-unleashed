"""Evaluate owned stopped-shell PTRACE_SEIZE and genuine exit23; collect the sole child on every path."""
import ctypes,os,signal,json
c=ctypes.CDLL(None,use_errno=True);c.ptrace.restype=ctypes.c_long
pid=os.posix_spawn('/bin/sh',['sh','-c','kill -STOP $$; exec "$@"','bootstrap','/bin/sh','-c','exit 23'],dict(os.environ))
rows=[]
try:
    stopped=os.waitpid(pid,os.WUNTRACED);rows.append({'bootstrap_wait':stopped})
    assert os.WIFSTOPPED(stopped[1])
    assert c.ptrace(0x4206,pid,0,0x10001f)==0
    assert c.ptrace(0x4207,pid,0,0)==0
    rows.append({'seize_interrupt_wait':os.waitpid(pid,0x40000000)})
    os.kill(pid,signal.SIGCONT)
    assert c.ptrace(24,pid,0,0)==0
    while True:
        p,s=os.waitpid(pid,0x40000000)
        if os.WIFEXITED(s):
            rows.append({'terminal_exit':os.WEXITSTATUS(s)});break
        assert os.WIFSTOPPED(s),(p,s)
        sig=os.WSTOPSIG(s); event=s>>16
        if event==4: rows.append({'exec_event':event})
        assert c.ptrace(24,pid,0,0 if sig in (5,19,18,133) else sig)==0
finally:
    try:os.kill(pid,9)
    except ProcessLookupError:pass
    try:os.waitpid(pid,0x40000000)
    except ChildProcessError:pass
print(json.dumps({'operation':'posix_spawn -> group-stop -> SEIZE -> INTERRUPT -> SYSCALL -> waitpid','results':rows,'remaining':os.path.exists('/proc/'+str(pid))}))
