import com.holdmyspot.codexunleashed.scheduler.LinuxAllocationTrace;
import java.io.IOException;
import java.lang.foreign.Linker;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Exercises the public trace operation on unchanged native Zig and owned shell fork/exit cases.
 */
public final class TraceFixture
{
	/**
	 * Prevents fixture construction.
	 */
	private TraceFixture()
	{
	}

	/**
	 * Runs one independently retained native acceptance case.
	 * @param args mode, Zig executable, and owned fixture directory
	 * @throws Exception if a required native observation or assertion fails
	 */
	public static void main(String[] args) throws Exception
	{
		String mode = args[0];
		Path zig = Path.of(args[1]);
		Path work = Path.of(args[2]);
		Map<String, String> env = Map.of("PATH", "/usr/bin:/bin", "HOME", work.toString(),
			"TMPDIR", work.toString(), "ZIG_LOCAL_CACHE_DIR", work.resolve("zig-local").toString(),
			"ZIG_GLOBAL_CACHE_DIR", work.resolve("zig-global").toString());
		AtomicInteger denials = new AtomicInteger();
		String before = digest(zig);
		Files.writeString(work.resolve("tiny.c"), "int value(void) { return 42; }\n");
		List<String> command = switch (mode)
		{
			case "version" -> List.of(zig.toString(), "version");
			case "denial" -> List.of(zig.toString(), "cc", "-c", "tiny.c", "-o", "tiny.o");
			case "exit23" -> List.of("/bin/sh", "-c", "exit 23");
			case "fork" -> List.of("/bin/sh", "-c", "sleep 2 & exit 23");
			default -> throw new IllegalArgumentException("Unknown native case: " + mode);
		};
		long cap = mode.equals("denial") ? 209715200 : 0;
		LinuxAllocationTrace.Outcome outcome = LinuxAllocationTrace.run(Linker.nativeLinker(), command, env,
			work, cap, denial ->
			{
				denials.incrementAndGet();
				System.out.println("NATIVE_DENIAL=" + denial);
				Path statPath = Path.of("/proc", Integer.toString(denial.thread().tid()), "stat");
				String first = Files.readString(statPath);
				try
				{
					Thread.sleep(2000);
				}
				catch (InterruptedException interrupted)
				{
					Thread.currentThread().interrupt();
					throw new IOException("Held-denial observation interrupted", interrupted);
				}
				String second = Files.readString(statPath);
				if (!first.substring(first.lastIndexOf(')') + 2).startsWith("t ") ||
					!second.substring(second.lastIndexOf(')') + 2).startsWith("t "))
					throw new IOException("Allocating thread did not remain held throughout caller decision");
				System.out.println("HELD_TWO_SECONDS=true");
			});
		System.out.println("OUTCOME=" + outcome);
		if (mode.equals("denial"))
		{
			if (denials.get() != 1 || !outcome.denied() || (outcome.root().waitStatus() & 127) != 9)
				throw new IOException("Genuine denied mmap was not delivered held to the Java caller");
		}
		else
		{
			int expectedExit = mode.equals("version") ? 0 : 23;
			if (denials.get() != 0 || outcome.denied() || outcome.root().waitStatus() != (expectedExit << 8))
				throw new IOException("Authentic native exit or absence of a denial was not preserved");
		}
		if (mode.equals("fork"))
		{
			if (outcome.collected().size() < 2 || !outcome.collected().getFirst().equals(outcome.root()))
				throw new IOException("Root did not exit before its owned fork/exec descendant was collected");
		}
		for (LinuxAllocationTrace.Terminal terminal : outcome.collected())
			if (Files.exists(Path.of("/proc", Integer.toString(terminal.identity().tid()))))
				throw new IOException("Collected task remains in proc: " + terminal.identity());
		String after = digest(zig);
		if (!before.equals(after))
			throw new IOException("On-disk Zig changed during native tracing");
		System.out.println("ZIG_SHA256=" + after);
		System.out.println("REMAINING_OWNED_TASKS=0");
		System.out.println("GATE=" + mode + ":PASSED");
	}

	/**
	 * Hashes the unchanged native executable for the before/after assertion.
	 * @param file native executable
	 * @return lowercase SHA-256
	 * @throws Exception if the file cannot be hashed
	 */
	private static String digest(Path file) throws Exception
	{
		return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(file)));
	}
}
