set -euo pipefail
python3 - <<'PY_REMOTE'
from pathlib import Path
import tarfile,hashlib,json,re,base64,subprocess,os
r=Path('/Users/runner/work/_temp/macos-close-WQ5ZW8-native-arm-f81.5UVTEL');os.chdir(r)
(r/'publish-fixed-products.py').write_bytes(base64.b64decode('IiIiUHVibGlzaCB0aGUgY3JlZGVudGlhbC1mcmVlIGFyY2hpdmUgdGhyb3VnaCB0aGUgd29ya2Zsb3cncyBhbHJlYWR5IHBpbm5lZCBvZmZpY2lhbCBhcnRpZmFjdCBhY3Rpb24uIiIiCmltcG9ydCBwYXRobGliLHN1YnByb2Nlc3Msb3MsanNvbixzeXMKcm9vdD1wYXRobGliLlBhdGguY3dkKCk7cGluPSJiYmJjYTJkZGFhNWQ4ZmVhYTYzZTM2Yjc2ZmRhYWQ3NzM4NmYwMjRmIgphY3Rpb249cGF0aGxpYi5QYXRoKG9zLmVudmlyb25bIlJVTk5FUl9XT1JLU1BBQ0UiXSkucGFyZW50LyJfYWN0aW9ucy9hY3Rpb25zL3VwbG9hZC1hcnRpZmFjdCIvcGluLyJkaXN0L3VwbG9hZC9pbmRleC5qcyIKbm9kZT1zdHIocGF0aGxpYi5QYXRoKCIvVXNlcnMvcnVubmVyL2FjdGlvbnMtcnVubmVyL2NhY2hlZC9leHRlcm5hbHMvbm9kZTI0L2Jpbi9ub2RlIikpCnZlcnNpb249c3VicHJvY2Vzcy5jaGVja19vdXRwdXQoW25vZGUsIi1wIiwicHJvY2Vzcy52ZXJzaW9ucy5ub2RlIl0sdGV4dD1UcnVlKS5zdHJpcCgpCmlmIHZlcnNpb24uc3BsaXQoIi4iKVswXSE9IjI0IjpyYWlzZSBSdW50aW1lRXJyb3IoIlBpbm5lZCBhcnRpZmFjdCBhY3Rpb24gcmVxdWlyZXMgTm9kZTI0OiAiK3ZlcnNpb24pCmVudmlyb25tZW50PWRpY3Qob3MuZW52aXJvbikKZW52aXJvbm1lbnQudXBkYXRlKHsiSU5QVVRfTkFNRSI6ImNwMy1tYWNvcy1jbG9zZS0iK3N5cy5hcmd2WzFdKyItV1E1Wlc4LWY4MS1maXhlZCIsIklOUFVUX1BBVEgiOnN0cihyb290LyJtYWNvcy1jbG9zZS1maXhlZC1wcm9kdWN0cy50YXIuZ3oiKSsiXG4iK3N0cihyb290LyJtYWNvcy1jbG9zZS1maXhlZC1wcm9kdWN0cy5qc29uIiksIklOUFVUX0lGLU5PLUZJTEVTLUZPVU5EIjoiZXJyb3IiLCJJTlBVVF9SRVRFTlRJT04tREFZUyI6IjEiLCJJTlBVVF9DT01QUkVTU0lPTi1MRVZFTCI6IjYiLCJJTlBVVF9PVkVSV1JJVEUiOiJmYWxzZSIsIklOUFVUX0lOQ0xVREUtSElEREVOLUZJTEVTIjoiZmFsc2UiLCJJTlBVVF9BUkNISVZFIjoidHJ1ZSIsIkdJVEhVQl9PVVRQVVQiOnN0cihyb290LyJmaXhlZC1hcnRpZmFjdC1vdXRwdXQudHh0IiksIkdJVEhVQl9TVEVQX1NVTU1BUlkiOnN0cihyb290LyJmaXhlZC1hcnRpZmFjdC1zdW1tYXJ5LnR4dCIpfSkKcm9vdC5qb2lucGF0aCgiZml4ZWQtYXJ0aWZhY3Qtb3V0cHV0LnR4dCIpLnRvdWNoKCkKcm9vdC5qb2lucGF0aCgiZml4ZWQtYXJ0aWZhY3Qtc3VtbWFyeS50eHQiKS50b3VjaCgpCmNvbW1hbmQ9W25vZGUsc3RyKGFjdGlvbildCndpdGggcm9vdC5qb2lucGF0aCgiZml4ZWQtYXJ0aWZhY3QtdXBsb2FkLmxvZyIpLm9wZW4oInciKSBhcyBsb2c6cmVzdWx0PXN1YnByb2Nlc3MucnVuKGNvbW1hbmQsZW52PWVudmlyb25tZW50LHN0ZG91dD1sb2csc3RkZXJyPXN1YnByb2Nlc3MuU1RET1VUKQoKcmVjZWlwdD17ImFyZ3YiOmNvbW1hbmQsImV4aXQiOnJlc3VsdC5yZXR1cm5jb2RlLCJsb2ciOiJmaXhlZC1hcnRpZmFjdC11cGxvYWQubG9nIiwibm9kZVZlcnNpb24iOnZlcnNpb24sImFjdGlvblBpbiI6cGlufQppZiByb290LmpvaW5wYXRoKCJmaXhlZC1hcnRpZmFjdC1vdXRwdXQudHh0IikuZXhpc3RzKCk6cmVjZWlwdFsib3V0cHV0cyJdPXJvb3Quam9pbnBhdGgoImZpeGVkLWFydGlmYWN0LW91dHB1dC50eHQiKS5yZWFkX3RleHQoKQpyb290LmpvaW5wYXRoKCJmaXhlZC1hcnRpZmFjdC11cGxvYWQtcmVjZWlwdC5qc29uIikud3JpdGVfdGV4dChqc29uLmR1bXBzKHJlY2VpcHQsaW5kZW50PTIpKTtwcmludChqc29uLmR1bXBzKHJlY2VpcHQpKTtzeXMuZXhpdChyZXN1bHQucmV0dXJuY29kZSkK'))

selected={}
for directory in ['classes']:
 for p in (r/directory).rglob('*'):
  if p.is_file():selected[str(p.relative_to(r))]=p
for name in ['libmac-workload.dylib','mac-workload-anchor','workload-fixture','workload-fixture.c','MacWorkloadNativeProbe.java','toolchain.json','cargo-tools.json','declared-native-build-commands.json','native-cluster-fix-results.json','native-final-fixed-reuse-results.json']:
 selected[name]=r/name
for name in ['mac-workload.c','mac-descriptor-protection.c','mac-descriptor-protection.js']:
 relative='source/src/main/resources/com/holdmyspot/codexunleashed/scheduler/'+name;selected[relative]=r/relative
manifest={}
for name,p in selected.items():
 data=p.read_bytes();assert not re.search(rb'-----BEGIN (?:OPENSSH|RSA|EC) PRIVATE KEY|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}',data),name
 manifest[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
metadata=dict(architecture='aarch64-apple-darwin',baseArtifactId=13101485884,baseInnerSha256='051924d92b1f929cc65149d51265b04e31184122ec2b8cea92df703abd83490d',purpose='Overlay corrected stale ownership CModule, SDK-asserted bridge/anchor, robust object witnesses and compiled classes on retained pinned base dependencies; no diagnostic trace in production resources',files=manifest,credentialScan='passed',owner='/root/linux_pressure_boundary')
(r/'macos-close-fixed-products-manifest.json').write_text(json.dumps(metadata,indent=2));selected['macos-close-fixed-products-manifest.json']=r/'macos-close-fixed-products-manifest.json'
a=r/'macos-close-fixed-products.tar.gz'
with tarfile.open(a,'w:gz') as tar:
 for name,p in sorted(selected.items()):tar.add(p,arcname=name,recursive=False)
data=a.read_bytes();receipt=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),members=len(selected),credentialScan='passed',manifestSha256=hashlib.sha256((r/'macos-close-fixed-products-manifest.json').read_bytes()).hexdigest())
(r/'macos-close-fixed-products.json').write_text(json.dumps(receipt,indent=2));print('PRODUCT_ARCHIVE '+json.dumps(receipt),flush=True)
subprocess.run(['python3',str(r/'publish-fixed-products.py'),'aarch64-apple-darwin'],check=True)
PY_REMOTE
