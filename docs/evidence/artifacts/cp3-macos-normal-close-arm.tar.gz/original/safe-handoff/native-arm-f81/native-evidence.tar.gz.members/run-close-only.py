"""Run the connected close/reuse and actual installed Cargo cluster with genuine process waits."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
attempt = sys.argv[2]
assert attempt.isalnum() or all(character.isalnum() or character in '_-' for character in attempt)
tools = json.loads((root / 'toolchain.json').read_text())
results = []
for mode in ['close']:
    suffix = mode + '-' + attempt
    command = ['sudo', '-n', tools['java'], '--enable-native-access=ALL-UNNAMED',
        '-Djava.io.tmpdir=' + str(root / 'java-tmp'), '-cp', str(root / 'classes') + ':' + str(root / 'lib/*'),
        'com.holdmyspot.codexunleashed.scheduler.MacWorkloadNativeProbe', str(root), mode,
        tools['clang'], tools['sdk'], attempt]
    (root / ('native-' + suffix + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
    with (root / 'original-input.txt').open('rb') as original, (root / ('native-' + suffix + '.stdout')).open('wb') as output, (root / ('native-' + suffix + '.stderr')).open('wb') as error:
        process = subprocess.Popen(command, stdin=original, stdout=output, stderr=error)
        (root / ('native-' + suffix + '-wait-owner.json')).write_text(json.dumps(dict(pid=process.pid,
            ownership='original Popen sudo driver; actual JVM publishes its independently retained PID/birth', argv=command), indent=2) + '\n')
        status = process.wait()
    result = dict(mode=mode, attempt=attempt, genuineDriverWait=status)
    receipt = root / ('composition-' + suffix + '.json')
    if receipt.is_file():
        contents = json.loads(receipt.read_text())
        result.update(passed=contents.get('passed') is True, receipt=str(receipt), receiptSha256=hashlib.sha256(receipt.read_bytes()).hexdigest())
    else:
        result.update(passed=False, failure='No terminal original-owner receipt; retain raw outputs and ownership')
    if mode == 'cargo':
        stdout = (root / ('native-' + suffix + '.stdout')).read_bytes()
        stderr = (root / ('native-' + suffix + '.stderr')).read_bytes()
        result['usefulCargoStreams'] = b'cargo-useful-output\n' in stdout and b'cargo-useful-error\n' in stderr
        result['passed'] = result['passed'] and result['usefulCargoStreams']
    results.append(result)
    (root / ('native-cluster-' + attempt + '-results.json')).write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    if status != 0 or not result['passed']:
        raise SystemExit(1)
print('MAC_CLOSE_DIAGNOSTIC_ATTEMPT_PASSED', tools['architecture'], flush=True)
