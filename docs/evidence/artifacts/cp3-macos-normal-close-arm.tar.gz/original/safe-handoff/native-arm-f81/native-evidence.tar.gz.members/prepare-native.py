"""Restore pinned inputs and compile the declared caller-facing source on one owned native worker."""
from pathlib import Path, PurePosixPath
import concurrent.futures
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import urllib.request

root = Path(sys.argv[1]).resolve()
assert root.parent == Path('/Users/runner/work/_temp')
assert root.name.startswith('macos-close-WQ5ZW8-native-')
os.chdir(root)
source = root / 'source'
source.mkdir()
manifest = json.loads((root / 'input/baseline-manifest.json').read_text())
archive_url = 'https://codeload.github.com/holdmyspot-com/codex-unleashed/tar.gz/4d744def04f89b5cacc407c89ff731417a080209'
restored = set()
with urllib.request.urlopen(archive_url, timeout=60) as response:
    with tarfile.open(fileobj=response, mode='r|gz') as archive:
        for member in archive:
            relative = '/'.join(PurePosixPath(member.name).parts[1:])
            if relative not in manifest:
                continue
            assert member.isfile(), relative
            data = archive.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest() == manifest[relative], relative
            output = source / relative.removeprefix('tooling/cli/')
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(data)
            restored.add(relative)
assert restored == set(manifest), sorted(set(manifest) - restored)
for relative, digest in json.loads((root / 'input/candidate-manifest.json').read_text()).items():
    original = root / 'input' / relative
    data = original.read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, relative
    if relative.startswith('candidate/tooling/cli/'):
        output = source / relative.removeprefix('candidate/tooling/cli/')
    elif relative.startswith('fixture/'):
        output = root / Path(relative).name
    else:
        continue
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(data)

architecture = subprocess.check_output(['uname', '-m'], text=True).strip()
assert architecture in ['arm64', 'x86_64']
assert os.getuid() == 501 and os.getgid() == 20
vendors = json.loads((root / 'input/vendor-inputs.json').read_text())[architecture]
for directory in ['downloads', 'jdk', 'frida', 'lib', 'classes', 'java-tmp', 'cargo-home', 'cargo-target', 'cargo-project/src']:
    (root / directory).mkdir(parents=True, exist_ok=True)

def download(item, directory):
    """Verify every declared immutable dependency before extraction or use."""
    output = directory / item['name']
    urllib.request.urlretrieve(item['url'], output)
    assert hashlib.sha256(output.read_bytes()).hexdigest() == item['sha256'], item['name']
    return output

def vendor(item):
    """Extract verified native vendor inputs only on this native worker."""
    archive_path = download(item, root / 'downloads')
    with tarfile.open(archive_path) as archive:
        archive.extractall(root / item['target'], filter='data')
    return dict(name=item['name'], sha256=item['sha256'])

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    tasks = [pool.submit(vendor, item) for item in vendors]
    tasks += [pool.submit(download, item, root / 'lib') for item in json.loads((root / 'input/composition-dependencies.json').read_text())]
    for task in tasks:
        task.result()

clang = subprocess.check_output(['xcrun', '--find', 'clang'], text=True).strip()
sdk = subprocess.check_output(['xcrun', '--show-sdk-path'], text=True).strip()
java_candidates = list((root / 'jdk').glob('*/Contents/Home/bin/java'))
assert len(java_candidates) == 1
java = java_candidates[0]
javac = java.with_name('javac')
javadoc = java.with_name('javadoc')
package = Path('com/holdmyspot/codexunleashed/scheduler')
resource = source / 'src/main/resources' / package
code = source / 'src/main/java'
main = code / package
native = [clang, '-isysroot', sdk, '-std=c11', '-Wall', '-Wextra', '-Werror']
commands = [
    native + ['-dynamiclib', str(resource / 'mac-workload.c'), '-framework', 'CoreFoundation', '-o', str(root / 'libmac-workload.dylib')],
    native + ['-DMW_ANCHOR', str(resource / 'mac-workload.c'), '-framework', 'CoreFoundation', '-o', str(root / 'mac-workload-anchor')],
    native + ['-Wl,-export_dynamic', str(root / 'workload-fixture.c'), '-o', str(root / 'workload-fixture')],
]
link = [clang, '-isysroot', sdk, '-shared', '-arch', architecture, '-O2', '-DNDEBUG', '-Wl,-dead_strip', '-Wl,-x', '-Wl,-fatal_warnings']
if architecture == 'x86_64':
    link += ['-Wl,-segalign,0x4000']
# This is the unchanged archived caller's legacy filename; architecture is
# authenticated separately and never inferred from that historical basename.
frida = root / 'libfrida-core-arm64.dylib'
link += ['-o', str(frida), '-Wl,-install_name,@rpath/libfrida-core.dylib', '-Wl,-force_load,' + str(root / 'frida/libfrida-core.a'),
    '-framework', 'CoreFoundation', '-framework', 'Foundation', '-framework', 'AppKit', '-framework', 'IOKit', '-framework', 'Security',
    '-lbsm', '-ldl', '-lm', '-lresolv']
commands += [link, ['codesign', '--force', '--sign', '-', str(frida)], ['codesign', '--verify', '--strict', str(frida)]]
entries = [str(main / (name + '.java')) for name in ['MacImages', 'MacWorkloadNative', 'MacDescriptorProtection']]
entries.append(str(root / 'MacWorkloadNativeProbe.java'))
classpath = str(root / 'lib/*')
commands += [
    [str(javac), '-Xlint:none', '-sourcepath', str(code), '-cp', classpath, '-d', str(root / 'classes'), *entries],
    [str(javac), '-Xlint:all', '-Werror', '-sourcepath', '', '-cp', str(root / 'classes') + ':' + classpath, '-d', str(root / 'classes'), *entries],
    [str(javadoc), '-quiet', '-private', '-Xdoclint:all', '-Werror', '-classpath', str(root / 'classes') + ':' + classpath,
        '-d', str(root / 'private-javadoc'), *entries],
    ['sudo', '-n', 'chown', 'root:wheel', str(root / 'mac-workload-anchor'), str(root / 'libmac-workload.dylib')],
]
(root / 'declared-native-build-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
results = []
for index, command in enumerate(commands):
    with (root / ('build-' + str(index) + '.stdout')).open('wb') as output, (root / ('build-' + str(index) + '.stderr')).open('wb') as error:
        result = subprocess.run(command, stdout=output, stderr=error)
    results.append(dict(index=index, argv=command, exit=result.returncode))
    (root / 'native-build-results.json').write_text(json.dumps(results, indent=2) + '\n')
    assert result.returncode == 0, results[-1]
shutil.copytree(source / 'src/main/resources', root / 'classes', dirs_exist_ok=True)
(root / 'compiler-input.c').write_text('int main(void){return 0;}\n')
(root / 'original-input.txt').write_text('original-input-token\n')
cargo = subprocess.check_output(['rustup', 'which', 'cargo'], text=True).strip()
rustc = subprocess.check_output(['rustup', 'which', 'rustc'], text=True).strip()
tools = dict(cargo=cargo, rustc=rustc, cargoSha256=hashlib.sha256(Path(cargo).read_bytes()).hexdigest(),
    rustcSha256=hashlib.sha256(Path(rustc).read_bytes()).hexdigest(),
    cargoVersion=subprocess.check_output([cargo, '--version', '--verbose'], text=True),
    rustcVersion=subprocess.check_output([rustc, '--version', '--verbose'], text=True))
(root / 'cargo-tools.json').write_text(json.dumps(tools, indent=2) + '\n')
(root / 'cargo-project/Cargo.toml').write_text('[package]\nname = "native_cargo_close"\nversion = "0.1.0"\nedition = "2021"\n')
(root / 'cargo-project/src/main.rs').write_text('use std::io::Read;\nfn main(){let mut input=String::new();std::io::stdin().read_to_string(&mut input).unwrap();assert_eq!(input,"original-input-token\\n");println!("cargo-useful-output");eprintln!("cargo-useful-error");}\n')
(root / 'toolchain.json').write_text(json.dumps(dict(clang=clang, sdk=sdk, java=str(java), architecture=architecture,
    baseline='4d744def04f89b5cacc407c89ff731417a080209', baselineFiles=len(manifest), vendorInputs=vendors), indent=2) + '\n')
print(json.dumps(dict(prepared=True, architecture=architecture, java=str(java), clang=clang, sdk=sdk,
    baselineFiles=len(manifest), actualCargo=tools)), flush=True)
