"""Publish the credential-free archive through the workflow's already pinned official artifact action."""
import pathlib,subprocess,os,json,sys
root=pathlib.Path.cwd();pin="bbbca2ddaa5d8feaa63e36b76fdaad77386f024f"
action=pathlib.Path(os.environ["RUNNER_WORKSPACE"]).parent/"_actions/actions/upload-artifact"/pin/"dist/upload/index.js"
node=str(pathlib.Path("/Users/runner/actions-runner/cached/externals/node24/bin/node"))
version=subprocess.check_output([node,"-p","process.versions.node"],text=True).strip()
if version.split(".")[0]!="24":raise RuntimeError("Pinned artifact action requires Node24: "+version)
environment=dict(os.environ)
environment.update({"INPUT_NAME":"cp3-macos-close-"+sys.argv[1]+"-WQ5ZW8-f81-fixed","INPUT_PATH":str(root/"macos-close-fixed-products.tar.gz")+"\n"+str(root/"macos-close-fixed-products.json"),"INPUT_IF-NO-FILES-FOUND":"error","INPUT_RETENTION-DAYS":"1","INPUT_COMPRESSION-LEVEL":"6","INPUT_OVERWRITE":"false","INPUT_INCLUDE-HIDDEN-FILES":"false","INPUT_ARCHIVE":"true","GITHUB_OUTPUT":str(root/"fixed-artifact-output.txt"),"GITHUB_STEP_SUMMARY":str(root/"fixed-artifact-summary.txt")})
root.joinpath("fixed-artifact-output.txt").touch()
root.joinpath("fixed-artifact-summary.txt").touch()
command=[node,str(action)]
with root.joinpath("fixed-artifact-upload.log").open("w") as log:result=subprocess.run(command,env=environment,stdout=log,stderr=subprocess.STDOUT)

receipt={"argv":command,"exit":result.returncode,"log":"fixed-artifact-upload.log","nodeVersion":version,"actionPin":pin}
if root.joinpath("fixed-artifact-output.txt").exists():receipt["outputs"]=root.joinpath("fixed-artifact-output.txt").read_text()
root.joinpath("fixed-artifact-upload-receipt.json").write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));sys.exit(result.returncode)
