/* Real application close/reuse and original fork/exec/compiler acceptance. */
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/event.h>
#include <sys/file.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <libproc.h>
#include <sys/proc_info.h>
__attribute__((visibility("default"))) volatile int mw_fixture_ready=0;
__attribute__((visibility("default"))) volatile int mw_fixture_initialized=0;
__attribute__((visibility("default"))) volatile int mw_fixture_entered=0;
__attribute__((constructor)) static void fixture_initializer(void) { mw_fixture_initialized=(int)getpid(); }
/* The fixture can deliberately suppress a close to establish that its
 * witnesses reject the same false success that production must prevent. */
static const char *canary_mode;
static int close_canary(int fd,const char *kind) {
 if((strcmp(canary_mode,"blockpipe")==0 && strcmp(kind,"pipe")==0) ||
    (strcmp(canary_mode,"blockfile")==0 && strcmp(kind,"file")==0) ||
    (strcmp(canary_mode,"blockqueue")==0 && strcmp(kind,"queue")==0)) {
  fprintf(stderr,"CONTROLLED_SUPPRESSED_CLOSE kind=%s pid=%d fd=%d\n",kind,getpid(),fd);fflush(stderr);return 0;
 }
 return close(fd);
}
/* Allocate only an available number. Unlike dup2, F_DUPFD never destroys a
 * descriptor that another runtime thread acquired since the held observation. */
static int duplicate_available(int source,int minimum) {
 return fcntl(source,F_DUPFD,minimum);
}
/* Deliberately reuse a genuinely freed number without overwriting a live
 * runtime descriptor. Object witnesses below remain valid after this reuse. */
static int reuse_after_close(int source,int number,const char *kind) {
 if(strcmp(canary_mode,"reuse")!=0)return -1;
 int result=duplicate_available(source,number);
 fprintf(stderr,"CONTROLLED_POST_CLOSE_REUSE kind=%s pid=%d closed_fd=%d allocated_fd=%d exact=%d\n",kind,getpid(),number,result,result==number);fflush(stderr);
 return result;
}
static int canary_failure(const char *phase,const char *kind,int detail) {
 fprintf(stderr,"OBJECT_CANARY_FAILURE phase=%s kind=%s pid=%d detail=%d errno=%d\n",phase,kind,getpid(),detail,errno);fflush(stderr);return 0;
}
/* Host evidence names a genuine private-runtime close. Acquire its old number
 * through the kernel's available-descriptor allocation, then observe EOF on a
 * retained pipe object; later reuse of the number cannot manufacture EOF. */
static int application_canaries(const char *phase) {
 const char *directory=getenv("MW_REUSE_DIRECTORY");char path[4096];int slot=-1;
 if(directory==NULL || snprintf(path,sizeof path,"%s/%d",directory,getpid()) >= (int)sizeof path)return canary_failure(phase,"slot-path",0);
 FILE *input=fopen(path,"r");if(input==NULL)return canary_failure(phase,"slot-open",0);
 int read_ok=fscanf(input,"%d",&slot)==1;int close_ok=fclose(input)==0;
 if(!read_ok || !close_ok || slot<3)return canary_failure(phase,"slot-read",slot);
 int reservation=open("/dev/null",O_RDONLY);
 if(reservation<0)return canary_failure(phase,"application-reservation",reservation);
 int reader=-1,target=-1;
 for(int attempt=0;attempt<256 && target!=slot;attempt++) {
  int pipes[2];if(pipe(pipes)!=0)return canary_failure(phase,"pipe-create",attempt);
  fprintf(stderr,"PIPE_LAYOUT phase=%s pid=%d reader=%d writer=%d slot=%d attempt=%d\n",phase,getpid(),pipes[0],pipes[1],slot,attempt);fflush(stderr);
  reader=duplicate_available(pipes[0],128);
  if(reader<0)return canary_failure(phase,"pipe-reader-retain",attempt);
  if(close(pipes[0])!=0)return canary_failure(phase,"pipe-original-reader-close",attempt);
  if(pipes[1]==slot)target=slot;
  else {
   target=duplicate_available(pipes[1],slot);
   int original_writer_close=close(pipes[1]);
   fprintf(stderr,"PIPE_WRITER_TRANSFER pid=%d old=%d target=%d close=%d remains=%d\n",getpid(),pipes[1],target,original_writer_close,fcntl(pipes[1],F_GETFD));fflush(stderr);
   if(original_writer_close!=0)return canary_failure(phase,"pipe-original-writer-close",attempt);
  }
  if(target!=slot) {
   if(target>=0 && close(target)!=0)return canary_failure(phase,"pipe-contended-copy-close",attempt);
   if(close(reader)!=0)return canary_failure(phase,"pipe-contended-reader-close",attempt);
   reader=-1;target=-1;
  }
 }
 if(target!=slot)return canary_failure(phase,"slot-contention",slot);
 if(fcntl(reader,F_SETFL,O_NONBLOCK)!=0)return canary_failure(phase,"pipe-nonblock",reader);
 int pipe_status=close_canary(target,"pipe");int pipe_copy=reuse_after_close(reader,target,"pipe");
 char byte;errno=0;ssize_t read_status=read(reader,&byte,1);int read_error=errno;
 fprintf(stderr,"PIPE_OBJECT_WITNESS phase=%s pid=%d reused_private=%d close=%d read=%ld errno=%d\n",phase,getpid(),target,pipe_status,(long)read_status,read_error);fflush(stderr);
 if(pipe_copy>=0 && close(pipe_copy)!=0)return canary_failure(phase,"pipe-reuse-copy-close",pipe_copy);
 if(close(reader)!=0)return canary_failure(phase,"pipe-reader-close",reader);
 if(pipe_status!=0 || read_status!=0)return canary_failure(phase,"pipe-writer-remains",(int)read_status);
 if(close(reservation)!=0)return canary_failure(phase,"application-reservation-close",reservation);
 /* A separately opened witness can acquire the file's advisory lock only
  * after the original open-file reference was actually closed. */
 char temporary[]="/tmp/mw-close-canary-XXXXXX";int file=mkstemp(temporary);
 if(file<0)return canary_failure(phase,"file-create",0);
 int witness=open(temporary,O_RDWR);int removed=unlink(temporary);
 if(witness<0 || removed!=0 || flock(file,LOCK_EX|LOCK_NB)!=0)return canary_failure(phase,"file-lock",file);
 int file_status=close_canary(file,"file");int file_copy=reuse_after_close(witness,file,"file");
 errno=0;int lock_status=flock(witness,LOCK_EX|LOCK_NB);int lock_error=errno;
 fprintf(stderr,"FILE_OBJECT_WITNESS phase=%s pid=%d fd=%d close=%d lock=%d errno=%d\n",phase,getpid(),file,file_status,lock_status,lock_error);fflush(stderr);
 if(file_copy>=0 && close(file_copy)!=0)return canary_failure(phase,"file-reuse-copy-close",file_copy);
 if(close(witness)!=0)return canary_failure(phase,"file-witness-close",witness);
 if(file_status!=0 || lock_status!=0)return canary_failure(phase,"file-lock-remains",lock_status);
 /* A private EVFILT_USER registration belongs to this application queue.
  * Delete-with-receipt succeeds only if that original queue remains alive.
  * EBADF, or ENOENT on a replacement queue, establishes its disappearance. */
 int queue=kqueue();struct kevent change,receipt;struct timespec zero={0,0};
 uintptr_t cookie=(uintptr_t)&mw_fixture_entered;
 if(queue<0)return canary_failure(phase,"queue-create",queue);
 EV_SET(&change,cookie,EVFILT_USER,EV_ADD|EV_CLEAR,0,0,NULL);
 if(kevent(queue,&change,1,NULL,0,&zero)!=0)return canary_failure(phase,"queue-tag",queue);
 int queue_status=close_canary(queue,"queue");int queue_copy=reuse_after_close(STDIN_FILENO,queue,"queue");
 EV_SET(&change,cookie,EVFILT_USER,EV_DELETE|EV_RECEIPT,0,0,NULL);
 errno=0;int probe=kevent(queue,&change,1,&receipt,1,&zero);int probe_error=errno;
 int queue_gone=(probe==-1 && probe_error==EBADF) || (probe==1 && (receipt.flags&EV_ERROR)!=0 && receipt.data==ENOENT);
 fprintf(stderr,"QUEUE_OBJECT_WITNESS phase=%s pid=%d fd=%d close=%d probe=%d errno=%d receipt_error=%lld gone=%d\n",phase,getpid(),queue,queue_status,probe,probe_error,probe==1?(long long)receipt.data:-1LL,queue_gone);fflush(stderr);
 if(queue_copy>=0 && close(queue_copy)!=0)return canary_failure(phase,"queue-reuse-copy-close",queue_copy);
 if(queue_status!=0 || !queue_gone)return canary_failure(phase,"original-queue-remains",probe);
 fprintf(stderr,"application-close-canaries-closed phase=%s pid=%d reused-private=%d object_witnesses=pipe-eof,file-lock,queue-user-filter\n",phase,getpid(),slot);fflush(stderr);
 return 1;
}
/* Observe complete bounded fd rows, then perform real ordinary libc closes. */
static int close_boundary(const char *phase) {
 struct proc_fdinfo entries[512];int bytes=proc_pidinfo(getpid(),PROC_PIDLISTFDS,0,entries,sizeof entries);
 if(bytes<=0 || bytes>=(int)sizeof entries || bytes%(int)sizeof entries[0]!=0)return 0;
 int maximum=3;for(int index=0;index<bytes/(int)sizeof entries[0];index++)if(entries[index].proc_fd>maximum)maximum=entries[index].proc_fd;
 int retained_queues=0;
 for(int fd=3;fd<=maximum;fd++) {
  unsigned type=0;for(int index=0;index<bytes/(int)sizeof entries[0];index++)if(entries[index].proc_fd==fd)type=entries[index].proc_fdtype;
  int status=close(fd);int close_error=errno;int remains=fcntl(fd,F_GETFD);
  if(type==PROX_FDTYPE_KQUEUE && remains>=0)retained_queues++;
  if(type)fprintf(stderr,"close-boundary-fd phase=%s pid=%d fd=%d type=%u close=%d errno=%d remains=%d\n",phase,getpid(),fd,type,status,close_error,remains);
 }
 fprintf(stderr,"close-boundary-complete phase=%s pid=%d observed-queues-retained=%d\n",phase,getpid(),retained_queues);fflush(stderr);
 return retained_queues>0;
}
/* Refuse useful work unless this exact process was instrumented before release. */
static int armed(const char *phase) {
 mw_fixture_entered=(int)getpid();
 if(mw_fixture_ready!=(int)getpid()){fprintf(stderr,"UNINSTRUMENTED_EFFECT phase=%s pid=%d value=%d\n",phase,getpid(),mw_fixture_ready);return 0;}
 printf("instrumented-effect phase=%s pid=%d parent=%d\n",phase,getpid(),getppid());fflush(stdout);return 1;
}
int main(int argc,char **argv) {
 if(argc!=8)return 80;
 canary_mode=argv[2];
 const char *mode=argv[1];
 if(!armed(mode) || !application_canaries(mode) || !close_boundary(mode))return 81;
 if(strcmp(mode,"root")==0){
  char input[32]={0};if(read(0,input,sizeof input-1)<=0 || strcmp(input,"original-input-token\n")!=0)return 82;
  pid_t child=fork();if(child<0)return 83;if(child>0)return 17;
  if(!armed("fork-child") || !application_canaries("fork-child") || !close_boundary("fork-child"))_exit(84);
  if(setsid()<0)_exit(85);
  execl(argv[0],argv[0],"orphan",argv[2],argv[3],argv[4],argv[5],argv[6],argv[7],(char *)NULL);_exit(86);
 }
 if(strcmp(mode,"orphan")!=0)return 87;
 FILE *marker=fopen(argv[7],"w");if(!marker)return 88;fprintf(marker,"orphan=%d parent=%d\n",getpid(),getppid());if(fclose(marker))return 89;
 if(strcmp(argv[2],"loss")==0){for(;;)pause();}
 pid_t compiler=fork();if(compiler<0)return 90;
 if(compiler==0){if(!armed("compiler-child") || !application_canaries("compiler-child") || !close_boundary("compiler-child"))_exit(91);execl(argv[3],argv[3],argv[4],"-o",argv[5],"-isysroot",argv[6],(char *)NULL);_exit(92);}
 int status;while(waitpid(compiler,&status,0)<0){if(errno!=EINTR)return 93;}
 printf("ordinary-compiler-wait pid=%d status=%d\n",compiler,status);fflush(stdout);
 return WIFEXITED(status)&&WEXITSTATUS(status)==0?0:94;
}
