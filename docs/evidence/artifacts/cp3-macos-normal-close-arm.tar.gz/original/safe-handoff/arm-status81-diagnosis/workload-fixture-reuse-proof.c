/* Real application close/reuse and original fork/exec/compiler acceptance. */
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/event.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <libproc.h>
#include <sys/proc_info.h>
__attribute__((visibility("default"))) volatile int mw_fixture_ready=0;
__attribute__((visibility("default"))) volatile int mw_fixture_initialized=0;
__attribute__((visibility("default"))) volatile int mw_fixture_entered=0;
__attribute__((constructor)) static void fixture_initializer(void) { mw_fixture_initialized=(int)getpid(); }
/* Observe exact object snapshots around the fixture assertion. The numeric
 * descriptor may be allocated again after a successful close, so retain both
 * the close result and kernel object metadata rather than guessing its cause. */
static int prove_reuse;
static int checked_close(int fd,const char *phase,const char *label) {
 int held=-1,reused=-1;
 if(prove_reuse && strcmp(phase,"root")==0 && strcmp(label,"reused-pipe")==0)held=fcntl(fd,F_DUPFD,128);
 struct stat before={0},after={0};int before_status=fstat(fd,&before);
 errno=0;int status=close(fd);int close_error=errno;
 if(held>=0 && status==0) {
  reused=fcntl(held,F_DUPFD,fd);
  fprintf(stderr,"CONTROLLED_REUSE pid=%d closed_fd=%d close=%d retained_source=%d kernel_reallocated_fd=%d original_descriptor_close_proved=%d\n",getpid(),fd,status,held,reused,reused==fd);fflush(stderr);
 }
 errno=0;int observed=fcntl(fd,F_GETFD);int observation_error=errno;
 int after_status=fstat(fd,&after);unsigned type=0;
 struct proc_fdinfo rows[512];int bytes=proc_pidinfo(getpid(),PROC_PIDLISTFDS,0,rows,sizeof rows);
 if(bytes>0 && bytes<(int)sizeof rows && bytes%(int)sizeof rows[0]==0)
  for(int i=0;i<bytes/(int)sizeof rows[0];i++)if(rows[i].proc_fd==fd)type=rows[i].proc_fdtype;
 fprintf(stderr,"CLOSE_ASSERTION phase=%s label=%s pid=%d fd=%d close=%d close_errno=%d getfd=%d getfd_errno=%d before_status=%d before_dev=%lld before_ino=%llu before_mode=%u after_status=%d after_dev=%lld after_ino=%llu after_mode=%u observed_type=%u\n",phase,label,getpid(),fd,status,close_error,observed,observation_error,before_status,(long long)before.st_dev,(unsigned long long)before.st_ino,(unsigned)before.st_mode,after_status,(long long)after.st_dev,(unsigned long long)after.st_ino,(unsigned)after.st_mode,type);fflush(stderr);
 if(reused>=0)close(reused);
 if(held>=0)close(held);
 return status==0 && observed==-1 && observation_error==EBADF;
}
/* The host publishes a completed private runtime close while this image is held.
 * These application operations force that exact numeric slot to be reused. */
static int application_canaries(const char *phase) {
 const char *directory=getenv("MW_REUSE_DIRECTORY");char path[4096];int slot=-1;
 if(directory==NULL || snprintf(path,sizeof path,"%s/%d",directory,getpid()) >= (int)sizeof path){fprintf(stderr,"CANARY_FAILURE line=%d errno=%d slot=%d\n",__LINE__,errno,slot);fflush(stderr);return 0;}
 FILE *input=fopen(path,"r");if(input==NULL){fprintf(stderr,"CANARY_FAILURE line=%d errno=%d slot=%d\n",__LINE__,errno,slot);fflush(stderr);return 0;}
 int read_ok=fscanf(input,"%d",&slot)==1;int close_ok=fclose(input)==0;
 if(!read_ok || !close_ok || slot<3){fprintf(stderr,"CANARY_FAILURE line=%d errno=%d slot=%d\n",__LINE__,errno,slot);fflush(stderr);return 0;}
 int pipe_fds[2];if(pipe(pipe_fds)!=0){fprintf(stderr,"CANARY_FAILURE line=%d errno=%d slot=%d\n",__LINE__,errno,slot);fflush(stderr);return 0;}
 int slot_before=fcntl(slot,F_GETFD);int slot_before_error=errno;
 fprintf(stderr,"REUSE_PRECONDITION phase=%s pid=%d slot=%d pipe_read=%d pipe_write=%d getfd=%d errno=%d\n",phase,getpid(),slot,pipe_fds[0],pipe_fds[1],slot_before,slot_before_error);fflush(stderr);
 if(pipe_fds[0]!=slot && dup2(pipe_fds[0],slot)!=slot)return 0;
 if(!checked_close(slot,phase,"reused-pipe"))return 0;
 if(pipe_fds[0]!=slot && close(pipe_fds[0])!=0){fprintf(stderr,"CANARY_FAILURE line=%d errno=%d slot=%d\n",__LINE__,errno,slot);fflush(stderr);return 0;}
 if(pipe_fds[1]!=slot && close(pipe_fds[1])!=0){fprintf(stderr,"CANARY_FAILURE line=%d errno=%d slot=%d\n",__LINE__,errno,slot);fflush(stderr);return 0;}
 int file=open("/dev/null",O_RDONLY);int queue=kqueue();
 if(file<0 || queue<0)return 0;
 if(!checked_close(file,phase,"application-file"))return 0;
 if(!checked_close(queue,phase,"application-kqueue"))return 0;
 fprintf(stderr,"application-close-canaries-closed phase=%s pid=%d reused-private=%d file=%d kqueue=%d pipe-read=%d pipe-write=%d\n",phase,getpid(),slot,file,queue,pipe_fds[0],pipe_fds[1]);fflush(stderr);
 return 1;
}
/* Observe complete bounded fd rows, then perform real ordinary libc closes. */
static int close_boundary(const char *phase) {
 struct proc_fdinfo entries[512];int bytes=proc_pidinfo(getpid(),PROC_PIDLISTFDS,0,entries,sizeof entries);
 if(bytes<=0 || bytes>=(int)sizeof entries || bytes%(int)sizeof entries[0]!=0)return 0;
 int maximum=3;for(int index=0;index<bytes/(int)sizeof entries[0];index++)if(entries[index].proc_fd>maximum)maximum=entries[index].proc_fd;
 int retained_queues=0;
 for(int fd=3;fd<=maximum;fd++) {
  unsigned type=0;for(int index=0;index<bytes/(int)sizeof entries[0];index++)if(entries[index].proc_fd==fd)type=entries[index].proc_fdtype;
  int status=close(fd);int close_error=errno;int remains=fcntl(fd,F_GETFD);
  if(type==PROX_FDTYPE_KQUEUE && remains>=0)retained_queues++;
  if(type)fprintf(stderr,"close-boundary-fd phase=%s pid=%d fd=%d type=%u close=%d errno=%d remains=%d\n",phase,getpid(),fd,type,status,close_error,remains);
 }
 fprintf(stderr,"close-boundary-complete phase=%s pid=%d observed-queues-retained=%d\n",phase,getpid(),retained_queues);fflush(stderr);
 return retained_queues>0;
}
/* Refuse useful work unless this exact process was instrumented before release. */
static int armed(const char *phase) {
 mw_fixture_entered=(int)getpid();
 if(mw_fixture_ready!=(int)getpid()){fprintf(stderr,"UNINSTRUMENTED_EFFECT phase=%s pid=%d value=%d\n",phase,getpid(),mw_fixture_ready);return 0;}
 printf("instrumented-effect phase=%s pid=%d parent=%d\n",phase,getpid(),getppid());fflush(stdout);return 1;
}
int main(int argc,char **argv) {
 if(argc!=8)return 80;
 prove_reuse=strcmp(argv[2],"race")==0;
 const char *mode=argv[1];
 if(!armed(mode) || !application_canaries(mode) || !close_boundary(mode))return 81;
 if(strcmp(mode,"root")==0){
  char input[32]={0};if(read(0,input,sizeof input-1)<=0 || strcmp(input,"original-input-token\n")!=0)return 82;
  pid_t child=fork();if(child<0)return 83;if(child>0)return 17;
  if(!armed("fork-child") || !application_canaries("fork-child") || !close_boundary("fork-child"))_exit(84);
  if(setsid()<0)_exit(85);
  execl(argv[0],argv[0],"orphan",argv[2],argv[3],argv[4],argv[5],argv[6],argv[7],(char *)NULL);_exit(86);
 }
 if(strcmp(mode,"orphan")!=0)return 87;
 FILE *marker=fopen(argv[7],"w");if(!marker)return 88;fprintf(marker,"orphan=%d parent=%d\n",getpid(),getppid());if(fclose(marker))return 89;
 if(strcmp(argv[2],"loss")==0){for(;;)pause();}
 pid_t compiler=fork();if(compiler<0)return 90;
 if(compiler==0){if(!armed("compiler-child") || !application_canaries("compiler-child") || !close_boundary("compiler-child"))_exit(91);execl(argv[3],argv[3],argv[4],"-o",argv[5],"-isysroot",argv[6],(char *)NULL);_exit(92);}
 int status;while(waitpid(compiler,&status,0)<0){if(errno!=EINTR)return 93;}
 printf("ordinary-compiler-wait pid=%d status=%d\n",compiler,status);fflush(stdout);
 return WIFEXITED(status)&&WEXITSTATUS(status)==0?0:94;
}
