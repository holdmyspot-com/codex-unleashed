package com.holdmyspot.codexunleashed.scheduler;

import com.holdmyspot.codexunleashed.tooling.DefaultToolingScope;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.HashMap;
import java.util.HashSet;

/** Executes the connected production lifecycle against real original Frida and native owners. */
public final class MacWorkloadNativeProbe
{
    /** Prevents construction of this native acceptance entry point. */
    private MacWorkloadNativeProbe() {}

    /**
     * Runs one invocation in a fresh JVM, retaining failures through production cleanup.
     * @param args base directory, mode, actual compiler and SDK paths, and optional preserved-attempt label
     * @throws Exception if preparation, native execution or verified cleanup fails
     */
    public static void main(String[] args) throws Exception
    {
        Path base = Path.of(args[0]);
        String mode = args[1];
        String attempt = args.length == 5 ? args[4] : "initial";
        if (!attempt.matches("[a-zA-Z0-9_-]+")) throw new IllegalArgumentException("Invalid attempt label");
        String suffix = mode + "-" + attempt;
        Files.writeString(base.resolve("probe-owner-" + suffix + ".json"),
            "{\"pid\":" + ProcessHandle.current().pid() + ",\"started\":\"" +
            ProcessHandle.current().info().startInstant().orElseThrow() + "\",\"javaHome\":\"" +
            System.getProperty("java.home") + "\"}\n");
        Path directory = base.resolve("case-" + suffix);
        Files.createDirectory(directory, PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rwx------")));
        Path marker = base.resolve("orphan-" + suffix + ".txt");
        var report = new LinkedHashMap<String, Object>();
        var events = new ArrayList<String>();
        var inventories = new ArrayList<Map<String, Object>>();
        var slots = new HashMap<Long, Integer>();
        Path reuse = base.resolve("reuse-slots");
        Files.createDirectories(reuse);
        Files.setPosixFilePermissions(reuse, PosixFilePermissions.fromString("rwxr-xr-x"));
        Process foreign = new ProcessBuilder("/bin/sleep", "180").start();
        try (var scope = new DefaultToolingScope())
        {
            var runtime = new FridaRuntime(scope, base.resolve("libfrida-core-arm64.dylib"));
            runtime.start();
            var manager = runtime.newManager();
            manager.start();
            var command = List.of(base.resolve("workload-fixture").toString(), "root", mode, args[2],
                base.resolve("compiler-input.c").toString(), base.resolve("compiler-output-" + suffix).toString(), args[3], marker.toString());
            var environment = new ArrayList<>(List.of("PATH=/usr/bin:/bin", "SDKROOT=" + args[3], "MW_REUSE_DIRECTORY=" + reuse));
            if (mode.equals("cargo"))
            {
                var tools = scope.getLeaderJsonMapper().readTree(Files.readString(base.resolve("cargo-tools.json")));
                command = List.of(tools.path("cargo").asString(), "run", "--offline", "--manifest-path",
                    base.resolve("cargo-project/Cargo.toml").toString(), "--target-dir", base.resolve("cargo-target").toString());
                environment.add("RUSTC=" + tools.path("rustc").asString());
                environment.add("CARGO_HOME=" + base.resolve("cargo-home"));
                environment.add("CARGO_TARGET_AARCH64_APPLE_DARWIN_LINKER=" + args[2]);
                environment.add("CARGO_TARGET_X86_64_APPLE_DARWIN_LINKER=" + args[2]);
            }
            report.put("originalCommand", command);
            report.put("originalEnvironment", environment);
            var launch = new MacWorkloadNative.Launch(base.resolve("libmac-workload.dylib"),
                base.resolve("mac-workload-anchor"), directory, base, new MacWorkloadNative.Streams(0, 1, 2),
                command, environment, 501, 20);
            var nativeOwner = new MacWorkloadNative.Owner(scope, launch, manager);
            var hooks = new ArrayList<Hook>();
            MacWorkloadNative observed = new Observation(nativeOwner, marker, mode.equals("loss"), inventories, slots);
            MacWorkload workload;
            try
            {
                workload = new MacWorkload(scope, observed, identity ->
            {
                var hook = new Hook(scope, manager, nativeOwner, identity, events, inventories, slots, reuse);
                hooks.add(hook);
                return hook;
            }, Duration.ofSeconds(10));
            }
            catch (Throwable acquisitionFailure)
            {
                // Keep the exact native owner alive until its owned cleanup succeeds.
                while (!nativeOwner.isClosed())
                {
                    try { nativeOwner.close(); }
                    catch (IOException cleanupFailure)
                    {
                        try { nativeOwner.cancel(); nativeOwner.terminalResult(); }
                        catch (IOException pending) { acquisitionFailure.addSuppressed(pending); }
                        Thread.sleep(10);
                    }
                }
                runtime.close();
                foreign.destroy();
                foreign.waitFor();
                throw acquisitionFailure;
            }
            Throwable original = null;
            try { workload.start(); }
            catch (Throwable failure) { original = failure; }
            long deadline = System.nanoTime() + Duration.ofSeconds(90).toNanos();
            while (!nativeOwner.isClosed())
            {
                try
                {
                    for (Hook hook : hooks) hook.pump();
                    workload.advance();
                }
                catch (Throwable failure)
                {
                    if (original == null) original = failure;
                    events.add("failure:" + failure);
                }
                if (System.nanoTime() >= deadline)
                {
                    if (original == null) original = new IOException("Native composition deadline exceeded");
                    workload.cancel();
                    deadline = Long.MAX_VALUE;
                    events.add("deadline-cancellation-retains-owner");
                }
                Thread.sleep(2);
            }
            OptionalInt result = workload.completedResult();
            report.put("originalRootResult", result.isPresent() ? result.getAsInt() : "unavailable");
            report.put("nativeAndManagerClosed", nativeOwner.isClosed());
            report.put("foreignSurvived", foreign.isAlive());
            report.put("events", events);
            report.put("authenticatedInventories", inventories);
            report.put("orphan", Files.exists(marker) ? Files.readString(marker) : "unobserved");
            report.put("failure", original == null ? "none" : original.toString());
            boolean expectedLoss = mode.equals("loss") && original instanceof IOException &&
                original.getMessage().equals("Injected primary membership observation loss");
            boolean useful = mode.equals("cargo") ? Files.isRegularFile(base.resolve("cargo-target/debug/native_cargo_close")) :
                Files.exists(marker) && (mode.equals("loss") || Files.exists(base.resolve("compiler-output-" + suffix)));
            boolean passed = result.orElse(-1) == (mode.equals("cargo") ? 0 : 17) && foreign.isAlive() && useful &&
                (expectedLoss || original == null);
            report.put("passed", passed);
            Files.writeString(base.resolve("composition-" + suffix + ".json"), scope.getLeaderJsonMapper().writeValueAsString(report));
            runtime.close();
            foreign.destroy();
            foreign.waitFor();
            if (!passed) throw new IOException("Production composition acceptance failed: " + report.get("failure"), original);
            System.out.println("MAC_WORKLOAD_PRODUCTION_COMPOSITION_PASSED " + mode);
        }
    }

    /**
     * Injects primary observation loss while preserving every real native operation and owner.
     * @param owner exact retained production native owner
     * @param marker observed orphan effect used only to trigger the primary-observer failure
     * @param lose whether this invocation injects primary observation loss
     * @param inventories complete independently authenticated fixture observations
     * @param slots completed private-close numbers required unused before release
     */
    private record Observation(MacWorkloadNative.Owner owner, Path marker, boolean lose,
        List<Map<String, Object>> inventories, Map<Long, Integer> slots) implements MacWorkloadNative
    {
        @Override public MacImages.Identity root() throws IOException { return owner.root(); }
        @Override public MacImages.Identity inspect(long pid) throws IOException { return owner.inspect(pid); }
        @Override public void authenticate(MacImages.Identity identity) throws IOException { owner.authenticate(identity); }
        @Override public MacDescriptorProtection.Inventory descriptors(MacImages.Identity identity) throws IOException
        {
            MacDescriptorProtection.Inventory result = owner.descriptors(identity);
            inventories.add(Map.of("operation", "production-admission", "pid", identity.pid(),
                "authority", owner.authority(identity), "rows", result.descriptors(), "queueType", result.kqueueType(),
                "kqueueSyscall", result.kqueueSyscall()));
            Integer unused = slots.get(identity.pid());
            if (unused != null && result.descriptors().stream().anyMatch(row -> row.number() == unused))
                throw new IOException("Fixture private-close slot was reused before application release");
            return result;
        }
        @Override public AllocationHook.Connection connection(long pid)
        {
            AllocationHook.Connection retained = owner.connection(pid);
            return new AllocationHook.Connection()
            {
                @Override public void start(String source) throws IOException { retained.start(source); }
                @Override public Optional<String> pollMessage() throws IOException
                {
                    Optional<String> result = retained.pollMessage();
                    result.ifPresent(frame -> inventories.add(Map.of("operation", "copied-production-frame", "pid", pid,
                        "frame", frame)));
                    return result;
                }
                @Override public void post(tools.jackson.databind.JsonNode message) throws IOException { retained.post(message); }
                @Override public boolean detached() throws IOException { return retained.detached(); }
                @Override public void close() throws IOException { retained.close(); }
            };
        }
        @Override public void resume(long pid) throws IOException { owner.resume(pid); }
        @Override public void releaseRoot() throws IOException { owner.releaseRoot(); }
        @Override public Optional<FridaRuntime.Child> pollChild() throws IOException
        {
            if (lose && Files.exists(marker)) throw new IOException("Injected primary membership observation loss");
            Optional<FridaRuntime.Child> next = owner.pollChild();
            next.ifPresent(child -> slots.remove(child.pid()));
            return next;
        }
        @Override public void cancel() throws IOException { owner.cancel(); }
        @Override public OptionalInt terminalResult() throws IOException { return owner.terminalResult(); }
        @Override public void close() throws IOException { owner.close(); }
    }

    /** Installs an actual native allocation interceptor and an exact-process pre-effect marker. */
    private static final class Hook implements MacImages.Instrumentation
    {
        /** Invocation-scoped JSON serializer. */
        private final DefaultToolingScope scope;
        /** Original manager's resource-free native connection retained before its start. */
        private final AllocationHook.Connection connection;
        /** Separate Script owns the controlled worker through genuine native teardown. */
        private final AllocationHook.Connection workerConnection;
        /** Indicates that the separate worker close opportunity has been consumed. */
        private boolean workerCloseAttempted;
        /** Exact independently authenticated image. */
        private final MacImages.Identity identity;
        /** Method-owned execution observations. */
        private final List<String> events;
        /** Indicates the controlled runtime worker has published its ready message. */
        private boolean workerLive;
        /** Indicates the controlled worker completed native context teardown. */
        private boolean workerStopped;
        /** Indicates the exact connection destruction completed. */
        private boolean closed;
        /** Borrowed original native authority for fixture observations only. */
        private final MacWorkloadNative.Owner nativeOwner;
        /** Complete independently authenticated fixture observations. */
        private final List<Map<String, Object>> inventories;
        /** Completed runtime-close slots required unused until application release. */
        private final Map<Long, Integer> slots;
        /** Fixture-only files read by real application canaries. */
        private final Path reuse;
        /**
         * Retains a resource-free hook owner before any attachment.
         * @param scope invocation services
         * @param manager original retained manager
         * @param nativeOwner independently authenticated original workload owner
         * @param identity authenticated held image
         * @param events independent gate observations
         * @param inventories complete fixture observations
         * @param slots exact completed private-close slots
         * @param reuse fixture-only application input directory
         */
        private Hook(DefaultToolingScope scope, FridaRuntime.Manager manager, MacWorkloadNative.Owner nativeOwner,
            MacImages.Identity identity, List<String> events, List<Map<String, Object>> inventories,
            Map<Long, Integer> slots, Path reuse)
        {
            this.scope = scope;
            this.identity = identity;
            this.events = events;
            this.nativeOwner = nativeOwner;
            this.inventories = inventories;
            this.slots = slots;
            this.reuse = reuse;
            connection = AllocationHook.newNativeConnection(manager, identity.pid());
            workerConnection = AllocationHook.newNativeConnection(manager, identity.pid());
        }
        @Override public void start() throws IOException
        {
            MacDescriptorProtection.Inventory before = inventory("fixture-before-worker");
            String source = "const initialized=Module.findGlobalExportByName('mw_fixture_initialized');" +
                "const entered=Module.findGlobalExportByName('mw_fixture_entered');" +
                "if((initialized!==null && initialized.readS32()===Process.id)||" +
                "(entered!==null && entered.readS32()===Process.id))throw new Error('application already entered');" +
                "send({kind:'application-not-entered',pid:Process.id,initializer:initialized===null?null:initialized.readS32()," +
                "entry:entered===null?null:entered.readS32()});" +
                "const p=Module.findGlobalExportByName('mw_fixture_ready');if(p!==null)p.writeS32(Process.id);" +
                "const m=Module.findGlobalExportByName('malloc');if(m===null)throw new Error('malloc missing');" +
                "let observed=false;Interceptor.attach(m,{onEnter(){if(!observed){observed=true;send('allocation-observed');}}});" +
                "send('fixture-main-ready');";
            connection.start(source);
            String workerSource = "const worker=new Worker('file:///mac-descriptor-bootstrap-worker.js'," +
                "{onMessage(message){if(message!=='fixture-worker-live')throw new Error('worker challenge');" +
                "send('fixture-worker-live');}});";
            workerConnection.start(MacDescriptorProtection.packageScripts(workerSource, "export function run() { send('fixture-worker-live'); }"));
            awaitWorker(false);
            MacDescriptorProtection.Inventory during = inventory("fixture-worker-live");
            workerCloseAttempted = true;
            workerConnection.close();
            workerStopped = true;
            events.add("fixture-worker-stopped:" + identity.pid());
            MacDescriptorProtection.Inventory after = inventory("fixture-worker-stopped");
            var original = new HashSet<>(before.queues());
            var surviving = new HashSet<>(after.queues());
            List<Integer> released = during.queues().stream().filter(number -> !original.contains(number) &&
                !surviving.contains(number) && number > 2).toList();
            if (released.isEmpty()) throw new IOException("Controlled runtime worker did not release a private queue");
            int slot = released.contains(4) ? 4 : released.getFirst();
            Files.writeString(reuse.resolve(Long.toString(identity.pid())), slot + "\n");
            Files.setPosixFilePermissions(reuse.resolve(Long.toString(identity.pid())), PosixFilePermissions.fromString("r--r--r--"));
            slots.put(identity.pid(), slot);
            events.add("private-runtime-close-before-application-reuse:pid=" + identity.pid() + ":fd=" + slot);
            events.add("instrumented-before-release:" + identity.pid());
        }
        /**
         * Collects actual instrumentation receipts without creating native process authority.
         * @throws IOException if callback transport or script execution fails
         */
        private void pump() throws IOException
        {
            if (closed) return;
            pump(connection);
            if (!workerCloseAttempted) pump(workerConnection);
        }
        /**
         * Copies one owned live connection's actual frames into the independent evidence.
         * @param observed exact retained connection
         * @throws IOException if transport or Script execution fails
         */
        private void pump(AllocationHook.Connection observed) throws IOException
        {
            Optional<String> frame;
            while ((frame = observed.pollMessage()).isPresent())
            {
                var message = scope.getLeaderJsonMapper().readTree(frame.orElseThrow());
                if (!message.path("type").asString().equals("send")) throw new IOException("Native hook error: " + frame.orElseThrow());
                var copied = message.path("payload");
                if (copied.isObject())
                {
                    if (!copied.path("kind").asString().equals("application-not-entered") ||
                        copied.path("pid").asLong() != identity.pid()) throw new IOException("Unexpected fixture envelope");
                    events.add(copied.toString());
                    continue;
                }
                String payload = copied.asString();
                events.add(payload + ":" + identity.pid());
                if (payload.equals("fixture-worker-live")) workerLive = true;
                if (payload.equals("fixture-worker-stopped")) workerStopped = true;
            }
        }
        /**
         * Retains a complete independently authenticated fixture-only descriptor observation.
         * @param phase exact controlled worker lifecycle phase
         * @return complete native inventory
         * @throws IOException if authority or completeness is unavailable
         */
        private MacDescriptorProtection.Inventory inventory(String phase) throws IOException
        {
            var value = nativeOwner.descriptors(identity);
            inventories.add(Map.of("operation", phase, "pid", identity.pid(), "authority", nativeOwner.authority(identity),
                "rows", value.descriptors(), "queueType", value.kqueueType()));
            return value;
        }
        /**
         * Waits for the exact actual worker event without substituting a synthetic ready result.
         * @param stopped whether native teardown is required instead of initial readiness
         * @throws IOException if the actual worker cannot reach the bounded state
         */
        private void awaitWorker(boolean stopped) throws IOException
        {
            long began = System.nanoTime();
            while (!(stopped ? workerStopped : workerLive))
            {
                pump();
                if (System.nanoTime() - began >= Duration.ofSeconds(10).toNanos())
                    throw new IOException("Fixture runtime worker deadline");
                try { Thread.sleep(1); }
                catch (InterruptedException failure) { Thread.currentThread().interrupt(); throw new IOException(failure); }
            }
        }
        @Override public boolean detached() throws IOException { return connection.detached(); }
        @Override public void closeDetached() throws IOException { close(); }
        @Override public void close() throws IOException
        {
            IOException failure = null;
            if (!workerCloseAttempted)
            {
                workerCloseAttempted = true;
                try { workerConnection.close(); }
                catch (IOException cause) { failure = cause; }
            }
            try { connection.close(); closed = true; }
            catch (IOException cause)
            {
                if (failure == null) failure = cause;
                else failure.addSuppressed(cause);
            }
            if (failure != null) throw failure;
        }
    }
}
