#!/bin/bash
set -euo pipefail
root=$(cd -- "${0%/*}" && pwd)
: "${JAVA_HOME:?Require pinned JDK27}"
mkdir -p "$root/classes" "$root/tmp" "$root/results"
classpath=$(printf '%s:' "$root"/lib/*.jar)
classpath=${classpath%:}
"$JAVA_HOME/bin/javac" --release 27 -Xlint:all -Werror -Xdoclint:all/private -cp "$classpath" -d "$root/classes" "$root/source/tooling/cli/src/build/java/com/holdmyspot/codexunleashed/distribution/DistributionMain.java" "$root/source/tooling/cli/src/test/java/com/holdmyspot/codexunleashed/distribution/DistributionLauncherTest.java"
"$JAVA_HOME/bin/java" -Djava.io.tmpdir="$root/tmp" -Dbasedir="$root/source/tooling/cli" -cp "$root/classes:$classpath" org.testng.TestNG -testclass com.holdmyspot.codexunleashed.distribution.DistributionLauncherTest -parallel methods -threadcount 8 -d "$root/results"
