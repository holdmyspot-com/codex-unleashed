package com.holdmyspot.codexunleashed.distribution;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.jar.JarOutputStream;
import org.testng.SkipException;
import org.testng.annotations.Test;
import static io.github.cowwoc.requirements13.java.DefaultJavaValidators.requireThat;

/** Verifies actual generated companion launchers with independent, nonnative Java receiver fixtures. */
public final class DistributionLauncherTest
{
	/** Creates independently owned launcher checks. */
	public DistributionLauncherTest()
	{
	}

	/**
	 * Invokes the actual generated companion by its absolute path, preserving exact user arguments.
	 * @throws Exception if fixture assembly or execution fails
	 */
	@Test
	public void absoluteCompanionResolvesBundledJava() throws Exception
	{
		verifyLauncher(true);
	}

	/**
	 * Invokes the actual generated companion through a nested relative path.
	 * @throws Exception if fixture assembly or execution fails
	 */
	@Test
	public void nestedRelativeCompanionResolvesBundledJava() throws Exception
	{
		verifyLauncher(false);
	}

	/**
	 * Stages the production companion in an isolated child JVM; the controlled receiver performs no native work.
	 * @param args modules, runtime and backend fixture paths
	 * @throws Exception if production companion staging fails
	 */
	public static void main(String[] args) throws Exception
	{
		Method stage = DistributionMain.class.getDeclaredMethod("stageBazelCompanion", Path.class, Path.class, Path.class);
		stage.setAccessible(true);
		stage.invoke(null, Path.of(args[0]), Path.of(args[1]), Path.of(args[2]));
	}

	/**
	 * Exercises production staging and shell execution without changing shared platform properties.
	 * @param absolute whether the actual invocation uses an absolute path
	 * @throws Exception if fixture IO or process execution fails
	 */
	private static void verifyLauncher(boolean absolute) throws Exception
	{
		if (!System.getProperty("os.name").equals("Linux"))
			throw new SkipException("Generated POSIX companion requires Linux; no shared platform properties are changed");
		try (Directory directory = new Directory())
		{
			Path root = directory.path;
			Path modules = Files.createDirectory(root.resolve("modules"));
			try (JarOutputStream jar = new JarOutputStream(Files.newOutputStream(modules.resolve("fixture.jar"))))
			{
				jar.finish();
			}
			Path runtime = Files.createDirectories(root.resolve("nested/runtime"));
			Path bin = Files.createDirectory(runtime.resolve("bin"));
			Files.createDirectory(runtime.resolve("lib"));
			Path receiver = bin.resolve("java");
			Files.writeString(receiver, "#!/bin/sh\nset -eu\nprintf '%s\\000' \"$@\" > \"$RECEIVER_OUTPUT\"\n");
			Files.setPosixFilePermissions(receiver, PosixFilePermissions.fromString("rwxr-xr-x"));
			Path received = root.resolve("received-argv");
			Path stageLog = root.resolve("stage.log");
			ProcessBuilder stage = new ProcessBuilder(Path.of(System.getProperty("java.home"), "bin/java").toString(),
				"-Dos.arch=aarch64", "-cp", System.getProperty("java.class.path"), DistributionLauncherTest.class.getName(),
				modules.toString(), runtime.toString(), root.resolve("backend").toString());
			stage.environment().put("RECEIVER_OUTPUT", received.toString());
			stage.redirectErrorStream(true).redirectOutput(stageLog.toFile());
			try (Process child = stage.start())
			{
				requireThat(child.waitFor(), "productionStagingExit").isEqualTo(0);
			}
			Files.delete(received);
			Path launcher = bin.resolve("codex-tooling-bazel");
			String invocation = absolute ? launcher.toString() : root.relativize(launcher).toString();
			List<String> command = new ArrayList<>(List.of(invocation, "arg with spaces", "", "--literal=$value"));
			Path log = root.resolve("launcher.log");
			ProcessBuilder launch = new ProcessBuilder(command).directory(root.toFile());
			launch.environment().put("RECEIVER_OUTPUT", received.toString());
			launch.environment().put("TMPDIR", root.resolve("temp with spaces").toString());
			launch.redirectErrorStream(true).redirectOutput(log.toFile());
			try (Process child = launch.start())
			{
				int exit = child.waitFor();
				if (exit != 0) System.err.println(Files.readString(log));
				requireThat(exit, "generatedLauncherExit").isEqualTo(0);
			}
			List<String> actual = Arrays.asList(new String(Files.readAllBytes(received), StandardCharsets.UTF_8).split("\u0000", -1));
			List<String> expected = List.of("-Djava.io.tmpdir=" + root.resolve("temp with spaces"),
				"-Xlog:all=off:stdout", "-Xlog:all=warning:stderr", "--enable-native-access=ALL-UNNAMED", "-cp",
				bin + "/../lib/bazel-backend/codex-tooling.jar", "com.holdmyspot.codexunleashed.tooling.Main",
				"arg with spaces", "", "--literal=$value", "");
			requireThat(actual, "exactGeneratedLauncherArguments").isEqualTo(expected);
		}
	}

	/** Owns and removes one test's filesystem independently. */
	private static final class Directory implements AutoCloseable
	{
		/** Exclusive absolute fixture root. */
		private final Path path;

		/**
		 * Creates one exclusive fixture.
		 * @throws IOException if the fixture cannot be created
		 */
		private Directory() throws IOException
		{
			path = Files.createTempDirectory("distribution-launcher-").toAbsolutePath();
		}

		/**
		 * Removes only this fixture's paths.
		 * @throws IOException if owned fixture removal fails
		 */
		@Override
		public void close() throws IOException
		{
			try (var files = Files.walk(path))
			{
				for (Path file : files.sorted(Comparator.reverseOrder()).toList())
					Files.delete(file);
			}
		}
	}
}
